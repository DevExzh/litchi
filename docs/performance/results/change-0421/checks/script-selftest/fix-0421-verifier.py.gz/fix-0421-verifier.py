import json,hashlib,subprocess
from pathlib import Path
root=Path('/tmp/fixture-0421')
def digest(v): return hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.load(open(root/'capture.json'))
for item in manifest['runs']:
 jpath=root/item['journal']; j=json.load(open(jpath)); folder=jpath.parent; sel=j['selector']
 out=subprocess.run(['python3','/home/zhuhe/code/litchi/docs/performance/results/change-0421/verify.py','--repo-root','/home/zhuhe/code/litchi','--report',str(folder/'report.json'),'--catalog',str(folder/'catalog.json'),'--selector',sel,'--lane','allocator','--samples','30','--warmups','3'],capture_output=True,text=True)
 print(sel,out.returncode,out.stderr[:200])
 (folder/'verify-stdout.txt').write_text(out.stdout); (folder/'verify-stderr.txt').write_text(out.stderr)
 for n,fn in [('verify_stdout','verify-stdout.txt'),('verify_stderr','verify-stderr.txt')]:
  p=folder/fn;j['artifacts'][n].update(bytes=p.stat().st_size,sha256=sha(p))
 v=json.loads(out.stdout);j['verification'].update(stdout_sha256=sha(folder/'verify-stdout.txt'),stderr_sha256=sha(folder/'verify-stderr.txt'),summary_sha256=digest(v))
 jpath.write_text(json.dumps(j,indent=2,sort_keys=True)+'\n')
 item['journal_sha256']=sha(jpath)
manifest['runs']=manifest['runs']; (root/'capture.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
