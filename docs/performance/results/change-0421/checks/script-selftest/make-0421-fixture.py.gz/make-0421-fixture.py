import json,shutil,hashlib,os
from pathlib import Path
src=Path('/home/zhuhe/code/litchi/docs/performance/results/change-0421')
out=Path('/tmp/fixture-0421')
if out.exists(): shutil.rmtree(out)
out.mkdir()
shutil.copy2(src/'protocol.json',out/'protocol.json')
# source identity must be pair; replay doesn't inspect worktree
source={'worktree':'/tmp/no-source','revision':'7c7561160bf1e8e93feb739a60e4bf8d36f28906','git_status_porcelain':'','clean':True}
# build binary record based on existing report identity
sample=json.load(open('/home/zhuhe/code/litchi/docs/performance/results/change-0419/runs/allocator/A1/pptx_cross_copy_plain_lifecycle/report.json'))
bid=sample['binary_identity']; sha=bid['binary_sha256']; n=bid['binary_bytes']
build={'change':421,'role':'candidate','status':'pass','exit_code':0,'protocol_sha256':hashlib.sha256((out/'protocol.json').read_bytes()).hexdigest(),'source_before':source,'source_after':source,'source_after':source,'binaries':{'allocator':{'path':'/tmp/no-binary','sha256':sha,'binary_sha256':sha,'bytes':n,'binary_bytes':n}}}
(out/'build-candidate.json').write_text(json.dumps(build,indent=2)+'\n')
def digest(v): return hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def write(p,v): p.parent.mkdir(parents=True,exist_ok=True); p.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
rows=[]
for repeat in ('R1','R2'):
 for selector in ('pptx_cross_copy_media_rich_lifecycle','pptx_cross_copy_plain_lifecycle'):
  sourcefile=Path('/home/zhuhe/code/litchi/docs/performance/results/change-0419/runs/allocator/A1')/selector/'report.json'
  report=json.load(open(sourcefile)); report['tool']['allocator_counter_revision']='post_update_peak_v2'; report['binary_identity']['path']='/tmp/no-binary';
  # Ensure env revision
  report['environment']['git_revision']=source['revision']; report['environment']['git_worktree_dirty']=False
  folder=out/'runs'/repeat/selector; folder.mkdir(parents=True)
  (folder/'report.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
  catalog_path=Path('/home/zhuhe/code/litchi/docs/performance/results/change-0419/runs/allocator/A1')/selector/'catalog.json'
  shutil.copy2(catalog_path,folder/'catalog.json')
  (folder/'time-v.txt').write_text('Maximum resident set size (kbytes): 1234\nExit status: 0\n')
  (folder/'stdout.txt').write_text(''); (folder/'stderr.txt').write_text('')
  rsha=hashlib.sha256((folder/'report.json').read_bytes()).hexdigest()
  verification={'change':421,'claim_authorized':False,'performance_claim':None,'selector':selector,'lane':'allocator','samples':30,'warmups':3,'report_count':1,'reports':[{'report_sha256':rsha}]}
  (folder/'verify-stdout.txt').write_text(json.dumps(verification,sort_keys=True)+'\n'); (folder/'verify-stderr.txt').write_text('')
  arts={}
  for name,allow in [('report',False),('catalog',False),('time_v',False),('stdout',True),('stderr',True),('verify_stdout',False),('verify_stderr',True)]:
   p=folder+('/'+name.replace('_','-')+'.txt') if False else None
   fn={'report':'report.json','catalog':'catalog.json','time_v':'time-v.txt','stdout':'stdout.txt','stderr':'stderr.txt','verify_stdout':'verify-stdout.txt','verify_stderr':'verify-stderr.txt'}[name]
   p=folder/fn
   arts[name]={'path':str(p.relative_to(out)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'allow_empty':allow}
  journal={'schema_version':1,'change':421,'status':'pass','repeat':repeat,'selector':selector,'index':len(rows)+1,'fresh_process':True,'cpu':2,'source_before':source,'source_after':source,'source_identity_sha256':digest(source),'source_revision':source['revision'],'source_worktree':source['worktree'],'build':{'path':'build-candidate.json','sha256':hashlib.sha256((out/'build-candidate.json').read_bytes()).hexdigest()},'build_sha256':hashlib.sha256((out/'build-candidate.json').read_bytes()).hexdigest(),'binary':{'path':'/tmp/no-binary','sha256':sha,'bytes':n},'binary_before':{'sha256':sha,'bytes':n},'binary_after':{'sha256':sha,'bytes':n},'binary_sha256':sha,'binary_bytes':n,'protocol':{'path':'protocol.json','sha256':hashlib.sha256((out/'protocol.json').read_bytes()).hexdigest()},'protocol_sha256':hashlib.sha256((out/'protocol.json').read_bytes()).hexdigest(),'common_flags':json.load(open(out/'protocol.json'))['common_flags'],'contract':{'lane':'allocator','samples':30,'warmups':3},'argv':['taskset','-c','2','/usr/bin/time','-v','-o',str(folder/'time-v.txt'),'/tmp/no-binary','--case',selector,*json.load(open(out/'protocol.json'))['common_flags'],'--samples','30','--warmup','3','--json',str(folder/'report.json'),'--corpus-manifest',str(folder/'catalog.json')],'verify_argv':['python','verify.py','--repo-root','/tmp/repo','--report',str(folder/'report.json'),'--catalog',str(folder/'catalog.json'),'--selector',selector,'--lane','allocator','--samples','30','--warmups','3'],'artifacts':arts,'started_utc':'x','exit_code':0,'finished_utc':'x','verification':{'status':'pass','exit_code':0,'stdout_sha256':arts['verify_stdout']['sha256'],'stderr_sha256':arts['verify_stderr']['sha256'],'summary_sha256':digest(verification)}}
  write(folder/'journal.json',journal); rows.append({'repeat':repeat,'selector':selector,'journal':str((folder/'journal.json').relative_to(out)),'journal_sha256':hashlib.sha256((folder/'journal.json').read_bytes()).hexdigest(),'status':'pass'})
manifest={'schema_version':1,'change':421,'status':'pass','performance_claim':None,'claim_authorized':False,'protocol':{'path':'protocol.json','sha256':hashlib.sha256((out/'protocol.json').read_bytes()).hexdigest()},'build':{'path':'build-candidate.json','sha256':hashlib.sha256((out/'build-candidate.json').read_bytes()).hexdigest()},'binary':{'sha256':sha,'bytes':n},'source':{'revision':source['revision'],'identity_sha256':digest(source)},'cpu':2,'selectors':['pptx_cross_copy_media_rich_lifecycle','pptx_cross_copy_plain_lifecycle'],'repeats':['R1','R2'],'samples':30,'warmups':3,'common_flags':json.load(open(out/'protocol.json'))['common_flags'],'verifier':{'path':'/tmp/verifier','sha256':'0'*64},'runs':rows,'expected_run_count':4}
write(out/'capture.json',manifest)
print(out)
