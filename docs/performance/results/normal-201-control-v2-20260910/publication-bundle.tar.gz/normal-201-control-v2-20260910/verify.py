#!/usr/bin/env python3
"""Portable verifier for the normal-201 control publication.

The verifier authenticates sealed report/catalog bytes and derived metadata. It
never runs a benchmark. --binary is optional and checks only an external
release binary's recorded bytes.
"""
from __future__ import annotations

import argparse
import difflib
import gzip
import hashlib
import json
import math
import os
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Any

EXPECTED_KEYS = "f0fd76293959e72211e06e51b0a2b41f371423fda34c55144077193d262b1670"
EXPECTED_COMMIT = "995bdaf09352297bde17e6ed7d986360f8c10134"
EXPECTED_TREE = "7f02507971d036c174273bff0ad643c8338d6227"
EXPECTED_BINARY_SHA = "12c814245830fcd37adc31d049f19537de1399bfcb25854b3a0d6d44ae5ebb0d"
EXPECTED_BINARY_BYTES = 58873640
EXPECTED_RUNNER_SHA = "ae30040b74cec106683ef2b775a7cf629c5dcd98e7f3e70457c5d1d491505295"
EXPECTED_ANALYZER_SHA = "d1079d65a777efc866bd3249c306eb70f86683f58475918e269b655fd7cbbbdb"
EXPECTED_V1_CORRECTED_ANALYZER_SHA = "2147d1871f71106ce73ab9cf31777f6c54a2b060f460fae842da3ef85132d952"
EXPECTED_V2_CORRECTED_ANALYZER_SHA = "2556c64f5f5141e676382b7f34e57c5c7e2b9a2895ce18620ddd7de685521850"
EXPECTED_CORRECTED_ANALYZER_SHA = EXPECTED_V2_CORRECTED_ANALYZER_SHA
EXPECTED_LOCK_SHA = "3509994602d90b8f57f636b4728c5987b367a57b4c260077c151cc11ebfdfce8"


def fail(message: str) -> None:
    raise SystemExit(message)


def sha_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha(path: Path) -> str:
    return sha_bytes(path.read_bytes())


def read_json(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text())
    except Exception as exc:
        fail(f"cannot read JSON {path}: {exc}")
    if not isinstance(value, dict):
        fail(f"{path}: expected JSON object")
    return value


def read_gzip_json(path: Path) -> tuple[bytes, dict[str, Any]]:
    try:
        raw = gzip.decompress(path.read_bytes())
        value = json.loads(raw)
    except Exception as exc:
        fail(f"cannot read gzip JSON {path}: {exc}")
    if not isinstance(value, dict):
        fail(f"{path}: expected JSON object")
    return raw, value


def canonical_result_keys(report: dict[str, Any]) -> list[tuple[str, bytes]]:
    values = []
    for row in report.get("results", []):
        corpus = row.get("corpus")
        if not isinstance(corpus, dict):
            fail("report row has no corpus object")
        values.append((str(row.get("case")), json.dumps(corpus, sort_keys=True, separators=(",", ":")).encode()))
    return sorted(values)


def result_keys_digest(report: dict[str, Any]) -> str:
    digest = hashlib.sha256()
    for case, corpus in canonical_result_keys(report):
        digest.update(case.encode())
        digest.update(b"\0")
        digest.update(corpus)
        digest.update(b"\n")
    return digest.hexdigest()


def parse_time(path: Path) -> dict[str, float | int]:
    text = path.read_text()
    elapsed = re.search(r"^\s*Elapsed \(wall clock\) time(?: \([^)]*\))?:\s*(.+)$", text, re.MULTILINE)
    rss = re.search(r"^\s*Maximum resident set size \(kbytes\):\s*(\d+)\s*$", text, re.MULTILINE)
    status = re.search(r"^\s*Exit status:\s*(-?\d+)\s*$", text, re.MULTILINE)
    if elapsed is None or rss is None or status is None:
        fail(f"{path}: incomplete GNU time envelope")
    value = elapsed.group(1).strip()
    parts = value.split(":")
    if len(parts) == 3:
        wall = int(parts[0]) * 3600 + int(parts[1]) * 60 + float(parts[2])
    elif len(parts) == 2:
        wall = int(parts[0]) * 60 + float(parts[1])
    else:
        wall = float(value)
    return {
        "wall_clock_seconds": wall,
        "maximum_resident_set_size_kib": int(rss.group(1)),
        "exit_status": int(status.group(1)),
    }



def harness_percentiles(samples: list[int]) -> dict[str, int]:
    ordered = sorted(samples)
    left = ordered[(len(ordered) - 1) // 2]
    right = ordered[len(ordered) // 2]
    midpoint = left // 2 + right // 2 + ((left % 2 + right % 2) // 2)

    def nearest_rank(percentile: int) -> int:
        index = (percentile * len(ordered) + 99) // 100 - 1
        return ordered[min(index, len(ordered) - 1)]

    return {"p50": midpoint, "p95": nearest_rank(95), "p99": nearest_rank(99)}


def validate_elapsed_row(row: dict[str, Any], location: str) -> dict[str, int]:
    elapsed = row.get("elapsed_ns")
    if not isinstance(elapsed, dict) or elapsed.get("unit") != "ns":
        fail(f"{location}: elapsed_ns unit/object mismatch")
    samples = elapsed.get("samples")
    if not isinstance(samples, list) or len(samples) != 15:
        fail(f"{location}: expected exactly 15 elapsed samples")
    if any(type(value) is not int or value <= 0 or value > 2**64 - 1 for value in samples):
        fail(f"{location}: elapsed samples must be finite positive u64 integers")
    if samples != sorted(samples):
        fail(f"{location}: elapsed samples are not harness-sorted")
    sample_order = elapsed.get("sample_order")
    if not isinstance(sample_order, list) or sorted(sample_order) != list(range(15)):
        fail(f"{location}: sample_order is not a permutation of 0..14")
    expected = harness_percentiles(samples)
    for name, value in expected.items():
        if elapsed.get(name) != value:
            fail(f"{location}: {name}={elapsed.get(name)!r} != harness value {value}")
    if elapsed.get("min") != samples[0] or elapsed.get("max") != samples[-1]:
        fail(f"{location}: min/max do not match retained samples")
    for name in ("mean", "standard_deviation"):
        value = elapsed.get(name)
        if not isinstance(value, (int, float)) or isinstance(value, bool) or not math.isfinite(float(value)) or float(value) < 0:
            fail(f"{location}: {name} is not finite and nonnegative")
    interval = elapsed.get("confidence_interval_95")
    if not isinstance(interval, dict):
        fail(f"{location}: missing confidence interval")
    for name in ("lower", "upper"):
        value = interval.get(name)
        if not isinstance(value, (int, float)) or isinstance(value, bool) or not math.isfinite(float(value)) or float(value) < 0:
            fail(f"{location}: confidence interval {name} is not finite and nonnegative")
    return expected


def normalize_analyzer_paths(value: Any, replacements: dict[str, str], execution_root: str) -> Any:
    if isinstance(value, dict):
        return {key: normalize_analyzer_paths(item, replacements, execution_root) for key, item in value.items()}
    if isinstance(value, list):
        return [normalize_analyzer_paths(item, replacements, execution_root) for item in value]
    if isinstance(value, str):
        if value in replacements:
            return replacements[value]
        if execution_root in value:
            fail(f"fresh analyzer emitted an unrecognized temporary path: {value}")
    return value


def run_fresh_analyzer(root: Path, manifest: dict[str, Any], repeat_names: list[str]) -> dict[str, Any]:
    analyzer = root / "scripts/derive-normal-repeat-corrected-v2.py"
    with tempfile.TemporaryDirectory(prefix="litchi-normal-201-analyzer-verify-") as temp_name:
        execution = Path(temp_name)
        for repeat in repeat_names:
            run_dir = execution / repeat
            run_dir.mkdir()
            report_raw, _ = read_gzip_json(root / f"raw/control/{repeat}/report.json.gz")
            catalog_raw, _ = read_gzip_json(root / f"raw/control/{repeat}/catalog.json.gz")
            (run_dir / "report.json").write_bytes(report_raw)
            (run_dir / "catalog.json").write_bytes(catalog_raw)
            shutil.copyfile(root / f"raw/control/{repeat}/time-v.txt", run_dir / "time-v.txt")
            shutil.copyfile(root / f"raw/control/{repeat}/run-meta.txt", run_dir / "run-meta.txt")
        output = execution / "derived-control-absolute.json"
        command = [sys.executable, str(analyzer), "--run-dir", str(execution), "--role", "control", "--output", str(output)]
        environment = os.environ.copy()
        environment.update({"PYTHONDONTWRITEBYTECODE": "1", "LC_ALL": "C"})
        completed = subprocess.run(command, cwd=root, env=environment, text=True, capture_output=True)
        if completed.returncode != 0:
            fail(f"fresh corrected analyzer failed: {completed.stdout}\n{completed.stderr}")
        try:
            absolute = json.loads(output.read_text())
        except Exception as exc:
            fail(f"fresh corrected analyzer output is invalid JSON: {exc}")
        replacements = {
            str(execution / repeat / "report.json"): f"raw/control/{repeat}/report.json"
            for repeat in repeat_names
        }
        normalized = normalize_analyzer_paths(absolute, replacements, str(execution))
        normalized_raw = (json.dumps(normalized, indent=2, sort_keys=True) + "\n").encode()
        published_raw, published = read_gzip_json(root / "derived/control-corrected.json.gz")
        if published_raw != normalized_raw:
            fail("published derived output is not the fresh corrected analyzer output after explicit path normalization")
        if sha_bytes(published_raw) != manifest.get("derived_uncompressed_sha256"):
            fail("freshly derived output hash does not match the publication manifest")
        if any(item.get("report_key_digest") != EXPECTED_KEYS for item in normalized.get("invocations", [])):
            fail("fresh corrected analyzer emitted a noncanonical invocation-key digest")
        return {
            "executed": True,
            "binary_check": "none",
            "stdout": completed.stdout,
            "stderr": completed.stderr,
            "normalized_output_sha256": sha_bytes(normalized_raw),
            "result_count": published.get("result_count"),
            "repeat_count": published.get("repeat_count"),
        }


def check_analyzer_execution_evidence(root: Path, manifest: dict[str, Any]) -> None:
    receipt_path = root / "provenance/analyzer-execution-receipt.json"
    receipt = read_json(receipt_path)
    if receipt.get("status") != "completed" or receipt.get("raw_inputs_unchanged") is not True:
        fail("analyzer execution receipt does not prove a completed unchanged-input run")
    evidence = manifest.get("analyzer_execution", {})
    if sha(receipt_path) != evidence.get("receipt_sha256"):
        fail("analyzer execution receipt hash mismatch")
    if receipt.get("analyzer_sha256") != EXPECTED_V2_CORRECTED_ANALYZER_SHA:
        fail("analyzer execution used an unexpected corrected analyzer")
    absolute_path = root / "derived/control-analyzer-absolute.json.gz"
    if sha(absolute_path) != evidence.get("absolute_output_gzip_sha256"):
        fail("absolute analyzer output evidence hash mismatch")
    if receipt.get("absolute_output_gzip", {}).get("gzip_sha256") != evidence.get("absolute_output_gzip_sha256"):
        fail("analyzer receipt absolute output binding mismatch")
    if receipt.get("normalized_output", {}).get("uncompressed_sha256") != manifest.get("derived_uncompressed_sha256"):
        fail("analyzer receipt normalized output binding mismatch")
    if len(receipt.get("path_normalization", {}).get("replacements", {})) != 3:
        fail("analyzer receipt does not record the three explicit report path replacements")


def check_artifact_receipt(root: Path) -> list[str]:
    receipt = root / "artifact-files.sha256"
    if not receipt.is_file():
        fail("missing artifact-files.sha256")
    expected: dict[str, str] = {}
    for line in receipt.read_text().splitlines():
        if not line.strip() or line.startswith("#"):
            continue
        try:
            digest, rel = line.split("  ", 1)
        except ValueError:
            fail(f"malformed artifact receipt line: {line!r}")
        if len(digest) != 64 or Path(rel).is_absolute() or ".." in Path(rel).parts:
            fail(f"unsafe artifact receipt path: {line!r}")
        expected[rel] = digest
    actual_files = []
    for path in root.rglob("*"):
        rel = path.relative_to(root).as_posix()
        if path.is_symlink():
            fail(f"symlink is not allowed in publication: {rel}")
        if path.is_file() and rel != "artifact-files.sha256":
            actual_files.append(rel)
    if set(actual_files) != set(expected):
        fail(f"artifact set mismatch; missing={sorted(set(expected) - set(actual_files))}, extra={sorted(set(actual_files) - set(expected))}")
    for rel, digest in expected.items():
        actual = sha(root / rel)
        if actual != digest:
            fail(f"artifact hash mismatch: {rel}: {actual} != {digest}")
        if "target" in Path(rel).parts or Path(rel).name == "litchi-perf-baseline":
            fail(f"large build artifact unexpectedly embedded: {rel}")
    return sorted(expected)


def check_analyzer_correction(root: Path, manifest: dict[str, Any]) -> None:
    original_path = root / "scripts/derive-normal-repeat.py"
    v1_path = root / "scripts/derive-normal-repeat-corrected-v1.py"
    v2_path = root / "scripts/derive-normal-repeat-corrected-v2.py"
    v1_diff_path = root / "provenance/analyzer-correction.diff"
    v2_diff_path = root / "provenance/analyzer-correction-v1-to-v2.diff"
    original = original_path.read_text().splitlines(keepends=True)
    v1 = v1_path.read_text().splitlines(keepends=True)
    v2 = v2_path.read_text().splitlines(keepends=True)
    if sha(original_path) != EXPECTED_ANALYZER_SHA:
        fail("original analyzer hash mismatch")
    if sha(v1_path) != EXPECTED_V1_CORRECTED_ANALYZER_SHA:
        fail("v1 corrected analyzer hash mismatch")
    if sha(v2_path) != EXPECTED_V2_CORRECTED_ANALYZER_SHA:
        fail("v2 corrected analyzer hash mismatch")
    if sha(v1_diff_path) != manifest["analyzer_correction_diff_sha256"]:
        fail("v1 analyzer correction diff hash mismatch")
    if sha(v2_diff_path) != manifest["analyzer_correction_v1_to_v2_diff_sha256"]:
        fail("v1-to-v2 analyzer correction diff hash mismatch")

    original_to_v1 = [opcode for opcode in difflib.SequenceMatcher(None, original, v1).get_opcodes() if opcode[0] != "equal"]
    if len(original_to_v1) != 1 or original_to_v1[0][0] != "replace" or original_to_v1[0][2] - original_to_v1[0][1] != 1 or original_to_v1[0][4] - original_to_v1[0][3] != 1:
        fail(f"v1 analyzer correction is not exactly one line: {original_to_v1}")
    if r"Elapsed \(wall clock\) time(?: \([^)]*\))?" not in v1_path.read_text():
        fail("v1 corrected analyzer does not contain the expected elapsed-label fix")

    v1_to_v2 = [opcode for opcode in difflib.SequenceMatcher(None, v1, v2).get_opcodes() if opcode[0] != "equal"]
    if len(v1_to_v2) != 1 or v1_to_v2[0][0] != "replace" or v1_to_v2[0][2] - v1_to_v2[0][1] != 1 or v1_to_v2[0][4] - v1_to_v2[0][3] != 1:
        fail(f"v1-to-v2 analyzer correction is not exactly one line: {v1_to_v2}")
    old_line = v1[v1_to_v2[0][1]].strip()
    new_line = v2[v1_to_v2[0][3]].strip()
    if old_line != "framed.append(0)" or new_line != "framed.append(10)":
        fail(f"v1-to-v2 framing correction mismatch: {old_line!r} -> {new_line!r}")
    if "framed.append(10)" not in v2_path.read_text():
        fail("v2 corrected analyzer does not contain LF final framing")

    defect_receipt = read_json(root / "provenance/analyzer-defect-receipt.json")
    if defect_receipt.get("correction_count") != 2 or defect_receipt.get("v2_corrected_analyzer_sha256") != EXPECTED_V2_CORRECTED_ANALYZER_SHA:
        fail("analyzer defect receipt does not record both corrections")
    if defect_receipt.get("v1_history_receipt") != "provenance/analyzer-defect-receipt-v1.json":
        fail("analyzer v1 history receipt binding is missing")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--binary", type=Path)
    args = parser.parse_args()
    root = args.root.resolve()
    manifest = read_json(root / "publication-manifest.json")
    recorded_verifier_sha = manifest.get("verifier_sha256")
    if recorded_verifier_sha and recorded_verifier_sha != sha(root / "verify.py"):
        fail("verifier hash mismatch")
    members = check_artifact_receipt(root)
    if manifest.get("result_keys_sha256") != EXPECTED_KEYS:
        fail("manifest result-key digest mismatch")
    if manifest.get("result_key_digest_framing") != "sorted case UTF-8 + NUL + compact canonical corpus JSON + LF":
        fail("manifest result-key framing mismatch")
    if manifest.get("measured_source_commit") != EXPECTED_COMMIT or manifest.get("measured_source_tree") != EXPECTED_TREE:
        fail("manifest measured source mismatch")
    if not manifest.get("measured_source_is_not_latest"):
        fail("manifest does not label measured source as historical")
    workload = manifest.get("workload", {})
    if workload.get("repeats") != 3 or workload.get("result_count_per_repeat") != 201 or workload.get("corpora_count") != 31:
        fail("manifest workload dimensions mismatch")
    if workload.get("fresh_process_per_repeat") is not True or workload.get("abba") is not False or workload.get("paired_optimization_comparison") is not False:
        fail("manifest process/comparison scope mismatch")
    binary = manifest.get("binary", {})
    if binary.get("embedded") is not False or binary.get("sha256") != EXPECTED_BINARY_SHA or binary.get("bytes") != EXPECTED_BINARY_BYTES:
        fail("manifest binary identity mismatch")
    if manifest.get("lock", {}).get("sha256") != EXPECTED_LOCK_SHA:
        fail("manifest lock identity mismatch")
    runner = manifest.get("runner", {})
    if runner.get("original_sha256") != EXPECTED_RUNNER_SHA:
        fail("manifest runner identity mismatch")
    if manifest.get("corrected_analyzer_sha256") != EXPECTED_V2_CORRECTED_ANALYZER_SHA:
        fail("manifest corrected analyzer identity mismatch")
    if runner.get("v1_corrected_analyzer_sha256") != EXPECTED_V1_CORRECTED_ANALYZER_SHA or runner.get("v2_corrected_analyzer_sha256") != EXPECTED_V2_CORRECTED_ANALYZER_SHA:
        fail("manifest corrected analyzer lineage mismatch")
    if manifest.get("v1_corrected_analyzer_sha256") != EXPECTED_V1_CORRECTED_ANALYZER_SHA or manifest.get("v2_corrected_analyzer_sha256") != EXPECTED_V2_CORRECTED_ANALYZER_SHA:
        fail("manifest corrected analyzer hashes mismatch")
    if sha(root / "provenance/analyzer-defect-receipt.json") != manifest.get("analyzer_defect_receipt_sha256"):
        fail("analyzer defect receipt hash mismatch")
    check_analyzer_correction(root, manifest)

    repeat_names = ["repeat-01", "repeat-02", "repeat-03"]
    seen_keys: list[tuple[str, str]] | None = None
    repeat_summaries = []
    for repeat_name in repeat_names:
        entry = next((item for item in manifest["repeats"] if item.get("name") == repeat_name), None)
        if entry is None:
            fail(f"manifest missing {repeat_name}")
        report_path = root / entry["report_path"]
        catalog_path = root / entry["catalog_path"]
        time_path = root / entry["time_path"]
        raw_report, report = read_gzip_json(report_path)
        raw_catalog, catalog = read_gzip_json(catalog_path)
        if sha(report_path) != entry["report_gzip_sha256"] or sha_bytes(raw_report) != entry["report_sha256"]:
            fail(f"{repeat_name}: report hash mismatch")
        if sha(catalog_path) != entry["catalog_gzip_sha256"] or sha_bytes(raw_catalog) != entry["catalog_sha256"]:
            fail(f"{repeat_name}: catalog hash mismatch")
        if report.get("tool", {}).get("binary") != "litchi-perf-baseline" or report.get("tool", {}).get("instrumentation") != "none":
            fail(f"{repeat_name}: tool identity mismatch")
        if report.get("configuration", {}).get("samples_per_case") != 15 or report.get("configuration", {}).get("warmup_iterations_per_case") != 3:
            fail(f"{repeat_name}: sample configuration mismatch")
        if len(report.get("results", [])) != 201 or len(catalog.get("corpora", [])) != 31 or len(catalog.get("case_bindings", [])) != 201:
            fail(f"{repeat_name}: row/catalog dimensions mismatch")
        row_percentiles = {}
        for row_index, row in enumerate(report["results"]):
            row_key = (str(row.get("case")), str(row.get("corpus", {}).get("name")))
            row_percentiles[row_key] = validate_elapsed_row(row, f"{repeat_name}/row-{row_index}")
        env = report.get("environment", {})
        if env.get("git_revision") != EXPECTED_COMMIT or env.get("git_worktree_dirty") is not False or env.get("cpu_affinity") != "0-7":
            fail(f"{repeat_name}: source/affinity identity mismatch")
        digest = result_keys_digest(report)
        if digest != EXPECTED_KEYS or entry.get("result_keys_sha256") != EXPECTED_KEYS:
            fail(f"{repeat_name}: result-key digest mismatch")
        keys = [(case, corpus.decode()) for case, corpus in canonical_result_keys(report)]
        if seen_keys is None:
            seen_keys = keys
        elif keys != seen_keys:
            fail(f"{repeat_name}: result-key set differs")
        time_values = parse_time(time_path)
        for key in ("wall_clock_seconds", "maximum_resident_set_size_kib", "exit_status"):
            if time_values[key] != entry["time"][key]:
                fail(f"{repeat_name}: time value mismatch for {key}")
        if time_values["exit_status"] != 0:
            fail(f"{repeat_name}: nonzero exit status")
        stats = read_json(root / f"derived/{repeat_name}-stats.json")
        if stats.get("report_sha256") != entry["report_sha256"] or stats.get("catalog_sha256") != entry["catalog_sha256"]:
            fail(f"{repeat_name}: derived stats input binding mismatch")
        if stats.get("result_count") != 201 or stats.get("corpora_count") != 31 or stats.get("result_keys_sha256") != EXPECTED_KEYS:
            fail(f"{repeat_name}: derived stats dimensions mismatch")
        expected_rows = sorted((key[0], key[1], row_percentiles[key]) for key in row_percentiles)
        actual_rows = sorted((row["case"], row["corpus"], {"p50": row["p50_ns"], "p95": row["p95_ns"], "p99": row["p99_ns"]}) for row in stats.get("rows", []))
        if len(actual_rows) != 201 or any(a[0] != e[0] or a[1] != e[1] or a[2] != e[2] for a, e in zip(actual_rows, expected_rows)):
            fail(f"{repeat_name}: per-repeat percentile stats mismatch")
        repeat_summaries.append({**entry["time"], "repeat": repeat_name, "report_sha256": entry["report_sha256"], "catalog_sha256": entry["catalog_sha256"]})

    derived_path = root / "derived/control-corrected.json.gz"
    raw_derived, derived = read_gzip_json(derived_path)
    if sha_bytes(raw_derived) != manifest.get("derived_uncompressed_sha256"):
        fail("derived uncompressed hash mismatch")
    if sha(derived_path) != manifest.get("derived_gzip_sha256"):
        fail("derived gzip hash mismatch")
    if derived.get("result_count") != 201 or derived.get("repeat_count") != 3:
        fail("derived dimensions mismatch")
    if derived.get("throughput", {}).get("status") != "unavailable" or derived.get("throughput", {}).get("rows_with_execution_logical_bytes") != 0:
        fail("derived throughput boundary mismatch")
    if derived.get("cache_semantics", {}).get("physical_eviction_claim") is not False:
        fail("derived cache boundary mismatch")
    if len(derived.get("rss", {}).get("samples", [])) != 3 or len(derived.get("rows", [])) != 201:
        fail("derived statistics incomplete")
    check_analyzer_execution_evidence(root, manifest)
    fresh_analyzer = run_fresh_analyzer(root, manifest, repeat_names)

    binary_status = "skipped"
    if args.binary is not None:
        if not args.binary.is_file() or args.binary.is_symlink():
            fail(f"external binary is not a regular file: {args.binary}")
        if args.binary.stat().st_size != EXPECTED_BINARY_BYTES or sha(args.binary) != EXPECTED_BINARY_SHA:
            fail("external binary identity mismatch")
        binary_status = "verified"
    result = {
        "status": "passed",
        "artifact_file_count": len(members),
        "measured_source_commit": EXPECTED_COMMIT,
        "publication_base_commit": manifest.get("publication_base_commit"),
        "result_keys_sha256": EXPECTED_KEYS,
        "repeat_summaries": repeat_summaries,
        "binary_check": binary_status,
        "timed_workload_executed_by_verifier": False,
        "fresh_corrected_analyzer_executed": fresh_analyzer["executed"],
        "fresh_corrected_analyzer_normalized_output_sha256": fresh_analyzer["normalized_output_sha256"],
        "large_binary_embedded": False,
    }
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    sys.exit(main())
