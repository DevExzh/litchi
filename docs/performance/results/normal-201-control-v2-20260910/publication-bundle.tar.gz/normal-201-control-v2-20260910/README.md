# Normal 201-row control publication v2

This bundle publishes one completed normal, uninstrumented control capture. The
publication candidate is based on feature commit
`fdd2b80dfa9efc246a5983a3fec64de25e5c4f63`, while the timed workload was
measured from clean detached source commit
`995bdaf09352297bde17e6ed7d986360f8c10134` (tree
`7f02507971d036c174273bff0ad643c8338d6227`). The measured source is historical
and is not the current/latest publication HEAD.

The capture has three fresh process repeats of the full 201-row matrix, with 31
corpora, 15 samples, and three warmups per row, on CPUs `0-7`. It is a single
control baseline. It is not an ABBA run and is not a paired optimization
comparison. The raw reports and catalogs are gzip-compressed for transport;
`verify.py` authenticates their uncompressed bytes.

The expected canonical result-key digest is
`f0fd76293959e72211e06e51b0a2b41f371423fda34c55144077193d262b1670`. Its
framing is sorted case UTF-8, a NUL separator, compact canonical corpus JSON,
and an LF final frame. The binary is intentionally not embedded; its external
SHA-256, size, and build recipe are recorded. Run the integrity verifier from
this directory:

```sh
PYTHONDONTWRITEBYTECODE=1 python3 verify.py
PYTHONDONTWRITEBYTECODE=1 python3 verify.py --binary /path/to/litchi-perf-baseline
```

The verifier recomputes every retained 15-sample row percentile using the
harness rules and executes the corrected analyzer in a temporary directory. It
normalizes only the three expected report paths (including their RSS sample
references), then compares the complete fresh derived JSON with the sealed
output. The optional binary argument only verifies the recorded external bytes;
the verifier never runs a workload.

The original frozen runner and analyzer remain unchanged. Two separately hashed
analyzer corrections are retained. Version 1 fixes the GNU time elapsed-label
regular expression, which otherwise rejects the emitted
`(h:mm:ss or m:ss)` annotation. Version 2 fixes the canonical result-key digest
final frame from NUL to LF. The original analyzer, v1 analyzer, v2 analyzer,
the v1 diff, the v1-to-v2 one-line diff, and both defect receipts are included;
raw capture bytes, runner, and binary are unchanged. The v2 analyzer execution
receipt binds the fresh absolute output and the normalized publication output.

The default matrix emitted zero filesystem rows. `warm` and `cold-requested`
are harness selectors, not evidence of physical cache eviction or cold I/O.
Aggregate payload throughput is unavailable because no row exposes a common
`execution.logical_bytes` denominator. RSS is GNU time whole-process maximum
resident set size, not operation-scoped RSS. The host was shared.
