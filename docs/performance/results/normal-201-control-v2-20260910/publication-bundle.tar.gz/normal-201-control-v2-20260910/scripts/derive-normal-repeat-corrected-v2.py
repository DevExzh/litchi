#!/usr/bin/env python3
"""Derive reviewable statistics from repeated normal 201-row reports.

This consumes completed raw reports and GNU time -v envelopes. It never runs
benchmark code. Whole-report rows/second is retained as a harness progress rate;
there is deliberately no aggregate payload-throughput claim for the heterogeneous
201-row matrix unless a row explicitly exposes execution.logical_bytes.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import statistics
from pathlib import Path
from typing import Any

EXPECTED_ROWS = 201
EXPECTED_BINARY = "litchi-perf-baseline"
EXPECTED_INSTRUMENTATION = "none"


def fail(message: str) -> None:
    raise SystemExit(message)


def read_json(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text())
    except Exception as exc:  # pragma: no cover - command-line diagnostics
        fail(f"cannot read JSON {path}: {exc}")
    if not isinstance(value, dict):
        fail(f"{path} is not a JSON object")
    return value


def canonical(value: Any) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":")).encode()


def digest_keys(report: dict[str, Any]) -> str:
    framed = bytearray()
    keys = []
    for result in report["results"]:
        corpus = result.get("corpus")
        if not isinstance(corpus, dict):
            fail("result has no corpus object")
        key = (str(result["case"]), canonical(corpus))
        keys.append(key)
    keys.sort()
    for case, corpus in keys:
        framed.extend(case.encode())
        framed.append(0)
        framed.extend(corpus)
        framed.append(10)
    return hashlib.sha256(framed).hexdigest()


def parse_wall_seconds(value: str) -> float:
    value = value.strip()
    parts = value.split(":")
    try:
        if len(parts) == 3:
            hours, minutes, seconds = parts
            return int(hours) * 3600 + int(minutes) * 60 + float(seconds)
        if len(parts) == 2:
            minutes, seconds = parts
            return int(minutes) * 60 + float(seconds)
        return float(value)
    except ValueError as exc:
        fail(f"cannot parse GNU time elapsed value {value!r}: {exc}")


def parse_time(path: Path) -> dict[str, Any]:
    text = path.read_text()
    elapsed = re.search(r"^\s*Elapsed \(wall clock\) time(?: \([^)]*\))?:\s*(.+)$", text, re.MULTILINE)
    rss = re.search(r"^\s*Maximum resident set size \(kbytes\):\s*(\d+)\s*$", text, re.MULTILINE)
    status = re.search(r"^\s*Exit status:\s*(-?\d+)\s*$", text, re.MULTILINE)
    if elapsed is None or rss is None or status is None:
        fail(f"GNU time envelope is incomplete: {path}")
    wall_seconds = parse_wall_seconds(elapsed.group(1))
    exit_status = int(status.group(1))
    if exit_status != 0:
        fail(f"timed command failed according to {path}: status {exit_status}")
    return {
        "wall_clock_seconds": wall_seconds,
        "maximum_resident_set_size_kib": int(rss.group(1)),
        "exit_status": exit_status,
        "rss_scope": "GNU time -v whole process invocation maximum resident set size; not operation RSS",
    }


def percentile_value(result: dict[str, Any], name: str) -> float:
    elapsed = result.get("elapsed_ns")
    if not isinstance(elapsed, dict) or not isinstance(elapsed.get(name), (int, float)):
        fail(f"result has no elapsed_ns.{name}")
    return elapsed[name]


def row_key(result: dict[str, Any]) -> tuple[str, str]:
    corpus = result.get("corpus")
    if not isinstance(corpus, dict) or not isinstance(corpus.get("name"), str):
        fail("result corpus has no name")
    return str(result.get("case")), corpus["name"]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-dir", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--role", default="control")
    args = parser.parse_args()

    run_dirs = sorted(p for p in args.run_dir.glob("repeat-*") if p.is_dir())
    if not run_dirs:
        fail(f"no repeat directories under {args.run_dir}")

    reports: list[dict[str, Any]] = []
    invocation_rows: list[dict[str, Any]] = []
    expected_keys: set[tuple[str, str]] | None = None
    expected_corpus_by_key: dict[tuple[str, str], dict[str, Any]] = {}
    expected_binary_hash: str | None = None
    expected_source: tuple[str, str] | None = None

    for repeat_dir in run_dirs:
        report_path = repeat_dir / "report.json"
        time_path = repeat_dir / "time-v.txt"
        report = read_json(report_path)
        if report.get("tool", {}).get("binary") != EXPECTED_BINARY:
            fail(f"{report_path}: normal binary identity mismatch")
        if report.get("tool", {}).get("instrumentation") != EXPECTED_INSTRUMENTATION:
            fail(f"{report_path}: report is not uninstrumented")
        config = report.get("configuration")
        if not isinstance(config, dict):
            fail(f"{report_path}: missing configuration")
        if config.get("samples_per_case") != 15 or config.get("warmup_iterations_per_case") != 3:
            fail(f"{report_path}: expected 15 samples and 3 warmups")
        results = report.get("results")
        if not isinstance(results, list) or len(results) != EXPECTED_ROWS:
            fail(f"{report_path}: expected {EXPECTED_ROWS} results")
        binary_hash = report.get("binary_identity", {}).get("binary_sha256")
        if not isinstance(binary_hash, str):
            fail(f"{report_path}: missing binary hash")
        if expected_binary_hash is None:
            expected_binary_hash = binary_hash
        elif expected_binary_hash != binary_hash:
            fail(f"{report_path}: binary hash differs between repeats")
        source = (
            str(report.get("environment", {}).get("git_revision")),
            str(report.get("environment", {}).get("git_worktree_dirty")),
        )
        if expected_source is None:
            expected_source = source
        elif expected_source != source:
            fail(f"{report_path}: source identity differs between repeats")

        keys = {row_key(result) for result in results}
        if expected_keys is None:
            expected_keys = keys
        elif expected_keys != keys:
            fail(f"{report_path}: case/corpus identity set differs between repeats")
        for result in results:
            key = row_key(result)
            corpus = result["corpus"]
            previous = expected_corpus_by_key.setdefault(key, corpus)
            if previous != corpus:
                fail(f"{report_path}: corpus descriptor changed for {key}")
        time_summary = parse_time(time_path)
        time_summary.update(
            {
                "repeat": repeat_dir.name,
                "report": str(report_path),
                "report_sha256": hashlib.sha256(report_path.read_bytes()).hexdigest(),
                "catalog_sha256": hashlib.sha256((repeat_dir / "catalog.json").read_bytes()).hexdigest(),
                "binary_sha256": binary_hash,
                "result_count": len(results),
                "report_key_digest": digest_keys(report),
                "report_rows_per_wall_second": len(results) / time_summary["wall_clock_seconds"]
                if time_summary["wall_clock_seconds"] > 0
                else None,
            }
        )
        invocation_rows.append(time_summary)
        reports.append(report)

    if expected_keys is None or len(expected_keys) != EXPECTED_ROWS:
        fail("repeat reports did not establish 201 unique case/corpus rows")

    row_summaries = []
    throughput_rows = 0
    for key in sorted(expected_keys):
        values = []
        logical_bytes: set[int] = set()
        for report in reports:
            result = next(row for row in report["results"] if row_key(row) == key)
            entry: dict[str, Any] = {
                "repeat_p50_ns": percentile_value(result, "p50"),
                "repeat_p95_ns": percentile_value(result, "p95"),
                "repeat_p99_ns": percentile_value(result, "p99"),
            }
            execution = result.get("execution")
            if isinstance(execution, dict) and isinstance(execution.get("logical_bytes"), int):
                logical_bytes.add(execution["logical_bytes"])
                entry["logical_bytes"] = execution["logical_bytes"]
                throughput_rows += 1
                for percentile in ("p50", "p95", "p99"):
                    elapsed = entry[f"repeat_{percentile}_ns"]
                    entry[f"logical_bytes_per_second_{percentile}"] = (
                        execution["logical_bytes"] * 1_000_000_000 / elapsed if elapsed > 0 else None
                    )
            values.append(entry)
        if len(logical_bytes) > 1:
            fail(f"logical byte work changed between repeats for {key}")
        aggregate: dict[str, Any] = {
            "case": key[0],
            "corpus": key[1],
            "repeat_values": values,
            "median_of_repeat_p50_ns": statistics.median(v["repeat_p50_ns"] for v in values),
            "median_of_repeat_p95_ns": statistics.median(v["repeat_p95_ns"] for v in values),
            "median_of_repeat_p99_ns": statistics.median(v["repeat_p99_ns"] for v in values),
        }
        if logical_bytes:
            aggregate["logical_bytes"] = next(iter(logical_bytes))
            for percentile in ("p50", "p95", "p99"):
                values_for_rate = [v[f"logical_bytes_per_second_{percentile}"] for v in values]
                aggregate[f"median_logical_bytes_per_second_{percentile}"] = statistics.median(values_for_rate)
        row_summaries.append(aggregate)

    first = reports[0]
    configuration = first["configuration"]
    cache_states = configuration.get("filesystem_cache_states")
    filesystem_rows = sum(1 for report in reports for row in report["results"] if row.get("cache_state") is not None)
    derived = {
        "schema": "litchi-normal-201-repeated-derived-v1",
        "role": args.role,
        "result_count": EXPECTED_ROWS,
        "repeat_count": len(reports),
        "source": {
            "git_revision": expected_source[0] if expected_source else None,
            "git_worktree_dirty": expected_source[1] if expected_source else None,
            "binary_sha256": expected_binary_hash,
        },
        "configuration": {
            "samples_per_case": 15,
            "warmup_iterations_per_case": 3,
            "filesystem_cache_states": cache_states,
            "filesystem_root_selected": configuration.get("filesystem_root_selected"),
            "filesystem_fresh_child_per_sample": configuration.get("filesystem_fresh_child_per_sample"),
            "filesystem_process_isolated": configuration.get("filesystem_process_isolated"),
        },
        "cache_semantics": {
            "requested_states": cache_states,
            "physical_eviction_claim": False,
            "filesystem_rows_in_default_matrix": filesystem_rows,
            "statement": "warm/cold-requested are harness selectors; cold-requested does not prove physical cache eviction",
        },
        "throughput": {
            "status": "available_for_explicit_execution_logical_bytes_rows" if throughput_rows else "unavailable",
            "rows_with_execution_logical_bytes": throughput_rows,
            "aggregate_claim": False,
            "statement": "the heterogeneous default 201-row matrix has no common payload-throughput denominator; rows/second is retained only as a whole-report harness progress rate",
        },
        "rss": {
            "source": "GNU time -v",
            "scope": "whole process invocation maximum resident set size in KiB",
            "operation_scoped_claim": False,
            "samples": invocation_rows,
        },
        "invocations": invocation_rows,
        "rows": row_summaries,
    }
    args.output.write_text(json.dumps(derived, indent=2, sort_keys=True) + "\n")
    print(f"validated {len(reports)} repeats with {EXPECTED_ROWS} rows each")
    print(f"throughput_rows={throughput_rows}")
    print(f"wrote {args.output}")


if __name__ == "__main__":
    main()
