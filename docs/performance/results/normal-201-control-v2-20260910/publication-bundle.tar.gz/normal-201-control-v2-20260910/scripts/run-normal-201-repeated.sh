#!/usr/bin/env bash
set -Eeuo pipefail

# Preparation artifact: timing is deliberately gated.  Root enables it only
# after reserving the requested CPU set and recording the host-contention
# receipt.
if [[ "${RUN_CAPTURE_AFTER_REVIEW:-0}" != 1 ]]; then
  echo 'capture deferred: set RUN_CAPTURE_AFTER_REVIEW=1 after the CPU reservation clears'
  exit 0
fi

OUT=${OUT:-/var/tmp/litchi-normal-201-baseline-v1-20260910}
SOURCE=${SOURCE:-$OUT/source-worktree}
BIN=${BIN:-$OUT/target/release/litchi-perf-baseline}
ANALYZER=${ANALYZER:-$OUT/derive-normal-repeat.py}
CPU_SET=${CPU_SET:-0-7}
REPEATS=${REPEATS:-3}
SAMPLES=15
WARMUP=3
CACHE_SELECTION=warm,cold-requested
ROLE=${ROLE:-control}
RESERVATION_RECEIPT=${RESERVATION_RECEIPT:?RESERVATION_RECEIPT is required}
EXPECTED_COMMIT=${EXPECTED_COMMIT:-995bdaf09352297bde17e6ed7d986360f8c10134}
EXPECTED_TREE=${EXPECTED_TREE:-7f02507971d036c174273bff0ad643c8338d6227}
EXPECTED_BINARY_SHA256=${EXPECTED_BINARY_SHA256:-12c814245830fcd37adc31d049f19537de1399bfcb25854b3a0d6d44ae5ebb0d}

if ! [[ "$REPEATS" =~ ^[1-9][0-9]*$ ]] || (( REPEATS > 12 )); then
  echo 'REPEATS must be an integer from 1 through 12' >&2
  exit 2
fi
[[ -x "$BIN" ]] || { echo "missing normal binary: $BIN" >&2; exit 2; }
[[ -x "$ANALYZER" ]] || { echo "missing derived analyzer: $ANALYZER" >&2; exit 2; }
[[ -r "$RESERVATION_RECEIPT" ]] || { echo "missing reservation receipt: $RESERVATION_RECEIPT" >&2; exit 2; }
if [[ "$RESERVATION_RECEIPT" == *.json ]]; then
  python3 - "$RESERVATION_RECEIPT" "$CPU_SET" <<'PY'
import json, sys
from pathlib import Path
value = json.loads(Path(sys.argv[1]).read_text())
if value.get("status") not in {"reserved", "granted"}:
    raise SystemExit("reservation JSON is not reserved/granted")
if str(value.get("scaling_cpu_set", value.get("cpu_set", ""))) != sys.argv[2]:
    raise SystemExit("reservation JSON CPU set mismatch")
PY
else
  rg -q '^status=(reserved|granted)$' "$RESERVATION_RECEIPT" || { echo 'invalid reservation status' >&2; exit 2; }
  rg -q "^scaling_cpu_set=$CPU_SET$" "$RESERVATION_RECEIPT" || { echo 'reservation CPU set mismatch' >&2; exit 2; }
fi
[[ "$(git -C "$SOURCE" rev-parse HEAD)" == "$EXPECTED_COMMIT" ]] || { echo 'source commit mismatch' >&2; exit 2; }
[[ "$(git -C "$SOURCE" rev-parse HEAD^{tree})" == "$EXPECTED_TREE" ]] || { echo 'source tree mismatch' >&2; exit 2; }
[[ -z "$(git -C "$SOURCE" status --porcelain)" ]] || { echo 'source worktree is dirty' >&2; exit 2; }
[[ "$(sha256sum "$BIN" | cut -d' ' -f1)" == "$EXPECTED_BINARY_SHA256" ]] || { echo 'binary hash mismatch' >&2; exit 2; }

RUN_ROOT="$OUT/runs/$ROLE"
mkdir -p "$RUN_ROOT" "$OUT/contention/$ROLE" "$OUT/commands/$ROLE"
: > "$OUT/commands/$ROLE/commands.log"
sha256sum "$RESERVATION_RECEIPT" > "$OUT/commands/$ROLE/reservation.sha256"
{
  printf 'schema=normal-201-repeated-run-v1\n'
  printf 'role=%s\n' "$ROLE"
  printf 'started_utc='; date -u '+%Y-%m-%dT%H:%M:%SZ'
  printf 'source_worktree=%s\n' "$SOURCE"
  printf 'source_commit=%s\n' "$EXPECTED_COMMIT"
  printf 'source_tree=%s\n' "$EXPECTED_TREE"
  printf 'source_status=%q\n' "$(git -C "$SOURCE" status --porcelain)"
  printf 'binary=%s\n' "$BIN"
  printf 'binary_sha256=%s\n' "$EXPECTED_BINARY_SHA256"
  printf 'runner=%s\n' "$0"
  printf 'runner_sha256='; sha256sum "$0" | cut -d' ' -f1
  printf 'analyzer=%s\n' "$ANALYZER"
  printf 'analyzer_sha256='; sha256sum "$ANALYZER" | cut -d' ' -f1
  printf 'reservation_receipt=%s\n' "$RESERVATION_RECEIPT"
  printf 'reservation_sha256='; sha256sum "$RESERVATION_RECEIPT" | cut -d' ' -f1
  printf 'cpu_set=%s\nrepeats=%s\nsamples=%s\nwarmup=%s\n' "$CPU_SET" "$REPEATS" "$SAMPLES" "$WARMUP"
  printf 'filesystem_cache_selection=%s\n' "$CACHE_SELECTION"
  printf 'filesystem_root_selected=false\n'
  printf 'physical_cache_eviction_claim=false\n'
  printf 'rss_scope=GNU time -v whole process invocation maximum resident set size; not operation RSS\n'
  printf 'throughput_scope=explicit execution.logical_bytes rows only; no aggregate default-matrix payload throughput claim\n'
  printf 'fresh_process_per_repeat=true\n'
  printf 'shared_host_idle_claim=false\n'
} > "$OUT/commands/$ROLE/run-provenance.txt"

snapshot() {
  local label=$1
  taskset -c "$CPU_SET" env -i HOME=/home/zhuhe PATH=/home/zhuhe/.cargo/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin LC_ALL=C \
    bash -c '
      {
        printf "captured_utc="; date -u "+%Y-%m-%dT%H:%M:%SZ"
        printf "label=%s\\n" "$1"
        printf "taskset="; taskset -pc $$ 2>&1
        printf "loadavg="; cat /proc/loadavg
        printf "cpus_allowed_list="; sed -n "s/^Cpus_allowed_list:[[:space:]]*//p" /proc/self/status
        printf "online_cpus="; cat /sys/devices/system/cpu/online
        printf "cgroup_cpu.max="; cat /sys/fs/cgroup/cpu.max 2>/dev/null || printf "unavailable\\n"
        printf "processes\\n"
        ps -eo pid,ppid,psr,pcpu,pmem,stat,comm,args --sort=-pcpu | head -80 || true
      } > "$2"
    ' bash "$label" "$OUT/contention/$ROLE/$label.txt"
}

for ((index=1; index<=REPEATS; index++)); do
  repeat=$(printf 'repeat-%02d' "$index")
  repeat_dir="$RUN_ROOT/$repeat"
  mkdir -p "$repeat_dir"
  report="$repeat_dir/report.json"
  catalog="$repeat_dir/catalog.json"
  time_file="$repeat_dir/time-v.txt"
  log_file="$repeat_dir/stdout.log"
  snapshot "${repeat}-before"
  command=(taskset -c "$CPU_SET" /usr/bin/time -v -o "$time_file" env -i
    HOME=/home/zhuhe PATH=/home/zhuhe/.cargo/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/bin
    RUSTFLAGS= LC_ALL=C TMPDIR=/var/tmp
    "$BIN" --warmup "$WARMUP" --samples "$SAMPLES"
    --filesystem-cache "$CACHE_SELECTION" --json "$report" --corpus-manifest "$catalog")
  printf '%q ' "${command[@]}" >> "$OUT/commands/$ROLE/commands.log"
  printf '\n' >> "$OUT/commands/$ROLE/commands.log"
  {
    printf 'repeat=%s\n' "$repeat"
    printf 'started_utc='; date -u '+%Y-%m-%dT%H:%M:%SZ'
    printf 'fresh_process=true\n'
  } > "$repeat_dir/run-meta.txt"
  (
    cd "$SOURCE"
    "${command[@]}"
  ) > "$log_file" 2>&1
  {
    printf 'finished_utc='; date -u '+%Y-%m-%dT%H:%M:%SZ'
  } >> "$repeat_dir/run-meta.txt"
  snapshot "${repeat}-after"
done

PYTHONDONTWRITEBYTECODE=1 python3 "$ANALYZER" --run-dir "$RUN_ROOT" --role "$ROLE" --output "$OUT/derived-$ROLE.json"
printf 'completed_utc=%s\n' "$(date -u '+%Y-%m-%dT%H:%M:%SZ')" > "$OUT/commands/$ROLE/completion.txt"
