#!/usr/bin/env python3
"""Verify the paired current-head scaling publication without rebuilding it."""
from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
HASH_RECEIPT = ROOT / "artifact-files.sha256"
EXPECTED_SOURCE = "cf98bee37455e8e6d0e73002ff2e94299ef546cb"
EXPECTED_TREE = "46c3a5c1c10c0178a4e31db4bf2f2d838ef2beab"
EXPECTED_BINARY = "727c6e718cf5d64aeb40edaadb2fa3e5c70b005d8c1e827bb296c12341a398b7"
EXPECTED_BINARY_BYTES = 58_696_912
EXPECTED_VALIDATOR = "7b96b797bda8e441fa462e386238c1e676f5ad96fc2c73e59002a1b61de0df3e"
EXPECTED_FIRST_SCRIPT = "b3265a00695bfa4bda2703ba5450d450f3010102addd01606e37d5834db8b42c"
EXPECTED_SCRIPT_DIFF = "01b1c56ff6eeaf740a808a122bfbea37dfe22e9ec110e502e157d41295373413"
EXPECTED_PAIRED_SCRIPT = "deb6cae81d709f8603a62da5ab53d95dfa3f05a312f8235dcc8f47a77f752aed"


def fail(message: str) -> None:
    raise SystemExit(f"verification failed: {message}")


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_json(path: Path) -> dict:
    try:
        value = json.loads(path.read_text())
    except (OSError, ValueError) as exc:
        fail(f"cannot read JSON {path.relative_to(ROOT)}: {exc}")
    if not isinstance(value, dict):
        fail(f"JSON root is not an object: {path.relative_to(ROOT)}")
    return value


def read_key_values(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    for line in path.read_text().splitlines():
        if "=" in line:
            key, value = line.split("=", 1)
            values[key] = value
    return values


def parse_hash_receipt() -> dict[str, str]:
    if not HASH_RECEIPT.is_file():
        fail("artifact-files.sha256 is missing")
    entries: dict[str, str] = {}
    for number, line in enumerate(HASH_RECEIPT.read_text().splitlines(), 1):
        if not line.strip():
            continue
        pieces = line.split(None, 1)
        if len(pieces) != 2 or len(pieces[0]) != 64:
            fail(f"malformed artifact hash receipt line {number}")
        digest, name = pieces[0], pieces[1].strip()
        if not name or name in entries:
            fail(f"duplicate or empty artifact hash path on line {number}")
        entries[name] = digest
    return entries


def verify_hash_receipt(entries: dict[str, str]) -> None:
    actual = {
        path.relative_to(ROOT).as_posix()
        for path in ROOT.rglob("*")
        if path.is_file() and path.relative_to(ROOT).as_posix() != HASH_RECEIPT.name
    }
    listed = set(entries)
    if actual != listed:
        fail(f"artifact file set differs: missing={sorted(actual - listed)} extra={sorted(listed - actual)}")
    for name, expected in sorted(entries.items()):
        observed = sha256_file(ROOT / name)
        if observed != expected:
            fail(f"artifact SHA-256 mismatch for {name}: {observed} != {expected}")


def read_gzip(path: Path) -> bytes:
    try:
        with gzip.open(path, "rb") as stream:
            return stream.read()
    except OSError as exc:
        fail(f"cannot decompress {path.relative_to(ROOT)}: {exc}")


def verify_gzip_against(path: Path, expected_bytes: int, expected_sha: str, label: str) -> bytes:
    data = read_gzip(path)
    observed = sha256_bytes(data)
    if len(data) != expected_bytes or observed != expected_sha:
        fail(f"{label} identity mismatch: {len(data)}/{observed}")
    return data


def verify_first_capture() -> tuple[dict, dict[str, bytes]]:
    capture = read_json(ROOT / "raw/first/provenance/capture-complete.json")
    if capture.get("source_commit") != EXPECTED_SOURCE or capture.get("source_tree") != EXPECTED_TREE:
        fail("first capture source identity mismatch")
    if capture.get("validator_status") != "passed" or capture.get("timed_lanes_terminal") is not True:
        fail("first capture is not terminal and validated")
    reports: dict[str, bytes] = {}
    for entry in capture.get("reports", []):
        source_path = Path(entry["path"])
        stored = ROOT / "raw/first" / source_path.parent / f"{source_path.name}.gz"
        data = verify_gzip_against(stored, entry["bytes"], entry["sha256"], f"first {entry['path']}")
        try:
            json.loads(data)
        except ValueError as exc:
            fail(f"first report is not JSON: {entry['path']}: {exc}")
        reports[source_path.name] = data
    if len(reports) != 6:
        fail(f"expected six first reports, got {len(reports)}")
    for path in sorted((ROOT / "raw/first/manifests").glob("*.json.gz")):
        json.loads(read_gzip(path))
    if (ROOT / "raw/first/provenance/scaling-analysis.json").read_bytes() != (ROOT / "validation/recomputed-first-scaling-analysis.json").read_bytes():
        fail("first scaling analysis differs from validator recomputation")
    if "validated 4 scaling reports and 2 range reports" not in (ROOT / "validation/first-validator-run.txt").read_text():
        fail("first validator receipt does not show a pass")
    return capture, reports


def paired_member_storage(member_path: str) -> tuple[Path | None, bool]:
    path = Path(member_path)
    if member_path == "litchi-perf-baseline":
        return None, False
    if member_path.startswith("reports/") and path.suffix == ".json":
        return ROOT / "raw/paired/reports" / f"{path.name}.gz", True
    if member_path.startswith("reports/"):
        return ROOT / "raw/paired/logs" / f"{path.name}.gz", True
    if member_path.startswith("manifests/"):
        return ROOT / "raw/paired/manifests" / f"{path.name}.gz", True
    if member_path.startswith("contention/"):
        return ROOT / "raw/paired/host" / f"{path.name}.gz", True
    if member_path in {"run-environment.txt", "pre-run-process-snapshot.txt", "post-run-process-snapshot.txt"}:
        return ROOT / "raw/paired/host" / f"{path.name}.gz", True
    if member_path in {"executed-paired-scaling.sh", "run-paired-scaling.sh", "validate-paired-scaling.py"}:
        return ROOT / "provenance/scripts" / path.name, False
    if member_path == "validate_reports.py":
        return ROOT / "provenance/scripts/validate_reports.py", False
    return ROOT / "raw/paired/provenance" / path.name, False


def verify_paired_capture() -> tuple[dict, dict[str, bytes]]:
    manifest = read_json(ROOT / "raw/paired/provenance/paired-member-manifest.json")
    if manifest.get("source_commit") != EXPECTED_SOURCE or manifest.get("source_tree") != EXPECTED_TREE:
        fail("paired capture source identity mismatch")
    if manifest.get("validator_status") != "passed" or manifest.get("same_logical_tasks_and_bytes_across_workers") is not True:
        fail("paired capture validation/equal-work receipt is not passing")
    reports: dict[str, bytes] = {}
    members = manifest.get("members")
    if not isinstance(members, list):
        fail("paired member manifest has no members")
    for member in members:
        member_path = member["path"]
        stored, compressed = paired_member_storage(member_path)
        if stored is None:
            continue
        if not stored.is_file():
            fail(f"paired member is missing: {member_path} -> {stored.relative_to(ROOT)}")
        data = read_gzip(stored) if compressed else stored.read_bytes()
        if len(data) != member["bytes"] or sha256_bytes(data) != member["sha256"]:
            fail(f"paired member identity mismatch: {member_path}")
        if member_path.startswith("reports/") and member_path.endswith(".json"):
            json.loads(data)
            reports[Path(member_path).name] = data
    if len(reports) != 4:
        fail(f"expected four paired reports, got {len(reports)}")
    if (ROOT / "raw/paired/provenance/paired-scaling-analysis.json").read_bytes() != (ROOT / "validation/recomputed-paired-scaling-analysis.json").read_bytes():
        fail("paired scaling analysis differs from validator recomputation")
    if "validated 4 paired scaling reports" not in (ROOT / "validation/paired-validator-run.txt").read_text():
        fail("paired validator receipt does not show a pass")
    return manifest, reports


def verify_source_and_scripts(publication: dict, first_capture: dict, paired_manifest: dict) -> None:
    if publication.get("measured_source", {}).get("commit") != EXPECTED_SOURCE or publication.get("measured_source", {}).get("tree") != EXPECTED_TREE:
        fail("publication measured source identity changed")
    if publication.get("publication_source", {}).get("commit") == EXPECTED_SOURCE:
        fail("publication source is incorrectly presented as measured source")
    source = read_json(ROOT / "provenance/capture-plan/source-identity.json")["source"]
    if source.get("commit") != EXPECTED_SOURCE or source.get("tree") != EXPECTED_TREE:
        fail("plan source identity mismatch")
    first_script = ROOT / "provenance/scripts/capture.sh.executed-recovered-b3265a00.sh"
    if sha256_file(first_script) != EXPECTED_FIRST_SCRIPT or first_script.stat().st_size != 8795:
        fail("recovered first executed script identity mismatch")
    diff = ROOT / "provenance/scripts/executed-capture-script.diff"
    if sha256_file(diff) != EXPECTED_SCRIPT_DIFF:
        fail("first script recovery diff identity mismatch")
    recovery = read_json(ROOT / "provenance/scripts/executed-script-recovery.json")
    if recovery.get("status") != "exact_bytes_recovered" or recovery.get("recovered_sha256") != EXPECTED_FIRST_SCRIPT or recovery.get("diff_sha256") != EXPECTED_SCRIPT_DIFF:
        fail("script recovery receipt is not exact")
    plan_manifest = read_json(ROOT / "raw/first/provenance/plan-artifact-manifest.json")
    capture_members = {entry["path"]: entry for entry in plan_manifest.get("members", [])}
    if capture_members.get("capture.sh", {}).get("sha256") != EXPECTED_FIRST_SCRIPT or capture_members.get("capture.sh", {}).get("bytes") != 8795:
        fail("plan manifest does not bind the recovered first script")
    if sha256_file(ROOT / "provenance/scripts/executed-paired-scaling.sh") != EXPECTED_PAIRED_SCRIPT:
        fail("paired runner identity mismatch")
    before = (ROOT / "raw/paired/provenance/input-hashes.before.txt").read_bytes()
    after = (ROOT / "raw/paired/provenance/input-hashes.after.txt").read_bytes()
    if before != after or EXPECTED_BINARY not in before.decode() or EXPECTED_VALIDATOR not in before.decode():
        fail("paired input hash receipt changed or lacks binary/validator binding")
    if paired_manifest.get("binary_sha256") != EXPECTED_BINARY:
        fail("paired member manifest binary identity mismatch")
    if first_capture.get("source_commit") != EXPECTED_SOURCE or paired_manifest.get("source_commit") != EXPECTED_SOURCE:
        fail("capture source commit mismatch")


def run_fresh_validator(command: list[str], label: str) -> str:
    environment = os.environ.copy()
    environment["PYTHONDONTWRITEBYTECODE"] = "1"
    result = subprocess.run(command, env=environment, capture_output=True, text=True)
    if result.returncode != 0:
        detail = (result.stderr or result.stdout)[-2000:]
        fail(f"fresh {label} validator failed ({result.returncode}): {detail}")
    return result.stdout


def verify_fresh_validators(first_reports: dict[str, bytes], paired_reports: dict[str, bytes]) -> None:
    """Extract the sealed reports and execute the bundled validators afresh."""
    with tempfile.TemporaryDirectory(prefix="litchi-scaling-publication-") as directory:
        temporary = Path(directory)
        first = temporary / "first"
        paired = temporary / "paired"
        first.mkdir()
        paired.mkdir()
        for name, data in first_reports.items():
            (first / name).write_bytes(data)
        for name, data in paired_reports.items():
            (paired / name).write_bytes(data)

        first_output = first / "scaling-analysis.json"
        first_stdout = run_fresh_validator(
            [
                sys.executable,
                str(ROOT / "provenance/capture-plan/validate_reports.py"),
                "--scaling",
                str(first / "scaling-w1.json"),
                str(first / "scaling-w2.json"),
                str(first / "scaling-w4.json"),
                str(first / "scaling-w8.json"),
                "--range",
                str(first / "range-opc.json"),
                str(first / "range-xlsx.json"),
                "--output",
                str(first_output),
            ],
            "first scaling/range",
        )
        if "validated 4 scaling reports and 2 range reports" not in first_stdout:
            fail("fresh first validator did not report six validated reports")
        if first_output.read_bytes() != (ROOT / "raw/first/provenance/scaling-analysis.json").read_bytes():
            fail("fresh first validator output differs from retained scaling analysis")

        # The paired validator resolves validate_reports.py beside its own file.
        paired_validator = paired / "validate-paired-scaling.py"
        shutil.copy2(ROOT / "provenance/scripts/validate-paired-scaling.py", paired_validator)
        shutil.copy2(ROOT / "provenance/scripts/validate_reports.py", paired / "validate_reports.py")
        paired_output = paired / "paired-scaling-analysis.json"
        paired_stdout = run_fresh_validator(
            [
                sys.executable,
                str(paired_validator),
                "--scaling",
                str(paired / "scaling-w1.json"),
                str(paired / "scaling-w2.json"),
                str(paired / "scaling-w4.json"),
                str(paired / "scaling-w8.json"),
                "--output",
                str(paired_output),
            ],
            "paired scaling",
        )
        if "validated 4 paired scaling reports" not in paired_stdout:
            fail("fresh paired validator did not report four validated reports")
        if paired_output.read_bytes() != (ROOT / "raw/paired/provenance/paired-scaling-analysis.json").read_bytes():
            fail("fresh paired validator output differs from retained paired analysis")


def scaling_rows(reports: dict[str, bytes], label: str) -> tuple[dict, set[str], set[str]]:
    rows: dict[tuple[str, str, int], dict] = {}
    binary_hashes: set[str] = set()
    source_commits: set[str] = set()
    for width in (1, 2, 4, 8):
        name = f"scaling-w{width}.json"
        if name not in reports:
            fail(f"{label} report is missing {name}")
        report = json.loads(reports[name])
        binary_hashes.add(report["binary_identity"]["binary_sha256"])
        source_commits.add(report["environment"]["git_revision"])
        for result in report.get("results", []):
            corpus = result.get("corpus")
            if not isinstance(corpus, dict) or not isinstance(corpus.get("name"), str):
                fail(f"{label} {name} has no corpus name")
            execution = result.get("execution")
            elapsed = result.get("elapsed_ns")
            if not isinstance(execution, dict) or not isinstance(elapsed, dict):
                fail(f"{label} {name} lacks execution/elapsed fields")
            key = (result["case"], corpus["name"], width)
            if key in rows:
                fail(f"duplicate {label} row: {key}")
            rows[key] = {
                "p50_ns": elapsed["p50"],
                "logical_bytes": execution["logical_bytes"],
                "logical_tasks": execution["logical_tasks"],
            }
    if len(rows) != 16:
        fail(f"{label} report vectors contain {len(rows)} rows instead of 16")
    return rows, binary_hashes, source_commits


def verify_comparison(first_reports: dict[str, bytes], paired_reports: dict[str, bytes]) -> None:
    """Compare freshly parsed report vectors, then bind the result to the receipt."""
    first_rows, first_binary_hashes, first_source_commits = scaling_rows(first_reports, "first")
    paired_rows, paired_binary_hashes, paired_source_commits = scaling_rows(paired_reports, "paired")
    if first_binary_hashes != {EXPECTED_BINARY} or paired_binary_hashes != {EXPECTED_BINARY}:
        fail("report-derived binary identities do not match the expected binary")
    if first_source_commits != {EXPECTED_SOURCE} or paired_source_commits != {EXPECTED_SOURCE}:
        fail("report-derived source commits do not match the measured source")
    if set(first_rows) != set(paired_rows):
        fail("first and paired report vectors have different row keys")

    rows = []
    same_work_vectors = True
    for case, corpus, workers in sorted(first_rows):
        first = first_rows[(case, corpus, workers)]
        paired = paired_rows[(case, corpus, workers)]
        if (first["logical_tasks"], first["logical_bytes"]) != (paired["logical_tasks"], paired["logical_bytes"]):
            same_work_vectors = False
        rows.append(
            {
                "case": case,
                "corpus": corpus,
                "first_p50_ns": first["p50_ns"],
                "logical_bytes": first["logical_bytes"],
                "logical_tasks": first["logical_tasks"],
                "paired_minus_first_ns": paired["p50_ns"] - first["p50_ns"],
                "paired_over_first": paired["p50_ns"] / first["p50_ns"],
                "paired_p50_ns": paired["p50_ns"],
                "workers": workers,
            }
        )
    if not same_work_vectors:
        fail("fresh first/paired report vectors disagree on logical work")
    actual_comparison = {
        "first_binary_sha256": next(iter(first_binary_hashes)),
        "first_capture": "/var/tmp/litchi-current-head-scaling-capture-v2-live-20260910",
        "paired_binary_sha256": next(iter(paired_binary_hashes)),
        "paired_capture": "/var/tmp/litchi-current-head-scaling-paired-v2-20260910",
        "row_count": len(rows),
        "rows": rows,
        "same_work_vectors": same_work_vectors,
        "schema": "litchi-current-head-scaling-paired-comparison-v1",
        "source_commit": next(iter(first_source_commits)),
        "source_tree": EXPECTED_TREE,
    }
    stored_comparison = read_json(ROOT / "raw/paired/provenance/paired-comparison.json")
    if actual_comparison != stored_comparison:
        fail("fresh report-derived comparison differs from retained paired-comparison.json")

    first_catalogs = {p.name: read_gzip(p) for p in (ROOT / "raw/first/manifests").glob("*.json.gz")}
    paired_catalogs = {p.name: read_gzip(p) for p in (ROOT / "raw/paired/manifests").glob("*.json.gz")}
    if set(first_catalogs) != {f"scaling-w{i}.catalog.json.gz" for i in (1, 2, 4, 8)} | {"range-opc.catalog.json.gz", "range-xlsx.catalog.json.gz"}:
        fail("first catalog set is incomplete")
    for name in ("scaling-w1.catalog.json.gz", "scaling-w2.catalog.json.gz", "scaling-w4.catalog.json.gz", "scaling-w8.catalog.json.gz"):
        if paired_catalogs.get(name) != first_catalogs.get(name):
            fail(f"first/paired catalog differs: {name}")

def verify_binary_if_supplied(path: Path | None) -> bool:
    identity = read_key_values(ROOT / "binary-identity.txt")
    if path is None:
        return False
    if not path.is_file():
        fail(f"external binary is missing: {path}")
    digest = sha256_file(path)
    size = path.stat().st_size
    expected_sha = identity.get("sha256")
    expected_size = int(identity.get("bytes", "-1"))
    if digest != expected_sha or size != expected_size:
        fail(f"external binary identity mismatch: {size}/{digest}")
    return True


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--binary", type=Path, help="optional external release binary to hash")
    args = parser.parse_args()
    entries = parse_hash_receipt()
    verify_hash_receipt(entries)
    publication = read_json(ROOT / "publication-manifest.json")
    if publication.get("status") != "final_paired_provenance_complete_external_binary":
        fail("publication manifest is not final paired status")
    first_capture, first_reports = verify_first_capture()
    paired_manifest, paired_reports = verify_paired_capture()
    verify_source_and_scripts(publication, first_capture, paired_manifest)
    verify_fresh_validators(first_reports, paired_reports)
    verify_comparison(first_reports, paired_reports)
    external_verified = verify_binary_if_supplied(args.binary)
    print(f"verified {len(entries)} sealed publication files")
    print("verified first capture: six reports and six catalogs")
    print("verified paired capture: four reports, four catalogs and member manifest")
    print("executed fresh first/paired validators and bound their outputs to retained analyses")
    print("computed fresh report-derived work/p50 comparison and bound paired-comparison.json")
    print("verified exact first-run script recovery and paired runner hash")
    if external_verified:
        print("verified supplied external binary size and SHA-256")
    else:
        print("external binary not supplied; recorded binary identity was not treated as byte verification")


if __name__ == "__main__":
    try:
        main()
    except (KeyError, OSError, ValueError) as exc:
        fail(str(exc))
