# Review request: paired measured cf98 scaling publication

Reviewer: `opc_capture_review`; capture owner: `xlsb_data_model_fix`.

Review the final candidate at
`/var/tmp/litchi-current-head-scaling-final-publication-worktree-20260910`.
The measured source is `cf98bee` / tree `46c3a5c1`; publication HEAD is
`cf4f383c` / tree `f0ec6056`; the latter is not a measured-source claim.

Required checks:

1. Run `PYTHONDONTWRITEBYTECODE=1 python3 scripts/verify.py` and then repeat
   with the paired external binary path recorded in `binary-identity.txt`.
   Confirm the verifier extracts temporary report inputs and executes both
   bundled validators afresh, binding fresh outputs to retained analyses.
   Confirm the binary is checked only when supplied, while metadata and build
   recipe remain valid without embedding the 22 MB compressed binary.
2. Confirm first and paired reports/catalogs are byte-authenticated, fresh
   report-derived work/p50 rows equal `paired-comparison.json`, the paired member
   manifest retains equal logical tasks/bytes, and both captures
   use the same source/tree, validator and binary hash.
3. Confirm exact first-run script recovery (`b3265a00…`) and its two-line diff
   (`01b1c56f…`), plus paired runner hash `deb6cae8…`; do not treat the
   post-run corrected script as the executed first runner.
4. Check that README observations preserve warm MiniFAT cache and six-member
   OPC qualifications, shared-host caveats, and model-invalid superlinear
   rows. No Amdahl/parallel-fraction or causal performance claim is supported.
5. Ensure no raw report, catalog, command, host snapshot, reservation record,
   source identity or binary hash was silently rewritten. Add reviewer status
   separately after these checks; do not edit raw evidence in place.
