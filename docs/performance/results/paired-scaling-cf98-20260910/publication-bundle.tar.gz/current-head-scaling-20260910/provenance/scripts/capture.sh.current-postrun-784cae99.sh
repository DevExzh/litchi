#!/usr/bin/env bash
set -Eeuo pipefail

if (( $# != 2 )); then
  echo "usage: capture.sh REPOSITORY_ROOT EMPTY_OUTPUT_DIRECTORY" >&2
  exit 2
fi

ROOT=$(cd -- "$1" && pwd -P)
OUT=$2
PLAN_DIR=$(cd -- "$(dirname -- "$0")" && pwd -P)
EXPECTED_COMMIT=cf98bee37455e8e6d0e73002ff2e94299ef546cb
EXPECTED_TREE=46c3a5c1c10c0178a4e31db4bf2f2d838ef2beab
SCALING_CPU_SET=${SCALING_CPU_SET:-0-7}
RANGE_CPU_SET=${RANGE_CPU_SET:-0}
SCALING_WARMUP=${SCALING_WARMUP:-3}
SCALING_SAMPLES=${SCALING_SAMPLES:-20}
RANGE_WARMUP=${RANGE_WARMUP:-2}
RANGE_SAMPLES=${RANGE_SAMPLES:-10}
RUN_CFB_RANGE=${RUN_CFB_RANGE:-0}
RESERVATION_RECEIPT=${RESERVATION_RECEIPT:-}

if [[ -e "$OUT" ]]; then
  echo "output directory already exists; refusing to overwrite: $OUT" >&2
  exit 2
fi
if [[ "$(git -C "$ROOT" rev-parse HEAD)" != "$EXPECTED_COMMIT" ]]; then
  echo "repository HEAD is not the pinned current feature head" >&2
  exit 2
fi
if [[ "$(git -C "$ROOT" rev-parse HEAD^{tree})" != "$EXPECTED_TREE" ]]; then
  echo "repository tree is not the pinned current feature tree" >&2
  exit 2
fi
if ! taskset -c "$SCALING_CPU_SET" true; then
  echo "scaling CPU affinity is unavailable: $SCALING_CPU_SET" >&2
  exit 2
fi
if ! taskset -c "$RANGE_CPU_SET" true; then
  echo "range CPU affinity is unavailable: $RANGE_CPU_SET" >&2
  exit 2
fi
if [[ -z "$RESERVATION_RECEIPT" || ! -f "$RESERVATION_RECEIPT" ]]; then
  echo "an explicit reservation receipt is required in RESERVATION_RECEIPT" >&2
  exit 2
fi
if ! rg -q '^status=(granted|reserved)$' "$RESERVATION_RECEIPT"; then
  echo "reservation receipt must contain status=granted or status=reserved" >&2
  exit 2
fi
if ! rg -q "^scaling_cpu_set=$SCALING_CPU_SET$" "$RESERVATION_RECEIPT"; then
  echo "reservation receipt does not cover the requested scaling CPU set" >&2
  exit 2
fi
if ! rg -q "^range_cpu_set=$RANGE_CPU_SET$" "$RESERVATION_RECEIPT"; then
  echo "reservation receipt does not cover the requested range CPU set" >&2
  exit 2
fi

mkdir -p "$OUT/reports" "$OUT/manifests" "$OUT/perf"
: > "$OUT/commands.log"
cp -- "$PLAN_DIR/artifact-manifest.json" "$OUT/plan-artifact-manifest.json"
{
  printf 'plan_directory=%s\n' "$PLAN_DIR"
  printf 'validator=%s\n' "$PLAN_DIR/validate_reports.py"
  printf 'validator_sha256='; sha256sum "$PLAN_DIR/validate_reports.py" | cut -d' ' -f1
  printf 'capture_script_sha256='; sha256sum "$PLAN_DIR/capture.sh" | cut -d' ' -f1
  printf 'plan_manifest_sha256='; sha256sum "$PLAN_DIR/artifact-manifest.json" | cut -d' ' -f1
} > "$OUT/plan-binding.txt"
SOURCE="$OUT/source-worktree"
TARGET="$OUT/target"
BIN="$TARGET/release/litchi-perf-baseline"
git -C "$ROOT" worktree add --detach "$SOURCE" "$EXPECTED_COMMIT" >/dev/null
if [[ -n "$(git -C "$SOURCE" status --porcelain)" ]]; then
  echo "detached source worktree is unexpectedly dirty" >&2
  exit 2
fi

HOME_VALUE=${HOME:?HOME must be set}
PATH_VALUE=${PATH:?PATH must be set}
RUSTUP_HOME_VALUE=${RUSTUP_HOME:-$HOME_VALUE/.rustup}
CARGO_HOME_VALUE=${CARGO_HOME:-$HOME_VALUE/.cargo}
TMP_VALUE=${TMPDIR:-/tmp}

record_command() {
  printf '%q ' "$@" >> "$OUT/commands.log"
  printf '\n' >> "$OUT/commands.log"
}
clean_exec() {
  record_command "$@"
  (cd "$SOURCE" && env -i \
    HOME="$HOME_VALUE" PATH="$PATH_VALUE" RUSTUP_HOME="$RUSTUP_HOME_VALUE" \
    CARGO_HOME="$CARGO_HOME_VALUE" CARGO_TARGET_DIR="$TARGET" \
    TMPDIR="$TMP_VALUE" LC_ALL=C \
    "$@")
}

{
  printf 'source_root=%s\n' "$ROOT"
  printf 'source_commit=%s\n' "$(git -C "$SOURCE" rev-parse HEAD)"
  printf 'source_tree=%s\n' "$(git -C "$SOURCE" rev-parse HEAD^{tree})"
  printf 'source_status=%q\n' "$(git -C "$SOURCE" status --porcelain)"
  printf 'scaling_cpu_set=%s\n' "$SCALING_CPU_SET"
  printf 'range_cpu_set=%s\n' "$RANGE_CPU_SET"
  printf 'scaling_warmup=%s\nscaling_samples=%s\n' "$SCALING_WARMUP" "$SCALING_SAMPLES"
  printf 'range_warmup=%s\nrange_samples=%s\n' "$RANGE_WARMUP" "$RANGE_SAMPLES"
  printf 'run_cfb_range=%s\n' "$RUN_CFB_RANGE"
  printf 'reservation_receipt=%s\n' "$RESERVATION_RECEIPT"
  printf 'reservation_sha256='; sha256sum "$RESERVATION_RECEIPT" | cut -d' ' -f1
  printf 'retained_source_worktree=%s\n' "$SOURCE"
  uname -srvm
  lscpu
  printf 'cpu_allowed_process='; taskset -pc $$ 2>&1
  for quota_path in \
      /sys/fs/cgroup/cpu.max \
      /sys/fs/cgroup/cpu.weight \
      /sys/fs/cgroup/cpu/cpu.cfs_quota_us \
      /sys/fs/cgroup/cpu/cpu.cfs_period_us \
      /sys/fs/cgroup/cpu/cpu.shares; do
    quota_name=${quota_path#/sys/fs/cgroup/}
    quota_name=${quota_name//\//_}
    if [[ -r "$quota_path" ]]; then
      printf 'cgroup_%s=' "$quota_name"
      cat "$quota_path"
    else
      printf 'cgroup_%s=unavailable\n' "$quota_name"
    fi
  done
  printf 'cpufreq_snapshot_start\n'
  freq_seen=0
  for freq_path in /sys/devices/system/cpu/cpu[0-9]*/cpufreq/scaling_cur_freq; do
    [[ -r "$freq_path" ]] || continue
    freq_seen=1
    printf '%s=' "$freq_path"
    cat "$freq_path"
  done
  if (( ! freq_seen )); then
    printf 'cpufreq_snapshot=unavailable\n'
  fi
  printf 'cpufreq_snapshot_end\n'
  printf 'contention_process_snapshot_start\n'
  ps -eo pid,ppid,psr,stat,pcpu,pmem,comm,args --sort=-pcpu | head -80
  printf 'contention_process_snapshot_end\n'
  printf 'perf_event_paranoid='; cat /proc/sys/kernel/perf_event_paranoid
  printf 'source_lock_hashes\n'
  sha256sum "$SOURCE/tools/perf-baseline/Cargo.lock" \
    "$SOURCE/tools/perf-baseline/Cargo.toml" \
    "$SOURCE/tools/perf-baseline/src/lib.rs"
  printf 'rustc='; rustc +1.95.0 -V
  printf 'cargo='; cargo +1.95.0 -V
  printf 'perf='; perf --version
} > "$OUT/run-environment.txt"
cp -- "$RESERVATION_RECEIPT" "$OUT/reservation-receipt.txt"

clean_exec cargo +1.95.0 build --release --locked \
  --manifest-path "$SOURCE/tools/perf-baseline/Cargo.toml" \
  --bin litchi-perf-baseline > "$OUT/build.log" 2>&1

if [[ ! -x "$BIN" ]]; then
  echo "release binary was not produced: $BIN" >&2
  exit 1
fi
{
  printf 'path=%s\n' "$BIN"
  printf 'bytes='; stat -c '%s' "$BIN"
  printf 'sha256='; sha256sum "$BIN" | cut -d' ' -f1
  printf 'mode='; stat -c '%a' "$BIN"
} > "$OUT/binary-identity.txt"

run_scaling() {
  local workers=$1
  local report="$OUT/reports/scaling-w${workers}.json"
  local catalog="$OUT/manifests/scaling-w${workers}.catalog.json"
  clean_exec taskset -c "$SCALING_CPU_SET" "$BIN" \
    --case opc_open_session_scaling,cfb_bulk_read_scaling \
    --shape many-small,few-large --payload incompressible --workers "$workers" \
    --warmup "$SCALING_WARMUP" --samples "$SCALING_SAMPLES" \
    --json "$report" --corpus-manifest "$catalog" \
    > "$OUT/reports/scaling-w${workers}.stdout.log" 2>&1
}
for workers in 1 2 4 8; do
  run_scaling "$workers"
done

clean_exec taskset -c "$RANGE_CPU_SET" "$BIN" \
  --case opc_range_source_open,opc_range_source_open_main_read \
  --shape many-small --payload incompressible --workers 1 \
  --range-fixed-latency-us 2000 --range-request-overhead-us 250 \
  --range-bandwidth-bytes-per-sec 16777216 --range-max-physical-bytes 65536 \
  --warmup "$RANGE_WARMUP" --samples "$RANGE_SAMPLES" \
  --json "$OUT/reports/range-opc.json" \
  --corpus-manifest "$OUT/manifests/range-opc.catalog.json" \
  > "$OUT/reports/range-opc.stdout.log" 2>&1

clean_exec taskset -c "$RANGE_CPU_SET" "$BIN" \
  --case xlsx_range_source_open,xlsx_range_source_list_sheets,xlsx_range_source_first_cell,xlsx_range_source_narrow_column_range_scan \
  --shape many-small --payload incompressible --xlsx-shape dense-wide --workers 1 \
  --range-fixed-latency-us 2000 --range-request-overhead-us 250 \
  --range-bandwidth-bytes-per-sec 16777216 --range-max-physical-bytes 65536 \
  --warmup "$RANGE_WARMUP" --samples "$RANGE_SAMPLES" \
  --json "$OUT/reports/range-xlsx.json" \
  --corpus-manifest "$OUT/manifests/range-xlsx.catalog.json" \
  > "$OUT/reports/range-xlsx.stdout.log" 2>&1

if [[ "$RUN_CFB_RANGE" != 0 ]]; then
  clean_exec taskset -c "$RANGE_CPU_SET" "$BIN" \
    --case cfb_selective_simulated_mini_shared_read,cfb_selective_simulated_fat_shared_read \
    --shape many-small,wide-root --payload incompressible --workers 1 \
    --range-fixed-latency-us 2000 --range-request-overhead-us 250 \
    --range-bandwidth-bytes-per-sec 16777216 --range-max-physical-bytes 65536 \
    --warmup "$RANGE_WARMUP" --samples "$RANGE_SAMPLES" \
    --json "$OUT/reports/range-cfb-selective.json" \
    --corpus-manifest "$OUT/manifests/range-cfb-selective.catalog.json" \
    > "$OUT/reports/range-cfb-selective.stdout.log" 2>&1
fi

PYTHONDONTWRITEBYTECODE=1 python3 "$PLAN_DIR/validate_reports.py" \
  --scaling "$OUT/reports/scaling-w1.json" "$OUT/reports/scaling-w2.json" \
             "$OUT/reports/scaling-w4.json" "$OUT/reports/scaling-w8.json" \
  --range "$OUT/reports/range-opc.json" "$OUT/reports/range-xlsx.json" \
  --output "$OUT/scaling-analysis.json"
