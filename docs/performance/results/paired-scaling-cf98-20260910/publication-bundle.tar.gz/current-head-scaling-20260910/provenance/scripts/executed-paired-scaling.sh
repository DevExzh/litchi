#!/usr/bin/env bash
set -Eeuo pipefail

PAIR=/var/tmp/litchi-current-head-scaling-paired-v2-20260910
SOURCE=/var/tmp/litchi-current-head-scaling-capture-v2-live-20260910/source-worktree
BIN="$PAIR/litchi-perf-baseline"
RESERVATION=${RESERVATION_RECEIPT:?RESERVATION_RECEIPT is required}
CPU_SET=${SCALING_CPU_SET:-0-7}
WARMUP=3
SAMPLES=20
ORDER=(4 1 8 2)

[[ -x "$BIN" ]] || { echo "missing paired binary: $BIN" >&2; exit 2; }
[[ -d "$SOURCE" ]] || { echo "missing retained source worktree: $SOURCE" >&2; exit 2; }
rg -q '^status=(reserved|granted)$' "$RESERVATION" || { echo "invalid paired reservation status" >&2; exit 2; }
rg -q "^scaling_cpu_set=$CPU_SET$" "$RESERVATION" || { echo "paired reservation CPU set mismatch" >&2; exit 2; }
[[ "$(git -C "$SOURCE" rev-parse HEAD)" == cf98bee37455e8e6d0e73002ff2e94299ef546cb ]] || { echo "paired source commit mismatch" >&2; exit 2; }
[[ "$(git -C "$SOURCE" rev-parse HEAD^{tree})" == 46c3a5c1c10c0178a4e31db4bf2f2d838ef2beab ]] || { echo "paired source tree mismatch" >&2; exit 2; }
[[ -z "$(git -C "$SOURCE" status --porcelain)" ]] || { echo "paired source worktree is dirty" >&2; exit 2; }

HOME_VALUE=/home/zhuhe
PATH_VALUE=/home/zhuhe/.cargo/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
RUSTUP_VALUE=/tmp/litchi-spec-gap-rustup
CARGO_VALUE=/home/zhuhe/.cargo
TMP_VALUE=/var/tmp

sha256_file() { sha256sum "$1" | cut -d' ' -f1; }
record_command() {
  printf '%q ' "$@" >> "$PAIR/commands.log"
  printf '\n' >> "$PAIR/commands.log"
}
snapshot() {
  local label=$1
  {
    printf 'captured_utc='; date -u '+%Y-%m-%dT%H:%M:%SZ'
    printf 'label=%s\n' "$label"
    ps -eo pid,ppid,psr,stat,etime,pcpu,pmem,comm,args --sort=-pcpu | head -100 || true
  } > "$PAIR/contention/$label.txt"
}

mkdir -p "$PAIR/reports" "$PAIR/manifests" "$PAIR/contention"
: > "$PAIR/commands.log"
cp -- "$RESERVATION" "$PAIR/reservation-receipt.txt"
{
  printf 'schema=paired-scaling-run-v1\n'
  printf 'captured_utc='; date -u '+%Y-%m-%dT%H:%M:%SZ'
  printf 'source_worktree=%s\n' "$SOURCE"
  printf 'source_commit='; git -C "$SOURCE" rev-parse HEAD
  printf 'source_tree='; git -C "$SOURCE" rev-parse HEAD^{tree}
  printf 'source_status=%q\n' "$(git -C "$SOURCE" status --porcelain)"
  printf 'binary=%s\n' "$BIN"
  printf 'binary_sha256='; sha256_file "$BIN"
  printf 'validator=%s\n' "$PAIR/validate_reports.py"
  printf 'validator_sha256='; sha256_file "$PAIR/validate_reports.py"
  printf 'reservation=%s\n' "$RESERVATION"
  printf 'reservation_sha256='; sha256_file "$RESERVATION"
  printf 'cpu_set=%s\n' "$CPU_SET"
  printf 'width_order=%s\n' "${ORDER[*]}"
  printf 'warmup=%s\nsamples=%s\n' "$WARMUP" "$SAMPLES"
  printf 'shared_host_idle_claim=false\n'
  printf 'profile_cpu2_summary=/var/tmp/litchi-profile-exact-cpu2-20260910/profile-summary.json\n'
  printf 'profile_cpu2_summary_sha256='; sha256_file /var/tmp/litchi-profile-exact-cpu2-20260910/profile-summary.json
  printf 'cgroup_cpu.max='; cat /sys/fs/cgroup/cpu.max 2>/dev/null || printf 'unavailable\n'
  printf 'cgroup_cpu.weight='; cat /sys/fs/cgroup/cpu.weight 2>/dev/null || printf 'unavailable\n'
  printf 'cpufreq_snapshot_start\n'
  freq_seen=0
  for freq_path in /sys/devices/system/cpu/cpu[0-9]*/cpufreq/scaling_cur_freq; do
    [[ -r "$freq_path" ]] || continue
    freq_seen=1
    printf '%s=' "$freq_path"; cat "$freq_path"
  done
  (( freq_seen )) || printf 'cpufreq_snapshot=unavailable\n'
  printf 'cpufreq_snapshot_end\n'
  printf 'cpu_allowed_process='; taskset -pc $$ 2>&1
  lscpu
  uname -srvm
  printf 'perf_event_paranoid='; cat /proc/sys/kernel/perf_event_paranoid
} > "$PAIR/run-environment.txt"
snapshot before-all

for width in "${ORDER[@]}"; do
  report="$PAIR/reports/scaling-w${width}.json"
  catalog="$PAIR/manifests/scaling-w${width}.catalog.json"
  snapshot "before-w${width}"
  command=(taskset -c "$CPU_SET" env -i
    HOME="$HOME_VALUE" PATH="$PATH_VALUE" RUSTUP_HOME="$RUSTUP_VALUE"
    CARGO_HOME="$CARGO_VALUE" TMPDIR="$TMP_VALUE" LC_ALL=C
    "$BIN" --case opc_open_session_scaling,cfb_bulk_read_scaling
    --shape many-small,few-large --payload incompressible --workers "$width"
    --warmup "$WARMUP" --samples "$SAMPLES" --json "$report"
    --corpus-manifest "$catalog")
  record_command "${command[@]}"
  {
    printf 'started_utc='; date -u '+%Y-%m-%dT%H:%M:%SZ'
  } > "$PAIR/reports/scaling-w${width}.run-meta.txt"
  (
    cd "$SOURCE"
    "${command[@]}"
  ) > "$PAIR/reports/scaling-w${width}.stdout.log" 2>&1
  {
    printf 'finished_utc='; date -u '+%Y-%m-%dT%H:%M:%SZ'
  } >> "$PAIR/reports/scaling-w${width}.run-meta.txt"
  snapshot "after-w${width}"
done

PYTHONDONTWRITEBYTECODE=1 python3 "$PAIR/validate-paired-scaling.py" \
  --scaling "$PAIR/reports/scaling-w1.json" "$PAIR/reports/scaling-w2.json" \
             "$PAIR/reports/scaling-w4.json" "$PAIR/reports/scaling-w8.json" \
  --output "$PAIR/paired-scaling-analysis.json"

sha256sum "$BIN" "$PAIR/validate_reports.py" > "$PAIR/input-hashes.after.txt"
printf 'timed_lanes_terminal=true\nvalidator_status=passed\n' > "$PAIR/completion.txt"
