#!/usr/bin/env python3
from __future__ import annotations

import argparse
import importlib.util
import json
from pathlib import Path


def load_validator(path: Path):
    spec = importlib.util.spec_from_file_location("scaling_validator", path)
    if spec is None or spec.loader is None:
        raise SystemExit(f"cannot load validator: {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--scaling", nargs=4, type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    validator_path = Path(__file__).with_name("validate_reports.py")
    validator = load_validator(validator_path)
    analysis = validator.validate_scaling(args.scaling)
    args.output.write_text(json.dumps(analysis, indent=2, sort_keys=True) + "\n")
    print(f"validated {len(args.scaling)} paired scaling reports")
    print(f"wrote {args.output}")


if __name__ == "__main__":
    main()
