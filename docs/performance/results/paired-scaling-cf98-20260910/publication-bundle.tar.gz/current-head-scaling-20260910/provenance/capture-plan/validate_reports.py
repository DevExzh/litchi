#!/usr/bin/env python3
"""Validate current-head scaling/range report invariants and calculate Amdahl rows.

This consumes already-created JSON reports. It never invokes Cargo or the
benchmark binary.
"""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
from typing import Any

EXPECTED_COMMIT = "cf98bee37455e8e6d0e73002ff2e94299ef546cb"
EXPECTED_TREE = "46c3a5c1c10c0178a4e31db4bf2f2d838ef2beab"
RANGE_LIMIT = 65_536
SCALING_CASES = {"opc_open_session_scaling", "cfb_bulk_read_scaling"}
RANGE_CASES = {
    "opc_range_source_open",
    "opc_range_source_open_main_read",
    "xlsx_range_source_open",
    "xlsx_range_source_list_sheets",
    "xlsx_range_source_first_cell",
    "xlsx_range_source_narrow_column_range_scan",
}


def fail(message: str) -> None:
    raise SystemExit(f"validation failed: {message}")


def read_report(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text())
    except (OSError, json.JSONDecodeError) as exc:
        fail(f"{path}: cannot read JSON: {exc}")
    if not isinstance(value, dict):
        fail(f"{path}: report root is not an object")
    return value


def require(condition: bool, message: str) -> None:
    if not condition:
        fail(message)


def all_equal(values: list[Any], message: str) -> Any:
    require(bool(values), message + ": empty vector")
    require(all(value == values[0] for value in values), message)
    return values[0]


def validate_identity(report: dict[str, Any], path: Path, expected_workers: list[int]) -> None:
    env = report.get("environment")
    require(isinstance(env, dict), f"{path}: missing environment")
    require(env.get("git_revision") == EXPECTED_COMMIT, f"{path}: wrong git revision")
    require(env.get("git_worktree_dirty") is False, f"{path}: detached source is dirty")
    rustc = env.get("rustc_version")
    require(isinstance(rustc, str) and rustc.startswith("rustc 1.95.0"), f"{path}: wrong rustc")
    require(isinstance(env.get("logical_cpus_available"), int) and env["logical_cpus_available"] >= 1,
            f"{path}: invalid available CPU count")
    binary = report.get("binary_identity")
    require(isinstance(binary, dict), f"{path}: missing binary identity")
    digest = binary.get("binary_sha256")
    require(isinstance(digest, str) and len(digest) == 64, f"{path}: invalid binary hash")
    config = report.get("configuration")
    require(isinstance(config, dict), f"{path}: missing configuration")
    require(config.get("execution_workers") == expected_workers, f"{path}: worker selection mismatch")
    require(config.get("samples_per_case", 0) > 0, f"{path}: no samples")
    require(config.get("warmup_iterations_per_case", -1) >= 0, f"{path}: invalid warmup count")
    metrics = report.get("parallel_metrics")
    require(isinstance(metrics, dict), f"{path}: missing parallel metrics envelope")
    process_threads = metrics.get("observed_process_thread_count")
    require(isinstance(process_threads, dict) and process_threads.get("status") == "unavailable",
            f"{path}: process thread metric must remain explicitly unavailable")


def corpus_work(result: dict[str, Any]) -> tuple[Any, ...]:
    corpus = result.get("corpus")
    require(isinstance(corpus, dict), "result has no corpus")
    return (
        corpus.get("archive_sha256"),
        corpus.get("archive_bytes"),
        corpus.get("entry_count"),
        corpus.get("archive_member_count"),
        corpus.get("entry_bytes"),
        corpus.get("uncompressed_payload_bytes"),
        corpus.get("target_entry"),
        corpus.get("target_payload_bytes"),
        corpus.get("target_payload_sha256"),
    )


def validate_scaling(paths: list[Path]) -> dict[str, Any]:
    require(len(paths) == 4, "exactly four scaling reports are required")
    reports: list[tuple[int, Path, dict[str, Any]]] = []
    expected_workers = [1, 2, 4, 8]
    binary_hashes: set[str] = set()
    for worker, path in zip(expected_workers, paths):
        report = read_report(path)
        validate_identity(report, path, [worker])
        config = report["configuration"]
        require(config.get("cases") == ["opc_open_session_scaling", "cfb_bulk_read_scaling"], f"{path}: scaling case selection mismatch")
        require(config.get("corpus_shapes") == ["many-small", "few-large"], f"{path}: scaling shapes mismatch")
        require(config.get("payload_kinds") == ["incompressible"], f"{path}: scaling payload mismatch")
        results = report.get("results")
        require(isinstance(results, list) and len(results) == 4, f"{path}: expected four scaling rows")
        for result in results:
            require(result.get("case") in SCALING_CASES, f"{path}: unexpected scaling case")
            execution = result.get("execution")
            require(isinstance(execution, dict), f"{path}: scaling row lacks execution facts")
            require(execution.get("worker_count") == worker, f"{path}: row worker mismatch")
            require(isinstance(execution.get("logical_tasks"), int) and execution["logical_tasks"] > 0,
                    f"{path}: invalid logical task count")
            require(isinstance(execution.get("logical_bytes"), int) and execution["logical_bytes"] > 0,
                    f"{path}: invalid logical byte count")
            samples = result.get("elapsed_ns", {}).get("samples")
            require(isinstance(samples, list) and len(samples) == config["samples_per_case"],
                    f"{path}: sample count mismatch")
            require(all(isinstance(value, int) and value > 0 for value in samples),
                    f"{path}: invalid elapsed sample")
            binary_hashes.add(report["binary_identity"]["binary_sha256"])
        reports.append((worker, path, report))
    require(len(binary_hashes) == 1, "scaling reports were produced by different binaries")

    rows: dict[tuple[str, str], list[dict[str, Any]]] = {}
    work_by_key: dict[tuple[str, str], tuple[Any, ...]] = {}
    execution_by_key: dict[tuple[str, str], tuple[int, int]] = {}
    for worker, path, report in reports:
        for result in report["results"]:
            corpus = result["corpus"]
            key = (result["case"], corpus["name"])
            work = corpus_work(result)
            execution = result["execution"]
            fact = (execution["logical_tasks"], execution["logical_bytes"])
            require(key not in work_by_key or work_by_key[key] == work,
                    f"{path}: corpus identity changed for {key}")
            require(key not in execution_by_key or execution_by_key[key] == fact,
                    f"{path}: logical work changed for {key}: "
                    f"expected {execution_by_key.get(key)}, got {fact}")
            work_by_key[key] = work
            execution_by_key[key] = fact
            rows.setdefault(key, []).append({
                "workers": worker,
                "corpus": corpus,
                "execution": execution,
                "p50_ns": result["elapsed_ns"]["p50"],
                "p95_ns": result["elapsed_ns"]["p95"],
                "p99_ns": result["elapsed_ns"]["p99"],
                "logical_tasks": fact[0],
                "logical_bytes": fact[1],
            })
    require(len(rows) == 4, "scaling rows did not cover both cases and both shapes")
    analysis: list[dict[str, Any]] = []
    for (case, corpus_name), values in sorted(rows.items()):
        values.sort(key=lambda row: row["workers"])
        require([row["workers"] for row in values] == expected_workers,
                f"missing worker width for {case}/{corpus_name}")
        if case == "opc_open_session_scaling" and corpus_name == "few-large-incompressible":
            corpus = values[0]["corpus"]
            require(corpus.get("archive_member_count") == 6,
                    "OPC few-large workload must contain six archive members")
            require(corpus.get("entry_count") == 4,
                    "OPC few-large workload must contain four typed payload parts")
            require(values[0]["logical_tasks"] == 6,
                    "OPC few-large workload must expose two metadata tasks plus four payload tasks")
        baseline = values[0]["p50_ns"]
        require(baseline > 0, f"invalid baseline p50 for {case}/{corpus_name}")
        for row in values:
            speedup = baseline / row["p50_ns"]
            workers = row["workers"]
            efficiency = speedup / workers
            serial_fraction: float | None = None
            classification = "one-worker-baseline"
            if workers > 1:
                if speedup < 1.0:
                    classification = "slowdown-observed-model-invalid"
                elif speedup > workers:
                    classification = "superlinear-observed-model-invalid"
                else:
                    serial_fraction = (1.0 / speedup - 1.0 / workers) / (1.0 - 1.0 / workers)
                    if not 0.0 <= serial_fraction <= 1.0:
                        classification = "serial-fraction-outside-model"
                    else:
                        classification = "amdahl-fixed-work"
            row_analysis = {
                "case": case,
                "corpus": corpus_name,
                "workers": workers,
                "logical_tasks": row["logical_tasks"],
                "logical_bytes": row["logical_bytes"],
                "p50_ns": row["p50_ns"],
                "p95_ns": row["p95_ns"],
                "p99_ns": row["p99_ns"],
                "speedup_from_one_worker": speedup,
                "efficiency": efficiency,
                "serial_fraction": serial_fraction,
                "classification": classification,
            }
            if case == "opc_open_session_scaling" and corpus_name == "few-large-incompressible":
                row_analysis["workload_qualification"] = {
                    "archive_member_count": 6,
                    "parallel_typed_payload_parts": 4,
                    "serial_metadata_tasks": 2,
                    "interpretation": (
                        "four typed payload parts can run in parallel; two metadata "
                        "tasks remain serial"
                    ),
                }
            elif case == "cfb_bulk_read_scaling" and corpus_name == "cfb-many-small-incompressible":
                row_analysis["workload_qualification"] = {
                    "source_behavior": "warm MiniFAT cache reread",
                    "interpretation": (
                        "many-small is a warm MiniFAT-cache reread workload, not a cold-source read"
                    ),
                }
            elif case == "cfb_bulk_read_scaling" and corpus_name == "cfb-few-large-incompressible":
                row_analysis["workload_qualification"] = {
                    "source_behavior": "regular FAT source read",
                    "interpretation": (
                        "few-large reads the regular FAT source and is distinct from many-small"
                    ),
                }
            analysis.append(row_analysis)
    return {
        "schema": "litchi-current-head-scaling-analysis-v1",
        "source_commit": EXPECTED_COMMIT,
        "source_tree": EXPECTED_TREE,
        "binary_sha256": next(iter(binary_hashes)),
        "worker_widths": expected_workers,
        "rows": analysis,
    }


def vector(source: dict[str, Any], key: str, path: Path) -> list[Any]:
    value = source.get(key)
    require(isinstance(value, list) and value, f"{path}: source.{key} is empty or missing")
    return value


def validate_simulation(source: dict[str, Any], path: Path, limit: int) -> None:
    simulation = source.get("simulation")
    require(isinstance(simulation, dict), f"{path}: missing source simulation")
    logical = vector(simulation, "logical_read_bytes", path)
    physical = vector(simulation, "physical_request_bytes", path)
    counts = vector(simulation, "physical_request_count", path)
    sizes = vector(simulation, "physical_request_sizes", path)
    require(len(logical) == len(physical) == len(counts) == len(sizes), f"{path}: simulation vectors differ")
    for logical_bytes, physical_bytes, count, request_sizes in zip(logical, physical, counts, sizes):
        require(logical_bytes == physical_bytes, f"{path}: physical/logical bytes differ")
        require(count == len(request_sizes), f"{path}: physical request count differs from sizes")
        require(all(isinstance(size, int) and 0 < size <= limit for size in request_sizes),
                f"{path}: physical range exceeds configured bound")


def validate_range(paths: list[Path]) -> None:
    require(len(paths) == 2, "exactly OPC and XLSX range reports are required")
    all_cases: set[str] = set()
    binary_hashes: set[str] = set()
    for path in paths:
        report = read_report(path)
        validate_identity(report, path, [1])
        config = report["configuration"]
        require(config.get("range_simulation", {}).get("fixed_latency_us") == 2000,
                f"{path}: fixed latency mismatch")
        require(config.get("range_simulation", {}).get("request_overhead_us") == 250,
                f"{path}: request overhead mismatch")
        require(config.get("range_simulation", {}).get("bandwidth_bytes_per_second") == 16 * 1024 * 1024,
                f"{path}: bandwidth mismatch")
        require(config.get("range_simulation", {}).get("max_physical_range_bytes") == RANGE_LIMIT,
                f"{path}: range bound mismatch")
        results = report.get("results")
        require(isinstance(results, list) and results, f"{path}: empty range results")
        binary_hashes.add(report["binary_identity"]["binary_sha256"])
        for result in results:
            case = result.get("case")
            require(case in RANGE_CASES, f"{path}: unexpected range case {case}")
            all_cases.add(case)
            samples = result.get("elapsed_ns", {}).get("samples")
            require(isinstance(samples, list) and len(samples) == config["samples_per_case"],
                    f"{path}: range sample count mismatch")
            source = result.get("source")
            require(isinstance(source, dict), f"{path}: {case} lacks source metrics")
            validate_simulation(source, path, RANGE_LIMIT)
            if case == "opc_range_source_open":
                require(all(value == 0 for value in vector(source, "ordinary_payload_read_calls", path)),
                        f"{path}: OPC structural open materialized payload")
                require(all(value == 0 for value in vector(source, "ordinary_payload_materializations", path)),
                        f"{path}: OPC structural open materialized payload")
            elif case == "opc_range_source_open_main_read":
                require(all(value > 0 for value in vector(source, "ordinary_payload_read_calls", path)),
                        f"{path}: OPC main-read did not read ordinary payload")
                require(all(value > 0 for value in vector(source, "ordinary_payload_materializations", path)),
                        f"{path}: OPC main-read did not materialize payload")
            elif case.startswith("xlsx_range_source_"):
                xlsx = source.get("xlsx")
                require(isinstance(xlsx, dict), f"{path}: {case} lacks XLSX source metrics")
                require(all(value == 0 for value in vector(xlsx, "unselected_worksheet_read_calls", path)),
                        f"{path}: {case} read an unselected worksheet")
                if case == "xlsx_range_source_list_sheets":
                    simulation = source["simulation"]
                    require(all(value == 0 for value in simulation["logical_read_calls"]),
                            f"{path}: XLSX listing issued a logical read")
                    require(all(value == 0 for value in simulation["physical_request_count"]),
                            f"{path}: XLSX listing issued a physical request")
                elif case in {"xlsx_range_source_first_cell", "xlsx_range_source_narrow_column_range_scan"}:
                    require(all(value > 0 for value in vector(xlsx, "selected_worksheet_read_calls", path)),
                            f"{path}: {case} did not touch the selected worksheet")
    require(all_cases == RANGE_CASES, f"range selector coverage mismatch: {sorted(all_cases)}")
    require(len(binary_hashes) == 1, "range reports were produced by different binaries")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--scaling", nargs=4, type=Path, required=True)
    parser.add_argument("--range", nargs=2, type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    analysis = validate_scaling(args.scaling)
    validate_range(args.range)
    args.output.write_text(json.dumps(analysis, indent=2, sort_keys=True) + "\n")
    print(f"validated {len(args.scaling)} scaling reports and {len(args.range)} range reports")
    print(f"wrote {args.output}")


if __name__ == "__main__":
    main()
