# Current feature head execution and range scaling capture plan v2

This is the regenerated read only capture plan prepared on 2026-09-10. It does
not contain new timings. It binds the proposed capture to the feature
repository at commit `cf98bee37455e8e6d0e73002ff2e94299ef546cb`, tree
`46c3a5c1c10c0178a4e31db4bf2f2d838ef2beab`, Rust `1.95.0`, and the tracked
`tools/perf-baseline/Cargo.lock`. The complete source and document identities
are in `source-identity.json`. The earlier e44a233 plan is explicitly
superseded; it came from an unrelated worktree.

The retained scaling record is historical, not a current-head result. It was
built from dirty `d6bd13c9043737885ad27fa9d6207f4c30c1addd` on a 12-logical-CPU
host and used workers 1, 2, 4, 8, 12, three warmups, and 20 samples. The
retained high-latency range record is also dirty `d6bd13c`, used one logical
CPU, two warmups, and ten samples. Neither record can close the current-head
scaling requirement on this host.

The preflight observed 32 one-thread AMD EPYC 9R45 cores, four L3 groups, one
NUMA node, about 123 GiB of RAM, and CPU allowance `0-31`. CPUs `0-7` share one
L3 group, so the proposed CPU lane pins every process to `0-7`; explicit
workers remain `1,2,4,8`. The range lane pins to CPU `0` and uses one worker.
The capture must fail before building if those affinities are unavailable. Each
capture records the cgroup CPU quota and weight, current-frequency snapshots,
the process contention snapshot, and the reservation receipt. These records
describe the host at capture time; they do not establish that the host was
idle, that frequency was fixed, or that unrelated work was absent.
If the container does not expose a cgroup quota or cpufreq interface, the
corresponding field is recorded as `unavailable` rather than inferred.

## What the selectors actually measure

The CPU lane uses the two existing explicit execution-context selectors:

- `opc_open_session_scaling` opens the generated OPC archive through an
  `OpenSession` with a caller-created local pool. It measures the generated
  archive parse/decompression work and verifies every part after each timed
  sample.
- `cfb_bulk_read_scaling` opens the generated CFB source, preloads and verifies
  all streams before the timer, resets the instrumented source, then measures a
  bulk read through the caller-created execution context and verifies all
  outputs after the timer.

The selected shapes are `many-small` and `few-large`, with an incompressible
payload. The harness reports exact logical task and byte totals for each row,
and the validator requires those totals to be identical at every worker width
for each `(case, corpus)` pair. The OPC `few-large` archive has six members,
four typed payload parts that can run in parallel, and two metadata tasks that
remain serial. The CFB `many-small` case is a warm MiniFAT-cache reread, while
the CFB `few-large` case reads the regular FAT source; they are distinct source
behaviors and neither is a cold-storage result. Worker widths above the
available independent work are reported as saturation, not evidence for an
unbounded pool. The many-small cases expose scheduling and coordination
overhead.

The range lane uses the existing deterministic simulated `ReadAt` source:

- OPC: `opc_range_source_open` and `opc_range_source_open_main_read` on
  `many-small`/incompressible.
- XLSX: `xlsx_range_source_open`, `xlsx_range_source_list_sheets`,
  `xlsx_range_source_first_cell`, and
  `xlsx_range_source_narrow_column_range_scan` on the `dense-wide` workbook.
- Optional CFB follow-up: the two shared simulated selective-read selectors
  on `many-small` and `wide-root`. This is a separate CFB selective-read
  workload, not the same logical work as `cfb_bulk_read_scaling`, and must be
  reported separately.

The comparable range configuration is the retained one: 2,000 us fixed
latency, 250 us per-request overhead, 16 MiB/s bandwidth, and a 65,536-byte
maximum physical range. It is a deterministic source simulation, not a remote
or physical-I/O claim.

## Exact capture commands

Run the prepared `capture.sh` from a clean shell with the feature repository
path, an empty output directory, and a schedule-owner reservation receipt. The
receipt must contain `status=reserved` or `status=granted`,
`scaling_cpu_set=0-7`, and `range_cpu_set=0`. The script creates a detached
worktree at the pinned commit, builds with a fresh target directory, records
the binary hash, and retains the detached measurement worktree for replay
provenance. It never copies a linked-worktree `.git` file. The command is:

```text
RESERVATION_RECEIPT=/path/to/exclusive-schedule.txt \
/var/tmp/litchi-current-head-scaling-capture-plan-v2-20260910/capture.sh \
  /path/to/litchi-spec-gaps \
  /var/tmp/litchi-current-head-scaling-capture-v2-20260910
```

The script's primary lane deliberately keeps the historical protocol for
comparability: three warmups and 20 samples for CPU scaling; two warmups and
ten samples for the high-latency range cases. It runs one fresh process per
worker width, so a 1-worker report cannot warm a 4-worker report. The generated
commands are recorded in `commands.log` before execution. The essential
commands are equivalent to:

```text
env -i HOME="$HOME" PATH="$PATH" RUSTUP_HOME="${RUSTUP_HOME:-$HOME/.rustup}" \
  CARGO_HOME="${CARGO_HOME:-$HOME/.cargo}" TMPDIR="$TMPDIR" LC_ALL=C \
  CARGO_TARGET_DIR="$OUT/target" RUSTFLAGS= CARGO_ENCODED_RUSTFLAGS= \
  CARGO_BUILD_TARGET= CARGO_BUILD_RUSTFLAGS= CARGO_INCREMENTAL=0 \
  RUSTC_WRAPPER= RUSTC_WORKSPACE_WRAPPER= \
  cargo +1.95.0 build --release --locked --manifest-path \
  "$SOURCE/tools/perf-baseline/Cargo.toml" --bin litchi-perf-baseline

taskset -c 0-7 "$BIN" \
  --case opc_open_session_scaling,cfb_bulk_read_scaling \
  --shape many-small,few-large --payload incompressible --workers 1 \
  --warmup 3 --samples 20 --json "$OUT/reports/scaling-w1.json" \
  --corpus-manifest "$OUT/manifests/scaling-w1.catalog.json"
```

Repeat the last command with `--workers 2`, `4`, and `8`, changing the report
and catalog names. The complete script also emits the two range reports:

```text
taskset -c 0 "$BIN" \
  --case opc_range_source_open,opc_range_source_open_main_read \
  --shape many-small --payload incompressible --workers 1 \
  --range-fixed-latency-us 2000 --range-request-overhead-us 250 \
  --range-bandwidth-bytes-per-sec 16777216 \
  --range-max-physical-bytes 65536 --warmup 2 --samples 10 \
  --json "$OUT/reports/range-opc.json" \
  --corpus-manifest "$OUT/manifests/range-opc.catalog.json"

taskset -c 0 "$BIN" \
  --case xlsx_range_source_open,xlsx_range_source_list_sheets,xlsx_range_source_first_cell,xlsx_range_source_narrow_column_range_scan \
  --shape many-small --payload incompressible --xlsx-shape dense-wide \
  --workers 1 --range-fixed-latency-us 2000 \
  --range-request-overhead-us 250 --range-bandwidth-bytes-per-sec 16777216 \
  --range-max-physical-bytes 65536 --warmup 2 --samples 10 \
  --json "$OUT/reports/range-xlsx.json" \
  --corpus-manifest "$OUT/manifests/range-xlsx.catalog.json"
```

The XLSX command is shown across lines for readability; the actual shell array
in `capture.sh` contains each case name as one comma-separated argument. The
optional CFB simulated range command is:

```text
taskset -c 0 "$BIN" \
  --case cfb_selective_simulated_mini_shared_read,cfb_selective_simulated_fat_shared_read \
  --shape many-small,wide-root --payload incompressible --workers 1 \
  --range-fixed-latency-us 2000 --range-request-overhead-us 250 \
  --range-bandwidth-bytes-per-sec 16777216 \
  --range-max-physical-bytes 65536 --warmup 2 --samples 10 \
  --json "$OUT/reports/range-cfb-selective.json" \
  --corpus-manifest "$OUT/manifests/range-cfb-selective.catalog.json"
```

The optional lane is disabled by default in `capture.sh` because the CFB
selectors have a different selective-read workload and should not be folded
into the CPU scaling graph.

For CPU utilization and hardware counters, the harness itself is insufficient:
`parallel_metrics` deliberately marks process thread count and lock wait as
unavailable. After the correctness reports pass, the schedule owners may run
the same exact commands under a separate `perf stat` receipt, one process per
worker, for example:

```text
/usr/bin/perf stat -x, -o "$OUT/perf/scaling-w4.perf.csv" \
  -e task-clock,cycles,instructions,branches,branch-misses,minor-faults,context-switches \
  -- taskset -c 0-7 "$BIN" \
  --case opc_open_session_scaling,cfb_bulk_read_scaling \
  --shape many-small,few-large --payload incompressible --workers 4 \
  --warmup 3 --samples 20 --json "$OUT/reports/scaling-w4.json" \
  --corpus-manifest "$OUT/manifests/scaling-w4.catalog.json"
```

The `perf` receipt is supplemental whole-process evidence. It must record the
exact command, kernel, `perf_event_paranoid`, binary hash, and whether counters
were unavailable. It must not be used to attribute a function-level cause or
to turn task-clock into operation-local CPU utilization.

## Preflight and invariants

Before accepting the reports, run `validate_reports.py` over all four scaling
reports and the two range reports. It checks the commit, clean detached
worktree identity, exact worker selection, sample counts, nonempty samples,
consistent corpus hash and manifest fields across widths, and exact logical
work. It also checks the range source invariants:

- each physical request is at most 65,536 bytes and physical bytes equal
  logical bytes;
- OPC structural open has zero ordinary payload reads/materializations, while
  open-plus-main-read has a positive ordinary payload read and materialization;
- XLSX list has zero timed logical/physical reads;
- XLSX first-cell and narrow-column operations touch a selected worksheet and
  zero unselected worksheet ranges; structural open leaves worksheets deferred.

The validator writes `scaling-analysis.json`. It rejects any change in logical
task or byte totals for a `(case, corpus)` pair across worker widths. It also
records the OPC six-member/four-payload/two-metadata qualification and the
different warm MiniFAT versus regular FAT CFB source behaviors in the analysis
rows. It uses each report's p50 for
`T_N`, with `S_N = T_1/T_N` and efficiency `E_N = S_N/N`. It reports the
Amdahl serial estimate only where `S_N >= 1` and the result is in `[0,1]`:

```text
serial_fraction = (1/S_N - 1/N) / (1 - 1/N)
```

A slowdown (`S_N < 1`), a superlinear result, or an estimate outside the model
is retained as `model_invalid` with the raw speedup and tails. p95 and p99 are
reported as observed tails, not fitted Amdahl values. The four large-task
limits and the small-task scheduling knee are interpreted from the exact task
counts and bytes, never from worker count alone.

A second independent run at the same settings is the required follow-up when a
width changes the case classification or a p99 tail is unstable. Do not change
corpus, affinity, allocator, toolchain, compiler flags, warmup, or sample
protocol between the paired runs.

## What remains unmeasured

The retained records and the current selectors leave these concrete gaps:

1. There is no current-head 1/2/4/8 report on the present host. The historical
   rows cannot establish a regression or improvement because commit, CPU count,
   affinity, and source state differ.
2. There is no current-head p50/p95/p99 scaling curve with paired repeats,
   current corpus hashes, binary identity, and exact source/lock provenance.
3. The scaling selectors expose local worker width and logical work, but no
   process CPU utilization, process thread count, lock-wait interval, or
   operation-local contention counter. The optional `perf stat` lane is
   diagnostic whole-process data; lock-wait remains unavailable unless the
   separate OPC cache contention selector and its direct lock diagnostics are
   scheduled.
4. There is no current-head CPU-versus-simulated-range paired record. The range
   selectors currently use one worker and are not execution-scaling cases; a
   range-source scaling curve would require a new selector/harness change.
5. The existing range evidence covers OPC/XLSX simulated sources. CFB
   simulated selective reads are a separate workload and have no matched
   current-head range/scaling capture; the optional command records that gap
   without merging its work into the two scaling curves.
6. No lane here measures cold physical storage, a real remote source, network
   behavior, allocator totals, peak RSS, copied/decompressed/recompressed
   bytes, or output throughput. Those require separate process-isolated
   protocols and must not be inferred from these elapsed samples.

The next scheduling decision is whether `crypto_profile_review` and
`cfb_root_policy` can reserve the pinned CPU sets without overlapping other
captures. Their receipt must be copied beside the reports. The capture script
must not be started until that receipt and the detached source/lock preflight
are accepted. Any concurrent build, test, capture, CPU quota, or frequency
change belongs in the provenance and limits interpretation; no idle-host
claim may be made from this protocol.
