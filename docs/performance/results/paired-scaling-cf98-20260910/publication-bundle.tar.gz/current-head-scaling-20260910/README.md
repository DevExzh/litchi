# Measured cf98 scaling snapshot: paired publication

This directory publishes the first `cf98bee` snapshot together with its
paired scaling rerun. Both timed scaling captures used the clean detached
source `cf98bee37455e8e6d0e73002ff2e94299ef546cb` (tree
`46c3a5c1c10c0178a4e31db4bf2f2d838ef2beab`) and the same release binary
SHA-256 `727c6e718cf5d64aeb40edaadb2fa3e5c70b005d8c1e827bb296c12341a398b7`.
The publication worktree is feature commit `cf4f383c4c203381880d4c2e8445d2616a53d283`
(tree `f0ec6056e97d3b861128b80b0a52d6b108d616c4`); that commit supplies the
publication documentation and instrumentation context, not the measured
source.

The first capture has four scaling widths plus the two one-worker simulated
range families. The paired capture reran the four scaling widths in order
`4, 1, 8, 2`, with three warmups and 20 samples per result. Both validators
passed, and the paired member manifest confirms equal logical work and byte
vectors across widths. The first and paired p50 values are retained together
for repeatability context; their differences are not a causal regression or
improvement comparison.

The benchmark binary is intentionally not embedded in this Git bundle. Its
size/hash, locked build recipe, and both external capture paths are in
[`binary-identity.txt`](binary-identity.txt) and
[`binary-rebuild-recipe.txt`](binary-rebuild-recipe.txt). The verifier accepts
an optional external binary and checks its actual bytes; without that argument
it verifies the recorded identity and reports that binary-byte verification was
skipped.

## Worker-width observations

The table reports raw p50 elapsed nanoseconds. First-capture values come from
`raw/first/provenance/scaling-analysis.json`; paired values come from
`raw/paired/provenance/paired-scaling-analysis.json`.

| selector and corpus | logical tasks / bytes | first w1 / w2 / w4 / w8 | paired w1 / w2 / w4 / w8 | paired w1-to-w8 ratio |
| --- | ---: | ---: | ---: | ---: |
| CFB bulk, `few-large` | 4 / 16,777,216 | 2,528,087 / 887,064 / 903,139 / 880,204 | 2,707,132 / 875,133 / 885,529 / 891,719 | 3.036x |
| CFB bulk, `many-small` | 256 / 262,144 | 222,181 / 181,806 / 151,440 / 143,831 | 224,796 / 178,196 / 153,510 / 144,551 | 1.555x |
| OPC open session, `few-large` | 6 / 16,778,178 | 4,037,903 / 2,587,891 / 613,932 / 712,828 | 4,334,768 / 2,465,626 / 689,353 / 819,929 | 5.287x |
| OPC open session, `many-small` | 258 / 285,282 | 651,734 / 657,703 / 622,658 / 609,652 | 658,168 / 657,623 / 621,602 / 621,172 | 1.060x |

These are observed ratios for fixed generated workloads. The validators retain
superlinear observations as `model-invalid` and do not support an Amdahl or
parallel-fraction claim. In particular, CFB `few-large` at width 2 and OPC
`few-large` at width 4 are superlinear observations in both captures; their
p95/p99 tails remain in the raw reports.

The CFB `few-large` corpus reads the regular FAT source. CFB `many-small` is a
warm MiniFAT-cache reread, not a cold-source read. The OPC `few-large` archive
has six members, four typed payload parts and two metadata tasks. The logical
task totals are harness work units; they are not process-thread counts or proof
that every task is independently parallel. Process-global thread and exact
lock-wait counters were unavailable.

The paired run used a shared-host reservation on CPUs 0-7. Contention and
reservation snapshots are retained. The host was not claimed idle.

## Simulated range records

Only the first capture contains the one-worker range lane. It uses CPU 0 and a
deterministic `ReadAt` simulation with 2,000 us fixed latency, 250 us request
overhead, 16 MiB/s bandwidth and a 65,536-byte maximum physical range. These
records are not remote, network or physical-storage measurements.

| selector | first p50 elapsed ns | validated source behavior |
| --- | ---: | --- |
| OPC structural open | 26,987,514 | 11 requests / 19,659 bytes; zero ordinary payload reads/materializations |
| OPC open plus main read | 36,288,272 | 15 requests / 20,757 bytes; one 1,036-byte payload read/materialization |
| XLSX structural open | 43,954,782 | workbook metadata read; worksheet payload remains deferred |
| XLSX list sheets | 190 | zero logical and physical reads |
| XLSX first cell | 167,355,131 | selected worksheet only: 190,528 bytes in six reads |
| XLSX narrow-column scan | 171,413,140 | selected worksheet only: 190,528 bytes in six reads |

## Retained evidence and provenance

- [`raw/first/`](raw/first/) retains the first six JSON reports, six catalogs,
  host/build/stdout logs and capture receipts. Its report hashes are bound by
  `raw/first/provenance/capture-complete.json`.
- [`raw/paired/`](raw/paired/) retains the four paired reports and catalogs,
  per-width run metadata, commands, contention snapshots, reservation records,
  paired member manifest, equal-work comparison and paired analysis.
- The exact recovered first runner is
  [`capture.sh.executed-recovered-b3265a00.sh`](provenance/scripts/capture.sh.executed-recovered-b3265a00.sh),
  SHA-256 `b3265a00695bfa4bda2703ba5450d450f3010102addd01606e37d5834db8b42c`.
  The recovery receipt and the two-line redirect diff (`01b1c56f…`) are beside
  it. The paired runner and exact command order are retained in
  [`provenance/scripts/`](provenance/scripts/).
- [`provenance/capture-plan/`](provenance/capture-plan/) retains the source
  identity, plan, lock/toolchain context and validator. The large detached
  source checkout is not duplicated; its commit/tree, clean status, selected
  harness hashes and lock identity are retained under
  [`provenance/source/`](provenance/source/).
- [`provenance/host/`](provenance/host/) retains both scheduling receipts and
  the CPU 2 profile/build receipts referenced by the paired run.
- [`artifact-files.sha256`](artifact-files.sha256) authenticates every regular
  file in this directory except itself. The external binary is deliberately
  outside that file set and is checked only when supplied to the verifier.

Run the portable integrity check from this directory:

```sh
PYTHONDONTWRITEBYTECODE=1 python3 scripts/verify.py
PYTHONDONTWRITEBYTECODE=1 python3 scripts/verify.py \
  --binary /var/tmp/litchi-current-head-scaling-paired-v2-20260910/litchi-perf-baseline
```

The verifier extracts the sealed report bytes into a temporary directory and
executes the bundled first and paired validators afresh. It compares those fresh
outputs with the retained analyses, parses both report sets to recompute every
work/p50 comparison row, and checks that fresh comparison against the retained
receipt. It also verifies all retained report/catalog bytes, source separation
and the sealed artifact set. The second command additionally hashes the supplied
external binary and requires the recorded 58,696,912-byte identity.

## Limits

This record does not establish a production-wide scaling law, causal
bottleneck, latency improvement, cold-cache behavior, remote I/O behavior,
allocation totals, peak RSS, copied/decompressed bytes or output throughput.
The range lane is simulated and one-worker. The paired rerun reduces uncertainty
around the descriptive rows while preserving the shared-host and cache-state
qualifications.

The reviewer handoff is in
[`provenance/review-request.md`](provenance/review-request.md). The raw captures
and reports are immutable inputs to this publication.
