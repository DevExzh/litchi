#!/usr/bin/env python3
"""Verify the portable full-default allocator publication bundle."""
from __future__ import annotations

import argparse
import copy
import gzip
import hashlib
import json
import re
import subprocess
import sys
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parent
APPROVED_DIGEST = "f0fd76293959e72211e06e51b0a2b41f371423fda34c55144077193d262b1670"
VECTOR_NAMES = (
    "allocation_calls",
    "deallocation_calls",
    "reallocation_calls",
    "failed_allocation_calls",
    "allocated_bytes",
    "deallocated_bytes",
    "live_bytes_before",
    "live_bytes_after",
    "peak_live_bytes_before",
    "peak_live_bytes_after",
    "region_peak_live_bytes",
)


class VerificationError(ValueError):
    pass


def fail(condition: bool, message: str) -> None:
    if not condition:
        raise VerificationError(message)


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def canonical_json(value: Any) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


def load_json(path: Path) -> Any:
    with path.open(encoding="utf-8") as stream:
        return json.load(stream)


def load_gzip_json(path: Path) -> tuple[bytes, Any]:
    with gzip.open(path, "rb") as stream:
        payload = stream.read()
    return payload, json.loads(payload)


def result_key_digest(results: list[dict[str, Any]]) -> str:
    keys = {(row["case"], canonical_json(row["corpus"]).decode("utf-8")) for row in results}
    digest = hashlib.sha256()
    for case, corpus in sorted(keys):
        digest.update(case.encode("utf-8"))
        digest.update(b"\0")
        digest.update(corpus.encode("utf-8"))
        digest.update(b"\n")
    return digest.hexdigest()


def verify_bundle_manifest() -> None:
    manifest_path = ROOT / "bundle-manifest.json"
    sidecar_path = ROOT / "bundle-manifest.sha256"
    expected = sidecar_path.read_text(encoding="utf-8").split()[0]
    fail(sha256_file(manifest_path) == expected, "bundle-manifest.sha256 does not match manifest")
    manifest = load_json(manifest_path)
    fail(manifest.get("schema_version") == 1, "bundle manifest schema differs")
    entries = manifest.get("files")
    fail(isinstance(entries, list) and entries, "bundle manifest has no files")
    listed: set[str] = set()
    for entry in entries:
        fail(isinstance(entry, dict), "bundle manifest entry is not an object")
        relative = entry.get("path")
        fail(isinstance(relative, str) and relative and not relative.startswith("/"), "invalid bundle path")
        target = (ROOT / relative).resolve()
        fail(ROOT == target or ROOT in target.parents, f"bundle path escapes root: {relative}")
        fail(relative not in listed, f"duplicate bundle path: {relative}")
        listed.add(relative)
        fail(target.is_file(), f"bundle file is missing: {relative}")
        fail(entry.get("bytes") == target.stat().st_size, f"bundle byte count differs: {relative}")
        fail(entry.get("sha256") == sha256_file(target), f"bundle SHA-256 differs: {relative}")
    actual = {
        path.relative_to(ROOT).as_posix()
        for path in ROOT.rglob("*")
        if path.is_file() and path.name not in {"bundle-manifest.json", "bundle-manifest.sha256"}
    }
    fail(actual == listed, f"bundle file set differs: missing={sorted(listed - actual)}, extra={sorted(actual - listed)}")


def verify_source_patch(manifest: dict[str, Any]) -> None:
    patch = ROOT / "source-delta.patch"
    patch_info = manifest["source_delta_patch"]
    fail(patch_info["sha256"] == sha256_file(patch), "source delta SHA-256 differs")
    headers = re.findall(r"^diff --git a/(.+) b/(.+)$", patch.read_text(encoding="utf-8"), re.MULTILINE)
    paths = sorted(left for left, right in headers if left == right)
    fail(paths == sorted(patch_info["paths"]), "source delta path set differs")
    fail(paths == sorted(manifest["publication_source_paths"]), "source delta does not cover exact publication paths")


def verify_capture(manifest: dict[str, Any]) -> None:
    report_path = ROOT / "capture/raw/full-default-allocator.json.gz"
    catalog_path = ROOT / "capture/raw/full-default-allocator.corpus-manifest-v2.json.gz"
    report_bytes, report = load_gzip_json(report_path)
    catalog_bytes, catalog = load_gzip_json(catalog_path)
    measured = manifest["measured_capture_source"]
    fail(sha256_bytes(report_bytes) == measured["report_sha256"], "raw report hash differs from measured capture")
    fail(sha256_bytes(catalog_bytes) == measured["catalog_file_sha256"], "raw catalog hash differs from measured capture")
    results = report["results"]
    fail(len(results) == 201, "raw report does not contain 201 results")
    coverage = report["allocation_coverage"]
    fail(coverage["result_count"] == 201 and coverage["measured_result_count"] == 201, "allocation coverage count differs")
    fail(coverage["result_key_sha256"] == APPROVED_DIGEST, "allocation coverage digest differs")
    fail(result_key_digest(results) == APPROVED_DIGEST, "retained report digest differs")
    for index, row in enumerate(results):
        metrics = row.get("operation_metrics")
        fail(metrics is not None, f"row {index} has no operation metrics")
        fail(metrics["latency_claim"] == "allocator_instrumented_elapsed_not_latency_claim", f"row {index} exposes allocator elapsed as latency")
        allocation = metrics["allocation"]
        fail(allocation["status"] == "measured" and allocation["scope"] == "operation_global_system_allocator", f"row {index} allocation scope/status differs")
        for name in VECTOR_NAMES:
            vector = allocation[name]
            fail(vector["status"] == "measured" and vector["scope"] == "operation_global_system_allocator", f"row {index} {name} is not measured")
            fail(len(vector["values"]) == 15, f"row {index} {name} length differs")

    fail(len(catalog["case_bindings"]) == 201, "catalog does not contain 201 bindings")
    without_hash = copy.deepcopy(catalog)
    catalog_hash = without_hash.pop("catalog_sha256")
    fail(sha256_bytes(canonical_json(without_hash)) == catalog_hash, "catalog SHA-256 does not validate")
    by_id = {item["id"]: item for item in catalog["corpora"]}
    report_keys = {(row["case"], canonical_json(row["corpus"]).decode("utf-8")) for row in results}
    catalog_keys = set()
    for binding in catalog["case_bindings"]:
        corpus = by_id[binding["corpus_id"]]
        legacy = corpus["legacy_v1"]
        fail(binding["legacy_name"] == legacy["name"], "binding legacy name differs")
        fail(binding["legacy_archive_sha256"] == legacy["archive_sha256"], "binding archive hash differs")
        catalog_keys.add((binding["case"], canonical_json(legacy).decode("utf-8")))
    fail(report_keys == catalog_keys, "report/catalog canonical identity join differs")
    content_value = {
        "corpora": [
            {
                "id": item["id"],
                "archive_sha256": item["bytes"]["archive_sha256"],
                "members": [
                    {"ordinal": member["ordinal"], "name": member["name"], "sha256": member["sha256"]}
                    for member in item["members"]["items"]
                ],
            }
            for item in catalog["corpora"]
        ],
        "case_bindings": [
            {"case": item["case"], "corpus_id": item["corpus_id"], "role": item["role"]}
            for item in catalog["case_bindings"]
        ],
    }
    fail(
        sha256_bytes(canonical_json(content_value)) == catalog["content_set_sha256"],
        "catalog content-set SHA-256 does not validate",
    )
    reference = report["corpus_catalog"]
    for field in ("manifest_version", "catalog_id", "catalog_sha256", "content_set_sha256"):
        fail(reference[field] == catalog[field], f"report/catalog reference differs for {field}")

    checker_result = load_json(ROOT / "capture/checker/full-default-allocator.check.json")
    fail(checker_result["result_count"] == 201 and checker_result["result_key_sha256"] == APPROVED_DIGEST, "retained checker result differs")
    run = load_json(ROOT / "capture/provenance/full-default-allocator.run-provenance.json")
    fail(run["report_sha256"] == measured["report_sha256"], "run provenance report hash differs")
    fail(run["catalog_file_sha256"] == measured["catalog_file_sha256"], "run provenance catalog hash differs")
    fail(run["result_count"] == 201 and run["capture_cpu_affinity"] == "2", "run provenance capture identity differs")
    fail(run["allocator_elapsed_is_latency_claim"] is False and run["latency_eligibility"] == "ineligible", "run provenance exposes latency claim")
    build = load_json(ROOT / "capture/provenance/allocator-build-provenance.json")
    fail(build["build_status"] == 0 and build["build_affinity"] == "8-31", "build provenance status/affinity differs")
    fail(build["binary_sha256"] == run["binary_sha256"], "build/run binary hash differs")
    review = ROOT / "capture/provenance/review-provenance.json"
    clearance = load_json(ROOT / "capture/provenance/review-clearance")
    fail(clearance["review_provenance_sha256"] == sha256_file(review), "review clearance binding differs")


def verify_source_root(source_root: Path, manifest: dict[str, Any]) -> None:
    expected_revision = manifest["integration_base_revision"]
    actual_revision = subprocess.check_output(["git", "-C", str(source_root), "rev-parse", "HEAD"], text=True).strip()
    fail(actual_revision == expected_revision, "source root integration base differs")
    for relative, expected_hash in manifest["publication_source_paths"].items():
        target = source_root / relative
        fail(target.is_file() and sha256_file(target) == expected_hash, f"publication source hash differs: {relative}")
    lib = (source_root / "tools/perf-baseline/src/lib.rs").read_text(encoding="utf-8")
    readme = (source_root / "tools/perf-baseline/README.md").read_text(encoding="utf-8")
    fail("dimensions: result" in lib and '"cache_state".to_owned()' in lib, "cache_state corpus hook was not preserved")
    fail("When a filesystem selector emits warm and cold rows over the same input" in readme, "cache_state README note was not preserved")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-root", type=Path)
    args = parser.parse_args()
    try:
        verify_bundle_manifest()
        manifest = load_json(ROOT / "publication-source-manifest.json")
        verify_source_patch(manifest)
        verify_capture(manifest)
        if args.source_root is not None:
            verify_source_root(args.source_root.resolve(), manifest)
    except (OSError, json.JSONDecodeError, KeyError, subprocess.CalledProcessError, VerificationError) as error:
        print(f"FAIL: {error}", file=sys.stderr)
        return 2
    print(json.dumps({"status": "verified", "result_count": 201, "approved_result_key_sha256": APPROVED_DIGEST}, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
