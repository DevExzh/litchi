#!/usr/bin/env python3
"""Regression for the report/catalog identity join in the full-matrix checker.

The individual catalog and report digests can both be internally valid while
describing different corpus identities.  This test keeps each side's hashes
valid and verifies that the checker rejects both directions of that split.
"""
from __future__ import annotations

import copy
import importlib.util
import json
import tempfile
from pathlib import Path


HERE = Path(__file__).resolve().parent
CHECKER_PATH = HERE / "check-full-default-allocator.py"
SPEC = importlib.util.spec_from_file_location("full_allocator_checker", CHECKER_PATH)
if SPEC is None or SPEC.loader is None:
    raise RuntimeError(f"cannot import {CHECKER_PATH}")
CHECKER = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(CHECKER)

# A one-row fixture exercises the same join without duplicating the 201-row
# capture. The production checker remains unchanged for the real matrix.
CHECKER.RESULT_COUNT = 1
CHECKER.EXPECTED_CASE_COUNTS = {"zip_index": 1}


def catalog_and_report() -> tuple[dict, dict]:
    legacy = {
        "name": "tiny-legacy",
        "archive_bytes": 17,
        "archive_sha256": "a" * 64,
        "member_count": 1,
    }
    catalog = {
        "manifest_version": 2,
        "manifest_kind": "corpus-catalog",
        "catalog_id": "joint-fabrication-test",
        "canonicalization": {"algorithm": "sorted-json-utf8-compact-v1", "hash": "sha256"},
        "catalog_sha256": "",
        "content_set_sha256": "",
        "build": {},
        "corpora": [
            {
                "id": "corpus-0",
                "bytes": {"archive_sha256": "a" * 64},
                "members": {"items": [{"ordinal": 0, "name": "a", "sha256": "b" * 64}]},
                "legacy_v1": legacy,
            }
        ],
        "case_bindings": [
            {
                "case": "zip_index",
                "corpus_id": "corpus-0",
                "legacy_name": legacy["name"],
                "legacy_archive_sha256": legacy["archive_sha256"],
                "role": "timed",
            }
        ],
    }
    content_value = {
        "corpora": [
            {
                "id": "corpus-0",
                "archive_sha256": "a" * 64,
                "members": [{"ordinal": 0, "name": "a", "sha256": "b" * 64}],
            }
        ],
        "case_bindings": [{"case": "zip_index", "corpus_id": "corpus-0", "role": "timed"}],
    }
    catalog["content_set_sha256"] = CHECKER.hashlib.sha256(
        CHECKER.canonical_json(content_value)
    ).hexdigest()
    without_hash = copy.deepcopy(catalog)
    without_hash.pop("catalog_sha256")
    catalog["catalog_sha256"] = CHECKER.hashlib.sha256(
        CHECKER.canonical_json(without_hash)
    ).hexdigest()
    report = {
        "corpus_catalog": {
            "manifest_version": catalog["manifest_version"],
            "catalog_id": catalog["catalog_id"],
            "catalog_sha256": catalog["catalog_sha256"],
            "content_set_sha256": catalog["content_set_sha256"],
        },
        "results": [{"case": "zip_index", "corpus": copy.deepcopy(legacy)}],
    }
    return catalog, report


def rewrite_catalog_hash(catalog: dict) -> None:
    without_hash = copy.deepcopy(catalog)
    without_hash.pop("catalog_sha256")
    catalog["catalog_sha256"] = CHECKER.hashlib.sha256(
        CHECKER.canonical_json(without_hash)
    ).hexdigest()


def assert_rejected(catalog: dict, report: dict, path: Path, label: str) -> None:
    path.write_text(json.dumps(catalog, ensure_ascii=False, sort_keys=True) + "\n", encoding="utf-8")
    try:
        CHECKER.check_catalog(report, path)
    except CHECKER.CheckError:
        return
    raise AssertionError(f"checker accepted {label}")


with tempfile.TemporaryDirectory(prefix="allocator-joint-fabrication-") as directory:
    catalog_path = Path(directory) / "catalog.json"
    catalog, report = catalog_and_report()
    catalog_path.write_text(json.dumps(catalog, sort_keys=True) + "\n", encoding="utf-8")
    CHECKER.check_catalog(report, catalog_path)

    report_fabricated = copy.deepcopy(report)
    report_fabricated["results"][0]["corpus"]["archive_bytes"] = 18
    assert_rejected(catalog, report_fabricated, catalog_path, "a report row with a fabricated corpus")

    catalog_fabricated = copy.deepcopy(catalog)
    catalog_fabricated["corpora"][0]["legacy_v1"]["archive_bytes"] = 18
    rewrite_catalog_hash(catalog_fabricated)
    catalog_fabricated_report = copy.deepcopy(report)
    catalog_fabricated_report["corpus_catalog"]["catalog_sha256"] = catalog_fabricated[
        "catalog_sha256"
    ]
    assert_rejected(
        catalog_fabricated,
        catalog_fabricated_report,
        catalog_path,
        "a catalog with a fabricated legacy_v1 corpus",
    )

    print("joint report/catalog fabrication checks passed")
