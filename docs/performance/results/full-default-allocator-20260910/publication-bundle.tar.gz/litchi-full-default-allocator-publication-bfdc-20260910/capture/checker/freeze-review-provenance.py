#!/usr/bin/env python3
"""Freeze helper/source hashes after the independent review is cleared.

The resulting review-provenance.json is then bound by a separate JSON
review-clearance marker containing its SHA-256. This script is intentionally
never called by the capture runner, so a post-review edit cannot silently
refresh the review binding.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

APPROVED_DEFAULT_RESULT_KEY_SHA256 = (
    "f0fd76293959e72211e06e51b0a2b41f371423fda34c55144077193d262b1670"
)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-root", type=Path, required=True)
    parser.add_argument("--artifacts", type=Path, required=True)
    parser.add_argument("--review-id", required=True)
    parser.add_argument("--reviewer", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    _ = args.source_root.resolve()
    artifacts = args.artifacts.resolve()
    manifest = artifacts / "source-lock-fixture-hashes.json"
    checker = artifacts / "check-full-default-allocator.py"
    refresher = artifacts / "refresh-source-manifest.py"
    runner = artifacts / "run-full-default-allocator-deferred.sh"
    plan = artifacts / "capture-plan.md"
    required = [manifest, checker, refresher, runner, plan]
    for path in required:
        if not path.is_file():
            raise SystemExit(f"missing review artifact: {path}")
    source_manifest = json.loads(manifest.read_text(encoding="utf-8"))
    if source_manifest.get("candidate_root") != str(args.source_root.resolve()):
        raise SystemExit("source manifest candidate root differs")
    review = {
        "schema_version": 1,
        "review_id": args.review_id,
        "review_status": "cleared",
        "reviewer": args.reviewer,
        "approved_default_result_key_sha256": APPROVED_DEFAULT_RESULT_KEY_SHA256,
        "base_revision": source_manifest["base_revision"],
        "source_manifest_sha256": sha256_file(manifest),
        "checker_sha256": sha256_file(checker),
        "refresh_manifest_sha256": sha256_file(refresher),
        "runner_sha256": sha256_file(runner),
        "capture_plan_sha256": sha256_file(plan),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(review, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(review, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
