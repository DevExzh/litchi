#!/usr/bin/env python3
"""Fail-closed checker for the complete default allocator matrix.

This checker validates the actual retained report and its generated corpus
catalog.  It is deliberately independent of the Rust run-time contract: a
successful one-row smoke report, an absent vector, a stale sample order, or a
mixed corpus cannot satisfy this checker.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import subprocess
import sys
from pathlib import Path
from typing import Any


SAMPLES = 15
WARMUPS = 3
RESULT_COUNT = 201
CONTRACT = "default_case_matrix_201_rows"
LATENCY_CLAIM = "allocator_instrumented_elapsed_not_latency_claim"
ALLOCATOR_SCOPE = "operation_global_system_allocator"
ALLOCATOR_INSTRUMENTATION = "system_allocator_operation_scoped"
ALLOCATOR_COUNTER_REVISION = "serialized_region_peak_v3"
ALLOCATOR = "CountingSystemAllocator(std::alloc::System)"
ALIGNMENT = "elapsed_ns.samples_by_elapsed_then_sample_index"
APPROVED_DEFAULT_RESULT_KEY_SHA256 = (
    "f0fd76293959e72211e06e51b0a2b41f371423fda34c55144077193d262b1670"
)
VECTOR_NAMES = (
    "allocation_calls",
    "deallocation_calls",
    "reallocation_calls",
    "failed_allocation_calls",
    "allocated_bytes",
    "deallocated_bytes",
    "live_bytes_before",
    "live_bytes_after",
    "peak_live_bytes_before",
    "peak_live_bytes_after",
    "region_peak_live_bytes",
)
CASES_8 = (
    "zip_index",
    "zip_read_one",
    "opc_open",
    "opc_open_owned",
    "opc_noop_save",
    "opc_mutated_save",
    "opc_source_open",
    "opc_source_open_main_read",
    "opc_source_cached_main_read",
    "opc_source_concurrent_same_part",
    "cfb_open",
    "cfb_list_streams",
    "cfb_read_one",
    "cfb_create_stream_borrowed",
    "cfb_create_stream_owned",
    "cfb_shared_open",
    "cfb_shared_read_one",
    "cfb_shared_concurrent_reads",
)
CASES_3_WRITERS = ("doc_fresh_write_to", "xls_fresh_write_to", "ppt_fresh_write_to")
CASES_3_XLSX = (
    "xlsx_open_owned",
    "xlsx_list_sheets",
    "xlsx_first_cell",
    "xlsx_full_cell_scan",
    "xlsx_narrow_column_range_scan",
    "xlsx_noop_commit",
    "xlsx_noop_commit_save",
    "xlsx_one_cell_commit",
    "xlsx_one_cell_commit_save",
    "xlsx_one_percent_commit",
    "xlsx_one_percent_commit_save",
    "xlsx_source_open",
    "xlsx_source_list_sheets",
    "xlsx_source_first_cell",
    "xlsx_source_narrow_column_range_scan",
    "odp_existing_append_lifecycle",
)
EXPECTED_CASE_COUNTS = {
    **{case: 8 for case in CASES_8},
    **{case: 3 for case in CASES_3_WRITERS + CASES_3_XLSX},
}
EXPECTED_CASE_ORDER = CASES_8 + CASES_3_WRITERS + CASES_3_XLSX
EXPECTED_CONFIG = {
    "samples_per_case": SAMPLES,
    "warmup_iterations_per_case": WARMUPS,
    "filesystem_cache_states": ["warm", "cold-requested"],
    "filesystem_fresh_child_per_sample": True,
    "filesystem_process_isolated": True,
    "filesystem_root_selected": False,
    "cases": list(EXPECTED_CASE_ORDER),
    "corpus_shapes": ["tiny", "many-small", "few-large", "wide-root"],
    "payload_kinds": ["compressible", "incompressible"],
    "writer_shapes": ["tiny", "large", "payload-heavy"],
    "xlsx_shapes": ["tiny", "medium", "dense-wide"],
    "xlsb_shapes": ["tiny", "medium", "large", "sparse"],
    "xlsx_cell_crud_shapes": ["medium", "dense-sparse"],
    "xlsx_row_visibility_shapes": ["medium", "large"],
    "semantic_shapes": ["tiny", "medium", "large"],
    "rtf_variants": ["plain"],
    "range_simulation": {
        "fixed_latency_us": 100,
        "request_overhead_us": 25,
        "bandwidth_bytes_per_second": 52_428_800,
        "max_physical_range_bytes": 4096,
    },
    "execution_workers": [1],
    "opc_cache_lock_diagnostics": False,
}
EXPECTED_REPORT_KEYS = {
    "schema_version",
    "tool",
    "binary_identity",
    "environment",
    "configuration",
    "parallel_metrics",
    "results",
    "allocation_coverage",
    "corpus_catalog",
}
EXPECTED_TOOL = {
    "name": "litchi-perf-baseline",
    "version": "0.1.0",
    "binary": "litchi-perf-baseline-alloc",
    "profile": "release",
    "target_os": "linux",
    "target_arch": "x86_64",
    "instrumentation": ALLOCATOR_INSTRUMENTATION,
    "allocator_counter_revision": ALLOCATOR_COUNTER_REVISION,
}
EXPECTED_ENVIRONMENT_KEYS = {
    "rustc_version",
    "git_revision",
    "git_worktree_dirty",
    "logical_cpus_available",
    "allocator",
    "rustflags",
    "cargo_build_target",
    "perf_event_paranoid",
    "os",
    "kernel",
    "cpu_model",
    "total_memory_bytes",
    "page_size_bytes",
    "filesystem_type",
    "source_destination_same_device",
    "cpu_affinity",
    "storage_identifier",
}


class CheckError(ValueError):
    pass


def reject_constant(value: str) -> None:
    raise CheckError(f"non-finite JSON constant {value}")


def no_duplicate_object(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise CheckError(f"duplicate JSON key {key!r}")
        result[key] = value
    return result


def load_json(path: Path) -> Any:
    try:
        with path.open(encoding="utf-8") as stream:
            return json.load(
                stream,
                object_pairs_hook=no_duplicate_object,
                parse_constant=reject_constant,
            )
    except (OSError, json.JSONDecodeError, CheckError) as error:
        raise CheckError(f"cannot read {path}: {error}") from error


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    try:
        with path.open("rb") as stream:
            for block in iter(lambda: stream.read(1024 * 1024), b""):
                digest.update(block)
    except OSError as error:
        raise CheckError(f"cannot hash {path}: {error}") from error
    return digest.hexdigest()


def canonical_json(value: Any) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode(
        "utf-8"
    )


def result_key_manifest_sha256(keys: set[tuple[str, str]]) -> str:
    digest = hashlib.sha256()
    for case, corpus_identity in sorted(keys):
        digest.update(case.encode("utf-8"))
        digest.update(b"\0")
        digest.update(corpus_identity.encode("utf-8"))
        digest.update(b"\n")
    return digest.hexdigest()


def require(condition: bool, message: str) -> None:
    if not condition:
        raise CheckError(message)


def object_at(value: Any, location: str) -> dict[str, Any]:
    require(isinstance(value, dict), f"{location} must be an object")
    return value


def list_at(value: Any, location: str) -> list[Any]:
    require(isinstance(value, list), f"{location} must be an array")
    return value


def exact_keys(value: dict[str, Any], expected: set[str], location: str) -> None:
    actual = set(value)
    require(actual == expected, f"{location} keys differ: expected {sorted(expected)}, got {sorted(actual)}")


def integer(value: Any, location: str) -> int:
    require(isinstance(value, int) and not isinstance(value, bool), f"{location} must be an integer")
    require(value >= 0, f"{location} must be non-negative")
    return value


def permutation(value: Any, length: int, location: str) -> list[int]:
    values = list_at(value, location)
    require(len(values) == length, f"{location} length {len(values)} != {length}")
    result = [integer(item, f"{location}[{index}]") for index, item in enumerate(values)]
    require(sorted(result) == list(range(length)), f"{location} is not a 0..{length - 1} permutation")
    return result


def check_source_manifest(path: Path, source_root_arg: Path) -> dict[str, Any]:
    manifest = object_at(load_json(path), "source manifest")
    root = source_root_arg.resolve()
    require(manifest.get("candidate_root") == str(root), "source manifest candidate root differs")

    def git(*args: str) -> str:
        try:
            return subprocess.check_output(
                ["git", "-C", str(root), *args], text=True, stderr=subprocess.STDOUT
            ).strip()
        except subprocess.CalledProcessError as error:
            raise CheckError(f"git {' '.join(args)} failed: {error.output}") from error

    require(git("rev-parse", "HEAD") == manifest["base_revision"], "candidate HEAD differs from manifest")
    diff = subprocess.check_output(["git", "-C", str(root), "diff", "--binary"])
    require(
        hashlib.sha256(diff).hexdigest() == manifest["tracked_diff_sha256"],
        "tracked source diff hash differs from manifest",
    )
    tracked_paths = sorted(
        filter(None, git("diff", "--name-only").splitlines())
    )
    require(tracked_paths == manifest["tracked_diff_paths"], "tracked diff path set differs from manifest")
    untracked_paths = sorted(filter(None, git("ls-files", "--others", "--exclude-standard").splitlines()))
    require(untracked_paths == sorted(manifest["untracked_paths"]), "untracked source path set differs from manifest")

    for relative, expected_hash in object_at(manifest["file_sha256"], "source manifest file_sha256").items():
        actual_path = root / relative
        require(actual_path.is_file(), f"manifest file is missing: {relative}")
        require(sha256_file(actual_path) == expected_hash, f"source hash differs for {relative}")

    recipe = object_at(manifest["fixture_recipe"], "source manifest fixture_recipe")
    recipe_hash = hashlib.sha256(canonical_json(recipe)).hexdigest()
    require(recipe_hash == manifest["fixture_recipe_sha256"], "fixture recipe hash differs")
    return manifest


def check_review_provenance(
    provenance_path: Path,
    clearance_path: Path,
    artifacts: Path,
    source_manifest_path: Path,
    source_root: Path,
    source_manifest: dict[str, Any],
) -> None:
    provenance = object_at(load_json(provenance_path), "review provenance")
    exact_keys(
        provenance,
        {
            "schema_version",
            "review_id",
            "review_status",
            "reviewer",
            "approved_default_result_key_sha256",
            "base_revision",
            "source_manifest_sha256",
            "checker_sha256",
            "refresh_manifest_sha256",
            "runner_sha256",
            "capture_plan_sha256",
        },
        "review provenance",
    )
    require(provenance["schema_version"] == 1, "review provenance schema differs")
    require(provenance["review_status"] == "cleared", "review provenance is not cleared")
    require(isinstance(provenance["review_id"], str) and provenance["review_id"], "review provenance id is empty")
    require(isinstance(provenance["reviewer"], str) and provenance["reviewer"], "review provenance reviewer is empty")
    require(
        provenance["approved_default_result_key_sha256"]
        == APPROVED_DEFAULT_RESULT_KEY_SHA256,
        "review provenance approved matrix digest differs",
    )
    require(provenance["base_revision"] == source_manifest["base_revision"], "review provenance base revision differs")
    require(
        provenance["source_manifest_sha256"] == sha256_file(source_manifest_path),
        "review provenance source manifest hash differs",
    )
    helper_hashes = {
        "checker_sha256": artifacts / "check-full-default-allocator.py",
        "refresh_manifest_sha256": artifacts / "refresh-source-manifest.py",
        "runner_sha256": artifacts / "run-full-default-allocator-deferred.sh",
        "capture_plan_sha256": artifacts / "capture-plan.md",
    }
    for field, path in helper_hashes.items():
        require(path.is_file(), f"review provenance helper is missing: {path}")
        require(provenance[field] == sha256_file(path), f"review provenance hash differs for {path.name}")

    clearance = object_at(load_json(clearance_path), "review clearance")
    exact_keys(
        clearance,
        {"schema_version", "review_id", "reviewer", "review_provenance_sha256"},
        "review clearance",
    )
    require(clearance["schema_version"] == 1, "review clearance schema differs")
    require(clearance["review_id"] == provenance["review_id"], "review clearance id differs")
    require(clearance["reviewer"] == provenance["reviewer"], "review clearance reviewer differs")
    require(
        clearance["review_provenance_sha256"] == sha256_file(provenance_path),
        "review clearance does not bind the frozen review provenance",
    )


def check_binary_identity(report: dict[str, Any], binary: Path) -> None:
    identity = object_at(report["binary_identity"], "binary_identity")
    exact_keys(identity, {"path", "binary_sha256", "binary_bytes", "mode_bits", "executable", "profile"}, "binary_identity")
    binary = binary.resolve()
    require(Path(identity["path"]).resolve() == binary, "report binary path differs from requested executable")
    require(identity["binary_sha256"] == sha256_file(binary), "report binary SHA-256 differs from executable")
    require(identity["binary_bytes"] == binary.stat().st_size, "report binary size differs from executable")
    require(identity["profile"] == "release", "report binary profile is not release")
    require(identity["executable"] is True, "report binary is not executable")


def check_catalog(report: dict[str, Any], catalog_path: Path) -> None:
    reference = object_at(report["corpus_catalog"], "corpus_catalog reference")
    exact_keys(reference, {"manifest_version", "catalog_id", "catalog_sha256", "content_set_sha256"}, "corpus_catalog reference")
    catalog = object_at(load_json(catalog_path), "corpus catalog")
    exact_keys(
        catalog,
        {
            "manifest_version",
            "manifest_kind",
            "catalog_id",
            "canonicalization",
            "catalog_sha256",
            "content_set_sha256",
            "build",
            "corpora",
            "case_bindings",
        },
        "corpus catalog",
    )
    require(catalog["manifest_version"] == 2, "corpus catalog version is not 2")
    require(catalog["manifest_kind"] == "corpus-catalog", "corpus catalog kind differs")
    require(catalog["canonicalization"] == {"algorithm": "sorted-json-utf8-compact-v1", "hash": "sha256"}, "corpus canonicalization differs")
    for field in ("manifest_version", "catalog_id", "catalog_sha256", "content_set_sha256"):
        require(reference[field] == catalog[field], f"report/catalog reference differs for {field}")

    without_hash = copy.deepcopy(catalog)
    without_hash.pop("catalog_sha256")
    catalog_hash = hashlib.sha256(canonical_json(without_hash)).hexdigest()
    require(catalog_hash == catalog["catalog_sha256"], "corpus catalog SHA-256 does not validate")
    corpora = list_at(catalog["corpora"], "corpus catalog corpora")
    bindings = list_at(catalog["case_bindings"], "corpus catalog case_bindings")
    require(len(bindings) == RESULT_COUNT, f"corpus catalog has {len(bindings)} bindings, expected {RESULT_COUNT}")
    corpora_by_id: dict[str, dict[str, Any]] = {}
    for index, item in enumerate(corpora):
        corpus = object_at(item, f"corpora[{index}]")
        corpus_id = corpus.get("id")
        require(isinstance(corpus_id, str) and corpus_id, f"corpora[{index}] has an invalid id")
        require(corpus_id not in corpora_by_id, f"duplicate corpus id {corpus_id}")
        corpora_by_id[corpus_id] = corpus

    report_keys: set[tuple[str, str]] = set()
    for index, item in enumerate(list_at(report["results"], "report.results")):
        row = object_at(item, f"report.results[{index}]")
        corpus = object_at(row.get("corpus"), f"report.results[{index}].corpus")
        report_keys.add((row["case"], canonical_json(corpus).decode("utf-8")))

    binding_keys: set[tuple[str, str]] = set()
    catalog_row_keys: set[tuple[str, str]] = set()
    binding_counts = {case: 0 for case in EXPECTED_CASE_COUNTS}
    for index, item in enumerate(bindings):
        binding = object_at(item, f"case_bindings[{index}]")
        exact_keys(
            binding,
            {"case", "corpus_id", "legacy_name", "legacy_archive_sha256", "role"},
            f"case_bindings[{index}]",
        )
        require(binding.get("role") == "timed", f"case_bindings[{index}] is not timed")
        case = binding.get("case")
        corpus_id = binding.get("corpus_id")
        require(case in EXPECTED_CASE_COUNTS, f"catalog contains unexpected case {case!r}")
        require(corpus_id in corpora_by_id, f"catalog binding {index} references unknown corpus")
        legacy = object_at(corpora_by_id[corpus_id].get("legacy_v1"), f"corpora[{corpus_id}].legacy_v1")
        require(binding["legacy_name"] == legacy.get("name"), f"catalog binding {index} legacy name disagrees with legacy_v1")
        require(
            binding["legacy_archive_sha256"] == legacy.get("archive_sha256"),
            f"catalog binding {index} archive hash disagrees with legacy_v1",
        )
        key = (case, corpus_id)
        require(key not in binding_keys, f"duplicate catalog binding {key}")
        binding_keys.add(key)
        catalog_row_keys.add((case, canonical_json(legacy).decode("utf-8")))
        binding_counts[case] += 1
    require(binding_counts == EXPECTED_CASE_COUNTS, "catalog case binding counts do not match 201-row matrix")
    require(report_keys == catalog_row_keys, "report case/corpus keys do not exactly match catalog legacy_v1 bindings")

    content_value = {
        "corpora": [
            {
                "id": item["id"],
                "archive_sha256": item["bytes"]["archive_sha256"],
                "members": [
                    {"ordinal": member["ordinal"], "name": member["name"], "sha256": member["sha256"]}
                    for member in item["members"]["items"]
                ],
            }
            for item in corpora
        ],
        "case_bindings": [
            {"case": item["case"], "corpus_id": item["corpus_id"], "role": item["role"]}
            for item in bindings
        ],
    }
    content_hash = hashlib.sha256(canonical_json(content_value)).hexdigest()
    require(content_hash == catalog["content_set_sha256"], "corpus content-set SHA-256 does not validate")


def check_report(
    report_path: Path,
    binary: Path,
    catalog_path: Path,
    source_manifest_path: Path,
    source_root: Path,
    review_provenance_path: Path,
    review_clearance_path: Path,
    artifacts: Path,
) -> dict[str, Any]:
    report = object_at(load_json(report_path), "allocator report")
    exact_keys(report, EXPECTED_REPORT_KEYS, "allocator report")
    require(report.get("schema_version") == 1, "report schema_version is not 1")
    require(report["tool"] == EXPECTED_TOOL, "allocator tool identity differs")
    check_binary_identity(report, binary)

    environment = object_at(report["environment"], "environment")
    exact_keys(environment, EXPECTED_ENVIRONMENT_KEYS, "environment")
    manifest = check_source_manifest(source_manifest_path, source_root)
    check_review_provenance(
        review_provenance_path,
        review_clearance_path,
        artifacts,
        source_manifest_path,
        source_root,
        manifest,
    )
    require(environment.get("git_revision") == manifest["base_revision"], "report git revision differs")
    require(environment.get("git_worktree_dirty") is True, "report must identify the intentionally dirty candidate")
    require(environment.get("allocator") == ALLOCATOR, "report allocator identity differs")
    require(str(environment.get("rustc_version", "")).startswith(manifest["toolchain"]["rustc_version_prefix"]), "report rustc does not use pinned toolchain")
    require(environment.get("rustflags") == manifest["build"]["rustflags"], "report RUSTFLAGS differs")
    require(environment.get("cpu_affinity") == manifest["capture"]["cpu_affinity"], "report CPU affinity differs")

    configuration = object_at(report["configuration"], "configuration")
    require(configuration == EXPECTED_CONFIG, "allocator configuration is not the complete default 201-row selection")
    coverage = object_at(report["allocation_coverage"], "allocation_coverage")
    exact_keys(
        coverage,
        {
            "schema_version",
            "contract",
            "result_count",
            "expected_result_count",
            "measured_result_count",
            "samples_per_result",
            "allocation_status",
            "latency_claim",
            "result_key_sha256",
        },
        "allocation_coverage",
    )
    require(coverage["schema_version"] == 1, "allocation coverage schema differs")
    require(coverage["contract"] == CONTRACT, "allocation coverage contract differs")
    require(coverage["result_count"] == RESULT_COUNT, "allocation coverage result count differs")
    require(coverage["expected_result_count"] == RESULT_COUNT, "allocation coverage expected count differs")
    require(coverage["measured_result_count"] == RESULT_COUNT, "allocation coverage measured count differs")
    require(coverage["samples_per_result"] == SAMPLES, "allocation coverage sample count differs")
    require(coverage["allocation_status"] == "measured", "allocation coverage status differs")
    require(coverage["latency_claim"] == LATENCY_CLAIM, "allocation coverage latency claim differs")
    require(
        coverage["result_key_sha256"] == APPROVED_DEFAULT_RESULT_KEY_SHA256,
        "allocation coverage result-key digest is not the approved default matrix",
    )

    results = list_at(report["results"], "results")
    require(len(results) == RESULT_COUNT, f"report has {len(results)} results, expected {RESULT_COUNT}")
    observed_counts = {case: 0 for case in EXPECTED_CASE_COUNTS}
    seen_result_keys: set[tuple[str, str]] = set()
    for index, raw in enumerate(results):
        row = object_at(raw, f"results[{index}]")
        require(row.get("case") in EXPECTED_CASE_COUNTS, f"results[{index}] has unexpected case")
        case = row["case"]
        observed_counts[case] += 1
        require("cache_state" not in row, f"results[{index}] unexpectedly has a filesystem cache state")
        corpus = object_at(row.get("corpus"), f"results[{index}].corpus")
        key = (case, canonical_json(corpus).decode("utf-8"))
        require(key not in seen_result_keys, f"duplicate case/corpus result at row {index}")
        seen_result_keys.add(key)

        elapsed = object_at(row.get("elapsed_ns"), f"results[{index}].elapsed_ns")
        require(len(list_at(elapsed.get("samples"), f"results[{index}].elapsed_ns.samples")) == SAMPLES, f"results[{index}] elapsed sample count differs")
        for sample_index, value in enumerate(elapsed["samples"]):
            integer(value, f"results[{index}].elapsed_ns.samples[{sample_index}]")
        sample_order = permutation(elapsed.get("sample_order"), SAMPLES, f"results[{index}].elapsed_ns.sample_order")

        metrics = object_at(row.get("operation_metrics"), f"results[{index}].operation_metrics")
        require(metrics.get("sample_count") == SAMPLES, f"results[{index}] operation sample count differs")
        metric_order = permutation(metrics.get("sample_indices"), SAMPLES, f"results[{index}].operation_metrics.sample_indices")
        require(metric_order == sample_order, f"results[{index}] operation/sample order disagrees with elapsed_ns")
        require(metrics.get("alignment") == ALIGNMENT, f"results[{index}] alignment differs")
        require(metrics.get("latency_claim") == LATENCY_CLAIM, f"results[{index}] exposes allocator elapsed as latency")

        allocation = object_at(metrics.get("allocation"), f"results[{index}].operation_metrics.allocation")
        exact_keys(allocation, {"status", "scope", *VECTOR_NAMES}, f"results[{index}].operation_metrics.allocation")
        require(allocation.get("status") == "measured", f"results[{index}] allocation status is not measured")
        require(allocation.get("scope") == ALLOCATOR_SCOPE, f"results[{index}] allocation scope differs")
        for name in VECTOR_NAMES:
            vector = object_at(allocation.get(name), f"results[{index}].operation_metrics.allocation.{name}")
            exact_keys(vector, {"values", "status", "scope"}, f"results[{index}].operation_metrics.allocation.{name}")
            require(vector.get("status") == "measured", f"results[{index}] {name} status is not measured")
            require(vector.get("scope") == ALLOCATOR_SCOPE, f"results[{index}] {name} scope differs")
            values = list_at(vector.get("values"), f"results[{index}].operation_metrics.allocation.{name}.values")
            require(len(values) == SAMPLES, f"results[{index}] {name} vector length differs")
            for value_index, value in enumerate(values):
                integer(value, f"results[{index}] {name}[{value_index}]")

    require(observed_counts == EXPECTED_CASE_COUNTS, "result case counts do not match 144+9+48=201")
    result_key_sha256 = result_key_manifest_sha256(seen_result_keys)
    require(
        coverage["result_key_sha256"] == result_key_sha256,
        "allocation coverage result-key digest does not match retained rows",
    )
    require(
        result_key_sha256 == APPROVED_DEFAULT_RESULT_KEY_SHA256,
        "retained report case/corpus digest is not the approved default matrix",
    )
    check_catalog(report, catalog_path)
    return {
        "report_sha256": sha256_file(report_path),
        "catalog_file_sha256": sha256_file(catalog_path),
        "catalog_sha256": report["corpus_catalog"]["catalog_sha256"],
        "content_set_sha256": report["corpus_catalog"]["content_set_sha256"],
        "result_count": len(results),
        "case_counts": observed_counts,
        "result_key_sha256": result_key_sha256,
        "allocator_elapsed_is_latency_claim": False,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--report", type=Path)
    parser.add_argument("--catalog", type=Path)
    parser.add_argument("--binary", type=Path)
    parser.add_argument("--source-root", type=Path, required=True)
    parser.add_argument("--source-manifest", type=Path, required=True)
    parser.add_argument("--review-provenance", type=Path, required=True)
    parser.add_argument("--review-clearance", type=Path, required=True)
    parser.add_argument("--artifacts", type=Path, required=True)
    parser.add_argument("--verify-review-only", action="store_true")
    args = parser.parse_args()
    try:
        manifest = check_source_manifest(args.source_manifest, args.source_root)
        check_review_provenance(
            args.review_provenance,
            args.review_clearance,
            args.artifacts,
            args.source_manifest,
            args.source_root,
            manifest,
        )
        if args.verify_review_only:
            result = {"review_provenance": "verified", "approved_result_key_sha256": APPROVED_DEFAULT_RESULT_KEY_SHA256}
        else:
            for name, value in (
                ("--report", args.report),
                ("--catalog", args.catalog),
                ("--binary", args.binary),
            ):
                if value is None:
                    raise CheckError(f"{name} is required unless --verify-review-only is used")
            result = check_report(
                args.report,
                args.binary,
                args.catalog,
                args.source_manifest,
                args.source_root,
                args.review_provenance,
                args.review_clearance,
                args.artifacts,
            )
    except (CheckError, OSError, subprocess.CalledProcessError) as error:
        print(f"FAIL: {error}", file=sys.stderr)
        return 2
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
