#!/usr/bin/env python3
"""Freeze candidate/lock/generator provenance for the deferred capture."""
from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
from pathlib import Path


SOURCE_FILES = (
    "tools/perf-baseline/Cargo.toml",
    "tools/perf-baseline/Cargo.lock",
    "tools/perf-baseline/src/lib.rs",
    "tools/perf-baseline/src/operation_metrics.rs",
    "tools/perf-baseline/src/corpus_manifest.rs",
    "tools/perf-baseline/src/odp_existing_append.rs",
    "tools/perf-baseline/README.md",
    "docs/performance/FULL_DEFAULT_ALLOCATOR_COVERAGE.md",
)
CASES_8 = (
    "zip_index", "zip_read_one", "opc_open", "opc_open_owned", "opc_noop_save",
    "opc_mutated_save", "opc_source_open", "opc_source_open_main_read",
    "opc_source_cached_main_read", "opc_source_concurrent_same_part", "cfb_open",
    "cfb_list_streams", "cfb_read_one", "cfb_create_stream_borrowed",
    "cfb_create_stream_owned", "cfb_shared_open", "cfb_shared_read_one",
    "cfb_shared_concurrent_reads",
)
CASES_3_WRITERS = ("doc_fresh_write_to", "xls_fresh_write_to", "ppt_fresh_write_to")
CASES_3_XLSX = (
    "xlsx_open_owned", "xlsx_list_sheets", "xlsx_first_cell", "xlsx_full_cell_scan",
    "xlsx_narrow_column_range_scan", "xlsx_noop_commit", "xlsx_noop_commit_save",
    "xlsx_one_cell_commit", "xlsx_one_cell_commit_save", "xlsx_one_percent_commit",
    "xlsx_one_percent_commit_save", "xlsx_source_open", "xlsx_source_list_sheets",
    "xlsx_source_first_cell", "xlsx_source_narrow_column_range_scan",
    "odp_existing_append_lifecycle",
)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def git(root: Path, *args: str) -> str:
    return subprocess.check_output(["git", "-C", str(root), *args], text=True).strip()


def canonical(value: object) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    root = args.source_root.resolve()
    file_sha256 = {relative: sha256_file(root / relative) for relative in SOURCE_FILES}
    diff = subprocess.check_output(["git", "-C", str(root), "diff", "--binary"])
    tracked_diff_paths = sorted(filter(None, git(root, "diff", "--name-only").splitlines()))
    untracked_paths = sorted(filter(None, git(root, "ls-files", "--others", "--exclude-standard").splitlines()))
    cases = {case: 8 for case in CASES_8}
    cases.update({case: 3 for case in CASES_3_WRITERS + CASES_3_XLSX})
    recipe = {
        "protocol": "full-default-allocator-v1",
        "generator": "in_process_deterministic_case_corpora",
        "external_fixture_files": [],
        "source_files": [
            {"path": relative, "sha256": file_sha256[relative]}
            for relative in SOURCE_FILES
            if relative
            in {
                "tools/perf-baseline/src/lib.rs",
                "tools/perf-baseline/src/corpus_manifest.rs",
                "tools/perf-baseline/src/odp_existing_append.rs",
            }
        ],
        "case_rows": cases,
        "result_count": 201,
        "samples_per_case": 15,
        "warmup_iterations_per_case": 3,
        "filesystem_cache_states": ["warm", "cold-requested"],
        "execution_workers": [1],
    }
    manifest = {
        "schema_version": 1,
        "candidate_root": str(root),
        "base_revision": git(root, "rev-parse", "HEAD"),
        "tracked_diff_sha256": hashlib.sha256(diff).hexdigest(),
        "tracked_diff_paths": tracked_diff_paths,
        "untracked_paths": untracked_paths,
        "file_sha256": file_sha256,
        "fixture_recipe": recipe,
        "fixture_recipe_sha256": hashlib.sha256(canonical(recipe)).hexdigest(),
        "toolchain": {
            "rustc_version_prefix": "rustc 1.95.0 ",
            "rustup_home": "/tmp/litchi-spec-gap-rustup",
            "cargo_version": "cargo 1.95.0 (f2d3ce0bd 2026-03-21)",
        },
        "build": {
            "rustflags": "-D warnings -D deprecated",
            "cargo_build_jobs": 4,
            "cargo_incremental": "0",
            "cargo_profile_release_debug": "0",
            "target_dir": "/var/tmp/litchi-full-default-allocator-candidate-20260910-target",
            "lock_overlay": None,
        },
        "capture": {
            "cpu_affinity": "2",
            "workers": [1],
            "normal_timing_gate": "must be complete before allocator launch",
            "review_gate": "xlsx_current_review and opc_capture_limits schedule clearance",
            "allocator_elapsed_latency_claim": "ineligible",
        },
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"output": str(args.output), "tracked_diff_sha256": manifest["tracked_diff_sha256"], "fixture_recipe_sha256": manifest["fixture_recipe_sha256"]}, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
