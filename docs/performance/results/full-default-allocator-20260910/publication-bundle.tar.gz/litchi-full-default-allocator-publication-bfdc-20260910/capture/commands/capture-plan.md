# Full default allocator capture plan (201 rows; deferred)

This plan is for the dirty candidate worktree
`/var/tmp/litchi-full-default-allocator-candidate-20260910` at
`fccbe6595f3a29561a8bfc6c192d8fa5e874ad05`. It prepares a complete resource
capture; it does not run the workload while CPU 2 is reserved for the normal
capture or while either independent review gate is open.

The allocator binary is evidence-only. Its elapsed samples are retained for
sample identity and boundary audit, and are explicitly ineligible for latency
comparisons. The run is valid only when the checker proves all 201 retained
rows and every operation-scoped vector.

## Frozen provenance at preparation

The candidate has intentional uncommitted performance-harness edits. The
capture binds the dirty source with the base revision plus the binary tracked
diff hash and the untracked coverage-document hash; a clean-tree report would
be a provenance failure for this candidate.

- source manifest:
  `source-lock-fixture-hashes.json` (current SHA-256 `edc871faa5a95342f0db939d843f8df2d922d7cccba65ee40167a99a66b98ec5`)
- tracked diff SHA-256: see the immutable value in the source manifest
- perf harness lock SHA-256:
  `911d911aca4bb68988d5faa4e46c71e95dcdc3107a7aef042aa3e2fa2fe5477d`
- fixture recipe SHA-256:
  `52176b74b5e7341d745a22dd1ed738e13cb0398e1240900c6947720ad7afd6bc`
- Rust toolchain: `rustc 1.95.0 (59807616e 2026-04-14)`, Cargo
  `1.95.0 (f2d3ce0bd 2026-03-21)`, `RUSTUP_HOME=/tmp/litchi-spec-gap-rustup`
- build target:
  `/var/tmp/litchi-full-default-allocator-candidate-20260910-target`
- build lock mode: `--locked`, no generated lock overlay
- CPU pin: `taskset --cpu-list 2`; allocator process worker selection: `--workers 1`

The immutable tracked diff value currently recorded by the manifest is
`0488bd832786d84bcd43065f35a510f2276e5002d840f2f22e5d81dbb5004c44`.

The complete file-level hashes, changed-path set, lock identity, generator
source hashes, and recipe are in `source-lock-fixture-hashes.json`. Refresh
that manifest only after an approved candidate change and before rebuilding;
the deferred runner refuses source or lock drift.

## Matrix and fixture identity

The runner uses the harness defaults for the complete `Case::DEFAULT` matrix,
made explicit as `--samples 15 --warmup 3 --workers 1`:

- 18 ZIP/OPC and CFB/OLE2 cases × 8 corpus combinations = 144 rows.
- 3 fresh DOC/XLS/PPT writer cases × 3 writer shapes = 9 rows.
- 15 XLSX snapshot/edit/save cases × 3 XLSX shapes = 45 rows.
- 1 existing ODP append lifecycle × 3 semantic shapes = 3 rows.
- Total: 201 rows, each retaining 15 measured samples after 3 warmups.

All corpora are generated in-process by the pinned candidate generator; there
are no external fixture files. The run passes `--corpus-manifest`, and the
sidecar catalog must contain 201 timed case/corpus bindings. The checker
validates the catalog's own SHA-256 and content-set SHA-256, the report's
catalog reference, each case count, and the full result corpus identity.

## Capture gates and exact command

`run-full-default-allocator-deferred.sh` is the only launch wrapper. It
requires both marker files below and refuses to start if a litchi performance
binary is still running:

- `review-provenance.json`: frozen by the independent `xlsx_current_review` /
  `opc_capture_limits` handoff after the candidate is frozen. It binds the
  candidate base revision, source manifest, checker, manifest refresher,
  runner, capture plan, and the approved default result-key digest
  `f0fd76293959e72211e06e51b0a2b41f371423fda34c55144077193d262b1670`.
- `review-clearance`: a separate marker that names the review provenance
  SHA-256. The checker rejects a clearance for any other provenance file.
- `normal-cpu2-timing-complete`: written after the normal CPU-2 timing capture
  has terminated and its retained vectors are closed.

The normal timing owner reported its terminal state; the second marker still
belongs to the scheduler, so this preparation does not infer clearance from a
message or from an idle process list. After both gates are recorded, the exact
command is:

```sh
RUN_FULL_DEFAULT_ALLOCATOR_AFTER_REVIEW=1 \
  /var/tmp/litchi-full-default-allocator-candidate-20260910-capture/run-full-default-allocator-deferred.sh
```

The wrapper first compares the current source/lock/fixture manifest with the
frozen manifest, builds the release allocator binary with:

```sh
RUSTUP_HOME=/tmp/litchi-spec-gap-rustup \
CARGO_TARGET_DIR=/var/tmp/litchi-full-default-allocator-candidate-20260910-target \
CARGO_BUILD_JOBS=4 CARGO_INCREMENTAL=0 CARGO_PROFILE_RELEASE_DEBUG=0 \
RUSTFLAGS='-D warnings -D deprecated' LC_ALL=C.UTF-8 \
cargo +1.95.0 build --release --locked --features allocator-metrics \
  --bin litchi-perf-baseline-alloc \
  --manifest-path /var/tmp/litchi-full-default-allocator-candidate-20260910/tools/perf-baseline/Cargo.toml
```

It then launches the binary exactly as follows, outside Cargo and pinned to
CPU 2:

```sh
taskset --cpu-list 2 env RUSTFLAGS='-D warnings -D deprecated' LC_ALL=C.UTF-8 \
  /var/tmp/litchi-full-default-allocator-candidate-20260910-target/release/litchi-perf-baseline-alloc \
  --samples 15 --warmup 3 --workers 1 \
  --filesystem-cache warm,cold-requested \
  --json /var/tmp/litchi-full-default-allocator-candidate-20260910-capture/full-default-allocator.json \
  --corpus-manifest /var/tmp/litchi-full-default-allocator-candidate-20260910-capture/full-default-allocator.corpus-manifest-v2.json
```

The output checker is then run with the executable hash bound to the report:

```sh
python3 /var/tmp/litchi-full-default-allocator-candidate-20260910-capture/check-full-default-allocator.py \
  --report /var/tmp/litchi-full-default-allocator-candidate-20260910-capture/full-default-allocator.json \
  --catalog /var/tmp/litchi-full-default-allocator-candidate-20260910-capture/full-default-allocator.corpus-manifest-v2.json \
  --binary /var/tmp/litchi-full-default-allocator-candidate-20260910-target/release/litchi-perf-baseline-alloc \
  --source-root /var/tmp/litchi-full-default-allocator-candidate-20260910 \
  --source-manifest /var/tmp/litchi-full-default-allocator-candidate-20260910-capture/source-lock-fixture-hashes.json \
  --review-provenance /var/tmp/litchi-full-default-allocator-candidate-20260910-capture/review-provenance.json \
  --review-clearance /var/tmp/litchi-full-default-allocator-candidate-20260910-capture/review-clearance \
  --artifacts /var/tmp/litchi-full-default-allocator-candidate-20260910-capture
```

The checker output is retained as `full-default-allocator.check.json`, and
`run-full-default-allocator-deferred.sh` records the report, catalog, binary,
source-manifest, review-provenance, checker, and checker-result hashes in
`full-default-allocator.run-provenance.json`. No result is interpretable as a
latency measurement: `allocation_coverage.latency_claim` and every row's
`operation_metrics.latency_claim` must equal
`allocator_instrumented_elapsed_not_latency_claim`.

## Acceptance checks

A capture is rejected if any of these conditions fail: fewer or more than 201
results; a missing or unexpected default case; per-case counts other than
144+9+45+3; a filesystem cache row; a duplicate case/corpus identity; a sample
vector other than 15 values; `elapsed_ns.sample_order` differing from
`operation_metrics.sample_indices`; a non-permutation or duplicate identity;
an absent, unavailable, overflowed, or wrong-scope allocation vector; any
vector whose status is not `measured`; a catalog/reference/hash mismatch; a
candidate HEAD, diff, lock, fixture recipe, CPU affinity, Rust flags, binary,
or toolchain mismatch; or a still-running litchi performance process. The
report's exact `(case, canonical corpus)` key set must equal the catalog's
`(case, canonical legacy_v1)` key set. Each catalog binding must name the
same `legacy_v1` name and archive hash it publishes, and the retained result
key digest must equal the approved default digest above. This rejects a
fabricated report row or a separately fabricated catalog whose individual
hashes are valid but whose joined identities differ.

Before clearance, the adversarial checker regression is run with:

```sh
python3 /var/tmp/litchi-full-default-allocator-candidate-20260910-capture/test-checker-joint-fabrication.py
```

After the reviewer has confirmed that regression and the source manifest, the
review owner freezes provenance with `freeze-review-provenance.py`, then
writes `review-clearance` containing its SHA-256. The deferred runner verifies
both files before building and retains its complete stdout/stderr in
`full-default-allocator.run.log`.

The current preparation artifacts are immutable until an independent review
requests a candidate source change. If that happens, refresh the source
manifest, recompute the artifact hashes, and repeat the review gate before any
resource launch.
