#!/usr/bin/env bash
set -euo pipefail

# This wrapper is intentionally inert until both independent review gates have
# created their marker files. It must never overlap CPU-2 normal timing or a
# profile/resource run.
ROOT=${SOURCE_ROOT:-/var/tmp/litchi-full-default-allocator-candidate-20260910}
ARTIFACTS=${CAPTURE_ARTIFACTS:-/var/tmp/litchi-full-default-allocator-candidate-20260910-capture}
TARGET=${CARGO_TARGET_DIR:-/var/tmp/litchi-full-default-allocator-candidate-20260910-target}
RUSTUP_HOME=${RUSTUP_HOME:-/tmp/litchi-spec-gap-rustup}
REVIEW_CLEARANCE=${REVIEW_CLEARANCE_FILE:-$ARTIFACTS/review-clearance}
REVIEW_PROVENANCE=${REVIEW_PROVENANCE_FILE:-$ARTIFACTS/review-provenance.json}
NORMAL_COMPLETE=${NORMAL_TIMING_COMPLETE_FILE:-$ARTIFACTS/normal-cpu2-timing-complete}
SOURCE_MANIFEST=$ARTIFACTS/source-lock-fixture-hashes.json
CHECKER=$ARTIFACTS/check-full-default-allocator.py
REPORT=$ARTIFACTS/full-default-allocator.json
CATALOG=$ARTIFACTS/full-default-allocator.corpus-manifest-v2.json
CHECK_RESULT=$ARTIFACTS/full-default-allocator.check.json
RUN_PROVENANCE=$ARTIFACTS/full-default-allocator.run-provenance.json
RUN_LOG=$ARTIFACTS/full-default-allocator.run.log

mkdir -p "$ARTIFACTS"
: > "$RUN_LOG"
exec > >(tee -a "$RUN_LOG") 2>&1

if [[ ${RUN_FULL_DEFAULT_ALLOCATOR_AFTER_REVIEW:-0} != 1 ]]; then
  echo "refusing allocator run: set RUN_FULL_DEFAULT_ALLOCATOR_AFTER_REVIEW=1 after both gates clear" >&2
  exit 2
fi
[[ -f $REVIEW_CLEARANCE ]] || { echo "missing review clearance: $REVIEW_CLEARANCE" >&2; exit 2; }
[[ -f $REVIEW_PROVENANCE ]] || { echo "missing review provenance: $REVIEW_PROVENANCE" >&2; exit 2; }
[[ -f $NORMAL_COMPLETE ]] || { echo "missing normal CPU-2 completion marker: $NORMAL_COMPLETE" >&2; exit 2; }
[[ -x $CHECKER ]] || { echo "missing checker: $CHECKER" >&2; exit 2; }
[[ -f $SOURCE_MANIFEST ]] || { echo "missing source manifest: $SOURCE_MANIFEST" >&2; exit 2; }

# The review artifact binds the exact checker, manifest refresher, runner,
# plan, source manifest, and approved matrix digest. This check happens before
# the release build so post-review helper edits cannot reach the workload.
python3 "$CHECKER" \
  --verify-review-only \
  --source-root "$ROOT" \
  --source-manifest "$SOURCE_MANIFEST" \
  --review-provenance "$REVIEW_PROVENANCE" \
  --review-clearance "$REVIEW_CLEARANCE" \
  --artifacts "$ARTIFACTS" >/dev/null

# Refuse source/lock drift before spending the full 201-row workload. The
# manifest is refreshed only by an explicit review handoff, never here.
TMP_MANIFEST=$(mktemp "$ARTIFACTS/source-manifest-check.XXXXXX.json")
trap 'rm -f "$TMP_MANIFEST"' EXIT
python3 "$ARTIFACTS/refresh-source-manifest.py" --source-root "$ROOT" --output "$TMP_MANIFEST" >/dev/null
cmp -s "$TMP_MANIFEST" "$SOURCE_MANIFEST" || {
  echo "refusing allocator run: source/lock/fixture manifest is stale" >&2
  exit 2
}

ACTIVE_PERF_PROCESSES=$(python3 - <<'PY'
import os

names = {"litchi-perf-baseline", "litchi-perf-baseline-alloc"}
for entry in os.listdir("/proc"):
    if not entry.isdigit():
        continue
    try:
        command = open(f"/proc/{entry}/cmdline", "rb").read().split(b"\0", 1)[0]
    except OSError:
        continue
    if command and os.path.basename(os.fsdecode(command)) in names:
        print(f"{entry} {os.fsdecode(command)}")
PY
)
if [[ -n $ACTIVE_PERF_PROCESSES ]]; then
  echo "refusing allocator run: a litchi performance binary is still active" >&2
  printf '%s\n' "$ACTIVE_PERF_PROCESSES" >&2
  exit 2
fi

mkdir -p "$ARTIFACTS" "$TARGET"
export RUSTUP_HOME
export CARGO_TARGET_DIR="$TARGET"
export CARGO_BUILD_JOBS=4
export CARGO_INCREMENTAL=0
export CARGO_PROFILE_RELEASE_DEBUG=0
export RUSTFLAGS='-D warnings -D deprecated'
export LC_ALL=C.UTF-8

cargo +1.95.0 build --release --locked --features allocator-metrics \
  --bin litchi-perf-baseline-alloc \
  --manifest-path "$ROOT/tools/perf-baseline/Cargo.toml"

BINARY="$TARGET/release/litchi-perf-baseline-alloc"
[[ -x $BINARY ]] || { echo "allocator binary was not built: $BINARY" >&2; exit 2; }

# The binary is pinned to CPU 2. Its elapsed samples are evidence only; the
# checker rejects any allocator elapsed latency interpretation.
taskset --cpu-list 2 env RUSTFLAGS="$RUSTFLAGS" LC_ALL="$LC_ALL" \
  "$BINARY" \
  --warmup 3 --samples 15 --workers 1 \
  --filesystem-cache warm,cold-requested \
  --json "$REPORT" \
  --corpus-manifest "$CATALOG"

python3 "$CHECKER" \
  --report "$REPORT" \
  --catalog "$CATALOG" \
  --binary "$BINARY" \
  --source-root "$ROOT" \
  --source-manifest "$SOURCE_MANIFEST" \
  --review-provenance "$REVIEW_PROVENANCE" \
  --review-clearance "$REVIEW_CLEARANCE" \
  --artifacts "$ARTIFACTS" > "$CHECK_RESULT"

python3 - "$RUN_PROVENANCE" "$SOURCE_MANIFEST" "$BINARY" "$REPORT" "$CATALOG" "$CHECK_RESULT" "$REVIEW_PROVENANCE" "$CHECKER" <<'PY'
import json, pathlib, sys, hashlib

def sha256(path):
    h = hashlib.sha256()
    with open(path, 'rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()

out, source, binary, report, catalog, check, review, checker = map(pathlib.Path, sys.argv[1:])
result = json.loads(check.read_text(encoding='utf-8'))
value = {
    "schema_version": 1,
    "source_manifest_sha256": sha256(source),
    "review_provenance_sha256": sha256(review),
    "binary_sha256": sha256(binary),
    "report_sha256": sha256(report),
    "catalog_file_sha256": sha256(catalog),
    "checker_sha256": sha256(checker),
    "checker_result": result,
    "allocator_elapsed_is_latency_claim": False,
    "latency_eligibility": "ineligible",
    "capture_cpu_affinity": "2",
    "samples_per_case": 15,
    "warmup_iterations_per_case": 3,
    "result_count": 201,
}
# No source or timing claim is inferred from this provenance object; it only
# binds the retained files and the checker output.
out.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding='utf-8')
PY

echo "full allocator capture and 201-row check passed: $CHECK_RESULT"
