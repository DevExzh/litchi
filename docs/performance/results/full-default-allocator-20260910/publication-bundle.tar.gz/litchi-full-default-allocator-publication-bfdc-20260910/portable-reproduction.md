# Full-default allocator publication candidate

This directory combines the reviewed allocator source delta with the retained
201-row resource capture. Apply `source-delta.patch` to integration base
`bfdc911c0577c6a3304b4a70b8b70e2661721355`; the patch has exactly four paths:

- `tools/perf-baseline/README.md`
- `tools/perf-baseline/src/lib.rs`
- `tools/perf-baseline/src/operation_metrics.rs`
- `docs/performance/FULL_DEFAULT_ALLOCATOR_COVERAGE.md`

The integration base already contains the six-line `cache_state` corpus
publication hook in `tools/perf-baseline/src/lib.rs` and its three-line README
note; the patch preserves both. The corpus `lib.rs` six-line hook is outside
the allocator instrumentation change and must remain a separately reviewed
root commit.

The raw report and catalog under `capture/raw/` are the actual retained output
from the frozen measured candidate at
`fccbe6595f3a29561a8bfc6c192d8fa5e874ad05`. They are compressed only for
transport; their uncompressed SHA-256 values are bound in
`capture/provenance/full-default-allocator.run-provenance.json` and
`publication-source-manifest.json`. The later integration base preserves the
reviewed source delta and historical README additions, but the raw capture is
not relabeled as a measurement from a later source tree.

The allocator binary's elapsed values and operation metrics are resource
instrumentation evidence. They are explicitly ineligible for latency claims;
the capture proves all 201 default rows and all required operation-scoped
allocation vectors. The checker also binds each report `(case, corpus)` pair
to the catalog's canonical `legacy_v1` pair and enforces the approved default
matrix digest.

Run the portable artifact verifier with:

```sh
python3 verify-publication.py
```

The exact pinned source validation commands and their results are in
`validation/commands.txt` and `validation/results.json`. They cover formatting,
the three allocator contract tests, all 27 operation-metrics tests, strict
all-targets Clippy, the source diff check, and the compressed-capture hash and
201-row verifier. They do not rerun the resource workload.

The exact build and wrapper commands used for the measured capture are under
`capture/commands/`. The release build was pinned to CPU 8–31; the resource
workload was pinned to CPU 2 after the scaling reservation released. The binary
itself is represented by its recorded SHA-256 and build provenance rather than
copied into this compact publication bundle.
