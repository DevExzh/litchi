# Performance requirements audit for `cf4f383c4`

This is a read-only audit of the committed allocator publication at `cf4f383c4c203381880d4c2e8445d2616a53d283`, compared with the supplied `docs/GOAL.md`, `docs/CRUD_Scenario_Checklist.md`, accepted ADRs, and the performance documents present at that commit. It does not run a new benchmark or timed workload. The complete row-level matrix is in [`requirements-matrix.json`](requirements-matrix.json).

The overall program status is **incomplete**. The allocator publication is **complete for its narrow operation-scoped resource contract**: its verifier proves 201 rows (37 cases, 31 catalogued corpora), 15 samples and 3 warmups, 11 aligned allocation vectors per row, source/patch/binary/catalog identities, and the explicit exclusion of allocator elapsed time from latency claims. That artifact does not close the performance program, the ADR-0005 measurement contract, or the CRUD certification checklist.

## Audit identity and evidence boundary

- Target commit: `cf4f383c4c203381880d4c2e8445d2616a53d283`; integration base `bfdc911c`; measured source `fccbe659`.
- Audited worktree HEAD during review: `e8ee19b063285cb0bb73dea819f1be1ac5e82133`. This is recorded for provenance only; current dirty-tree state is not treated as evidence for the target commit.
- `docs/GOAL.md` was read from the current supplied workspace (SHA-256 `bed4058bb76330daab8ce9d4bceff639ab3fbd7ea06634158bef41b133c4d1f1`) and is absent from the target commit. The target commit therefore does not package the exact goal text being audited.
- `docs/CRUD_Scenario_Checklist.md` SHA-256 is `d3a63f3aa001ad6e3dda7627b6294230ae87b3b5aaa595c45c3327e026dbf02a` and is present at the target commit.
- Accepted constraints used: ADR-0005 requires representative small/large/sparse/media/encrypted/malformed corpora, latency/resource/I/O/contention/scaling measurements, profiles and statistical evidence; ADR-0008 defines evidence levels through native Office and single/multi-thread performance. The relevant clauses are `docs/adr/0005-io-memory-and-performance.md:8-61` and `docs/adr/0008-migration-and-verification.md:5676-5693`.

## What the committed publication actually proves

| Evidence | Result | Boundary |
|---|---|---|
| 29-file bundle, manifest and SHA256SUMS | Pass | File set and hashes are internally consistent; this is publication integrity. |
| Raw allocator report | Pass | 201 rows, 37 cases, 31 corpus identities, 15 samples/3 warmups, 11 allocation vectors per row. |
| Allocation contract | Pass | Every row is operation-scoped and measured; digest `f0fd7629…`. |
| Elapsed-time interpretation | Pass | All rows say `allocator_instrumented_elapsed_not_latency_claim`; no latency claim is authorized. |
| Source/patch identity | Pass | Four source paths match the manifest; patch SHA `0aaf3ee7…` applies cleanly to `bfdc`. |
| Perf-crate tests/lints | Pass, scoped | 360 tests passed with 1 ignored; all-target perf-crate Clippy passed. |
| Workspace/release gates | Missing from bundle | No current workspace check, rustdoc, boundary, fuzz, native, security, or all-feature release receipt. |
| Source/range/I/O counters | Missing for this contract | Operation source metric groups are `not_applicable` for all 201 rows; process counters unavailable for 198 rows. |
| Scaling/range reports | Weak | Receipt names six reports, but the report files are not in the 29-file bundle and cannot be independently reviewed. |

The report configuration does name `warm` and `cold-requested`, but the publication README explicitly disclaims a physical cold-cache claim. The allocator run records `execution_workers: [1]`; the receipt for a separate scaling capture is not itself a speedup or Amdahl result.

## Requirement matrix

The JSON matrix contains **264** rows: **50** exact checklist rows plus **214** GOAL, ADR, publication, corpus, CRUD, gate, deliverable, and definition-of-done rows. Status counts are **{'complete': 10, 'incomplete': 99, 'missing': 39, 'weak': 116}**. Each row records its source, requirement, authoritative evidence, and concrete gap. The checklist parser preserves every row from `docs/CRUD_Scenario_Checklist.md:18-102`; the matrix also covers all 15 CRUD categories and the 23 minimum E2E scenarios named in `docs/GOAL.md:253-305`.

The key distinction is between a **complete artifact** and a **complete requirement**. For example, allocation vectors are complete for 201 default rows, while latency, throughput, physical I/O, copied bytes, decompression, RSS, lock wait, scaling, native/security corpora, and most CRUD categories remain weak, incomplete, or missing.

## Documentation and authority inconsistencies

- `docs/performance/BASELINE.md` labels the 201-row full baseline historical at source `1b3f2c2d`, with zero normal filesystem rows and a separate two-row allocator smoke. It expressly says it does not represent the current feature HEAD.
- `docs/performance/GOAL_AUDIT.md`, `REPORT.md`, and `ADR_COMPLIANCE.md` are led by older 0485/046x sections and do not integrate the cf4 allocator publication as a current whole-program result. The existing claim registry intentionally classifies only two historical REPORT tables and keeps allocator evidence outside that registry; this is an honest boundary, but it means no current program-level claim is registered.
- `docs/performance/REGRESSION_COMPARATOR.md` still describes 36 cases/198 records, while the checked `perf-regression-policy-v1.json` and cf4 allocator contract use 37 cases/201 records. The prose and policy need one explicit reconciliation before release use.
- `docs/performance/results/full-baseline-20260910/README.md` is carefully caveated: its source is historical, `cold-requested` is not physical eviction, and it makes no latency, scaling, native-producer, or production-optimization claim. It cannot serve as the current cf4 normal baseline.

## Highest-impact remaining execution

1. **Reconcile authoritative performance documents and publication identities.** — BASELINE/GOAL_AUDIT/REPORT/ADR_COMPLIANCE are led by older change sections; REGRESSION_COMPARATOR prose says 36/198 while the checked policy and allocator contract are 37/201. The current GOAL is not in cf4. Next concrete evidence: Add a cf4/0469 publication entry, reconcile policy counts, bind current source/revision and full gate receipts, and keep historical tables explicitly historical.
2. **Capture a current normal (uninstrumented) 201-row baseline and a paired before/after control.** — The allocator report deliberately cannot support latency; the available 201-row normal baseline is historical source 1b3f and has zero normal filesystem rows. Next concrete evidence: ABBA/repeated process-isolated rows with p50/p95/p99, throughput, RSS, binary/source/corpus identity, uncertainty, and explicit cold/warm semantics.
3. **Close the dense XLSX one-percent commit/save hotspot with current causal evidence.** — 0468 profile attributes inclusive cost to eager parser 40.01%, snapshot scanning 24.41%, compaction 13.27%, and web validation 10.33%; 0469 reports a 10.985% whole-process Heaptrack-call decrease but not an accepted end-to-end speedup. Next concrete evidence: Matched current normal latency/resource/copy/validation measurements, preserve exact no-op/source/unknown behavior, and report adverse tails.
4. **Measure the required provider and sink axes.** — Current allocator source groups are not_applicable; normal filesystem rows are absent; range settings are configuration only. Next concrete evidence: Owned/borrowed/filesystem positional/ReadAt/high-latency range/non-seek/atomic-save rows with physical and logical read/write counters, request distributions, copied/decompressed bytes.
5. **Package and analyze the claimed workers 1/2/4/8 and range reports.** — A receipt names six reports but the raw files are absent, so there is no independently reviewable speedup/serial fraction/lock-wait evidence. Next concrete evidence: Raw report files, hashes, CPU utilization, task overhead, lock wait, efficiency, serial fraction, Amdahl model, and shared-host caveat.
6. **Expand representative corpus and native/security coverage.** — The default matrix is synthetic and does not bind encrypted/signed/protected/macro/external, malformed/adversarial, very-large, or multiple real producer classes. Next concrete evidence: Content-addressed producer/version corpus, inert security fixtures, bounded malformed set, very-large sparse/dense/media/dependency shapes, and corresponding timing/resource rows.
7. **Complete the minimum CRUD and four append semantics with bounded memory.** — CRUD_COVERAGE rows remain Partial for conversion, large create/append, bulk/delete/sanitize/copy/merge/patch/validation/repair; large legacy writers still accumulate. Next concrete evidence: Distinct streaming-create, logical-append, new-Part, and arbitrary-repackage scenarios, each with correctness/preservation and resource/latency evidence.
8. **Run current workspace release and safety gates for the certified scope.** — Publication has perf-crate tests/Clippy only; no current workspace check/rustdoc/boundary/fuzz/native/security/cross-platform receipt. Next concrete evidence: Pinned fmt/check/Clippy/rustdoc/boundary/unit/integration/doc/compile/fuzz/native/security evidence and matrix status.

The first two items are evidence blockers rather than optimization suggestions: without a current normal baseline and reconciled authority, allocator counts cannot support a release-level latency or speedup statement. The dense XLSX profile is the clearest measured hotspot available for the next causal optimization loop, but its current evidence is a profile/allocation result rather than a full accepted before/after claim.

## Files

- [`requirements-matrix.json`](requirements-matrix.json) — machine-readable row-level matrix, artifact inventory, status counts, and remaining-work queue.
- This report: [`performance-requirements-audit-20260910.md`](performance-requirements-audit-20260910.md).

No primary source, Cargo manifest, stage area, or commit was changed by this audit. The only generated files are under `/var/tmp/litchi-performance-requirements-audit-20260910/`.
