# Verified-cold build preparation

This is a release build preparation artifact only. No harness execution, warmup, timing sample, cache advice, cache eviction, or CPU 2 capture was run.

## Frozen identity

- Source worktree: `/var/tmp/litchi-cold-verified-build-17552-20260910/source-worktree`
- Commit: `17552b1b41796f8c0e3953017931f497b1837b3b`
- Git tree: `526bdf83be043a0a59bdb3e1a799c1abcc1ccaa8`
- Clean detached worktree: yes
- `tools/perf-baseline/Cargo.lock`: `e1c66239cd25a5657a72ed48ece0cd39938a734867f621eeeacdf1217b04d14b`
- Rust toolchain: `rustc 1.95.0 (59807616e 2026-04-14)`, Cargo `1.95.0`

The structured identity record is `build-preparation.json` (SHA-256 `eaa5ae9dd110a38c90f51d9ba893b45d7f36ffec4f157e87bc46bf71d552cc93`).

## Build

Target and temporary directories were unique ext4 paths under `/var/tmp/litchi-cold-verified-build-17552-20260910`. The release harness was built with affinity 8–31:

```sh
taskset --cpu-list 8-31 cargo build --release --locked \
  --manifest-path /var/tmp/litchi-cold-verified-build-17552-20260910/source-worktree/tools/perf-baseline/Cargo.toml
```

Build exit status was 0. `cargo metadata --locked --offline --no-deps` also passed. Build log SHA-256: `82617be82f28de141c3e1e3bf90ddf12bc20830c4910b4517fe201b710f0070a`.

The runnable binary is:

```text
/var/tmp/litchi-cold-verified-build-17552-20260910/target/release/litchi-perf-baseline
```

Binary size is 60,237,560 bytes, SHA-256 `bb60a945eb855b3b87fec50765c3a50b73fea39c508b49751777acabd3bae57d`, ELF build ID `efe2bb337741cf0e0ee9dc07a3375e921dee36fd`.

## Later root-owned capture command

Run only after the root grant, on CPU 2, with a separately prepared capture directory:

```sh
taskset --cpu-list 2 env \
  TMPDIR=/var/tmp/litchi-cold-verified-capture-17552-20260910/tmp \
  /var/tmp/litchi-cold-verified-build-17552-20260910/target/release/litchi-perf-baseline \
  --warmup 1 --samples 5 \
  --filesystem-cache warm,cold-verified \
  --filesystem-root /var/tmp/litchi-cold-verified-capture-17552-20260910/filesystem \
  --case opc_file_source_open \
  --json /var/tmp/litchi-cold-verified-capture-17552-20260910/filesystem-cold-verified.json
```

The selected case is the pinned `few-large` incompressible OPC corpus: four 4 MiB entries, archive SHA-256 `a0c1af9e2c7a19148b44fc2a8c594c7a274131d74f9f042d55b487d5337cd1e6`. The eventual report is limited to strict fincore page-cache observations and positive process `read_bytes` for this case, corpus, host, and binary; it cannot claim physical-media temperature, device-cache state, durable-I/O latency, or suite-wide performance.
