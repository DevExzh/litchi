#!/usr/bin/env bash
set -euo pipefail

SCRIPT_PATH=$(readlink -f "${BASH_SOURCE[0]}")
ROOT=/var/tmp/litchi-allocator-optimization-v6-diagnostic-v3-20260910
PLAN=$ROOT/v6-diagnostic-continuation-plan.json
REUSE_MANIFEST=$ROOT/reuse-manifest.json
RETAINED=$ROOT/retained-v2
CARGO_ROOT=/tmp/litchi-spec-gap-rustup
CPU_SET=2
CASE=xlsx_one_percent_commit_save
SHAPE=dense-wide
WORKERS=1
WARMUP=0
SAMPLES=1

if [[ $# -gt 1 ]]; then
    echo "usage: RESERVATION_RECEIPT=/path/to/root-grant.json ${SCRIPT_PATH} [root-grant.json]" >&2
    exit 2
fi
if [[ $# -eq 1 ]]; then
    RESERVATION_RECEIPT=$1
else
    RESERVATION_RECEIPT=${RESERVATION_RECEIPT:-}
fi
export RESERVATION_RECEIPT

fail() {
    echo "v6 diagnostic continuation: $*" >&2
    exit 1
}

sha256() {
    sha256sum "$1" | awk '{print $1}'
}

json_field() {
    python3 - "$PLAN" "$1" <<'PY'
import json, sys
value = json.loads(open(sys.argv[1], encoding='utf-8').read())
for part in sys.argv[2].split('.'):
    value = value[part]
print(value)
PY
}

assert_grant() {
    [[ -n ${RESERVATION_RECEIPT:-} && -f $RESERVATION_RECEIPT ]] ||
        fail "missing root diagnostic grant receipt: ${RESERVATION_RECEIPT:-<unset>}"
    python3 - "$RESERVATION_RECEIPT" <<'PY'
import json, sys
path = sys.argv[1]
try:
    value = json.loads(open(path, encoding='utf-8').read())
except (OSError, json.JSONDecodeError) as exc:
    raise SystemExit(f'root diagnostic grant is not readable JSON: {exc}')
if not isinstance(value, dict):
    raise SystemExit('root diagnostic grant must be a JSON object')
expected = {'status': 'granted', 'owner': 'crypto_profile_review', 'cpu_set': '2'}
actual = {key: value.get(key) for key in expected}
if actual != expected:
    raise SystemExit(f'root diagnostic grant differs: expected {expected!r}, got {actual!r}')
PY
}

assert_plan() {
    local stage=$1
    python3 - "$PLAN" "$SCRIPT_PATH" "$REUSE_MANIFEST" "$stage" <<'PY'
import hashlib, json, pathlib, subprocess, sys
plan_path, runner_path, manifest_path = map(pathlib.Path, sys.argv[1:4])
stage = sys.argv[4]

def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()

def git(path, *args):
    return subprocess.check_output(['git', '-C', str(path), *args], text=True)

plan = json.loads(plan_path.read_text(encoding='utf-8'))
manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
if plan.get('schema_version') != 1 or plan.get('status') != 'planned':
    raise SystemExit('continuation plan is not schema-1 planned')
if plan.get('runner_path') != str(runner_path):
    raise SystemExit('continuation runner path differs from plan')
if plan.get('runner_sha256') != sha(runner_path):
    raise SystemExit('continuation runner hash differs from plan')
if plan.get('reuse_manifest_sha256') != sha(manifest_path):
    raise SystemExit('reuse manifest hash differs from plan')
if plan.get('cpu_set') != '2' or plan.get('owner') != 'crypto_profile_review':
    raise SystemExit('continuation CPU/owner binding differs from plan')

source_v2 = plan['source_v2']
for key in ('retained_plan_path', 'retained_runner_path'):
    if not pathlib.Path(source_v2[key]).is_file():
        raise SystemExit(f'missing retained V2 file: {source_v2[key]}')
if sha(pathlib.Path(source_v2['retained_plan_path'])) != source_v2['plan_sha256']:
    raise SystemExit('retained V2 plan hash changed')
if sha(pathlib.Path(source_v2['retained_runner_path'])) != source_v2['runner_sha256']:
    raise SystemExit('retained V2 runner hash changed')

if manifest.get('source_plan_sha256') != source_v2['plan_sha256']:
    raise SystemExit('reuse manifest source plan hash differs')
if manifest.get('source_runner_sha256') != source_v2['runner_sha256']:
    raise SystemExit('reuse manifest source runner hash differs')
for entry in manifest['retained_files']:
    retained = pathlib.Path(entry['retained_path'])
    if not retained.is_file() or sha(retained) != entry['sha256']:
        raise SystemExit(f'retained V2 file changed or is missing: {retained}')
for entry in manifest['reused_outputs']:
    destination = pathlib.Path(entry['destination_path'])
    if not destination.is_file() or sha(destination) != entry['sha256']:
        raise SystemExit(f'reused capture changed or is missing: {destination}')

for name, entry in plan['worktrees'].items():
    path = pathlib.Path(entry['path'])
    if git(path, 'rev-parse', 'HEAD').strip() != plan['base_commit']:
        raise SystemExit(f'{name} HEAD changed')
    status = git(path, 'status', '--porcelain=v1', '--untracked-files=all').splitlines()
    if name == 'control' and status:
        raise SystemExit(f'control worktree dirty: {status!r}')
    if name == 'candidate':
        expected = {' M ' + source for source in plan['source_files']}
        if set(status) != expected or len(status) != len(expected):
            raise SystemExit(f'candidate source status changed: expected {expected!r}, got {status!r}')
        if git(path, 'diff', '--cached', '--name-only').strip():
            raise SystemExit('candidate has staged changes')
        diff = subprocess.check_output(['git', '-C', str(path), 'diff', '--binary', '--', *plan['source_files']])
        if hashlib.sha256(diff).hexdigest() != plan['candidate_source_diff_sha256']:
            raise SystemExit('candidate source diff changed')
for name, entry in plan['locks'].items():
    path = pathlib.Path(entry['path'])
    if sha(path) != entry['sha256']:
        raise SystemExit(f'{name} lock changed')
for name, entry in plan['artifacts'].items():
    path = pathlib.Path(entry['path'])
    if not path.is_file() or sha(path) != entry['sha256']:
        raise SystemExit(f'{name} artifact changed or is missing')

reused = {entry['destination_path'] for entry in plan['reused_outputs']}
if reused != {entry['destination_path'] for entry in manifest['reused_outputs']}:
    raise SystemExit('plan and reuse manifest capture sets differ')
if stage == 'pre_continuation':
    for output in plan['remaining_outputs'] + plan['new_outputs']:
        if pathlib.Path(output).exists():
            raise SystemExit(f'continuation output already exists: {output}')
elif stage == 'post_continuation':
    for output in plan['all_outputs']:
        if not pathlib.Path(output).is_file():
            raise SystemExit(f'continuation output is missing: {output}')
PY
}

host_snapshot() {
    local path=$1
    {
        printf 'utc='; date -u +%Y-%m-%dT%H:%M:%SZ
        printf 'cwd='; pwd -P
        printf 'runner_sha256='; sha256 "$SCRIPT_PATH"
        printf 'plan_sha256='; sha256 "$PLAN"
        printf 'reuse_manifest_sha256='; sha256 "$REUSE_MANIFEST"
        printf 'grant='; printf '%s\n' "$RESERVATION_RECEIPT"
        printf 'grant_sha256='; sha256 "$RESERVATION_RECEIPT"
        printf 'taskset_self='; taskset -pc $$ 2>&1
        printf 'nproc='; nproc
        printf 'loadavg='; cat /proc/loadavg
        uname -a
        lscpu
        printf '%s\n' '--- top processes ---'
        ps -eo pid,psr,pcpu,pmem,etime,comm --sort=-pcpu | head -n 40 || true
    } > "$path"
}

write_provenance() {
    local output=$1 stage=$2 host=$3
    python3 - "$output" "$stage" "$host" "$PLAN" "$SCRIPT_PATH" "$REUSE_MANIFEST" "$RESERVATION_RECEIPT" <<'PY'
import hashlib, json, pathlib, sys
from datetime import datetime, timezone
output = pathlib.Path(sys.argv[1])
stage = sys.argv[2]
host = pathlib.Path(sys.argv[3])
plan_path = pathlib.Path(sys.argv[4])
runner_path = pathlib.Path(sys.argv[5])
manifest_path = pathlib.Path(sys.argv[6])
receipt = pathlib.Path(sys.argv[7])

def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()
plan = json.loads(plan_path.read_text(encoding='utf-8'))
value = {
    'schema_version': 1,
    'stage': stage,
    'utc': datetime.now(timezone.utc).isoformat(),
    'cwd': str(pathlib.Path.cwd()),
    'root_grant_receipt': str(receipt),
    'root_grant_receipt_sha256': sha(receipt),
    'plan': str(plan_path),
    'plan_sha256': sha(plan_path),
    'runner': str(runner_path),
    'runner_sha256': sha(runner_path),
    'reuse_manifest': str(manifest_path),
    'reuse_manifest_sha256': sha(manifest_path),
    'source_base': plan['base_commit'],
    'candidate_source_diff_sha256': plan['candidate_source_diff_sha256'],
    'source_v2': plan['source_v2'],
    'worktrees': plan['worktrees'],
    'locks': plan['locks'],
    'artifacts': plan['artifacts'],
    'host_snapshot': str(host),
    'host_snapshot_sha256': sha(host),
}
output.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n', encoding='utf-8')
PY
}

binary_for() {
    json_field "artifacts.$1.path"
}

run_offline_perf_report() {
    local label=$1 data=$2 symbols=$3
    [[ -f $data && ! -e $symbols ]] || fail "$label raw input missing or analysis output already exists"
    DEBUGINFOD_URLS='' perf report --stdio --input "$data" --sort symbol --percent-limit 0.01 \
        >"$symbols" 2>&1
    [[ -s $symbols ]] || fail "$label offline perf report is empty"
}

run_control_perf_record() {
    local data=$ROOT/perf-record-control.data
    local report=$ROOT/perf-record-control.json
    local corpus=$ROOT/perf-record-control.corpus.json
    local log=$ROOT/perf-record-control.log
    local symbols=$ROOT/perf-record-control.symbols.txt
    local binary
    binary=$(binary_for control_normal)
    for output in "$data" "$symbols" "$report" "$corpus" "$log"; do
        [[ ! -e $output ]] || fail "control record output already exists: $output"
    done
    taskset --cpu-list "$CPU_SET" perf record --no-buildid-cache \
        --call-graph dwarf,16384 --freq 997 -o "$data" -- env \
        DEBUGINFOD_URLS='' RUSTUP_HOME="$CARGO_ROOT" LC_ALL=C.UTF-8 "$binary" \
        --case "$CASE" --xlsx-shape "$SHAPE" --workers "$WORKERS" \
        --warmup "$WARMUP" --samples "$SAMPLES" --json "$report" \
        --corpus-manifest "$corpus" >"$log" 2>&1
    [[ -s $data && -s $report && -s $corpus ]] || fail "control perf record did not produce complete output"
    run_offline_perf_report control_perf_record "$data" "$symbols"
}

run_heaptrack() {
    local label=$1 binary_key=$2 heap_base=$3 heap_report=$4 report=$5 corpus=$6 log=$7
    local heap="${heap_base}.zst"
    local binary
    binary=$(binary_for "$binary_key")
    for output in "$heap" "$heap_report" "$report" "$corpus" "$log"; do
        [[ ! -e $output ]] || fail "$label output already exists: $output"
    done
    taskset --cpu-list "$CPU_SET" heaptrack --record-only -o "$heap_base" env \
        DEBUGINFOD_URLS='' RUSTUP_HOME="$CARGO_ROOT" LC_ALL=C.UTF-8 "$binary" \
        --case "$CASE" --xlsx-shape "$SHAPE" --workers "$WORKERS" --warmup "$WARMUP" \
        --samples "$SAMPLES" --json "$report" --corpus-manifest "$corpus" >"$log" 2>&1
    [[ -s $heap && -s $report && -s $corpus ]] || fail "$label heaptrack did not produce complete output"
    env DEBUGINFOD_URLS='' heaptrack_print --print-allocators --print-peaks -n 25 -s 10 \
        "$heap" >"$heap_report" 2>&1
    [[ -s $heap_report ]] || fail "$label offline heaptrack summary is empty"
}

run_allocator() {
    local label=$1 binary_key=$2 report=$3 corpus=$4 log=$5
    local binary
    binary=$(binary_for "$binary_key")
    for output in "$report" "$corpus" "$log"; do
        [[ ! -e $output ]] || fail "$label output already exists: $output"
    done
    taskset --cpu-list "$CPU_SET" env DEBUGINFOD_URLS='' RUSTUP_HOME="$CARGO_ROOT" \
        LC_ALL=C.UTF-8 "$binary" --case "$CASE" --xlsx-shape "$SHAPE" \
        --workers "$WORKERS" --warmup "$WARMUP" --samples "$SAMPLES" \
        --json "$report" --corpus-manifest "$corpus" >"$log" 2>&1
    [[ -s $report && -s $corpus ]] || fail "$label allocator run did not produce complete output"
}

write_path_summary() {
    python3 - "$ROOT/offline-path-symbol-summary.txt" \
        "$ROOT/perf-record-candidate.symbols.offline.txt" \
        "$ROOT/perf-record-control.symbols.txt" \
        "$ROOT/heaptrack-candidate.txt" "$ROOT/heaptrack-control.txt" <<'PY'
from pathlib import Path
import sys
out, candidate, control, heap_candidate, heap_control = map(Path, sys.argv[1:])
needles = [
    'litchi_xlsx::raw::worksheet::selected::scan_targets_bytes',
    'litchi_xlsx::raw::worksheet::selected::PlainScanner',
    'litchi_xlsx::raw::worksheet::selected::Scanner',
    'litchi_xlsx::raw::worksheet::parse',
]
lines = ['diagnostic symbol summary; offline analysis only; presence is evidence, absence is not a fast-path proof']
for name, path in [('candidate perf', candidate), ('control perf', control), ('candidate heaptrack', heap_candidate), ('control heaptrack', heap_control)]:
    text = path.read_text(errors='replace')
    lines.append(f'[{name}]')
    for needle in needles:
        matches = [line for line in text.splitlines() if needle in line]
        lines.append(f'{needle}: {len(matches)}')
        lines.extend(f'  {line}' for line in matches[:5])
out.write_text('\n'.join(lines) + '\n')
PY
    [[ -s $ROOT/offline-path-symbol-summary.txt ]] || fail "offline path symbol summary is empty"
}

assert_grant
[[ -f $PLAN && -f $REUSE_MANIFEST ]] || fail "missing continuation plan or reuse manifest"
assert_plan pre_continuation
PRE=$ROOT/diagnostic-preflight.json
POST=$ROOT/diagnostic-postflight.json
HOST_PRE=$ROOT/diagnostic-host-pre.txt
HOST_POST=$ROOT/diagnostic-host-post.txt
for path in "$PRE" "$POST" "$HOST_PRE" "$HOST_POST"; do
    [[ ! -e $path ]] || fail "provenance output already exists: $path"
done
host_snapshot "$HOST_PRE"
write_provenance "$PRE" pre_continuation "$HOST_PRE"

run_offline_perf_report candidate_perf_record \
    "$ROOT/perf-record-candidate.data" "$ROOT/perf-record-candidate.symbols.offline.txt"
run_control_perf_record

run_heaptrack candidate_normal \
    candidate_normal "$ROOT/heaptrack-candidate" "$ROOT/heaptrack-candidate.txt" \
    "$ROOT/heaptrack-candidate.json" "$ROOT/heaptrack-candidate.corpus.json" \
    "$ROOT/heaptrack-candidate.log"
run_heaptrack control_normal \
    control_normal "$ROOT/heaptrack-control" "$ROOT/heaptrack-control.txt" \
    "$ROOT/heaptrack-control.json" "$ROOT/heaptrack-control.corpus.json" \
    "$ROOT/heaptrack-control.log"

run_allocator allocator_candidate candidate_allocator \
    "$ROOT/allocator-candidate.json" "$ROOT/allocator-candidate.corpus.json" \
    "$ROOT/allocator-candidate.log"
run_allocator allocator_control control_allocator \
    "$ROOT/allocator-control.json" "$ROOT/allocator-control.corpus.json" \
    "$ROOT/allocator-control.log"

write_path_summary
host_snapshot "$HOST_POST"
write_provenance "$POST" post_continuation "$HOST_POST"
assert_plan post_continuation
