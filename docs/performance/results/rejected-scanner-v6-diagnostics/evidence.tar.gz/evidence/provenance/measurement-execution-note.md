# Commit execution accounting for V4 heaptrack

The `xlsx_one_percent_commit_save` harness invokes
`run_xlsx_update_commit_save`. Before the measured loop it calls
`xlsx_expected_output`, which performs one commit and save while preparing the
expected output. The measured loop has `warmup=0` and `samples=1`, so it then
performs one further commit and save for the single measured sample.

V4 heaptrack instruments the whole process, so its allocation-call total sees
both commit/save operations. The V4 candidate/control difference cannot be
described as a difference between two measured samples. V3 allocator JSON
reports use `system_allocator_operation_scoped` instrumentation with
`operation_global_system_allocator` metrics that begin after setup; this note
does not apply the V4 whole-process interpretation to those V3 deltas.
