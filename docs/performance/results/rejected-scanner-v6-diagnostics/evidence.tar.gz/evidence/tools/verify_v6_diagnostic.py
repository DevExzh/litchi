#!/usr/bin/env python3
"""Verify the compact V6 diagnostic publication without running workloads."""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

EXPECTED = {
    "base_commit": "cf4f383c4c203381880d4c2e8445d2616a53d283",
    "diff": "de5495e515335e08336a2f3e0588907bc6b2dcc533edc3907e267351d89c1cf2",
    "candidate_normal": "9fbe3eb71775a6fc8d982acbe518fc016608f3a03e63d88502d656aef21d20fd",
    "control_normal": "e3bf2aab0a29a186db0623f16cd049e2d3f89daa84c351244c01b8792476ba56",
    "candidate_allocator": "c7359fa2078c9aa66771cd85c6ff18d3b072d688bdd4383476b7092dd5c071fc",
    "control_allocator": "0f7b6cb68fc8588caf939bd7e8b7f9c86da674f5cb30951da83aa6e32bd0b2bf",
    "candidate_perf_data": "aceaa990331991d408a3a18560e0cd4a5b3cbfe6c0b60c86bfb4bb309d9568b0",
    "control_perf_data": "cbfcdfa38f3d27c7fa17181ef64284c9c1c5d5f3a1ba7acf459fa1965b10517f",
    "offline_report": "6318f15df607e35dc1c98728e8109cea94e8a97c1a8f3d867bbd202554bcbccf",
    "source_patch": "de5495e515335e08336a2f3e0588907bc6b2dcc533edc3907e267351d89c1cf2",
    "v4_candidate_zst": "96b55e609ff7c1315d3c430639fe2b6df46fd3ad74b9a32990bfe28dbda707b4",
    "v4_control_zst": "e8e0b6c10cf7c1d8b0a059732d24cf14eed9b33ccdaefbef5ed13112aac8e51e",
}


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def read_json(path: Path):
    return json.loads(path.read_text())


def fail(message: str) -> None:
    raise AssertionError(message)


def check_archive(root: Path, allow_result_absent: bool) -> dict[str, object]:
    manifest_path = root / "bundle-manifest.json"
    sums_path = root / "SHA256SUMS"
    if not manifest_path.is_file() or not sums_path.is_file():
        fail("bundle-manifest.json and SHA256SUMS are required")
    manifest = read_json(manifest_path)
    if manifest.get("bundle_id") != "litchi-allocator-optimization-v6-diagnostic-publication-v4-20260910":
        fail("unexpected V4 publication bundle id")
    if manifest.get("publication_revision") != 4:
        fail("unexpected V4 publication revision")
    entries = manifest.get("files")
    if not isinstance(entries, list):
        fail("manifest files must be a list")
    listed: dict[str, dict[str, object]] = {}
    for entry in entries:
        path = entry.get("path")
        if not isinstance(path, str) or not path or Path(path).is_absolute() or ".." in Path(path).parts:
            fail(f"unsafe manifest path: {path!r}")
        if path in listed:
            fail(f"duplicate manifest path: {path}")
        listed[path] = entry
        actual = root / path
        if not actual.is_file():
            fail(f"missing manifest file: {path}")
        if actual.stat().st_size != entry.get("bytes"):
            fail(f"size mismatch: {path}")
        if digest(actual) != entry.get("sha256"):
            fail(f"digest mismatch: {path}")
    if "results/verification.json" not in listed and not allow_result_absent:
        fail("final manifest must include results/verification.json")

    actual_files = {
        str(path.relative_to(root))
        for path in root.rglob("*")
        if path.is_file() and path.name not in {"bundle-manifest.json", "SHA256SUMS"}
    }
    expected_files = set(listed)
    if allow_result_absent:
        expected_files.discard("results/verification.json")
        actual_files.discard("results/verification.json")
    if actual_files != expected_files:
        fail(f"manifest/file set mismatch: actual-only={sorted(actual_files - expected_files)}, listed-only={sorted(expected_files - actual_files)}")

    sum_lines = {}
    for line in sums_path.read_text().splitlines():
        if not line.strip():
            continue
        try:
            value, path = line.split("  ", 1)
        except ValueError:
            fail(f"malformed SHA256SUMS line: {line!r}")
        if path in sum_lines:
            fail(f"duplicate SHA256SUMS path: {path}")
        sum_lines[path] = value
        actual = root / path
        if not actual.is_file():
            fail(f"missing SHA256SUMS file: {path}")
        if digest(actual) != value:
            fail(f"SHA256SUMS mismatch: {path}")
    if "SHA256SUMS" in sum_lines:
        fail("SHA256SUMS must not contain a self-entry")
    required_sum_paths = set(listed) | {"bundle-manifest.json"}
    if allow_result_absent:
        required_sum_paths.discard("results/verification.json")
    if set(sum_lines) != required_sum_paths:
        fail(f"SHA256SUMS/file set mismatch: actual-only={sorted(set(sum_lines) - required_sum_paths)}, missing={sorted(required_sum_paths - set(sum_lines))}")
    return {"manifest_entries": len(entries), "sha256sum_entries": len(sum_lines)}


def check_facts(root: Path) -> dict[str, object]:
    identity = read_json(root / "provenance/source-artifact-identity.json")
    plan = read_json(root / "provenance/v3/v6-diagnostic-continuation-plan.json")
    v3_release = read_json(root / "provenance/v3-root-release.json")
    v4_grant = read_json(root / "direct-heaptrack-v4/root-grant.json")
    v4_release = read_json(root / "direct-heaptrack-v4/root-release.json")
    offline = read_json(root / "provenance/offline-analysis.json")
    omission = read_json(root / "provenance/binary-omission.json")
    retention = read_json(root / "provenance/v3-retention-exceptions.json")

    if identity["base_commit"] != EXPECTED["base_commit"]:
        fail("source identity base commit mismatch")
    if identity["candidate"]["source_diff_sha256"] != EXPECTED["diff"]:
        fail("source identity diff mismatch")
    if plan["base_commit"] != EXPECTED["base_commit"] or plan["candidate_source_diff_sha256"] != EXPECTED["diff"]:
        fail("V3 continuation plan source binding mismatch")
    if digest(root / "provenance/v6-source.patch") != EXPECTED["source_patch"]:
        fail("source patch mismatch")

    expected_depfiles = {
        "candidate-allocator-litchi-perf-baseline-alloc.d": "26a6c8f8b8fcb4a3d63fb43bbdd5dbf83354bae4ead2601413199cb94203b82e",
        "candidate-normal-litchi-perf-baseline.d": "5476909a6cc388e66fe5f532e77feab524a688b976c259acdf7f95c92fd1d2e4",
        "control-allocator-litchi-perf-baseline-alloc.d": "264f2960ea16fb5d26fba79b2a7dcda78567ef42f050879b0eb287be930536ab",
        "control-normal-litchi-perf-baseline.d": "ff582901cfb31c0cdf2319f2fb4a7a92115f2ee0d51f111da96db8ab9c3add97",
    }
    for name, expected in expected_depfiles.items():
        actual = digest(root / "provenance/depfiles" / name)
        if actual != expected:
            fail(f"depfile mismatch: {name}")

    reports = {
        "candidate": ("v3-capture/perf-record-candidate.json", EXPECTED["candidate_normal"]),
        "control": ("v3-capture/perf-record-control.json", EXPECTED["control_normal"]),
        "candidate_allocator": ("v3-capture/allocator-candidate.json", EXPECTED["candidate_allocator"]),
        "control_allocator": ("v3-capture/allocator-control.json", EXPECTED["control_allocator"]),
        "candidate_heaptrack_invalid": ("historical-invalid-heaptrack-v3/heaptrack-candidate.json", EXPECTED["candidate_normal"]),
        "control_heaptrack_invalid": ("historical-invalid-heaptrack-v3/heaptrack-control.json", EXPECTED["control_normal"]),
        "candidate_heaptrack_direct": ("direct-heaptrack-v4/candidate.json", EXPECTED["candidate_normal"]),
        "control_heaptrack_direct": ("direct-heaptrack-v4/control.json", EXPECTED["control_normal"]),
    }
    expected_case = "xlsx_one_percent_commit_save"
    report_documents = {}
    for label, (rel, expected) in reports.items():
        report = read_json(root / rel)
        report_documents[label] = report
        got = report["binary_identity"]["binary_sha256"]
        if got != expected:
            fail(f"{label} binary hash mismatch")
        results = report.get("results")
        if not isinstance(results, list) or len(results) != 1:
            fail(f"{label} expected exactly one result")
        if results[0].get("case") != expected_case:
            fail(f"{label} result case missing or changed")

    # V3 allocator counts are operation-scoped. Bind this claim to every
    # serialized result and allocation metric field instead of inferring it
    # from filenames or prose.
    allocator_scope = "operation_global_system_allocator"
    allocator_instrumentation = "system_allocator_operation_scoped"
    allocator_metrics = [
        "allocation_calls",
        "deallocation_calls",
        "reallocation_calls",
        "failed_allocation_calls",
        "allocated_bytes",
        "deallocated_bytes",
        "live_bytes_before",
        "live_bytes_after",
        "peak_live_bytes_before",
        "peak_live_bytes_after",
        "region_peak_live_bytes",
    ]
    for label in ["candidate", "control"]:
        report = report_documents[label + "_allocator"]
        if report["tool"].get("instrumentation") != allocator_instrumentation:
            fail(f"V3 {label} allocator instrumentation scope missing or changed")
        for result_index, result in enumerate(report["results"]):
            allocation = result["operation_metrics"]["allocation"]
            if allocation.get("status") != "measured" or allocation.get("scope") != allocator_scope:
                fail(f"V3 {label} result {result_index} allocation_metric_scope missing or changed")
            for metric in allocator_metrics:
                if allocation[metric].get("scope") != allocator_scope:
                    fail(f"V3 {label} result {result_index} {metric} scope missing or changed")

    if digest(root / "v3-capture/perf-record-candidate.data") != EXPECTED["candidate_perf_data"]:
        fail("candidate perf raw data mismatch")
    if digest(root / "v3-capture/perf-record-control.data") != EXPECTED["control_perf_data"]:
        fail("control perf raw data mismatch")
    offline_report_path = root / "provenance/v2-history/offline-analysis-report.txt"
    offline_report = offline_report_path.read_text(errors="replace")
    raw_markers = [
        "Processed 2630 events and lost 6 chunks!",
        "# Total Lost Samples: 7",
        "Kernel address maps (/proc/{kallsyms,modules}) were restricted.",
        "As no suitable kallsyms nor vmlinux was found, kernel samples",
        "Samples in kernel modules can't be resolved as well.",
    ]
    for marker in raw_markers:
        if marker not in offline_report:
            fail(f"offline raw report caveat missing: {marker}")
    if digest(offline_report_path) != EXPECTED["offline_report"]:
        fail("offline report mismatch")
    if offline["raw_sha256"] != EXPECTED["candidate_perf_data"] or offline["report_sha256"] != EXPECTED["offline_report"]:
        fail("offline analysis hash binding mismatch")
    if offline["scope"] != "whole process, including setup; symbol presence alone does not attribute both parses to one timed operation":
        fail("offline whole-process scope missing or changed")
    if offline["limitations"] != ["7 lost samples and 6 lost chunks reported", "kernel symbols unavailable"]:
        fail("offline analysis limitation binding mismatch")
    if offline["gain_claim"] is not False or offline["new_workload_started"] is not False:
        fail("offline analysis gain/workload limitation mismatch")

    # V3 root receipt is retained byte-for-byte. Validate canonical root files;
    # retained V2 trees are intentionally covered by the retention exception.
    for item in v3_release["files"]:
        rel = item["path"]
        if rel.startswith("retained-v2/") or rel.startswith("retained-external/"):
            continue
        if rel.startswith("perf-") or rel.startswith("allocator-"):
            actual = root / "v3-capture" / rel
        elif rel.startswith("heaptrack-"):
            actual = root / "historical-invalid-heaptrack-v3" / rel
        else:
            actual = root / "provenance/v3" / rel
        if not actual.is_file() or digest(actual) != item["sha256"] or actual.stat().st_size != item["bytes"]:
            fail(f"V3 release binding mismatch: {rel}")
    if "coreutils env allocations" not in v3_release.get("limitation", ""):
        fail("V3 invalid heaptrack limitation missing")
    if v3_release.get("gain_claim") is not False:
        fail("V3 release gain claim must remain false")

    # The V4 receipt has no omitted files and all of its paths are copied.
    for item in v4_release["files"]:
        actual = root / "direct-heaptrack-v4" / item["path"]
        if not actual.is_file() or digest(actual) != item["sha256"] or actual.stat().st_size != item["bytes"]:
            fail(f"V4 release binding mismatch: {item['path']}")
    if v4_release["observations"]["candidate"]["whole_process_allocation_calls"] != 19014852:
        fail("V4 candidate allocation-call observation mismatch")
    if v4_release["observations"]["control"]["whole_process_allocation_calls"] != 11402262:
        fail("V4 control allocation-call observation mismatch")
    if v4_release["observations"]["candidate"]["target_stack_present"] is not True or v4_release["observations"]["control"]["target_stack_present"] is not True:
        fail("V4 target stack observation mismatch")
    if v4_release.get("scope") != "whole-process heaptrack attribution; instrumentation runtime and RSS are not normal timing/memory claims":
        fail("V4 whole-process scope missing or changed")
    if v4_release.get("gain_claim") is not False:
        fail("V4 gain claim must remain false")
    if "env" in v4_grant["commands"][0]["command"] or "env" in v4_grant["commands"][1]["command"]:
        fail("V4 direct-binary grant unexpectedly contains env wrapper")
    for name in ["candidate", "control"]:
        text = (root / f"direct-heaptrack-v4/{name}.txt").read_text(errors="replace")
        if "/usr/lib/cargo/bin/coreutils/env" in text or "Debuggee command was: env " in text:
            fail(f"V4 {name} report has env wrapper")
        if "MOST CALLS TO ALLOCATION FUNCTIONS" not in text:
            fail(f"V4 {name} report lacks allocation analysis")
    for name in ["candidate", "control"]:
        text = (root / f"historical-invalid-heaptrack-v3/heaptrack-{name}.txt").read_text(errors="replace")
        log = (root / f"historical-invalid-heaptrack-v3/heaptrack-{name}.log").read_text(errors="replace")
        if "/usr/lib/cargo/bin/coreutils/env" not in text or "Debuggee command was: env DEBUGINFOD_URLS=" not in text:
            fail(f"V3 invalid {name} report no longer records env wrapper")
        if "heaptrack detected DEBUGINFOD_URLS" not in log:
            fail(f"V3 invalid {name} log no longer records DEBUGINFOD_URLS")

    if omission["binary_bytes_present"] is not False:
        fail("binary omission record says binary bytes are present")
    if (root / "provenance/v3/retained-v2/perf-record-candidate.data").exists():
        fail("duplicate retained V2 perf data was copied")
    canonical = root / "v3-capture/perf-record-candidate.data"
    if retention["canonical_capture_sha256"] != digest(canonical) or retention["canonical_capture_bytes"] != canonical.stat().st_size:
        fail("V3 retention canonical capture binding mismatch")
    if retention["v2_reuse_status"] == "":
        fail("V3 retention reuse status is empty")
    return {
        "source_base": EXPECTED["base_commit"],
        "candidate_diff_sha256": EXPECTED["diff"],
        "candidate_perf_sha256": EXPECTED["candidate_perf_data"],
        "control_perf_sha256": EXPECTED["control_perf_data"],
        "direct_heaptrack_candidate_allocation_calls": 19014852,
        "direct_heaptrack_control_allocation_calls": 11402262,
        "historical_invalid_heaptrack": True,
        "offline_lost_samples": 7,
        "offline_lost_chunks": 6,
        "offline_raw_lost_samples": 7,
        "offline_raw_lost_chunks": 6,
        "kernel_symbols_unavailable": True,
        "offline_scope": "whole process, including setup; symbol presence alone does not attribute both parses to one timed operation",
        "offline_gain_claim": False,
        "v3_gain_claim": False,
        "v4_gain_claim": False,
        "v3_allocator_instrumentation": "system_allocator_operation_scoped",
        "v3_allocator_scope": "operation_global_system_allocator",
        "expected_report_result_count": 1,
        "expected_report_case": "xlsx_one_percent_commit_save",
    }


def write_result(root: Path) -> None:
    archive = check_archive(root, allow_result_absent=True)
    facts = check_facts(root)
    result = {
        "schema_version": 1,
        "status": "passed",
        "verifier_scope": "archive hashes, receipt bindings, source/depfile/binary metadata, and stated diagnostic limitations",
        "workload_executed_by_verifier": False,
        "manifest_entries_after_result": archive["manifest_entries"] + 1,
        "sha256sum_entries_after_result": archive["sha256sum_entries"] + 1,
        "checks": {
            "archive": "passed",
            "source_and_depfiles": "passed",
            "v3_perf_allocator_and_invalid_heaptrack": "passed",
            "v4_direct_binary_heaptrack": "passed",
            "offline_analysis_limitations": "passed",
        },
        "facts": facts,
    }
    path = root / "results/verification.json"
    path.parent.mkdir(exist_ok=True)
    path.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")


def check(root: Path) -> None:
    archive = check_archive(root, allow_result_absent=False)
    facts = check_facts(root)
    result = read_json(root / "results/verification.json")
    if result.get("status") != "passed" or result.get("workload_executed_by_verifier") is not False:
        fail("verification result is not a passed no-workload receipt")
    if result.get("manifest_entries_after_result") != archive["manifest_entries"]:
        fail("verification result manifest count mismatch")
    if result.get("sha256sum_entries_after_result") != archive["sha256sum_entries"]:
        fail("verification result checksum count mismatch")
    if result.get("facts") != facts:
        fail("verification result facts mismatch")
    print(json.dumps({"status": "passed", "manifest_entries": archive["manifest_entries"], "sha256sum_entries": archive["sha256sum_entries"], "workload_executed": False}, sort_keys=True))


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--write-result", action="store_true")
    mode.add_argument("--check", action="store_true")
    args = parser.parse_args()
    try:
        if args.write_result:
            write_result(args.root.resolve())
        else:
            check(args.root.resolve())
    except (AssertionError, OSError, KeyError, json.JSONDecodeError) as exc:
        print(f"verification failed: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
