# V6 allocator diagnostic evidence (compact publication, revision V4)

This directory is a portable evidence bundle for the completed V6 diagnostic
captures. It contains one canonical copy of the V3 perf and operation-scoped
allocator outputs, the V3 heaptrack output retained as invalid historical
evidence, and the V4 direct-binary heaptrack output with valid target-stack
attribution. Release binaries are deliberately omitted; exact binary hashes, sizes, source files,
source patch, depfiles, toolchain identity, commands, grants, releases, and
raw report data are retained.

Run the standalone verifier without a repository, Cargo, network, or workload:

```
python3 tools/verify_v6_diagnostic.py --check
```

The verifier only reads this directory. It recomputes all archive hashes,
checks the manifest and SHA256SUMS, binds the V3 and V4 receipts to their raw
files, requires exactly one `xlsx_one_percent_commit_save` result in every
serialized report, checks every V3 allocation metric scope, checks the source
patch/depfile and binary-hash bindings, and checks the scope caveats below. It
never starts a benchmark or instrumentation process.

## Evidence interpretation

The V3 perf recordings are process-level diagnostic outputs that include
process/setup context; their elapsed time and RSS fields are not normal
latency or memory claims. The V3 allocator reports are different: their JSON
identifies `system_allocator_operation_scoped` instrumentation and
`operation_global_system_allocator` allocation metrics at
`results[0].operation_metrics.allocation.scope`. The verifier also checks
every serialized allocation metric scope. The allocation metrics begin after
the setup commit, so candidate/control allocation deltas in these
reports are operation-scoped. They must not be interpreted as whole-process
heaptrack totals.

The V3 heaptrack report is retained under `historical-invalid-heaptrack-v3/`.
Its debuggee was the `env DEBUGINFOD_URLS= ...` wrapper, and its top allocation
stack is `/usr/lib/cargo/bin/coreutils/env`; it is not target allocation
attribution. The V3 release receipt records this limitation. It must not be
used to compare target allocation calls.

The V4 direct-binary heaptrack report is under `direct-heaptrack-v4/`. Its
candidate and control whole-process allocation-call observations are
19,014,852 and 11,402,262, respectively, with target stacks present. This is
valid direct-binary heaptrack attribution, but instrumentation runtime, RSS,
and all allocations remain whole-process diagnostics rather than normal timing
or memory claims. No combined performance gain claim is made.

The offline perf analysis is under `provenance/offline-analysis.json` and
`provenance/v2-history/offline-analysis-report.txt`. It records seven lost
samples, six lost chunks, and unavailable kernel symbols. Symbol presence is
useful diagnostic evidence, not attribution of both parses to one timed
operation. The offline analysis did not start a new workload.

The V3 candidate perf record was reused from the V2 capture. The duplicate
`retained-v2` raw tree is omitted; `provenance/v3/reuse-manifest.json` and
`provenance/v3-retention-exceptions.json` preserve the reuse binding. No
binary payload is present in this bundle, so a fresh rerun requires supplying
the binaries identified in `provenance/binary-omission.json`.

All source and run paths in copied receipts are historical provenance paths.
The publication itself has no live-worktree dependency.

## Commit execution accounting for V4 heaptrack

For the `xlsx_one_percent_commit_save` harness case,
`run_xlsx_update_commit_save` calls `xlsx_expected_output` before entering the
measured loop. That setup path commits and saves once. With `warmup=0` and
`samples=1`, the measured loop then commits and saves once. V4 heaptrack sees
both commit/save operations because it is whole-process instrumentation; its
allocation-call difference must not be described as two measured samples. This
accounting note does not redefine the operation-scoped V3 allocator metrics.
