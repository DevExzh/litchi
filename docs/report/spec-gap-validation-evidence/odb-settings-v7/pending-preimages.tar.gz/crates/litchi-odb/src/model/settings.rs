//! Bounded, inert ODF database connection and driver settings.
//!
//! These values describe the XML configuration carried by an ODB package.  A
//! settings value is deliberately independent of any database driver: reading
//! it never resolves a driver, asks for a password, opens a socket, or runs a
//! command.

use litchi_core::{Error, Result};
use quick_xml::{
    XmlVersion,
    events::{BytesStart, Event},
    name::{Namespace, ResolveResult},
    reader::NsReader,
};
#[cfg(test)]
use std::sync::{
    Mutex,
    atomic::{AtomicUsize, Ordering},
};

const OFFICE_NAMESPACE: &[u8] = b"urn:oasis:names:tc:opendocument:xmlns:office:1.0";
const DATABASE_NAMESPACE: &[u8] = b"urn:oasis:names:tc:opendocument:xmlns:database:1.0";
const MAX_TEXT_BYTES: usize = 1024 * 1024;
const MAX_SETTINGS: usize = 65_536;
const MAX_SETTING_VALUES: usize = 65_536;
const MAX_FILTER_PATTERNS: usize = 65_536;
const MAX_DEPTH: usize = 256;

#[cfg(test)]
static PARSE_COUNT: AtomicUsize = AtomicUsize::new(0);
#[cfg(test)]
static PARSE_TEST_LOCK: Mutex<()> = Mutex::new(());

/// A login declaration from `db:connection-data`.
///
/// Password values are intentionally not modeled.  `is-password-required` is
/// only an inert producer hint; this crate never obtains or tests credentials.
#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub struct LoginSettings {
    user_name: Option<String>,
    use_system_user: Option<bool>,
    password_required: Option<bool>,
    login_timeout: Option<u64>,
}

impl LoginSettings {
    /// Creates an empty login declaration.
    #[must_use]
    pub const fn new() -> Self {
        Self {
            user_name: None,
            use_system_user: None,
            password_required: None,
            login_timeout: None,
        }
    }

    /// Sets the inert user-name hint.
    #[must_use]
    pub fn with_user_name(mut self, value: impl Into<String>) -> Self {
        self.user_name = Some(value.into());
        self.use_system_user = None;
        self
    }

    /// Sets the producer's system-user flag.
    #[must_use]
    pub fn with_use_system_user(mut self, value: Option<bool>) -> Self {
        self.use_system_user = value;
        if value.is_some() {
            self.user_name = None;
        }
        self
    }

    /// Sets whether a host would request a password.  No password is stored.
    #[must_use]
    pub const fn with_password_required(mut self, value: Option<bool>) -> Self {
        self.password_required = value;
        self
    }

    /// Sets the positive, inert login timeout in seconds.
    #[must_use]
    pub const fn with_login_timeout(mut self, value: Option<u64>) -> Self {
        self.login_timeout = value;
        self
    }

    #[must_use]
    pub fn user_name(&self) -> Option<&str> {
        self.user_name.as_deref()
    }

    #[must_use]
    pub const fn use_system_user(&self) -> Option<bool> {
        self.use_system_user
    }

    #[must_use]
    pub const fn password_required(&self) -> Option<bool> {
        self.password_required
    }

    #[must_use]
    pub const fn login_timeout(&self) -> Option<u64> {
        self.login_timeout
    }
}

/// The bounded inert auto-increment statements under driver settings.
#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub struct AutoIncrementSettings {
    additional_column_statement: Option<String>,
    row_retrieving_statement: Option<String>,
}

impl AutoIncrementSettings {
    #[must_use]
    pub const fn new() -> Self {
        Self {
            additional_column_statement: None,
            row_retrieving_statement: None,
        }
    }

    #[must_use]
    pub fn with_additional_column_statement(mut self, value: impl Into<String>) -> Self {
        self.additional_column_statement = Some(value.into());
        self
    }

    #[must_use]
    pub fn with_row_retrieving_statement(mut self, value: impl Into<String>) -> Self {
        self.row_retrieving_statement = Some(value.into());
        self
    }

    #[must_use]
    pub fn additional_column_statement(&self) -> Option<&str> {
        self.additional_column_statement.as_deref()
    }

    #[must_use]
    pub fn row_retrieving_statement(&self) -> Option<&str> {
        self.row_retrieving_statement.as_deref()
    }
}

/// Delimiter hints used by a driver or one table setting.
#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub struct DelimiterSettings {
    field: Option<String>,
    string: Option<String>,
    decimal: Option<String>,
    thousand: Option<String>,
}

impl DelimiterSettings {
    #[must_use]
    pub const fn new() -> Self {
        Self {
            field: None,
            string: None,
            decimal: None,
            thousand: None,
        }
    }

    #[must_use]
    pub fn with_field(mut self, value: impl Into<String>) -> Self {
        self.field = Some(value.into());
        self
    }

    #[must_use]
    pub fn with_string(mut self, value: impl Into<String>) -> Self {
        self.string = Some(value.into());
        self
    }

    #[must_use]
    pub fn with_decimal(mut self, value: impl Into<String>) -> Self {
        self.decimal = Some(value.into());
        self
    }

    #[must_use]
    pub fn with_thousand(mut self, value: impl Into<String>) -> Self {
        self.thousand = Some(value.into());
        self
    }

    #[must_use]
    pub fn field(&self) -> Option<&str> {
        self.field.as_deref()
    }

    #[must_use]
    pub fn string(&self) -> Option<&str> {
        self.string.as_deref()
    }

    #[must_use]
    pub fn decimal(&self) -> Option<&str> {
        self.decimal.as_deref()
    }

    #[must_use]
    pub fn thousand(&self) -> Option<&str> {
        self.thousand.as_deref()
    }
}

/// An inert character-set declaration.
#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub struct CharacterSetSettings {
    encoding: Option<String>,
}

impl CharacterSetSettings {
    #[must_use]
    pub const fn new() -> Self {
        Self { encoding: None }
    }

    #[must_use]
    pub fn with_encoding(mut self, value: impl Into<String>) -> Self {
        self.encoding = Some(value.into());
        self
    }

    #[must_use]
    pub fn encoding(&self) -> Option<&str> {
        self.encoding.as_deref()
    }

    pub(crate) fn validate(&self) -> Result<()> {
        // ODF 1.4 textEncoding: [A-Za-z][A-Za-z0-9._\-]*.
        if let Some(value) = self.encoding() {
            let mut bytes = value.bytes();
            if !bytes.next().is_some_and(|byte| byte.is_ascii_alphabetic())
                || !bytes
                    .all(|byte| byte.is_ascii_alphanumeric() || matches!(byte, b'.' | b'_' | b'-'))
            {
                return Err(Error::InvalidFormat(
                    "invalid database character-set encoding".into(),
                ));
            }
        }
        Ok(())
    }
}

/// One table-scoped driver setting.  ODF intentionally does not attach a
/// table name to this element; the order and multiplicity are retained.
#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub struct TableSetting {
    first_row_header_line: Option<bool>,
    show_deleted: Option<bool>,
    delimiter: Option<DelimiterSettings>,
    character_set: Option<CharacterSetSettings>,
}

impl TableSetting {
    #[must_use]
    pub const fn new() -> Self {
        Self {
            first_row_header_line: None,
            show_deleted: None,
            delimiter: None,
            character_set: None,
        }
    }

    #[must_use]
    pub const fn with_first_row_header_line(mut self, value: Option<bool>) -> Self {
        self.first_row_header_line = value;
        self
    }

    #[must_use]
    pub const fn with_show_deleted(mut self, value: Option<bool>) -> Self {
        self.show_deleted = value;
        self
    }

    #[must_use]
    pub fn with_delimiter(mut self, value: Option<DelimiterSettings>) -> Self {
        self.delimiter = value;
        self
    }

    #[must_use]
    pub fn with_character_set(mut self, value: Option<CharacterSetSettings>) -> Self {
        self.character_set = value;
        self
    }

    #[must_use]
    pub const fn first_row_header_line(&self) -> Option<bool> {
        self.first_row_header_line
    }

    #[must_use]
    pub const fn show_deleted(&self) -> Option<bool> {
        self.show_deleted
    }

    #[must_use]
    pub fn delimiter(&self) -> Option<&DelimiterSettings> {
        self.delimiter.as_ref()
    }

    #[must_use]
    pub fn character_set(&self) -> Option<&CharacterSetSettings> {
        self.character_set.as_ref()
    }
}

/// A bounded driver-settings subtree.
#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub struct DriverSettings {
    show_deleted: Option<bool>,
    system_driver_settings: Option<String>,
    base_dn: Option<String>,
    first_row_header_line: Option<bool>,
    parameter_name_substitution: Option<bool>,
    auto_increment: Option<AutoIncrementSettings>,
    delimiter: Option<DelimiterSettings>,
    character_set: Option<CharacterSetSettings>,
    table_settings: Vec<TableSetting>,
}

impl DriverSettings {
    #[must_use]
    pub const fn new() -> Self {
        Self {
            show_deleted: None,
            system_driver_settings: None,
            base_dn: None,
            first_row_header_line: None,
            parameter_name_substitution: None,
            auto_increment: None,
            delimiter: None,
            character_set: None,
            table_settings: Vec::new(),
        }
    }

    #[must_use]
    pub const fn with_show_deleted(mut self, value: Option<bool>) -> Self {
        self.show_deleted = value;
        self
    }

    #[must_use]
    pub fn with_system_driver_settings(mut self, value: impl Into<String>) -> Self {
        self.system_driver_settings = Some(value.into());
        self
    }

    #[must_use]
    pub fn with_base_dn(mut self, value: impl Into<String>) -> Self {
        self.base_dn = Some(value.into());
        self
    }

    #[must_use]
    pub const fn with_first_row_header_line(mut self, value: Option<bool>) -> Self {
        self.first_row_header_line = value;
        self
    }

    #[must_use]
    pub const fn with_parameter_name_substitution(mut self, value: Option<bool>) -> Self {
        self.parameter_name_substitution = value;
        self
    }

    #[must_use]
    pub fn with_auto_increment(mut self, value: Option<AutoIncrementSettings>) -> Self {
        self.auto_increment = value;
        self
    }

    #[must_use]
    pub fn with_delimiter(mut self, value: Option<DelimiterSettings>) -> Self {
        self.delimiter = value;
        self
    }

    #[must_use]
    pub fn with_character_set(mut self, value: Option<CharacterSetSettings>) -> Self {
        self.character_set = value;
        self
    }

    #[must_use]
    pub fn with_table_settings(mut self, value: Vec<TableSetting>) -> Self {
        self.table_settings = value;
        self
    }

    #[must_use]
    pub const fn show_deleted(&self) -> Option<bool> {
        self.show_deleted
    }

    #[must_use]
    pub fn system_driver_settings(&self) -> Option<&str> {
        self.system_driver_settings.as_deref()
    }

    #[must_use]
    pub fn base_dn(&self) -> Option<&str> {
        self.base_dn.as_deref()
    }

    #[must_use]
    pub const fn first_row_header_line(&self) -> Option<bool> {
        self.first_row_header_line
    }

    #[must_use]
    pub const fn parameter_name_substitution(&self) -> Option<bool> {
        self.parameter_name_substitution
    }

    #[must_use]
    pub fn auto_increment(&self) -> Option<&AutoIncrementSettings> {
        self.auto_increment.as_ref()
    }

    #[must_use]
    pub fn delimiter(&self) -> Option<&DelimiterSettings> {
        self.delimiter.as_ref()
    }

    #[must_use]
    pub fn character_set(&self) -> Option<&CharacterSetSettings> {
        self.character_set.as_ref()
    }

    #[must_use]
    pub fn table_settings(&self) -> &[TableSetting] {
        &self.table_settings
    }
}

/// The comparison mode vocabulary from ODF §12.15.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub enum BooleanComparisonMode {
    EqualInteger,
    IsBoolean,
    EqualBoolean,
    EqualUseOnlyZero,
}

impl BooleanComparisonMode {
    #[must_use]
    pub const fn as_str(self) -> &'static str {
        match self {
            Self::EqualInteger => "equal-integer",
            Self::IsBoolean => "is-boolean",
            Self::EqualBoolean => "equal-boolean",
            Self::EqualUseOnlyZero => "equal-use-only-zero",
        }
    }
}

/// A table include/exclude filter.  Patterns are inert producer strings.
#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub struct TableFilter {
    include: Vec<String>,
    exclude: Vec<String>,
}

impl TableFilter {
    #[must_use]
    pub const fn new() -> Self {
        Self {
            include: Vec::new(),
            exclude: Vec::new(),
        }
    }

    #[must_use]
    pub fn with_include(mut self, values: Vec<String>) -> Self {
        self.include = values;
        self
    }

    #[must_use]
    pub fn with_exclude(mut self, values: Vec<String>) -> Self {
        self.exclude = values;
        self
    }

    #[must_use]
    pub fn include(&self) -> &[String] {
        &self.include
    }

    #[must_use]
    pub fn exclude(&self) -> &[String] {
        &self.exclude
    }
}

/// A table-type filter from application connection settings.
#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub struct TableTypeFilter {
    table_types: Vec<String>,
}

impl TableTypeFilter {
    #[must_use]
    pub const fn new() -> Self {
        Self {
            table_types: Vec::new(),
        }
    }

    #[must_use]
    pub fn with_table_types(mut self, values: Vec<String>) -> Self {
        self.table_types = values;
        self
    }

    #[must_use]
    pub fn table_types(&self) -> &[String] {
        &self.table_types
    }
}

/// The six ODF data-source setting type tokens.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub enum DataSourceSettingType {
    Boolean,
    Short,
    Int,
    Long,
    Double,
    String,
}

impl DataSourceSettingType {
    #[must_use]
    pub const fn as_str(self) -> &'static str {
        match self {
            Self::Boolean => "boolean",
            Self::Short => "short",
            Self::Int => "int",
            Self::Long => "long",
            Self::Double => "double",
            Self::String => "string",
        }
    }
}

/// One typed-but-inert data-source property.  Values remain lexical because
/// this crate does not own a driver's conversion rules.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct DataSourceSetting {
    name: String,
    setting_type: DataSourceSettingType,
    is_list: Option<bool>,
    values: Vec<String>,
}

impl DataSourceSetting {
    #[must_use]
    pub fn new(name: impl Into<String>, setting_type: DataSourceSettingType) -> Self {
        Self {
            name: name.into(),
            setting_type,
            is_list: None,
            values: Vec::new(),
        }
    }

    #[must_use]
    pub const fn with_is_list(mut self, value: Option<bool>) -> Self {
        self.is_list = value;
        self
    }

    #[must_use]
    pub fn with_values(mut self, values: Vec<String>) -> Self {
        self.values = values;
        self
    }

    #[must_use]
    pub fn name(&self) -> &str {
        &self.name
    }

    #[must_use]
    pub const fn setting_type(&self) -> DataSourceSettingType {
        self.setting_type
    }

    #[must_use]
    pub const fn is_list(&self) -> Option<bool> {
        self.is_list
    }

    #[must_use]
    pub fn values(&self) -> &[String] {
        &self.values
    }
}

/// Application-level ODF connection settings, with inert table filters.
#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub struct ApplicationConnectionSettings {
    table_name_length_limited: Option<bool>,
    enable_sql92_check: Option<bool>,
    append_table_alias_name: Option<bool>,
    ignore_driver_privileges: Option<bool>,
    boolean_comparison_mode: Option<BooleanComparisonMode>,
    use_catalog: Option<bool>,
    max_row_count: Option<i64>,
    suppress_version_columns: Option<bool>,
    table_filter: Option<TableFilter>,
    table_type_filter: Option<TableTypeFilter>,
    data_source_settings: Vec<DataSourceSetting>,
}

impl ApplicationConnectionSettings {
    #[must_use]
    pub const fn new() -> Self {
        Self {
            table_name_length_limited: None,
            enable_sql92_check: None,
            append_table_alias_name: None,
            ignore_driver_privileges: None,
            boolean_comparison_mode: None,
            use_catalog: None,
            max_row_count: None,
            suppress_version_columns: None,
            table_filter: None,
            table_type_filter: None,
            data_source_settings: Vec::new(),
        }
    }

    #[must_use]
    pub const fn with_table_name_length_limited(mut self, value: Option<bool>) -> Self {
        self.table_name_length_limited = value;
        self
    }

    #[must_use]
    pub const fn with_enable_sql92_check(mut self, value: Option<bool>) -> Self {
        self.enable_sql92_check = value;
        self
    }

    #[must_use]
    pub const fn with_append_table_alias_name(mut self, value: Option<bool>) -> Self {
        self.append_table_alias_name = value;
        self
    }

    #[must_use]
    pub const fn with_ignore_driver_privileges(mut self, value: Option<bool>) -> Self {
        self.ignore_driver_privileges = value;
        self
    }

    #[must_use]
    pub const fn with_boolean_comparison_mode(
        mut self,
        value: Option<BooleanComparisonMode>,
    ) -> Self {
        self.boolean_comparison_mode = value;
        self
    }

    #[must_use]
    pub const fn with_use_catalog(mut self, value: Option<bool>) -> Self {
        self.use_catalog = value;
        self
    }

    #[must_use]
    pub const fn with_max_row_count(mut self, value: Option<i64>) -> Self {
        self.max_row_count = value;
        self
    }

    #[must_use]
    pub const fn with_suppress_version_columns(mut self, value: Option<bool>) -> Self {
        self.suppress_version_columns = value;
        self
    }

    #[must_use]
    pub fn with_table_filter(mut self, value: Option<TableFilter>) -> Self {
        self.table_filter = value;
        self
    }

    #[must_use]
    pub fn with_table_type_filter(mut self, value: Option<TableTypeFilter>) -> Self {
        self.table_type_filter = value;
        self
    }

    #[must_use]
    pub fn with_data_source_settings(mut self, value: Vec<DataSourceSetting>) -> Self {
        self.data_source_settings = value;
        self
    }

    #[must_use]
    pub const fn table_name_length_limited(&self) -> Option<bool> {
        self.table_name_length_limited
    }

    #[must_use]
    pub const fn enable_sql92_check(&self) -> Option<bool> {
        self.enable_sql92_check
    }

    #[must_use]
    pub const fn append_table_alias_name(&self) -> Option<bool> {
        self.append_table_alias_name
    }

    #[must_use]
    pub const fn ignore_driver_privileges(&self) -> Option<bool> {
        self.ignore_driver_privileges
    }

    #[must_use]
    pub const fn boolean_comparison_mode(&self) -> Option<BooleanComparisonMode> {
        self.boolean_comparison_mode
    }

    #[must_use]
    pub const fn use_catalog(&self) -> Option<bool> {
        self.use_catalog
    }

    #[must_use]
    pub const fn max_row_count(&self) -> Option<i64> {
        self.max_row_count
    }

    #[must_use]
    pub const fn suppress_version_columns(&self) -> Option<bool> {
        self.suppress_version_columns
    }

    #[must_use]
    pub fn table_filter(&self) -> Option<&TableFilter> {
        self.table_filter.as_ref()
    }

    #[must_use]
    pub fn table_type_filter(&self) -> Option<&TableTypeFilter> {
        self.table_type_filter.as_ref()
    }

    #[must_use]
    pub fn data_source_settings(&self) -> &[DataSourceSetting] {
        &self.data_source_settings
    }
}

/// All modeled settings below one ODF database data-source.
#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub struct DatabaseSettings {
    login: Option<LoginSettings>,
    driver: Option<DriverSettings>,
    application_connection: Option<ApplicationConnectionSettings>,
}

impl DatabaseSettings {
    #[must_use]
    pub const fn new() -> Self {
        Self {
            login: None,
            driver: None,
            application_connection: None,
        }
    }

    #[must_use]
    pub fn with_login(mut self, value: Option<LoginSettings>) -> Self {
        self.login = value;
        self
    }

    #[must_use]
    pub fn with_driver(mut self, value: Option<DriverSettings>) -> Self {
        self.driver = value;
        self
    }

    #[must_use]
    pub fn with_application_connection(
        mut self,
        value: Option<ApplicationConnectionSettings>,
    ) -> Self {
        self.application_connection = value;
        self
    }

    #[must_use]
    pub fn login(&self) -> Option<&LoginSettings> {
        self.login.as_ref()
    }

    #[must_use]
    pub fn driver(&self) -> Option<&DriverSettings> {
        self.driver.as_ref()
    }

    #[must_use]
    pub fn application_connection(&self) -> Option<&ApplicationConnectionSettings> {
        self.application_connection.as_ref()
    }

    #[must_use]
    pub fn is_empty(&self) -> bool {
        self.login.is_none() && self.driver.is_none() && self.application_connection.is_none()
    }
}

/// Short ergonomic alias for [`DatabaseSettings`].
pub type Settings = DatabaseSettings;

#[derive(Clone, Copy, PartialEq, Eq)]
enum NamespaceKind {
    Office,
    Database,
    Other,
}

#[derive(Clone, Copy, PartialEq, Eq)]
enum Element {
    Document,
    Body,
    Database,
    DataSource,
    ConnectionData,
    Login,
    Driver,
    AutoIncrement,
    Delimiter,
    CharacterSet,
    TableSettings,
    TableSetting,
    Application,
    TableFilter,
    IncludeFilter,
    ExcludeFilter,
    Pattern,
    TableTypeFilter,
    TableType,
    DataSourceSettings,
    DataSourceSetting,
    DataSourceSettingValue,
    Other,
}

struct Frame {
    element: Element,
    text: String,
    login: Option<LoginSettings>,
    driver: Option<DriverSettings>,
    auto_increment: Option<AutoIncrementSettings>,
    delimiter: Option<DelimiterSettings>,
    character_set: Option<CharacterSetSettings>,
    table_setting: Option<TableSetting>,
    application: Option<ApplicationConnectionSettings>,
    table_filter: Option<TableFilter>,
    table_type_filter: Option<TableTypeFilter>,
    data_source_setting: Option<DataSourceSetting>,
}

impl Frame {
    fn new(element: Element) -> Self {
        Self {
            element,
            text: String::new(),
            login: None,
            driver: None,
            auto_increment: None,
            delimiter: None,
            character_set: None,
            table_setting: None,
            application: None,
            table_filter: None,
            table_type_filter: None,
            data_source_setting: None,
        }
    }
}

/// Parses the known ODF settings vocabulary under the unique data source.
pub(crate) fn parse(
    source: &str,
    max_attribute_bytes: usize,
    max_settings: usize,
    max_setting_values: usize,
    max_filter_patterns: usize,
) -> Result<DatabaseSettings> {
    #[cfg(test)]
    PARSE_COUNT.fetch_add(1, Ordering::Relaxed);

    let mut reader = NsReader::from_str(source);
    reader.config_mut().check_end_names = true;
    let mut buffer = Vec::new();
    let mut stack = Vec::<Frame>::new();
    let mut settings = DatabaseSettings::new();
    let mut data_source_seen = false;
    let mut setting_count = 0usize;
    let mut value_count = 0usize;
    let mut pattern_count = 0usize;

    loop {
        let (resolved, raw_event) = reader
            .read_resolved_event_into(&mut buffer)
            .map_err(|error| invalid(&format!("invalid ODB settings XML: {error}")))?;
        let namespace = namespace_kind(&resolved);
        let is_eof = matches!(raw_event, Event::Eof);
        match raw_event {
            Event::Start(element) => {
                if stack.len() >= MAX_DEPTH {
                    return Err(invalid("ODB settings XML nesting exceeds the limit"));
                }
                let kind = classify(stack.last().map(|frame| frame.element), namespace, &element);
                let mut frame = Frame::new(kind);
                parse_attributes(&reader, &element, kind, &mut frame, max_attribute_bytes)?;
                if kind == Element::DataSource {
                    if data_source_seen {
                        return Err(invalid("ODB settings has multiple data sources"));
                    }
                    data_source_seen = true;
                }
                stack.push(frame);
            },
            Event::Empty(element) => {
                let kind = classify(stack.last().map(|frame| frame.element), namespace, &element);
                let mut frame = Frame::new(kind);
                parse_attributes(&reader, &element, kind, &mut frame, max_attribute_bytes)?;
                if kind == Element::DataSource {
                    if data_source_seen {
                        return Err(invalid("ODB settings has multiple data sources"));
                    }
                    data_source_seen = true;
                }
                finalize(
                    frame,
                    &mut stack,
                    &mut settings,
                    &mut setting_count,
                    &mut value_count,
                    &mut pattern_count,
                    max_attribute_bytes,
                    max_settings,
                    max_setting_values,
                    max_filter_patterns,
                )?;
            },
            Event::Text(text) => {
                if stack.last().is_some_and(|frame| {
                    matches!(
                        frame.element,
                        Element::Pattern | Element::TableType | Element::DataSourceSettingValue
                    )
                }) {
                    append_text(
                        &mut stack,
                        text.xml_content(XmlVersion::Explicit1_0)
                            .map_err(|error| {
                                invalid(&format!("invalid ODB settings text: {error}"))
                            })?
                            .as_ref(),
                        max_attribute_bytes,
                    )?;
                }
            },
            Event::CData(text) => {
                if stack.last().is_some_and(|frame| {
                    matches!(
                        frame.element,
                        Element::Pattern | Element::TableType | Element::DataSourceSettingValue
                    )
                }) {
                    append_text(
                        &mut stack,
                        text.decode()
                            .map_err(|error| {
                                invalid(&format!("invalid ODB settings CDATA: {error}"))
                            })?
                            .as_ref(),
                        max_attribute_bytes,
                    )?;
                }
            },
            Event::End(_) => {
                let frame = stack
                    .pop()
                    .ok_or_else(|| invalid("ODB settings has an unmatched closing tag"))?;
                finalize(
                    frame,
                    &mut stack,
                    &mut settings,
                    &mut setting_count,
                    &mut value_count,
                    &mut pattern_count,
                    max_attribute_bytes,
                    max_settings,
                    max_setting_values,
                    max_filter_patterns,
                )?;
            },
            Event::DocType(_) => return Err(invalid("DOCTYPE is not permitted in ODB settings")),
            Event::GeneralRef(reference) => {
                if stack.last().is_some_and(|frame| {
                    matches!(
                        frame.element,
                        Element::Pattern | Element::TableType | Element::DataSourceSettingValue
                    )
                }) {
                    let decoded = decode_reference(&reference)?;
                    append_text(&mut stack, &decoded, max_attribute_bytes)?;
                }
            },
            Event::Comment(_) | Event::Decl(_) | Event::PI(_) | Event::Eof => {},
        }
        buffer.clear();
        if is_eof {
            break;
        }
    }
    if !stack.is_empty() {
        return Err(invalid("ODB settings XML is incomplete"));
    }
    if !data_source_seen {
        return Err(invalid("ODB settings has no data source"));
    }
    Ok(settings)
}

#[cfg(test)]
pub(crate) fn reset_parse_count() {
    PARSE_COUNT.store(0, Ordering::Relaxed);
}

#[cfg(test)]
pub(crate) fn parse_count() -> usize {
    PARSE_COUNT.load(Ordering::Relaxed)
}

#[cfg(test)]
pub(crate) fn parse_test_lock() -> &'static Mutex<()> {
    &PARSE_TEST_LOCK
}

fn classify(
    parent: Option<Element>,
    namespace: NamespaceKind,
    element: &BytesStart<'_>,
) -> Element {
    let local = element.local_name();
    if namespace == NamespaceKind::Other {
        return Element::Other;
    }
    if namespace == NamespaceKind::Database {
        return match (parent, local.as_ref()) {
            (Some(Element::Database), b"data-source") => Element::DataSource,
            (Some(Element::DataSource), b"connection-data") => Element::ConnectionData,
            (Some(Element::ConnectionData), b"login") => Element::Login,
            (Some(Element::DataSource), b"driver-settings") => Element::Driver,
            (Some(Element::Driver), b"auto-increment") => Element::AutoIncrement,
            (Some(Element::Driver | Element::TableSetting), b"delimiter") => Element::Delimiter,
            (Some(Element::Driver | Element::TableSetting), b"character-set") => {
                Element::CharacterSet
            },
            (Some(Element::Driver), b"table-settings") => Element::TableSettings,
            (Some(Element::TableSettings), b"table-setting") => Element::TableSetting,
            (Some(Element::DataSource), b"application-connection-settings") => Element::Application,
            (Some(Element::Application), b"table-filter") => Element::TableFilter,
            (Some(Element::TableFilter), b"table-include-filter") => Element::IncludeFilter,
            (Some(Element::TableFilter), b"table-exclude-filter") => Element::ExcludeFilter,
            (Some(Element::IncludeFilter | Element::ExcludeFilter), b"table-filter-pattern") => {
                Element::Pattern
            },
            (Some(Element::Application), b"table-type-filter") => Element::TableTypeFilter,
            (Some(Element::TableTypeFilter), b"table-type") => Element::TableType,
            (Some(Element::Application), b"data-source-settings") => Element::DataSourceSettings,
            (Some(Element::DataSourceSettings), b"data-source-setting") => {
                Element::DataSourceSetting
            },
            (Some(Element::DataSourceSetting), b"data-source-setting-value") => {
                Element::DataSourceSettingValue
            },
            _ => Element::Other,
        };
    }
    if namespace != NamespaceKind::Office {
        return Element::Other;
    }
    match (parent, local.as_ref()) {
        (None, b"document-content") => Element::Document,
        (Some(Element::Document), b"body") => Element::Body,
        (Some(Element::Body), b"database") => Element::Database,
        _ => Element::Other,
    }
}

fn namespace_kind(value: &ResolveResult<'_>) -> NamespaceKind {
    if matches!(value, ResolveResult::Bound(Namespace(uri)) if *uri == DATABASE_NAMESPACE) {
        NamespaceKind::Database
    } else if matches!(value, ResolveResult::Bound(Namespace(uri)) if *uri == OFFICE_NAMESPACE) {
        NamespaceKind::Office
    } else {
        NamespaceKind::Other
    }
}

fn parse_attributes(
    reader: &NsReader<&[u8]>,
    element: &BytesStart<'_>,
    kind: Element,
    frame: &mut Frame,
    max_attribute_bytes: usize,
) -> Result<()> {
    match kind {
        Element::Login => {
            let user_name = db_attr(reader, element, b"user-name", max_attribute_bytes)?;
            let use_system_user =
                db_attr(reader, element, b"use-system-user", max_attribute_bytes)?
                    .map(|value| parse_bool(&value))
                    .transpose()?;
            if user_name.is_some() && use_system_user.is_some() {
                return Err(invalid(
                    "ODB login cannot declare both user-name and use-system-user",
                ));
            }
            frame.login = Some(LoginSettings {
                user_name,
                use_system_user,
                password_required: db_attr(
                    reader,
                    element,
                    b"is-password-required",
                    max_attribute_bytes,
                )?
                .map(|value| parse_bool(&value))
                .transpose()?,
                login_timeout: db_attr(reader, element, b"login-timeout", max_attribute_bytes)?
                    .map(|value| parse_positive_u64(&value, "login-timeout"))
                    .transpose()?,
            });
        },
        Element::Driver => {
            frame.driver = Some(DriverSettings {
                show_deleted: db_attr(reader, element, b"show-deleted", max_attribute_bytes)?
                    .map(|value| parse_bool(&value))
                    .transpose()?,
                system_driver_settings: db_attr(
                    reader,
                    element,
                    b"system-driver-settings",
                    max_attribute_bytes,
                )?,
                base_dn: db_attr(reader, element, b"base-dn", max_attribute_bytes)?,
                first_row_header_line: db_attr(
                    reader,
                    element,
                    b"is-first-row-header-line",
                    max_attribute_bytes,
                )?
                .map(|value| parse_bool(&value))
                .transpose()?,
                parameter_name_substitution: db_attr(
                    reader,
                    element,
                    b"parameter-name-substitution",
                    max_attribute_bytes,
                )?
                .map(|value| parse_bool(&value))
                .transpose()?,
                auto_increment: None,
                delimiter: None,
                character_set: None,
                table_settings: Vec::new(),
            });
        },
        Element::AutoIncrement => {
            frame.auto_increment = Some(AutoIncrementSettings {
                additional_column_statement: db_attr(
                    reader,
                    element,
                    b"additional-column-statement",
                    max_attribute_bytes,
                )?,
                row_retrieving_statement: db_attr(
                    reader,
                    element,
                    b"row-retrieving-statement",
                    max_attribute_bytes,
                )?,
            });
        },
        Element::Delimiter => {
            frame.delimiter = Some(DelimiterSettings {
                field: db_attr(reader, element, b"field", max_attribute_bytes)?,
                string: db_attr(reader, element, b"string", max_attribute_bytes)?,
                decimal: db_attr(reader, element, b"decimal", max_attribute_bytes)?,
                thousand: db_attr(reader, element, b"thousand", max_attribute_bytes)?,
            });
        },
        Element::CharacterSet => {
            let value = CharacterSetSettings {
                encoding: db_attr(reader, element, b"encoding", max_attribute_bytes)?,
            };
            value.validate()?;
            frame.character_set = Some(value);
        },
        Element::TableSetting => {
            frame.table_setting = Some(TableSetting {
                first_row_header_line: db_attr(
                    reader,
                    element,
                    b"is-first-row-header-line",
                    max_attribute_bytes,
                )?
                .map(|value| parse_bool(&value))
                .transpose()?,
                show_deleted: db_attr(reader, element, b"show-deleted", max_attribute_bytes)?
                    .map(|value| parse_bool(&value))
                    .transpose()?,
                delimiter: None,
                character_set: None,
            });
        },
        Element::Application => {
            frame.application = Some(ApplicationConnectionSettings {
                table_name_length_limited: db_attr(
                    reader,
                    element,
                    b"is-table-name-length-limited",
                    max_attribute_bytes,
                )?
                .map(|value| parse_bool(&value))
                .transpose()?,
                enable_sql92_check: db_attr(
                    reader,
                    element,
                    b"enable-sql92-check",
                    max_attribute_bytes,
                )?
                .map(|value| parse_bool(&value))
                .transpose()?,
                append_table_alias_name: db_attr(
                    reader,
                    element,
                    b"append-table-alias-name",
                    max_attribute_bytes,
                )?
                .map(|value| parse_bool(&value))
                .transpose()?,
                ignore_driver_privileges: db_attr(
                    reader,
                    element,
                    b"ignore-driver-privileges",
                    max_attribute_bytes,
                )?
                .map(|value| parse_bool(&value))
                .transpose()?,
                boolean_comparison_mode: db_attr(
                    reader,
                    element,
                    b"boolean-comparison-mode",
                    max_attribute_bytes,
                )?
                .map(|value| parse_boolean_comparison_mode(&value))
                .transpose()?,
                use_catalog: db_attr(reader, element, b"use-catalog", max_attribute_bytes)?
                    .map(|value| parse_bool(&value))
                    .transpose()?,
                max_row_count: db_attr(reader, element, b"max-row-count", max_attribute_bytes)?
                    .map(|value| {
                        value
                            .parse::<i64>()
                            .map_err(|_| invalid("invalid ODB max-row-count"))
                    })
                    .transpose()?,
                suppress_version_columns: db_attr(
                    reader,
                    element,
                    b"suppress-version-columns",
                    max_attribute_bytes,
                )?
                .map(|value| parse_bool(&value))
                .transpose()?,
                table_filter: None,
                table_type_filter: None,
                data_source_settings: Vec::new(),
            });
        },
        Element::TableFilter => frame.table_filter = Some(TableFilter::new()),
        Element::IncludeFilter | Element::ExcludeFilter => {},
        Element::TableTypeFilter => frame.table_type_filter = Some(TableTypeFilter::new()),
        Element::DataSourceSetting => {
            let name = db_attr(
                reader,
                element,
                b"data-source-setting-name",
                max_attribute_bytes,
            )?
            .ok_or_else(|| invalid("ODB data-source-setting is missing a name"))?;
            let setting_type = db_attr(
                reader,
                element,
                b"data-source-setting-type",
                max_attribute_bytes,
            )?
            .ok_or_else(|| invalid("ODB data-source-setting is missing a type"))
            .and_then(|value| parse_data_source_setting_type(&value))?;
            frame.data_source_setting = Some(DataSourceSetting {
                name,
                setting_type,
                is_list: db_attr(
                    reader,
                    element,
                    b"data-source-setting-is-list",
                    max_attribute_bytes,
                )?
                .map(|value| parse_bool(&value))
                .transpose()?,
                values: Vec::new(),
            });
        },
        Element::Document
        | Element::Body
        | Element::Database
        | Element::DataSource
        | Element::ConnectionData
        | Element::Pattern
        | Element::TableType
        | Element::TableSettings
        | Element::DataSourceSettings
        | Element::DataSourceSettingValue
        | Element::Other => {},
    }
    Ok(())
}

fn finalize(
    frame: Frame,
    stack: &mut [Frame],
    settings: &mut DatabaseSettings,
    setting_count: &mut usize,
    value_count: &mut usize,
    pattern_count: &mut usize,
    max_attribute_bytes: usize,
    max_settings: usize,
    max_setting_values: usize,
    max_filter_patterns: usize,
) -> Result<()> {
    if frame.element == Element::Pattern {
        *pattern_count = pattern_count
            .checked_add(1)
            .ok_or_else(|| invalid("ODB filter pattern count overflow"))?;
        if *pattern_count > max_filter_patterns.min(MAX_FILTER_PATTERNS) {
            return Err(invalid("ODB filter pattern count exceeds the limit"));
        }
        if frame.text.len() > max_attribute_bytes {
            return Err(invalid("ODB filter pattern exceeds the byte limit"));
        }
        let parent_index = stack
            .len()
            .checked_sub(1)
            .ok_or_else(|| invalid("ODB table pattern has no filter owner"))?;
        let include = stack[parent_index].element == Element::IncludeFilter;
        let filter_index = stack[..parent_index]
            .iter()
            .rposition(|value| value.element == Element::TableFilter)
            .ok_or_else(|| invalid("ODB table pattern has no table-filter owner"))?;
        let filter = stack[filter_index]
            .table_filter
            .as_mut()
            .ok_or_else(|| invalid("ODB table pattern filter state is missing"))?;
        if include {
            filter.include.push(frame.text);
        } else if stack[parent_index].element == Element::ExcludeFilter {
            filter.exclude.push(frame.text);
        } else {
            return Err(invalid("ODB table pattern has an invalid filter owner"));
        }
        return Ok(());
    }
    let Some(parent) = stack.last_mut() else {
        match frame.element {
            Element::DataSource => {},
            Element::Other => {},
            _ => return Ok(()),
        }
        return Ok(());
    };
    match frame.element {
        Element::Login => {
            if settings
                .login
                .replace(
                    frame
                        .login
                        .ok_or_else(|| invalid("ODB login state is missing"))?,
                )
                .is_some()
            {
                return Err(invalid("ODB data source has multiple login declarations"));
            }
        },
        Element::Driver => {
            if settings
                .driver
                .replace(
                    frame
                        .driver
                        .ok_or_else(|| invalid("ODB driver state is missing"))?,
                )
                .is_some()
            {
                return Err(invalid(
                    "ODB data source has multiple driver-settings declarations",
                ));
            }
        },
        Element::Application => {
            if settings
                .application_connection
                .replace(
                    frame
                        .application
                        .ok_or_else(|| invalid("ODB application settings state is missing"))?,
                )
                .is_some()
            {
                return Err(invalid(
                    "ODB data source has multiple application settings declarations",
                ));
            }
        },
        Element::AutoIncrement => {
            let value = frame
                .auto_increment
                .ok_or_else(|| invalid("ODB auto-increment state is missing"))?;
            let driver = parent
                .driver
                .as_mut()
                .ok_or_else(|| invalid("ODB auto-increment has no driver owner"))?;
            if driver.auto_increment.replace(value).is_some() {
                return Err(invalid(
                    "ODB driver has multiple auto-increment declarations",
                ));
            }
        },
        Element::Delimiter => {
            let value = frame
                .delimiter
                .ok_or_else(|| invalid("ODB delimiter state is missing"))?;
            if parent.element == Element::Driver {
                let driver = parent
                    .driver
                    .as_mut()
                    .ok_or_else(|| invalid("ODB driver state is missing"))?;
                if driver.delimiter.replace(value).is_some() {
                    return Err(invalid("ODB driver has multiple delimiter declarations"));
                }
            } else if parent.element == Element::TableSetting {
                parent
                    .table_setting
                    .as_mut()
                    .ok_or_else(|| invalid("ODB table setting state is missing"))?
                    .delimiter = Some(value);
            }
        },
        Element::CharacterSet => {
            let value = frame
                .character_set
                .ok_or_else(|| invalid("ODB character-set state is missing"))?;
            if parent.element == Element::Driver {
                let driver = parent
                    .driver
                    .as_mut()
                    .ok_or_else(|| invalid("ODB driver state is missing"))?;
                if driver.character_set.replace(value).is_some() {
                    return Err(invalid(
                        "ODB driver has multiple character-set declarations",
                    ));
                }
            } else if parent.element == Element::TableSetting {
                parent
                    .table_setting
                    .as_mut()
                    .ok_or_else(|| invalid("ODB table setting state is missing"))?
                    .character_set = Some(value);
            }
        },
        Element::TableSetting => {
            let value = frame
                .table_setting
                .ok_or_else(|| invalid("ODB table setting state is missing"))?;
            let driver = stack
                .iter_mut()
                .rev()
                .find_map(|frame| frame.driver.as_mut())
                .ok_or_else(|| invalid("ODB table setting has no driver owner"))?;
            driver.table_settings.push(value);
        },
        Element::TableFilter => {
            let value = frame
                .table_filter
                .ok_or_else(|| invalid("ODB table filter state is missing"))?;
            parent
                .application
                .as_mut()
                .ok_or_else(|| invalid("ODB table filter has no application owner"))?
                .table_filter = Some(value);
        },
        Element::IncludeFilter | Element::ExcludeFilter => {
            let values = frame
                .text
                .is_empty()
                .then_some(())
                .map(|_| ())
                .ok_or_else(|| invalid("ODB table filter state is missing"));
            let _ = values;
            // The patterns are attached by `Pattern`; this frame is only a
            // namespace/parent boundary and carries no independent value.
        },
        Element::Pattern => {},
        Element::TableTypeFilter => {
            let value = frame
                .table_type_filter
                .ok_or_else(|| invalid("ODB table-type-filter state is missing"))?;
            parent
                .application
                .as_mut()
                .ok_or_else(|| invalid("ODB table-type-filter has no application owner"))?
                .table_type_filter = Some(value);
        },
        Element::TableType => {
            *pattern_count = pattern_count
                .checked_add(1)
                .ok_or_else(|| invalid("ODB table type count overflow"))?;
            if *pattern_count > max_filter_patterns.min(MAX_FILTER_PATTERNS) {
                return Err(invalid("ODB table type count exceeds the limit"));
            }
            if frame.text.len() > max_attribute_bytes {
                return Err(invalid("ODB table type exceeds the byte limit"));
            }
            parent
                .table_type_filter
                .as_mut()
                .ok_or_else(|| invalid("ODB table type has no filter owner"))?
                .table_types
                .push(frame.text);
        },
        Element::DataSourceSettings => {},
        Element::DataSourceSetting => {
            *setting_count = setting_count
                .checked_add(1)
                .ok_or_else(|| invalid("ODB data-source setting count overflow"))?;
            if *setting_count > max_settings.min(MAX_SETTINGS) {
                return Err(invalid("ODB data-source setting count exceeds the limit"));
            }
            let value = frame
                .data_source_setting
                .ok_or_else(|| invalid("ODB data-source setting state is missing"))?;
            if value.values.is_empty() {
                return Err(invalid(
                    "ODB data-source setting requires at least one value",
                ));
            }
            stack
                .iter_mut()
                .rev()
                .find_map(|frame| frame.application.as_mut())
                .ok_or_else(|| invalid("ODB data-source setting has no application owner"))?
                .data_source_settings
                .push(value);
        },
        Element::DataSourceSettingValue => {
            *value_count = value_count
                .checked_add(1)
                .ok_or_else(|| invalid("ODB data-source setting value count overflow"))?;
            if *value_count > max_setting_values.min(MAX_SETTING_VALUES) {
                return Err(invalid(
                    "ODB data-source setting value count exceeds the limit",
                ));
            }
            if frame.text.len() > max_attribute_bytes {
                return Err(invalid(
                    "ODB data-source setting value exceeds the byte limit",
                ));
            }
            parent
                .data_source_setting
                .as_mut()
                .ok_or_else(|| invalid("ODB setting value has no setting owner"))?
                .values
                .push(frame.text);
        },
        Element::Document
        | Element::Body
        | Element::Database
        | Element::DataSource
        | Element::ConnectionData
        | Element::TableSettings
        | Element::Other => {},
    }
    Ok(())
}

fn append_text(stack: &mut [Frame], text: &str, max: usize) -> Result<()> {
    let frame = stack
        .last_mut()
        .ok_or_else(|| invalid("ODB settings text has no element owner"))?;
    let next = frame
        .text
        .len()
        .checked_add(text.len())
        .ok_or_else(|| invalid("ODB settings text length overflow"))?;
    if next > max.min(MAX_TEXT_BYTES) {
        return Err(invalid("ODB settings text exceeds the byte limit"));
    }
    frame.text.push_str(text);
    Ok(())
}

fn decode_reference(reference: &quick_xml::events::BytesRef<'_>) -> Result<String> {
    if let Some(character) = reference.resolve_char_ref().map_err(|error| {
        invalid(&format!(
            "invalid ODB settings character reference: {error}"
        ))
    })? {
        return Ok(character.to_string());
    }
    let name = reference
        .decode()
        .map_err(|error| invalid(&format!("invalid ODB settings entity: {error}")))?;
    match name.as_ref() {
        "amp" => Ok("&".to_owned()),
        "lt" => Ok("<".to_owned()),
        "gt" => Ok(">".to_owned()),
        "quot" => Ok("\"".to_owned()),
        "apos" => Ok("'".to_owned()),
        _ => Err(invalid("unsupported ODB settings entity")),
    }
}

fn db_attr(
    reader: &NsReader<&[u8]>,
    element: &BytesStart<'_>,
    local: &[u8],
    max: usize,
) -> Result<Option<String>> {
    let mut found = None;
    for raw in element.attributes() {
        let attribute =
            raw.map_err(|error| invalid(&format!("invalid ODB settings attribute: {error}")))?;
        let (namespace, name) = reader.resolver().resolve_attribute(attribute.key);
        if matches!(namespace, ResolveResult::Bound(Namespace(uri)) if uri == DATABASE_NAMESPACE)
            && name.as_ref() == local
        {
            if attribute.value.len() > max {
                return Err(invalid("ODB settings attribute exceeds the byte limit"));
            }
            let value = attribute
                .decoded_and_normalized_value(XmlVersion::Explicit1_0, reader.decoder())
                .map_err(|error| {
                    invalid(&format!("invalid ODB settings attribute value: {error}"))
                })?
                .into_owned();
            if value.len() > max {
                return Err(invalid(
                    "ODB decoded settings attribute exceeds the byte limit",
                ));
            }
            if found.replace(value).is_some() {
                return Err(invalid("duplicate ODB settings attribute"));
            }
        }
    }
    Ok(found)
}

fn parse_bool(value: &str) -> Result<bool> {
    match value {
        "true" | "1" => Ok(true),
        "false" | "0" => Ok(false),
        _ => Err(invalid("invalid ODB settings boolean")),
    }
}

fn parse_positive_u64(value: &str, kind: &str) -> Result<u64> {
    let value = value
        .parse::<u64>()
        .map_err(|_| invalid(&format!("invalid ODB {kind}")))?;
    if value == 0 {
        return Err(invalid(&format!("ODB {kind} must be positive")));
    }
    Ok(value)
}

fn parse_boolean_comparison_mode(value: &str) -> Result<BooleanComparisonMode> {
    match value {
        "equal-integer" => Ok(BooleanComparisonMode::EqualInteger),
        "is-boolean" => Ok(BooleanComparisonMode::IsBoolean),
        "equal-boolean" => Ok(BooleanComparisonMode::EqualBoolean),
        "equal-use-only-zero" => Ok(BooleanComparisonMode::EqualUseOnlyZero),
        _ => Err(invalid("invalid ODB boolean-comparison-mode")),
    }
}

fn parse_data_source_setting_type(value: &str) -> Result<DataSourceSettingType> {
    match value {
        "boolean" => Ok(DataSourceSettingType::Boolean),
        "short" => Ok(DataSourceSettingType::Short),
        "int" => Ok(DataSourceSettingType::Int),
        "long" => Ok(DataSourceSettingType::Long),
        "double" => Ok(DataSourceSettingType::Double),
        "string" => Ok(DataSourceSettingType::String),
        _ => Err(invalid("invalid ODB data-source-setting type")),
    }
}

fn invalid(message: &str) -> Error {
    Error::InvalidFormat(message.to_owned())
}
