#![allow(
    clippy::unwrap_used,
    reason = "settings integration tests keep assertions concise"
)]

use litchi_odb::{
    ApplicationConnectionSettings, AutoIncrementSettings, BooleanComparisonMode,
    CharacterSetSettings, DataSourceSetting, DataSourceSettingType, Database, DelimiterSettings,
    DriverSettings, LoginSettings, TableFilter, TableSetting, TableTypeFilter,
};

const SOURCE: &str = concat!(
    r#"<?xml version="1.0" encoding="UTF-8"?><office:document-content "#,
    r#"xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0" "#,
    r#"xmlns:db="urn:oasis:names:tc:opendocument:xmlns:database:1.0" "#,
    r#"xmlns:xlink="http://www.w3.org/1999/xlink" "#,
    r#"xmlns:lo="urn:example:odb-extension" office:version="1.4">"#,
    r#"<office:body><office:database><db:data-source>"#,
    r#"<db:connection-data><db:connection-resource xlink:type="simple" xlink:href="sdbc:demo"/>"#,
    r#"<db:login db:user-name="alice" db:is-password-required="true" db:login-timeout="30"/>"#,
    r#"</db:connection-data>"#,
    r#"<db:driver-settings db:show-deleted="true" db:base-dn="ou=people">"#,
    r#"<db:auto-increment db:additional-column-statement="identity" db:row-retrieving-statement="returning id"/>"#,
    r#"<db:delimiter db:field="," db:string="&quot;" db:decimal="." db:thousand=","/>"#,
    r#"<db:character-set db:encoding="UTF-8"/><db:table-settings>"#,
    r#"<db:table-setting db:is-first-row-header-line="true"><db:character-set db:encoding="ISO-8859-1"/></db:table-setting>"#,
    r#"<lo:driver-extension lo:keep="yes"/></db:table-settings></db:driver-settings>"#,
    r#"<db:application-connection-settings db:enable-sql92-check="true" db:boolean-comparison-mode="equal-boolean" db:max-row-count="100">"#,
    r#"<db:table-filter><db:table-include-filter><db:table-filter-pattern>customers*</db:table-filter-pattern></db:table-include-filter>"#,
    r#"<db:table-exclude-filter><db:table-filter-pattern>customers_tmp</db:table-filter-pattern></db:table-exclude-filter></db:table-filter>"#,
    r#"<db:table-type-filter><db:table-type>TABLE</db:table-type><db:table-type>VIEW</db:table-type></db:table-type-filter>"#,
    r#"<db:data-source-settings><db:data-source-setting db:data-source-setting-name="timeout" db:data-source-setting-type="int">"#,
    r#"<db:data-source-setting-value>15</db:data-source-setting-value></db:data-source-setting></db:data-source-settings>"#,
    r#"<lo:application-extension lo:keep="yes"/></db:application-connection-settings>"#,
    r#"</db:data-source></office:database></office:body></office:document-content>"#,
);

fn database() -> Database {
    database_from(SOURCE)
}

fn database_from(source: &str) -> Database {
    Database::from_bytes(
        litchi_odb::Builder::new()
            .content_xml(source)
            .build()
            .unwrap(),
    )
    .unwrap()
}

#[test]
fn reads_all_settings_families_without_execution() {
    let database = database();
    let settings = database.settings().unwrap();
    let login = settings.login().unwrap();
    assert_eq!(login.user_name(), Some("alice"));
    assert_eq!(login.password_required(), Some(true));
    assert_eq!(login.login_timeout(), Some(30));

    let driver = settings.driver().unwrap();
    assert_eq!(driver.show_deleted(), Some(true));
    assert_eq!(driver.base_dn(), Some("ou=people"));
    assert_eq!(
        driver.auto_increment().unwrap().row_retrieving_statement(),
        Some("returning id")
    );
    assert_eq!(driver.delimiter().unwrap().field(), Some(","));
    assert_eq!(driver.character_set().unwrap().encoding(), Some("UTF-8"));
    assert_eq!(driver.table_settings().len(), 1);
    assert_eq!(
        driver.table_settings()[0]
            .character_set()
            .unwrap()
            .encoding(),
        Some("ISO-8859-1")
    );

    let application = settings.application_connection().unwrap();
    assert_eq!(application.enable_sql92_check(), Some(true));
    assert_eq!(
        application.boolean_comparison_mode(),
        Some(BooleanComparisonMode::EqualBoolean)
    );
    assert_eq!(application.max_row_count(), Some(100));
    assert_eq!(
        application.table_filter().unwrap().include(),
        &["customers*".to_string()]
    );
    assert_eq!(
        application.table_filter().unwrap().exclude(),
        &["customers_tmp".to_string()]
    );
    assert_eq!(
        application.table_type_filter().unwrap().table_types(),
        &["TABLE".to_string(), "VIEW".to_string()]
    );
    assert_eq!(
        application.data_source_settings()[0].values(),
        &["15".to_string()]
    );
}

#[test]
fn settings_edit_reopens_and_keeps_unknown_children() {
    let source = database();
    let settings = source.settings().unwrap();
    let replacement = settings
        .clone()
        .with_login(Some(LoginSettings::new().with_user_name("bob")))
        .with_driver(Some(
            DriverSettings::new()
                .with_character_set(Some(CharacterSetSettings::new().with_encoding("UTF-8")))
                .with_auto_increment(Some(
                    AutoIncrementSettings::new().with_row_retrieving_statement("returning key"),
                ))
                .with_delimiter(Some(DelimiterSettings::new().with_field(";")))
                .with_table_settings(vec![TableSetting::new().with_show_deleted(Some(false))]),
        ))
        .with_application_connection(Some(
            ApplicationConnectionSettings::new()
                .with_boolean_comparison_mode(Some(BooleanComparisonMode::EqualInteger))
                .with_table_filter(Some(
                    TableFilter::new().with_include(vec!["orders*".into()]),
                ))
                .with_table_type_filter(Some(
                    TableTypeFilter::new().with_table_types(vec!["TABLE".into()]),
                ))
                .with_data_source_settings(vec![
                    DataSourceSetting::new("fetch-size", DataSourceSettingType::Int)
                        .with_values(vec!["100".into()]),
                ]),
        ));
    let mut edit = source.edit();
    edit.set_settings(replacement.clone()).unwrap();
    let commit = edit.commit().unwrap();
    assert!(commit.changed());
    assert!(
        commit
            .database()
            .content_xml()
            .contains("lo:driver-extension")
    );
    assert!(
        commit
            .database()
            .content_xml()
            .contains("lo:application-extension")
    );
    assert_eq!(commit.database().settings().unwrap(), &replacement);
    assert_eq!(
        commit
            .patch()
            .inverse()
            .apply(commit.database())
            .unwrap()
            .as_bytes(),
        source.as_bytes()
    );
}

#[test]
fn settings_limits_refuse_unbounded_values_before_mutation() {
    let database = database();
    let catalog = database
        .catalog_with(litchi_odb::Limits::default().with_max_filter_patterns(0))
        .unwrap();
    let error = catalog.settings().unwrap_err();
    assert!(matches!(error, litchi_core::Error::InvalidFormat(_)));
}

#[test]
fn character_set_names_follow_odf_text_encoding_syntax() {
    for encoding in ["", "UTF 8", "8UTF", "UTF:8", "éUTF", " UTF-8", "UTF-8 "] {
        let xml = SOURCE.replace("UTF-8\"/>", &format!("{encoding}\"/>"));
        let malformed = database_from(&xml);
        assert!(
            matches!(
                malformed.settings(),
                Err(litchi_core::Error::InvalidFormat(_))
            ),
            "{encoding:?}"
        );

        for nested in [false, true] {
            let source = database();
            let charset = CharacterSetSettings::new().with_encoding(encoding);
            let driver = if nested {
                DriverSettings::new().with_table_settings(vec![
                    TableSetting::new().with_character_set(Some(charset)),
                ])
            } else {
                DriverSettings::new().with_character_set(Some(charset))
            };
            let replacement = source.settings().unwrap().clone().with_driver(Some(driver));
            let mut edit = source.edit();
            assert!(
                matches!(
                    edit.set_settings(replacement),
                    Err(litchi_core::Error::InvalidFormat(_))
                ),
                "{encoding:?}"
            );
            assert_eq!(
                edit.commit().unwrap().database().as_bytes(),
                source.as_bytes()
            );
        }
    }

    for encoding in ["UTF-8", "ISO_8859-1", "a", "x.custom-1"] {
        let source = database();
        let replacement = source
            .settings()
            .unwrap()
            .clone()
            .with_driver(Some(DriverSettings::new().with_character_set(Some(
                CharacterSetSettings::new().with_encoding(encoding),
            ))));
        let mut edit = source.edit();
        edit.set_settings(replacement).unwrap();
        let commit = edit.commit().unwrap();
        assert_eq!(
            commit
                .database()
                .settings()
                .unwrap()
                .driver()
                .unwrap()
                .character_set()
                .unwrap()
                .encoding(),
            Some(encoding)
        );
    }
}

#[test]
fn authored_setting_values_use_one_aggregate_budget() {
    let database = database();
    let values = vec!["v".to_owned(); 65_535];
    let settings = ApplicationConnectionSettings::new().with_data_source_settings(vec![
        DataSourceSetting::new("many", DataSourceSettingType::String).with_values(values),
    ]);
    let before = database.as_bytes().to_vec();
    let mut edit = database.edit();
    assert!(matches!(
        edit.set_application_connection_settings(Some(settings)),
        Err(litchi_core::Error::InvalidFormat(_))
    ));
    let committed = edit.commit().unwrap();
    assert_eq!(committed.database().as_bytes(), before.as_slice());
}

#[test]
fn settings_splice_empty_containers_and_lexical_extensions() {
    let source = SOURCE
        .replace(
            r#"<db:table-filter><db:table-include-filter><db:table-filter-pattern>customers*</db:table-filter-pattern></db:table-include-filter><db:table-exclude-filter><db:table-filter-pattern>customers_tmp</db:table-filter-pattern></db:table-exclude-filter></db:table-filter>"#,
            r#"<db:table-filter lo:marker="keep"><!--retain--><lo:filter-extension lo:value="x"/></db:table-filter>"#,
        )
        .replace(
            r#"<db:table-type-filter><db:table-type>TABLE</db:table-type><db:table-type>VIEW</db:table-type></db:table-type-filter>"#,
            r#"<db:table-type-filter/>"#,
        );
    let database = database_from(&source);
    let replacement = database
        .settings()
        .unwrap()
        .clone()
        .with_application_connection(Some(
            ApplicationConnectionSettings::new()
                .with_table_filter(Some(
                    TableFilter::new().with_include(vec!["orders*".into()]),
                ))
                .with_table_type_filter(Some(
                    TableTypeFilter::new().with_table_types(vec!["TABLE".into()]),
                )),
        ));
    let mut edit = database.edit();
    edit.set_settings(replacement).unwrap();
    let content = edit.commit().unwrap().database().content_xml().to_owned();
    assert!(content.contains(r#"lo:marker="keep""#));
    assert!(content.contains(r#"<!--retain-->"#));
    assert!(content.contains(r#"<lo:filter-extension lo:value="x"/>"#));
    assert!(content.contains("orders*"));
    assert!(content.contains("<db:table-type-filter><db:table-type>TABLE</db:table-type>"));
}

#[test]
fn settings_replacement_keeps_comments_and_foreign_pattern_children() {
    let source = SOURCE.replace(
        "<db:table-filter-pattern>customers*</db:table-filter-pattern>",
        r#"<db:table-filter-pattern lo:marker="keep"><!--retain-->customers*</db:table-filter-pattern>"#,
    );
    let database = database_from(&source);
    let replacement = database
        .settings()
        .unwrap()
        .clone()
        .with_application_connection(Some(
            ApplicationConnectionSettings::new().with_table_filter(Some(
                TableFilter::new().with_include(vec!["orders*".into()]),
            )),
        ));
    let mut edit = database.edit();
    edit.set_settings(replacement).unwrap();
    let content = edit.commit().unwrap().database().content_xml().to_owned();
    assert!(content.contains(r#"lo:marker="keep""#));
    assert!(content.contains(r#"<!--retain-->"#));
    assert!(content.contains("orders*"));
}

#[test]
fn login_only_edit_leaves_other_families_byte_exact() {
    let database = database();
    let original = database.content_xml().to_owned();
    let driver_start = original.find("<db:driver-settings").unwrap();
    let driver_end = original[driver_start..]
        .find("</db:driver-settings>")
        .map(|offset| driver_start + offset + "</db:driver-settings>".len())
        .unwrap();
    let driver = &original[driver_start..driver_end];
    let mut edit = database.edit();
    edit.set_login_settings(Some(LoginSettings::new().with_user_name("bob")))
        .unwrap();
    let content = edit.commit().unwrap().database().content_xml().to_owned();
    assert!(content.contains(driver));
}

#[test]
fn settings_updates_preserve_unknown_markup_inside_repeated_items() {
    let source = SOURCE
        .replace(
            r#"<db:table-setting db:is-first-row-header-line="true"><db:character-set db:encoding="ISO-8859-1"/></db:table-setting>"#,
            r#"<db:table-setting db:is-first-row-header-line="true" lo:marker="table"><db:character-set db:encoding="ISO-8859-1"/><lo:table-extension/></db:table-setting>"#,
        )
        .replace(
            r#"<db:data-source-setting db:data-source-setting-name="timeout" db:data-source-setting-type="int"><db:data-source-setting-value>15</db:data-source-setting-value></db:data-source-setting>"#,
            r#"<db:data-source-setting db:data-source-setting-name="timeout" db:data-source-setting-type="int" lo:marker="setting"><db:data-source-setting-value>15</db:data-source-setting-value><lo:setting-extension/></db:data-source-setting>"#,
        );
    let database = database_from(&source);
    let replacement = database
        .settings()
        .unwrap()
        .clone()
        .with_driver(Some(
            database
                .settings()
                .unwrap()
                .driver()
                .unwrap()
                .clone()
                .with_table_settings(vec![TableSetting::new().with_show_deleted(Some(false))]),
        ))
        .with_application_connection(Some(
            database
                .settings()
                .unwrap()
                .application_connection()
                .unwrap()
                .clone()
                .with_data_source_settings(vec![
                    DataSourceSetting::new("timeout", DataSourceSettingType::Int)
                        .with_values(vec!["30".into()]),
                ]),
        ));
    let mut edit = database.edit();
    edit.set_settings(replacement).unwrap();
    let content = edit.commit().unwrap().database().content_xml().to_owned();
    assert!(content.contains(r#"lo:marker="table""#));
    assert!(content.contains("<lo:table-extension/>"));
    assert!(content.contains(r#"lo:marker="setting""#));
    assert!(content.contains("<lo:setting-extension/>"));
    assert!(content.contains(">30</db:data-source-setting-value>"));
}

#[test]
fn removing_modeled_filters_does_not_drop_unknown_container_markup() {
    let source = SOURCE
        .replace(
            r#"<db:table-filter><db:table-include-filter><db:table-filter-pattern>customers*</db:table-filter-pattern></db:table-include-filter><db:table-exclude-filter><db:table-filter-pattern>customers_tmp</db:table-filter-pattern></db:table-exclude-filter></db:table-filter>"#,
            r#"<db:table-filter><db:table-include-filter lo:marker="keep"><lo:extension/></db:table-include-filter></db:table-filter>"#,
        )
        .replace(
            r#"<db:table-type-filter><db:table-type>TABLE</db:table-type><db:table-type>VIEW</db:table-type></db:table-type-filter>"#,
            r#"<db:table-type-filter/>"#,
        );
    let database = database_from(&source);
    let mut application = database
        .settings()
        .unwrap()
        .application_connection()
        .unwrap()
        .clone();
    application = application
        .with_table_filter(None)
        .with_table_type_filter(None);
    let mut edit = database.edit();
    edit.set_application_connection_settings(Some(application))
        .unwrap();
    let content = edit.commit().unwrap().database().content_xml().to_owned();
    assert!(content.contains(r#"lo:marker="keep""#));
    assert!(content.contains("<lo:extension/>"));
}

#[test]
fn settings_writer_reuses_an_aliased_database_namespace() {
    let source = SOURCE.replace("xmlns:db=", "xmlns:d=").replace("db:", "d:");
    let database = database_from(&source);
    let mut edit = database.edit();
    edit.set_login_settings(Some(LoginSettings::new().with_user_name("bob")))
        .unwrap();
    let content = edit.commit().unwrap().database().content_xml().to_owned();
    assert!(content.contains("<d:login"));
    assert!(!content.contains("<db:login"));
}
