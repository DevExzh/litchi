//! Ordinary worksheet SVG attach/detach planning.
//!
//! The source drawing scanner owns semantic picture discovery.  This module
//! owns the mutation and the complete OPC dependency closure: one source XML
//! splice, one source relationship token, an optional SVG media part, and the
//! content-types delta required by that part.

use std::collections::hash_map::Entry;
use std::collections::{HashMap, HashSet};
use std::sync::Arc;

use litchi_opc::constants::{content_type as ct, relationship_type as rt};
use litchi_opc::{
    BlobPart, OwnedContentTypes, OwnedElementEdit, OwnedElementUpdate, OwnedRelationships,
    OwnedXmlPart, PackURI, Part, Relationship, Relationships, TargetMode,
};
use quick_xml::XmlVersion;
use quick_xml::events::Event;
use quick_xml::reader::Reader;

use super::model::{
    ContentTypesChange, GraphAction, PackageChange, PartChange, RelationshipChange, SvgFinalGuard,
    SvgFinalMedia, SvgFinalState, SvgPartChange, SvgReadGuard,
};
use super::semantic::SvgLifecycleIntent;
use super::svg::PictureSelector;
use super::{Workbook, allocation, invalid};
use crate::drawing::source::{self, ElementRange, SourceDrawing, SvgOwnerState};
use crate::error::{Error, Result};

const MAX_DRAWING_BYTES: usize = 32 * 1024 * 1024;
const MAX_OUTPUT_BYTES: usize = 32 * 1024 * 1024;
const MAX_ID_ATTEMPTS: usize = 100_000;
pub(super) const MAX_SVG_LIFECYCLE_INTENTS: usize = 65_536;
const SVG_EXTENSION_URI: &str = "{96DAC541-7B7A-43D3-8B79-37D633B846F1}";
const SVG_NAMESPACE: &str = "http://schemas.microsoft.com/office/drawing/2016/SVG/main";
const DRAWINGML_NAMESPACE: &str = "http://schemas.openxmlformats.org/drawingml/2006/main";
const STRICT_DRAWINGML_NAMESPACE: &str = "http://purl.oclc.org/ooxml/drawingml/main";

fn output_limit(workbook: &Workbook) -> usize {
    let caller = workbook.inner.package.read_limits().max_part_bytes();
    usize::try_from(caller)
        .unwrap_or(usize::MAX)
        .min(MAX_OUTPUT_BYTES)
}

fn relationship_output_limit(workbook: &Workbook) -> usize {
    let caller = workbook.inner.package.read_limits();
    output_limit(workbook).min(caller.max_relationship_xml_bytes())
}

fn content_types_output_limit(workbook: &Workbook) -> usize {
    let caller = workbook.inner.package.read_limits();
    output_limit(workbook).min(caller.max_content_types_bytes())
}

pub(super) fn payload_limit(workbook: &Workbook) -> usize {
    output_limit(workbook)
}

/// Check the aggregate materialized-part budget before an SVG payload is
/// copied into a transaction-owned buffer.  The package reader enforces this
/// budget at ingress; staged media must fit the same retained policy before a
/// caller's borrowed bytes become owned state.
pub(super) fn materialized_part_bytes(workbook: &Workbook) -> Result<usize> {
    workbook
        .inner
        .package
        .iter_parts()
        .try_fold(0usize, |total, part| {
            total
                .checked_add(part.blob().len())
                .ok_or_else(|| invalid("SVG lifecycle package byte count overflows"))
        })
}

pub(super) fn check_payload_budget(
    workbook: &Workbook,
    existing_part_bytes: usize,
    already_staged: usize,
    incoming: usize,
) -> Result<()> {
    let prospective = existing_part_bytes
        .checked_add(already_staged)
        .and_then(|total| total.checked_add(incoming))
        .ok_or_else(|| invalid("SVG lifecycle staged package byte count overflows"))?;
    let maximum = usize::try_from(workbook.inner.package.read_limits().max_total_part_bytes())
        .unwrap_or(usize::MAX);
    if prospective > maximum {
        return Err(invalid(format!(
            "SVG lifecycle staged package bytes exceed {}",
            maximum
        )));
    }
    Ok(())
}

/// Source-backed semantic facts cached by one transaction.  The cache owns
/// only bounded scalar projections; source ranges remain in the immutable
/// package and are rescanned by the commit planner when it builds its proof.
#[derive(Clone, Debug)]
pub(super) struct DrawingPreflight {
    drawing_uri: PackURI,
    pictures: Vec<CachedPicture>,
}

#[derive(Clone, Debug)]
struct CachedPicture {
    owner: ProjectedSvgOwner,
    raster_relationship_id: Box<str>,
}

fn scan_limits(workbook: &Workbook) -> source::ScanLimits {
    let caller = workbook.inner.package.read_limits();
    let defaults = source::ScanLimits::default();
    let part_bytes = usize::try_from(caller.max_part_bytes()).unwrap_or(usize::MAX);
    source::ScanLimits {
        max_xml_bytes: defaults.max_xml_bytes.min(part_bytes),
        max_nodes: defaults.max_nodes.min(caller.max_xml_events()),
        max_depth: defaults.max_depth.min(caller.max_xml_depth()),
        max_pictures: defaults
            .max_pictures
            .min(caller.max_relationships_per_part()),
        max_relationship_references: defaults
            .max_relationship_references
            .min(caller.max_relationships_per_part()),
        max_fragment_bytes: defaults.max_fragment_bytes.min(part_bytes),
    }
}

/// Stage every SVG lifecycle intent against one candidate package closure.
/// Multiple pictures in one drawing share one source XML and relationship
/// transition, while media and content-type deltas remain package-scoped.
pub(super) fn plan(
    workbook: &Workbook,
    intents: &[SvgLifecycleIntent],
    base_part_bytes: usize,
    ordinary_graph: &[super::model::GraphChange],
    relationship_changes: &[RelationshipChange],
    parts: &mut Vec<PartChange>,
    relationships: &mut Vec<RelationshipChange>,
    svg_parts: &mut Vec<SvgPartChange>,
    content_types: &mut Option<ContentTypesChange>,
    package_changes: &mut Vec<PackageChange>,
) -> Result<()> {
    if intents.is_empty() {
        return Ok(());
    }
    if intents.len() > MAX_SVG_LIFECYCLE_INTENTS {
        return Err(invalid(format!(
            "SVG lifecycle intents exceed {MAX_SVG_LIFECYCLE_INTENTS}"
        )));
    }
    preflight_candidate_budget(
        workbook,
        intents,
        base_part_bytes,
        ordinary_graph,
        relationship_changes,
    )?;
    plan_composed(
        workbook,
        intents,
        ordinary_graph,
        relationship_changes,
        parts,
        relationships,
        svg_parts,
        content_types,
        package_changes,
    )
}

fn preflight_candidate_budget(
    workbook: &Workbook,
    intents: &[SvgLifecycleIntent],
    base_part_bytes: usize,
    ordinary_graph: &[super::model::GraphChange],
    relationship_changes: &[RelationshipChange],
) -> Result<()> {
    let limits = workbook.inner.package.read_limits();
    let attach_count = intents.iter().filter(|intent| intent.attach).count();
    let ordinary_added_parts = ordinary_graph
        .iter()
        .filter(|change| change.action == GraphAction::Add)
        .count();
    let ordinary_removed_parts = ordinary_graph
        .iter()
        .filter(|change| change.action == GraphAction::Remove)
        .count();
    let ordinary_added_relationships = ordinary_graph
        .iter()
        .filter(|change| change.action == GraphAction::Add)
        .try_fold(0usize, |total, change| {
            total
                .checked_add(1)
                .and_then(|count| count.checked_add(change.part.rels().len()))
                .ok_or_else(|| invalid("SVG lifecycle candidate relationship count overflows"))
        })?;
    let ordinary_added_relationship_parts = ordinary_graph
        .iter()
        .filter(|change| change.action == GraphAction::Add && !change.part.rels().is_empty())
        .count();
    let part_count = workbook
        .inner
        .package
        .part_count()
        .saturating_sub(ordinary_removed_parts)
        .checked_add(ordinary_added_parts)
        .and_then(|count| count.checked_add(attach_count))
        .ok_or_else(|| invalid("SVG lifecycle candidate part count overflows"))?;
    if part_count > limits.max_parts() {
        return Err(invalid(format!(
            "SVG lifecycle candidate parts exceed {}",
            limits.max_parts()
        )));
    }
    let mut staged_bytes = 0usize;
    for intent in intents {
        let Some(payload) = intent.payload.as_deref() else {
            continue;
        };
        if payload.len() > usize::try_from(limits.max_part_bytes()).unwrap_or(usize::MAX) {
            return Err(invalid(format!(
                "SVG lifecycle payload exceeds {} bytes",
                limits.max_part_bytes()
            )));
        }
        staged_bytes = staged_bytes
            .checked_add(payload.len())
            .ok_or_else(|| invalid("SVG lifecycle candidate part bytes overflow"))?;
    }
    let added_graph_bytes = ordinary_graph
        .iter()
        .filter(|change| change.action == GraphAction::Add)
        .try_fold(0usize, |total, change| {
            total
                .checked_add(change.part.blob().len())
                .ok_or_else(|| invalid("SVG lifecycle candidate graph bytes overflow"))
        })?;
    let removed_graph_bytes = ordinary_graph
        .iter()
        .filter(|change| change.action == GraphAction::Remove)
        .try_fold(0usize, |total, change| {
            total
                .checked_add(change.part.blob().len())
                .ok_or_else(|| invalid("SVG lifecycle candidate graph bytes overflow"))
        })?;
    let candidate_bytes = base_part_bytes
        .saturating_sub(removed_graph_bytes)
        .checked_add(added_graph_bytes)
        .and_then(|total| total.checked_add(staged_bytes))
        // Every authored SVG attachment changes at least one bounded source
        // member.  Reserve one byte per attachment before any XML/relationship
        // scratch allocation; the exact post-transition census below remains
        // authoritative for mixed detach/attach operations.
        .and_then(|total| total.checked_add(attach_count))
        .ok_or_else(|| invalid("SVG lifecycle candidate part bytes overflow"))?;
    if candidate_bytes > usize::try_from(limits.max_total_part_bytes()).unwrap_or(usize::MAX) {
        return Err(invalid(format!(
            "SVG lifecycle candidate part bytes exceed {}",
            limits.max_total_part_bytes()
        )));
    }

    let mut relationship_count = workbook.inner.package.rels().len();
    let root = PackURI::new("/").map_err(invalid)?;
    let root_relationships = workbook
        .inner
        .package
        .source_relationships_with_limits(&root, limits)?;
    let mut relationship_parts = usize::from(root_relationships.member_present());
    let mut relationship_xml_bytes = 0usize;
    let mut relationship_xml_events = 0usize;
    let mut graph_nodes = HashSet::new();
    relationship_xml_bytes = relationship_xml_bytes
        .checked_add(root_relationships.bytes().len())
        .ok_or_else(|| invalid("SVG lifecycle relationship XML bytes overflow"))?;
    relationship_xml_events = relationship_xml_events
        .checked_add(relationship_xml_event_count(
            root_relationships.bytes(),
            limits.max_xml_events(),
        )?)
        .ok_or_else(|| invalid("SVG lifecycle relationship XML events overflow"))?;
    for relationship in workbook.inner.package.rels().iter() {
        if relationship.target_mode() == TargetMode::Internal {
            let target = relationship.target_partname()?;
            let target = workbook
                .inner
                .package
                .get_part(&target)
                .map(|part| part.partname().clone())
                .unwrap_or(target);
            graph_nodes.insert(target.as_str().to_ascii_lowercase());
        }
    }
    for part in workbook.inner.package.iter_parts() {
        let source_relationships = workbook
            .inner
            .package
            .source_relationships_with_limits(part.partname(), limits)?;
        if source_relationships.member_present() {
            relationship_parts = relationship_parts
                .checked_add(1)
                .ok_or_else(|| invalid("SVG lifecycle relationship part count overflow"))?;
        }
        relationship_xml_bytes = relationship_xml_bytes
            .checked_add(source_relationships.bytes().len())
            .ok_or_else(|| invalid("SVG lifecycle relationship XML bytes overflow"))?;
        relationship_xml_events = relationship_xml_events
            .checked_add(relationship_xml_event_count(
                source_relationships.bytes(),
                limits.max_xml_events(),
            )?)
            .ok_or_else(|| invalid("SVG lifecycle relationship XML events overflow"))?;
        relationship_count = relationship_count
            .checked_add(part.rels().len())
            .ok_or_else(|| invalid("SVG lifecycle relationship count overflows"))?;
        for relationship in part.rels().iter() {
            if relationship.target_mode() == TargetMode::Internal {
                let target = relationship.target_partname()?;
                let target = workbook
                    .inner
                    .package
                    .get_part(&target)
                    .map(|part| part.partname().clone())
                    .unwrap_or(target);
                graph_nodes.insert(target.as_str().to_ascii_lowercase());
            }
        }
    }
    relationship_parts = relationship_parts
        .checked_add(ordinary_added_relationship_parts)
        .ok_or_else(|| invalid("SVG lifecycle relationship part count overflow"))?;
    relationship_count = relationship_count
        .checked_add(attach_count)
        .and_then(|count| count.checked_add(ordinary_added_relationships))
        .and_then(|count| {
            count.checked_add(
                relationship_changes
                    .iter()
                    .filter(|change| change.after.is_some())
                    .count(),
            )
        })
        .ok_or_else(|| invalid("SVG lifecycle relationship count overflows"))?;
    let relationship_edit_count = attach_count
        .checked_add(ordinary_added_relationships)
        .and_then(|count| {
            count.checked_add(
                relationship_changes
                    .iter()
                    .filter(|change| change.after.is_some())
                    .count(),
            )
        })
        .ok_or_else(|| invalid("SVG lifecycle relationship edit count overflows"))?;
    if relationship_count > limits.max_total_relationships() {
        return Err(invalid(format!(
            "SVG lifecycle relationships exceed {}",
            limits.max_total_relationships()
        )));
    }
    let graph_nodes = graph_nodes
        .len()
        .checked_add(attach_count)
        .and_then(|count| count.checked_add(ordinary_added_relationships))
        .ok_or_else(|| invalid("SVG lifecycle relationship graph nodes overflow"))?;
    if graph_nodes > limits.max_relationship_graph_nodes() {
        return Err(invalid(format!(
            "SVG lifecycle relationship graph nodes exceed {}",
            limits.max_relationship_graph_nodes()
        )));
    }

    if relationship_parts > limits.max_relationship_parts() {
        return Err(invalid(format!(
            "SVG lifecycle relationship parts exceed {}",
            limits.max_relationship_parts()
        )));
    }
    if relationship_xml_bytes
        .checked_add(relationship_edit_count)
        .is_none_or(|bytes| bytes > limits.max_total_relationship_xml_bytes())
    {
        return Err(invalid(format!(
            "SVG lifecycle relationship XML bytes exceed {}",
            limits.max_total_relationship_xml_bytes()
        )));
    }
    if relationship_xml_events
        .checked_add(relationship_edit_count)
        .is_none_or(|events| events > limits.max_total_relationship_xml_events())
    {
        return Err(invalid(format!(
            "SVG lifecycle relationship XML events exceed {}",
            limits.max_total_relationship_xml_events()
        )));
    }

    let manifest = workbook
        .inner
        .package
        .source_content_types_with_limits(limits)?;
    if !manifest_has_default_svg(manifest.bytes())? {
        check_content_type_mapping_growth(
            manifest.bytes(),
            attach_count,
            limits.max_content_type_mappings(),
        )?;
    }
    Ok(())
}

/// Capture the worksheet and package relationship reads that select an SVG
/// picture.  The resulting guards are attached to the in-memory patch after
/// the candidate workbook has been published, so their `after` snapshots
/// include any ordinary worksheet edits in the same transaction.
pub(super) fn read_guards(
    source: &Workbook,
    target: &Workbook,
    intents: &[SvgLifecycleIntent],
) -> Result<Box<[SvgReadGuard]>> {
    if intents.is_empty() {
        return Ok(Box::new([]));
    }
    let root = PackURI::new("/").map_err(invalid)?;
    let mut owners = Vec::new();
    owners
        .try_reserve(intents.len().saturating_add(1))
        .map_err(|source| allocation("SVG lifecycle read guards", source))?;
    owners.push(root);
    for intent in intents {
        let sheet = source
            .inner
            .sheets
            .get(intent.position)
            .ok_or_else(|| invalid("SVG lifecycle guard worksheet disappeared"))?;
        if !owners.iter().any(|owner| owner == &sheet.part_uri) {
            owners.push(sheet.part_uri.clone());
        }
    }

    let mut guards = Vec::new();
    guards
        .try_reserve(owners.len())
        .map_err(|source| allocation("SVG lifecycle read guards", source))?;
    let limits = source.inner.package.read_limits();
    for owner in owners {
        let before_relationships = source
            .inner
            .package
            .source_relationships_with_limits(&owner, limits)?;
        let after_relationships = target
            .inner
            .package
            .source_relationships_with_limits(&owner, limits)?;
        let before_xml = if owner.as_str() == "/" {
            None
        } else {
            Some(source.inner.package.get_part(&owner)?.blob_arc())
        };
        let after_xml = if owner.as_str() == "/" {
            None
        } else {
            Some(target.inner.package.get_part(&owner)?.blob_arc())
        };
        guards.push(SvgReadGuard {
            owner,
            before_xml,
            after_xml,
            before_relationships,
            after_relationships,
        });
    }
    Ok(guards.into_boxed_slice())
}

/// One bounded source inventory shared by every selected picture in a
/// drawing.  The source scanner and package tokens are immutable, so keeping
/// this short-lived cache avoids rescanning a large drawing once per intent.
struct FinalDrawingInventory<'a> {
    drawing: PackURI,
    worksheet_xml: Arc<Vec<u8>>,
    worksheet_relationships: OwnedRelationships,
    drawing_xml: Arc<Vec<u8>>,
    drawing_relationships: OwnedRelationships,
    content_types: OwnedContentTypes,
    source: Arc<SourceDrawing<'a>>,
}

/// Capture and validate the complete final readback contract for each
/// affected picture.  The mutation planner proves source ranges and graph
/// deltas, but those proofs inspect preimages.  This paired facade read is
/// deliberately performed only after all ordinary and SVG changes have been
/// published into the candidate workbook.
pub(super) fn capture_final_guards(
    source: &Workbook,
    target: &Workbook,
    intents: &[SvgLifecycleIntent],
) -> Result<Box<[SvgFinalGuard]>> {
    if intents.is_empty() {
        return Ok(Box::new([]));
    }
    let mut seen = HashSet::new();
    seen.try_reserve(intents.len())
        .map_err(|source| allocation("SVG lifecycle final selector guards", source))?;
    let mut guards = Vec::new();
    guards
        .try_reserve(intents.len())
        .map_err(|source| allocation("SVG lifecycle final selector guards", source))?;
    let mut source_inventories = HashMap::new();
    source_inventories
        .try_reserve(intents.len())
        .map_err(|source| allocation("SVG lifecycle final drawing inventories", source))?;
    let mut target_inventories = HashMap::new();
    target_inventories
        .try_reserve(intents.len())
        .map_err(|source| allocation("SVG lifecycle final drawing inventories", source))?;
    let source_content_types = source
        .inner
        .package
        .source_content_types_with_limits(source.inner.package.read_limits())?;
    let target_content_types = target
        .inner
        .package
        .source_content_types_with_limits(target.inner.package.read_limits())?;
    let mut expected_by_selector = HashMap::new();
    expected_by_selector
        .try_reserve(intents.len())
        .map_err(|source| allocation("SVG lifecycle final selector expectations", source))?;
    for intent in intents {
        expected_by_selector.insert((intent.position, intent.selector), intent.attach);
    }
    for intent in intents {
        let sheet = source
            .inner
            .sheets
            .get(intent.position)
            .ok_or_else(|| invalid("SVG lifecycle guard worksheet disappeared"))?;
        let key = (
            sheet.part_uri.clone(),
            selector_drawing(intent.selector),
            selector_picture(intent.selector),
        );
        if !seen.insert(key.clone()) {
            continue;
        }
        if let Entry::Vacant(entry) = source_inventories.entry((key.0.clone(), key.1)) {
            let inventory = capture_final_inventory(source, &key.0, key.1, &source_content_types)?;
            entry.insert(inventory);
        }
        if let Entry::Vacant(entry) = target_inventories.entry((key.0.clone(), key.1)) {
            let inventory = capture_final_inventory(target, &key.0, key.1, &target_content_types)?;
            entry.insert(inventory);
        }
        let before_inventory = source_inventories
            .get(&(key.0.clone(), key.1))
            .ok_or_else(|| invalid("SVG lifecycle source inventory disappeared"))?;
        let after_inventory = target_inventories
            .get(&(key.0.clone(), key.1))
            .ok_or_else(|| invalid("SVG lifecycle target inventory disappeared"))?;
        let before = capture_final_state_from_inventory(source, before_inventory, key.2)?;
        let after = capture_final_state_from_inventory(target, after_inventory, key.2)?;
        ensure_unchanged_raster(&before, &after)?;
        let expected_attached = expected_by_selector
            .get(&(intent.position, intent.selector))
            .copied()
            .unwrap_or_else(|| before.svg.is_some());
        if after.svg.is_some() != expected_attached {
            return Err(invalid(
                "SVG lifecycle final picture owner does not match the staged operation",
            ));
        }
        guards.push(SvgFinalGuard {
            worksheet: key.0,
            drawing_ordinal: key.1,
            picture_ordinal: key.2,
            before,
            after,
            expected_attached,
        });
    }
    Ok(guards.into_boxed_slice())
}

/// Validate the source state captured when a patch was created before any
/// patch transition is published.  This catches a shared SVG media edit that
/// leaves the selected drawing XML and relationship member bytes unchanged.
pub(super) fn validate_before_guards(workbook: &Workbook, guards: &[SvgFinalGuard]) -> Result<()> {
    validate_guard_states(workbook, guards, true)
}

/// Re-read a patch candidate through the same bounded source-backed worksheet
/// seam used by commit planning.  Only the stored target state is accepted;
/// all XML, relationships, content-type, anchor, raster, and admitted SVG
/// media expectations are exact source-bound values.
pub(super) fn validate_final_guards(workbook: &Workbook, guards: &[SvgFinalGuard]) -> Result<()> {
    validate_guard_states(workbook, guards, false)
}

fn validate_guard_states(
    workbook: &Workbook,
    guards: &[SvgFinalGuard],
    before: bool,
) -> Result<()> {
    let mut inventories = HashMap::new();
    inventories
        .try_reserve(guards.len())
        .map_err(|source| allocation("SVG lifecycle final drawing inventories", source))?;
    let content_types = workbook
        .inner
        .package
        .source_content_types_with_limits(workbook.inner.package.read_limits())?;
    for guard in guards {
        let key = (guard.worksheet.clone(), guard.drawing_ordinal);
        if !inventories.contains_key(&key) {
            let inventory = capture_final_inventory(
                workbook,
                &guard.worksheet,
                guard.drawing_ordinal,
                &content_types,
            )?;
            inventories.insert(key.clone(), inventory);
        }
        let inventory = inventories
            .get(&key)
            .ok_or_else(|| invalid("SVG lifecycle final inventory disappeared"))?;
        let actual = capture_final_state_from_inventory(workbook, inventory, guard.picture_ordinal)
            .map_err(|error| match error {
                Error::PatchConflict { .. } => error,
                _ => Error::PatchConflict {
                    part: guard.worksheet.to_string(),
                },
            })?;
        let expected = if before { &guard.before } else { &guard.after };
        if &actual != expected {
            return Err(Error::PatchConflict {
                part: guard.worksheet.to_string(),
            });
        }
        let expected_attached = if before {
            expected.svg.is_some()
        } else {
            guard.expected_attached
        };
        if actual.svg.is_some() != expected_attached {
            return Err(Error::PatchConflict {
                part: guard.worksheet.to_string(),
            });
        }
    }
    Ok(())
}

fn capture_final_inventory<'a>(
    workbook: &'a Workbook,
    worksheet_uri: &PackURI,
    drawing_ordinal: usize,
    content_types: &OwnedContentTypes,
) -> Result<FinalDrawingInventory<'a>> {
    let worksheet_part = workbook.inner.package.get_part(worksheet_uri)?;
    let (drawing_uri, _) = resolve_drawing_for_uri(workbook, worksheet_uri, drawing_ordinal)?;
    let drawing_part = workbook.inner.package.get_part(&drawing_uri)?;
    let source = Arc::new(SourceDrawing::scan_with_limits(
        drawing_part.blob(),
        drawing_ordinal,
        scan_limits(workbook),
    )?);
    Ok(FinalDrawingInventory {
        drawing: drawing_uri.clone(),
        worksheet_xml: worksheet_part.blob_arc(),
        worksheet_relationships: workbook.inner.package.source_relationships_with_limits(
            worksheet_uri,
            workbook.inner.package.read_limits(),
        )?,
        drawing_xml: drawing_part.blob_arc(),
        drawing_relationships: workbook
            .inner
            .package
            .source_relationships_with_limits(&drawing_uri, workbook.inner.package.read_limits())?,
        content_types: content_types.clone(),
        source,
    })
}

fn capture_final_state_from_inventory(
    workbook: &Workbook,
    inventory: &FinalDrawingInventory<'_>,
    picture_ordinal: usize,
) -> Result<SvgFinalState> {
    let drawing_part = workbook.inner.package.get_part(&inventory.drawing)?;
    let picture = inventory.source.picture(picture_ordinal)?;
    let raster_relationship_id = picture.raster_relationship_id();
    let raster_relationship = drawing_part
        .rels()
        .get(raster_relationship_id)
        .ok_or_else(|| invalid("final raster relationship is missing"))?;
    if raster_relationship.target_mode() != TargetMode::Internal
        || !matches!(raster_relationship.reltype(), rt::IMAGE | rt::STRICT_IMAGE)
    {
        return Err(invalid("final raster relationship is unsupported"));
    }
    let raster_target = raster_relationship.target_partname()?;
    ensure_final_media_uri(&raster_target, "raster")?;
    let raster_part = workbook.inner.package.get_part(&raster_target)?;
    if raster_part.content_type() != ct::PNG || !raster_part.rels().is_empty() {
        return Err(invalid("final raster fallback must be an inert PNG part"));
    }
    let svg = match picture.svg_owner() {
        SvgOwnerState::None | SvgOwnerState::Opaque => None,
        SvgOwnerState::Embedded(owner) => {
            let relationship_id = owner
                .embedded_relationship_id()
                .ok_or_else(|| invalid("embedded SVG owner has no relationship ID"))?;
            let relationship = drawing_part
                .rels()
                .get(relationship_id)
                .ok_or_else(|| invalid("final SVG relationship is missing"))?;
            if relationship.target_mode() != TargetMode::Internal
                || !matches!(relationship.reltype(), rt::IMAGE | rt::STRICT_IMAGE)
            {
                return Err(invalid("final SVG relationship is unsupported"));
            }
            let target = relationship.target_partname()?;
            ensure_final_media_uri(&target, "SVG")?;
            let part = workbook.inner.package.get_part(&target)?;
            if part.content_type() != "image/svg+xml" || !part.rels().is_empty() {
                return Err(invalid("final SVG target must be an inert SVG part"));
            }
            if !manifest_covers_svg(inventory.content_types.bytes(), &target)? {
                return Err(invalid(
                    "final SVG media part has no image/svg+xml content-type declaration",
                ));
            }
            Some(SvgFinalMedia {
                relationship_id: relationship_id.to_owned().into_boxed_str(),
                relationship_type: relationship.reltype().to_owned().into_boxed_str(),
                target_mode: relationship.target_mode(),
                part: part.partname().clone(),
                content_type: part.content_type().to_owned().into_boxed_str(),
                bytes: part.blob_arc(),
            })
        },
        SvgOwnerState::Linked(_) => {
            return Err(invalid("final SVG owner is linked"));
        },
        SvgOwnerState::Ambiguous => {
            return Err(invalid("final picture has duplicate SVG owners"));
        },
        SvgOwnerState::Refused => {
            return Err(invalid("final picture has a refused SVG owner"));
        },
    };
    Ok(SvgFinalState {
        drawing: inventory.drawing.clone(),
        worksheet_xml: Arc::clone(&inventory.worksheet_xml),
        worksheet_relationships: inventory.worksheet_relationships.clone(),
        drawing_xml: Arc::clone(&inventory.drawing_xml),
        drawing_relationships: inventory.drawing_relationships.clone(),
        content_types: inventory.content_types.clone(),
        anchor: *picture.anchor(),
        raster_relationship_id: raster_relationship_id.to_owned().into_boxed_str(),
        raster_relationship_type: raster_relationship.reltype().to_owned().into_boxed_str(),
        raster_target_mode: raster_relationship.target_mode(),
        raster_part: raster_part.partname().clone(),
        raster_content_type: raster_part.content_type().to_owned().into_boxed_str(),
        raster_bytes: raster_part.blob_arc(),
        svg,
    })
}

fn ensure_final_media_uri(uri: &PackURI, kind: &str) -> Result<()> {
    let mut segments = uri.as_str().split('/');
    let valid_prefix = segments.next() == Some("")
        && segments
            .next()
            .is_some_and(|segment| segment.eq_ignore_ascii_case("xl"))
        && segments
            .next()
            .is_some_and(|segment| segment.eq_ignore_ascii_case("media"));
    if !valid_prefix || segments.next().is_none() {
        return Err(invalid(format!(
            "final {kind} target is outside canonical /xl/media/"
        )));
    }
    Ok(())
}

fn resolve_drawing_for_uri(
    workbook: &Workbook,
    worksheet_uri: &PackURI,
    drawing_ordinal: usize,
) -> Result<(PackURI, Relationship)> {
    let worksheet = workbook.inner.package.get_part(worksheet_uri)?;
    let references = worksheet_drawing_references(workbook, worksheet.blob())?;
    let relationship_id = references
        .get(drawing_ordinal)
        .ok_or_else(|| invalid("drawing ordinal is outside worksheet drawings"))?;
    let relationship = worksheet
        .rels()
        .get(relationship_id)
        .cloned()
        .ok_or_else(|| invalid("worksheet drawing relationship is missing"))?;
    if relationship.target_mode() != TargetMode::Internal
        || !matches!(relationship.reltype(), rt::DRAWING | rt::STRICT_DRAWING)
    {
        return Err(invalid("worksheet drawing relationship is unsupported"));
    }
    let drawing_uri = relationship.target_partname()?;
    let drawing = workbook.inner.package.get_part(&drawing_uri)?;
    if drawing.content_type() != ct::OFC_DRAWING {
        return Err(invalid(
            "worksheet drawing target has an unsupported content type",
        ));
    }
    Ok((drawing_uri, relationship))
}

fn ensure_unchanged_raster(before: &SvgFinalState, after: &SvgFinalState) -> Result<()> {
    if before.anchor != after.anchor {
        return Err(invalid(
            "SVG lifecycle changed the selected picture anchor geometry",
        ));
    }
    if !before.raster_part.is_equivalent_to(&after.raster_part)
        || before.raster_relationship_id != after.raster_relationship_id
        || before.raster_relationship_type != after.raster_relationship_type
        || before.raster_target_mode != after.raster_target_mode
        || before.raster_content_type != after.raster_content_type
        || before.raster_bytes.as_slice() != after.raster_bytes.as_slice()
    {
        return Err(invalid(
            "SVG lifecycle changed the inert PNG compatibility fallback",
        ));
    }
    Ok(())
}

/// Preflight a public operation before its borrowed payload is copied.  A
/// detach with no admitted owner is an exact in-memory no-op.
/// Preflight an operation against the source package plus operations already
/// staged in this transaction.  The source scanner remains authoritative for
/// the initial owner state; this small projection prevents a later detach
/// from silently becoming a no-op after an earlier attach (and permits the
/// corresponding detach-then-attach sequence).
pub(super) fn preflight_with_pending(
    workbook: &Workbook,
    position: usize,
    selector: PictureSelector,
    attach: bool,
    cache: &mut HashMap<(usize, usize), DrawingPreflight>,
    projected: &mut HashMap<(usize, PictureSelector), ProjectedSvgOwner>,
) -> Result<bool> {
    let key = (position, selector_drawing(selector));
    if !cache.contains_key(&key) {
        cache
            .try_reserve(1)
            .map_err(|source| allocation("SVG lifecycle preflight cache", source))?;
        let facts = build_preflight_cache(workbook, position, selector)?;
        cache.insert(key, facts);
    }
    let facts = cache
        .get(&key)
        .ok_or_else(|| invalid("SVG lifecycle preflight cache disappeared"))?;
    let part = workbook.inner.package.get_part(&facts.drawing_uri)?;
    let picture = facts
        .pictures
        .get(selector_picture(selector))
        .ok_or_else(|| invalid("picture ordinal is outside worksheet drawing pictures"))?;
    validate_raster_fallback_id(workbook, part, &picture.raster_relationship_id)?;
    let owner = if let Some(owner) = projected.get(&(position, selector)) {
        *owner
    } else {
        projected.insert((position, selector), picture.owner);
        picture.owner
    };
    match (attach, owner) {
        (true, ProjectedSvgOwner::None | ProjectedSvgOwner::Opaque) => {
            projected.insert((position, selector), ProjectedSvgOwner::Embedded);
            Ok(true)
        },
        (true, ProjectedSvgOwner::Embedded) => Err(invalid(
            "selected picture already has an embedded SVG owner",
        )),
        (true, ProjectedSvgOwner::Linked) => Err(invalid(
            "linked SVG owners cannot be replaced by attach_svg",
        )),
        (true, ProjectedSvgOwner::Ambiguous | ProjectedSvgOwner::Refused) => Err(invalid(
            "selected picture has an ambiguous or refused SVG owner",
        )),
        (false, ProjectedSvgOwner::Embedded) => {
            projected.insert((position, selector), ProjectedSvgOwner::None);
            Ok(true)
        },
        (false, ProjectedSvgOwner::Linked) => Err(invalid("linked SVG owners cannot be detached")),
        (false, ProjectedSvgOwner::Ambiguous | ProjectedSvgOwner::Refused) => Err(invalid(
            "selected picture has an ambiguous or refused SVG owner",
        )),
        (false, ProjectedSvgOwner::None | ProjectedSvgOwner::Opaque) => Ok(false),
    }
}

fn build_preflight_cache(
    workbook: &Workbook,
    position: usize,
    selector: PictureSelector,
) -> Result<DrawingPreflight> {
    let (drawing_uri, _) = resolve_drawing(workbook, position, selector)?;
    let part = workbook.inner.package.get_part(&drawing_uri)?;
    let scanned = SourceDrawing::scan_with_limits(
        part.blob(),
        selector_drawing(selector),
        scan_limits(workbook),
    )?;
    let mut pictures = Vec::new();
    pictures
        .try_reserve(scanned.pictures().len())
        .map_err(|source| allocation("SVG lifecycle preflight pictures", source))?;
    for picture in scanned.pictures() {
        let owner = match picture.svg_owner() {
            SvgOwnerState::None => ProjectedSvgOwner::None,
            SvgOwnerState::Opaque => ProjectedSvgOwner::Opaque,
            SvgOwnerState::Embedded(_) => ProjectedSvgOwner::Embedded,
            SvgOwnerState::Linked(_) => ProjectedSvgOwner::Linked,
            SvgOwnerState::Ambiguous => ProjectedSvgOwner::Ambiguous,
            SvgOwnerState::Refused => ProjectedSvgOwner::Refused,
        };
        pictures.push(CachedPicture {
            owner,
            raster_relationship_id: picture.raster_relationship_id().into(),
        });
    }
    Ok(DrawingPreflight {
        drawing_uri,
        pictures,
    })
}

#[derive(Clone, Copy, Debug)]
pub(super) enum ProjectedSvgOwner {
    None,
    Opaque,
    Embedded,
    Linked,
    Ambiguous,
    Refused,
}

#[derive(Debug)]
struct DrawingPlanState {
    uri: PackURI,
    before_xml: OwnedXmlPart,
    current_xml: OwnedXmlPart,
    before_rels: OwnedRelationships,
    current_rels: OwnedRelationships,
    before_edges: Relationships,
    current_edges: Relationships,
}

fn new_drawing_plan_state(workbook: &Workbook, uri: PackURI) -> Result<DrawingPlanState> {
    let part = workbook.inner.package.get_part(&uri)?;
    let limits = scan_limits(workbook);
    if part.blob().len() > MAX_DRAWING_BYTES || part.blob().len() > limits.max_xml_bytes {
        return Err(invalid(format!(
            "SVG lifecycle drawing XML exceeds {} bytes",
            limits.max_xml_bytes.min(MAX_DRAWING_BYTES)
        )));
    }
    let before_xml = workbook.inner.package.source_xml_part(&uri)?;
    let before_rels = workbook
        .inner
        .package
        .source_relationships_with_limits(&uri, workbook.inner.package.read_limits())?;
    Ok(DrawingPlanState {
        current_xml: before_xml.clone(),
        current_rels: before_rels.clone(),
        before_xml,
        before_rels,
        before_edges: part.rels().clone(),
        current_edges: part.rels().clone(),
        uri,
    })
}

fn plan_composed(
    workbook: &Workbook,
    intents: &[SvgLifecycleIntent],
    ordinary_graph: &[super::model::GraphChange],
    relationship_changes: &[RelationshipChange],
    parts: &mut Vec<PartChange>,
    relationships: &mut Vec<RelationshipChange>,
    svg_parts: &mut Vec<SvgPartChange>,
    content_types: &mut Option<ContentTypesChange>,
    package_changes: &mut Vec<PackageChange>,
) -> Result<()> {
    let package_changes_start = package_changes.len();
    let parts_start = parts.len();
    let relationships_start = relationships.len();
    let svg_parts_start = svg_parts.len();
    let content_types_was_none = content_types.is_none();
    package_changes
        .try_reserve(intents.len())
        .map_err(|source| allocation("SVG lifecycle package changes", source))?;
    let mut states = Vec::new();
    states
        .try_reserve(intents.len())
        .map_err(|source| allocation("SVG lifecycle drawing states", source))?;
    let mut state_by_uri: HashMap<String, usize> = HashMap::new();
    state_by_uri
        .try_reserve(intents.len())
        .map_err(|source| allocation("SVG lifecycle drawing lookup", source))?;
    let mut drawing_by_selector: HashMap<(usize, usize), PackURI> = HashMap::new();
    drawing_by_selector
        .try_reserve(intents.len())
        .map_err(|source| allocation("SVG lifecycle worksheet drawing lookup", source))?;
    let mut state_groups: Vec<Vec<usize>> = Vec::new();
    state_groups
        .try_reserve(intents.len())
        .map_err(|source| allocation("SVG lifecycle drawing intent groups", source))?;
    let mut pending_parts = Vec::new();
    pending_parts
        .try_reserve(intents.len())
        .map_err(|source| allocation("SVG lifecycle pending media parts", source))?;
    let mut reserved_uris = HashSet::new();
    reserved_uris
        .try_reserve(intents.len())
        .map_err(|source| allocation("SVG lifecycle media identities", source))?;
    let mut occupied_part_names = HashSet::new();
    occupied_part_names
        .try_reserve(
            workbook
                .inner
                .package
                .iter_parts()
                .count()
                .saturating_add(intents.len()),
        )
        .map_err(|source| allocation("SVG lifecycle media identity index", source))?;
    let mut occupied_part_prefixes = HashSet::new();
    occupied_part_prefixes
        .try_reserve(
            workbook
                .inner
                .package
                .iter_parts()
                .count()
                .saturating_mul(2)
                .saturating_add(intents.len()),
        )
        .map_err(|source| allocation("SVG lifecycle media prefix index", source))?;
    for part in workbook.inner.package.iter_parts() {
        index_part_name(
            part.partname(),
            &mut occupied_part_names,
            &mut occupied_part_prefixes,
        );
    }
    let mut next_part_index = 0usize;
    let mut cleanup_targets = Vec::new();
    cleanup_targets
        .try_reserve(intents.len())
        .map_err(|source| allocation("SVG lifecycle media cleanup targets", source))?;
    let manifest_before = workbook
        .inner
        .package
        .source_content_types_with_limits(workbook.inner.package.read_limits())?;
    let mut manifest_after = manifest_before.clone();

    for (intent_index, intent) in intents.iter().enumerate() {
        let selector_key = (intent.position, selector_drawing(intent.selector));
        let drawing_uri = if let Some(uri) = drawing_by_selector.get(&selector_key) {
            uri.clone()
        } else {
            let (uri, _) = resolve_drawing(workbook, intent.position, intent.selector)?;
            drawing_by_selector.insert(selector_key, uri.clone());
            uri
        };
        let drawing_key = drawing_uri.as_str().to_ascii_lowercase();
        let state_index = if let Some(index) = state_by_uri.get(&drawing_key).copied() {
            index
        } else {
            state_by_uri.insert(drawing_key, states.len());
            states.push(new_drawing_plan_state(workbook, drawing_uri.clone())?);
            state_groups.push(Vec::new());
            states.len() - 1
        };
        state_groups
            .get_mut(state_index)
            .ok_or_else(|| invalid("SVG lifecycle drawing intent group disappeared"))?
            .try_reserve(1)
            .map_err(|source| allocation("SVG lifecycle drawing intent group", source))?;
        state_groups[state_index].push(intent_index);
        package_changes.push(PackageChange::SvgLifecycle {
            sheet: workbook.inner.sheets[intent.position].name.as_str().into(),
            drawing: selector_drawing(intent.selector),
            picture: selector_picture(intent.selector),
            attached: intent.attach,
        });
    }

    for state_index in 0..state_groups.len() {
        let group = &state_groups[state_index];
        let all_attach = group.iter().all(|index| intents[*index].attach);
        let all_detach = group.iter().all(|index| !intents[*index].attach);
        let mut selectors = HashSet::new();
        selectors
            .try_reserve(group.len())
            .map_err(|source| allocation("SVG lifecycle picture selectors", source))?;
        let unique_selectors = group
            .iter()
            .all(|index| selectors.insert(intents[*index].selector));
        if all_attach && unique_selectors {
            plan_composed_attach_batch(
                workbook,
                group,
                intents,
                &mut states[state_index],
                &mut pending_parts,
                &mut reserved_uris,
                &mut occupied_part_names,
                &mut occupied_part_prefixes,
                &mut next_part_index,
                &mut manifest_after,
            )?;
        } else if all_detach && unique_selectors {
            plan_composed_detach_batch(
                workbook,
                group,
                intents,
                &mut states[state_index],
                &pending_parts,
                &mut manifest_after,
                &mut cleanup_targets,
            )?;
        } else if unique_selectors {
            plan_composed_mixed_batch(
                workbook,
                group,
                intents,
                &mut states[state_index],
                &mut pending_parts,
                &mut reserved_uris,
                &mut occupied_part_names,
                &mut occupied_part_prefixes,
                &mut next_part_index,
                &mut manifest_after,
                &mut cleanup_targets,
            )?;
        } else {
            let first_selector = intents
                .get(
                    *group
                        .first()
                        .ok_or_else(|| invalid("empty SVG lifecycle group"))?,
                )
                .ok_or_else(|| invalid("SVG lifecycle intent disappeared"))?
                .selector;
            let same_selector = group.iter().all(|index| {
                intents
                    .get(*index)
                    .is_some_and(|intent| intent.selector == first_selector)
            });
            if same_selector {
                let first = intents
                    .get(group[0])
                    .ok_or_else(|| invalid("SVG lifecycle intent disappeared"))?;
                let last = intents
                    .get(
                        *group
                            .last()
                            .ok_or_else(|| invalid("empty SVG lifecycle group"))?,
                    )
                    .ok_or_else(|| invalid("SVG lifecycle intent disappeared"))?;
                if first.attach && !last.attach {
                    // The staged projection has already proved that the
                    // selected picture was absent before this sequence.  An
                    // attach followed by its final detach is therefore an
                    // exact no-op; avoid manufacturing and then deleting a
                    // temporary media part and drawing rewrite.
                    continue;
                }
                if !first.attach && last.attach {
                    plan_composed_replacement(
                        workbook,
                        first,
                        last,
                        &mut states[state_index],
                        &mut pending_parts,
                        &mut reserved_uris,
                        &mut occupied_part_names,
                        &mut occupied_part_prefixes,
                        &mut next_part_index,
                        &mut manifest_after,
                        &mut cleanup_targets,
                    )?;
                    continue;
                }
                if first.attach && last.attach {
                    plan_composed_intent(
                        workbook,
                        last,
                        &mut states[state_index],
                        &mut pending_parts,
                        &mut reserved_uris,
                        &mut occupied_part_names,
                        &mut occupied_part_prefixes,
                        &mut next_part_index,
                        &mut manifest_after,
                        &mut cleanup_targets,
                    )?;
                    continue;
                }
                plan_composed_intent(
                    workbook,
                    first,
                    &mut states[state_index],
                    &mut pending_parts,
                    &mut reserved_uris,
                    &mut occupied_part_names,
                    &mut occupied_part_prefixes,
                    &mut next_part_index,
                    &mut manifest_after,
                    &mut cleanup_targets,
                )?;
                continue;
            }
            for index in group {
                plan_composed_intent(
                    workbook,
                    &intents[*index],
                    &mut states[state_index],
                    &mut pending_parts,
                    &mut reserved_uris,
                    &mut occupied_part_names,
                    &mut occupied_part_prefixes,
                    &mut next_part_index,
                    &mut manifest_after,
                    &mut cleanup_targets,
                )?;
            }
        }
    }

    finalize_svg_target_cleanup(
        workbook,
        &states,
        ordinary_graph,
        relationship_changes,
        &mut pending_parts,
        &cleanup_targets,
        &mut manifest_after,
        content_types_output_limit(workbook),
    )?;

    for state in states {
        if state.current_xml.bytes() != state.before_xml.bytes() {
            parts.push(PartChange {
                uri: state.uri.clone(),
                before: state.before_xml.shared_bytes(),
                after: state.current_xml.shared_bytes(),
                before_source: Some(state.before_xml),
                after_source: Some(state.current_xml),
            });
        }
        if let Some(id) = changed_relationship_id(&state.before_edges, &state.current_edges)? {
            relationships.push(RelationshipChange {
                owner: state.uri,
                before: state.before_edges.get(&id).cloned(),
                after: state.current_edges.get(&id).cloned(),
                before_source: Some(state.before_rels),
                after_source: Some(state.current_rels),
            });
        }
    }
    svg_parts.extend(pending_parts);
    if manifest_after.bytes() != manifest_before.bytes() {
        *content_types = Some(ContentTypesChange {
            before: manifest_before,
            after: manifest_after,
        });
    }
    if content_types_was_none
        && parts.len() == parts_start
        && relationships.len() == relationships_start
        && svg_parts.len() == svg_parts_start
        && content_types.is_none()
    {
        package_changes.truncate(package_changes_start);
    }
    Ok(())
}

/// Plan the common detach-only batch in one source scan and one drawing XML
/// rewrite. Relationship members remain source-bound tokens; removing their
/// individual edges is cheap compared with rescanning and reallocating the
/// complete drawing once per picture.
fn plan_composed_detach_batch(
    workbook: &Workbook,
    group: &[usize],
    intents: &[SvgLifecycleIntent],
    state: &mut DrawingPlanState,
    pending_parts: &[SvgPartChange],
    _manifest: &mut OwnedContentTypes,
    cleanup_targets: &mut Vec<PackURI>,
) -> Result<()> {
    let limits = scan_limits(workbook);
    let output_cap = output_limit(workbook);
    let relationship_cap = relationship_output_limit(workbook);
    let scanned = SourceDrawing::scan_with_limits(
        state.before_xml.bytes(),
        selector_drawing(
            intents
                .get(
                    *group
                        .first()
                        .ok_or_else(|| invalid("empty SVG lifecycle group"))?,
                )
                .ok_or_else(|| invalid("SVG lifecycle intent disappeared"))?
                .selector,
        ),
        limits,
    )?;
    let mut operations = Vec::new();
    operations
        .try_reserve(group.len())
        .map_err(|source| allocation("SVG lifecycle detach batch", source))?;
    for index in group {
        let intent = intents
            .get(*index)
            .ok_or_else(|| invalid("SVG lifecycle intent disappeared"))?;
        let picture = scanned.picture(selector_picture(intent.selector))?;
        validate_raster_fallback_edges(workbook, &state.current_edges, picture)?;
        let owner = match picture.svg_owner() {
            SvgOwnerState::Embedded(owner) => owner,
            SvgOwnerState::None | SvgOwnerState::Opaque => {
                return Err(invalid("selected picture has no admitted SVG owner"));
            },
            SvgOwnerState::Linked(_) => {
                return Err(invalid("linked SVG owners cannot be detached"));
            },
            SvgOwnerState::Ambiguous | SvgOwnerState::Refused => {
                return Err(invalid(
                    "selected picture has an ambiguous or refused SVG owner",
                ));
            },
        };
        let relationship_id = owner
            .embedded_relationship_id()
            .ok_or_else(|| invalid("embedded SVG owner has no relationship ID"))?;
        let relationship = state
            .current_edges
            .get(relationship_id)
            .cloned()
            .ok_or_else(|| invalid("embedded SVG relationship is missing"))?;
        let target = relationship.target_partname()?;
        validate_svg_target_candidate(workbook, &relationship, &target, pending_parts)?;
        let (opening, removed) = detach_ranges(state.before_xml.bytes(), picture, owner)?;
        operations.push(DetachOperation {
            relationship_id: relationship_id.to_owned(),
            target,
            opening,
            removed,
            owner_range: owner.extension_range(),
            ext_list: picture
                .ext_list_range()
                .map(|range| (range.range(), range.start_end())),
        });
    }

    let mut xml_removals = Vec::new();
    xml_removals
        .try_reserve(operations.len())
        .map_err(|source| allocation("SVG lifecycle detach XML ranges", source))?;
    for operation in &operations {
        xml_removals.push(XmlRemoval {
            opening: operation.opening.clone(),
            removed: operation.removed,
        });
    }
    let mut ext_lists = Vec::new();
    ext_lists
        .try_reserve(operations.len())
        .map_err(|source| allocation("SVG lifecycle detach extension lists", source))?;
    for operation in &operations {
        let Some((range, start_end)) = operation.ext_list else {
            continue;
        };
        let Some(existing) = ext_lists
            .iter_mut()
            .find(|candidate: &&mut ExtListRemoval| candidate.range == range)
        else {
            let mut owner_ranges = Vec::new();
            owner_ranges
                .try_reserve(1)
                .map_err(|source| allocation("SVG lifecycle extension list owners", source))?;
            owner_ranges.push(operation.owner_range);
            ext_lists.push(ExtListRemoval {
                range,
                start_end,
                owner_ranges,
            });
            continue;
        };
        existing
            .owner_ranges
            .try_reserve(1)
            .map_err(|source| allocation("SVG lifecycle extension list owners", source))?;
        existing.owner_ranges.push(operation.owner_range);
    }
    for ext_list in &ext_lists {
        if !ext_list_contains_only_owner_ranges(
            state.before_xml.bytes(),
            ext_list.range,
            &ext_list.owner_ranges,
        )? {
            continue;
        }
        xml_removals.retain(|removal| {
            removal.removed != ext_list.range
                && !ext_list.owner_ranges.iter().any(|owner| {
                    owner.start == removal.removed.start && owner.end == removal.removed.end
                })
        });
        xml_removals.push(XmlRemoval {
            opening: ext_list.range.start..ext_list.start_end,
            removed: ext_list.range,
        });
    }
    xml_removals.sort_by(|left, right| {
        left.opening
            .start
            .cmp(&right.opening.start)
            .then(left.opening.end.cmp(&right.opening.end))
    });
    for pair in xml_removals.windows(2) {
        if pair[0].opening.end > pair[1].opening.start {
            return Err(invalid("SVG detach ranges overlap"));
        }
    }
    let mut updates = Vec::new();
    updates
        .try_reserve(xml_removals.len())
        .map_err(|source| allocation("SVG lifecycle detach XML updates", source))?;
    for removal in &xml_removals {
        updates.push(OwnedElementUpdate {
            start_tag: removal.opening.clone(),
            edit: OwnedElementEdit::Remove,
        });
    }
    state.current_xml = state.before_xml.update_elements(&updates, output_cap)?;

    let references = scanned.relationship_references();
    let mut removed_relationships = Vec::new();
    removed_relationships
        .try_reserve(operations.len())
        .map_err(|source| allocation("SVG lifecycle detach relationships", source))?;
    let mut removed_ranges = Vec::new();
    removed_ranges
        .try_reserve(xml_removals.len())
        .map_err(|source| allocation("SVG lifecycle removed ranges", source))?;
    removed_ranges.extend(xml_removals.iter().map(|removal| removal.removed));
    removed_ranges.sort_by_key(|range| range.start);
    let mut remaining_references = HashMap::<&str, usize>::new();
    remaining_references
        .try_reserve(references.len())
        .map_err(|source| allocation("SVG lifecycle relationship reference census", source))?;
    let mut removed_range_index = 0usize;
    for reference in references {
        while removed_range_index < removed_ranges.len()
            && removed_ranges[removed_range_index].end <= reference.range().start
        {
            removed_range_index += 1;
        }
        let removed = removed_range_index < removed_ranges.len()
            && ranges_overlap(reference.range(), removed_ranges[removed_range_index]);
        if !removed {
            let entry = remaining_references.entry(reference.id()).or_insert(0);
            *entry = entry
                .checked_add(1)
                .ok_or_else(|| invalid("SVG lifecycle relationship reference count overflow"))?;
        }
    }
    for operation in &operations {
        let remaining = remaining_references
            .get(operation.relationship_id.as_str())
            .copied()
            .unwrap_or(0);
        if remaining != 0
            || removed_relationships
                .iter()
                .any(|relationship_id: &String| relationship_id == &operation.relationship_id)
        {
            continue;
        }
        removed_relationships.push(operation.relationship_id.clone());
        if !cleanup_targets
            .iter()
            .any(|candidate| candidate.is_equivalent_to(&operation.target))
        {
            cleanup_targets.push(operation.target.clone());
        }
    }
    if !removed_relationships.is_empty() {
        let mut relationship_ids = Vec::new();
        relationship_ids
            .try_reserve(removed_relationships.len())
            .map_err(|source| allocation("SVG lifecycle relationship selectors", source))?;
        relationship_ids.extend(removed_relationships.iter().map(String::as_str));
        state.current_rels = state
            .current_rels
            .without_relationships(&relationship_ids, relationship_cap)?;
        for relationship_id in removed_relationships {
            state.current_edges.remove(&relationship_id);
        }
    }
    Ok(())
}

struct DetachOperation {
    relationship_id: String,
    target: PackURI,
    opening: std::ops::Range<usize>,
    removed: source::ByteRange,
    owner_range: source::ByteRange,
    ext_list: Option<(source::ByteRange, usize)>,
}

struct XmlRemoval {
    opening: std::ops::Range<usize>,
    removed: source::ByteRange,
}

struct ExtListRemoval {
    range: source::ByteRange,
    start_end: usize,
    owner_ranges: Vec<source::ByteRange>,
}

struct MixedAttachOperation {
    intent_index: usize,
    relationship_id: String,
    part_uri: PackURI,
    parent: std::ops::Range<usize>,
    parent_empty: bool,
    parent_name_len: usize,
    fragment_len: usize,
}

/// Coalesce the only meaningful repeated-selector replacement sequence into
/// one source drawing rewrite.  The public staging projection permits
/// `detach_svg(...).attach_svg(...)` so a caller can replace an existing SVG
/// payload in one ordinary transaction.  Reusing the existing owner range
/// keeps opaque extension siblings byte exact and avoids the intermediate
/// detach/attach XML and relationship allocations.
fn plan_composed_replacement(
    workbook: &Workbook,
    detach: &SvgLifecycleIntent,
    attach: &SvgLifecycleIntent,
    state: &mut DrawingPlanState,
    pending_parts: &mut Vec<SvgPartChange>,
    reserved_uris: &mut HashSet<PackURI>,
    occupied_part_names: &mut HashSet<String>,
    occupied_part_prefixes: &mut HashSet<String>,
    next_part_index: &mut usize,
    manifest: &mut OwnedContentTypes,
    cleanup_targets: &mut Vec<PackURI>,
) -> Result<()> {
    let limits = scan_limits(workbook);
    let output_cap = output_limit(workbook);
    let relationship_cap = relationship_output_limit(workbook);
    let content_types_cap = content_types_output_limit(workbook);
    let content_type_mapping_cap = workbook
        .inner
        .package
        .read_limits()
        .max_content_type_mappings();
    let scanned = SourceDrawing::scan_with_limits(
        state.before_xml.bytes(),
        selector_drawing(detach.selector),
        limits,
    )?;
    let picture = scanned.picture(selector_picture(detach.selector))?;
    validate_raster_fallback_edges(workbook, &state.current_edges, picture)?;
    let owner = match picture.svg_owner() {
        SvgOwnerState::Embedded(owner) => owner,
        SvgOwnerState::None | SvgOwnerState::Opaque => {
            return Err(invalid("selected picture has no admitted SVG owner"));
        },
        SvgOwnerState::Linked(_) => {
            return Err(invalid("linked SVG owners cannot be detached"));
        },
        SvgOwnerState::Ambiguous | SvgOwnerState::Refused => {
            return Err(invalid(
                "selected picture has an ambiguous or refused SVG owner",
            ));
        },
    };
    let relationship_id = owner
        .embedded_relationship_id()
        .ok_or_else(|| invalid("embedded SVG owner has no relationship ID"))?;
    let relationship = state
        .current_edges
        .get(relationship_id)
        .cloned()
        .ok_or_else(|| invalid("embedded SVG relationship is missing"))?;
    let old_target = relationship.target_partname()?;
    validate_svg_target_candidate(workbook, &relationship, &old_target, pending_parts)?;
    let payload = attach
        .payload
        .as_deref()
        .ok_or_else(|| invalid("attach_svg has no staged payload"))?;
    if payload.len() > output_cap {
        return Err(invalid(format!(
            "SVG lifecycle payload exceeds {} bytes",
            output_cap
        )));
    }

    let owner_range = owner.extension_range();
    let opaque_references = scanned
        .relationship_references()
        .iter()
        .filter(|reference| {
            reference.id() == relationship_id && !ranges_overlap(reference.range(), owner_range)
        })
        .count();
    let retain_old_relationship = opaque_references != 0;
    let new_relationship_id = if retain_old_relationship {
        allocate_relationship_id(&state.current_edges)?
    } else {
        relationship_id.to_owned()
    };
    let part_uri = allocate_part_uri_with_reservations(
        reserved_uris,
        occupied_part_names,
        occupied_part_prefixes,
        next_part_index,
    )?;
    reserved_uris.insert(part_uri.clone());
    index_part_name(&part_uri, occupied_part_names, occupied_part_prefixes);
    let relationship_type = if scanned.relationship_dialect() == source::RelationshipDialect::Strict
    {
        rt::STRICT_IMAGE
    } else {
        rt::IMAGE
    };
    let target_ref = part_uri.relative_ref(state.uri.base_uri());
    let next_relationship = Relationship::new_with_mode(
        new_relationship_id.clone(),
        relationship_type.to_owned(),
        target_ref.clone(),
        state.uri.base_uri().to_owned(),
        TargetMode::Internal,
    );
    let next_edges_len = state
        .current_edges
        .len()
        .checked_add(usize::from(!retain_old_relationship))
        .ok_or_else(|| invalid("SVG relationship count overflows"))?;
    if next_edges_len
        > workbook
            .inner
            .package
            .read_limits()
            .max_relationships_per_part()
    {
        return Err(invalid("SVG relationship count exceeds caller limit"));
    }
    let blip = picture.blip_range();
    let extension_len =
        generated_extension_size(blip.prefix(), &new_relationship_id, scanned.dialect());
    let owner_opening = opening_tag_range(state.before_xml.bytes(), owner_range)?;
    let output_size = state
        .before_xml
        .bytes()
        .len()
        .checked_sub(owner_range.len()?)
        .and_then(|size| size.checked_add(extension_len))
        .ok_or_else(|| invalid("SVG lifecycle replacement output size overflow"))?;
    if output_size > output_cap {
        return Err(invalid(format!(
            "SVG lifecycle drawing output exceeds {} bytes",
            output_cap
        )));
    }

    let extension = generated_extension(blip.prefix(), &new_relationship_id, scanned.dialect())?;
    let next_xml = state.before_xml.update_elements(
        &[OwnedElementUpdate {
            start_tag: owner_opening,
            edit: OwnedElementEdit::Replace(&extension),
        }],
        output_cap,
    )?;
    let mut next_rels = state.current_rels.clone();
    if !retain_old_relationship {
        next_rels = next_rels.without_relationship(relationship_id, relationship_cap)?;
    }
    next_rels = next_rels.with_relationship(
        relationship_type,
        &target_ref,
        &new_relationship_id,
        TargetMode::Internal,
        relationship_cap,
    )?;
    if !retain_old_relationship {
        state.current_edges.remove(relationship_id);
        if !cleanup_targets
            .iter()
            .any(|candidate| candidate.is_equivalent_to(&old_target))
        {
            cleanup_targets.push(old_target);
        }
    }
    state.current_edges.try_add_relationship(
        next_relationship.reltype().to_owned(),
        next_relationship.target_ref().to_owned(),
        next_relationship.r_id().to_owned(),
        next_relationship.target_mode(),
    )?;
    state.current_xml = next_xml;
    state.current_rels = next_rels;
    pending_parts.push(SvgPartChange {
        action: GraphAction::Add,
        part: Box::new(BlobPart::new_shared(
            part_uri.clone(),
            "image/svg+xml".to_owned(),
            Arc::clone(
                attach
                    .payload
                    .as_ref()
                    .ok_or_else(|| invalid("attach_svg has no staged payload"))?,
            ),
        )),
    });
    *manifest = manifest_add_token(
        manifest,
        &part_uri,
        content_types_cap,
        content_type_mapping_cap,
    )?;
    Ok(())
}

/// Plan a drawing group containing one attach/detach operation per picture.
/// Distinct selectors address disjoint source elements, so all structural
/// changes can be published by one drawing XML splice.  Repeated selectors
/// are coalesced to their final projected owner state; selectors mixed with
/// other pictures retain the bounded sequential path because their source
/// ranges can overlap an intermediate owner transition.
fn plan_composed_mixed_batch(
    workbook: &Workbook,
    group: &[usize],
    intents: &[SvgLifecycleIntent],
    state: &mut DrawingPlanState,
    pending_parts: &mut Vec<SvgPartChange>,
    reserved_uris: &mut HashSet<PackURI>,
    occupied_part_names: &mut HashSet<String>,
    occupied_part_prefixes: &mut HashSet<String>,
    next_part_index: &mut usize,
    manifest: &mut OwnedContentTypes,
    cleanup_targets: &mut Vec<PackURI>,
) -> Result<()> {
    let limits = scan_limits(workbook);
    let output_cap = output_limit(workbook);
    let relationship_cap = relationship_output_limit(workbook);
    let content_types_cap = content_types_output_limit(workbook);
    let content_type_mapping_cap = workbook
        .inner
        .package
        .read_limits()
        .max_content_type_mappings();
    let first = intents
        .get(
            *group
                .first()
                .ok_or_else(|| invalid("empty SVG lifecycle group"))?,
        )
        .ok_or_else(|| invalid("SVG lifecycle intent disappeared"))?;
    let scanned = SourceDrawing::scan_with_limits(
        state.before_xml.bytes(),
        selector_drawing(first.selector),
        limits,
    )?;
    let relationship_type = if scanned.relationship_dialect() == source::RelationshipDialect::Strict
    {
        rt::STRICT_IMAGE
    } else {
        rt::IMAGE
    };
    let mut planning_edges = state.current_edges.clone();
    let mut attachments = Vec::new();
    attachments
        .try_reserve(group.len())
        .map_err(|source| allocation("SVG lifecycle mixed attachments", source))?;
    let mut additions: Vec<(String, String, String, TargetMode)> = Vec::new();
    additions
        .try_reserve(group.len())
        .map_err(|source| allocation("SVG lifecycle mixed relationships", source))?;
    let mut new_uris = Vec::new();
    new_uris
        .try_reserve(group.len())
        .map_err(|source| allocation("SVG lifecycle mixed media", source))?;
    let mut detach_operations = Vec::new();
    detach_operations
        .try_reserve(group.len())
        .map_err(|source| allocation("SVG lifecycle mixed detachments", source))?;

    for index in group {
        let intent = intents
            .get(*index)
            .ok_or_else(|| invalid("SVG lifecycle intent disappeared"))?;
        let picture = scanned.picture(selector_picture(intent.selector))?;
        validate_raster_fallback_edges(workbook, &planning_edges, picture)?;
        if intent.attach {
            let payload = intent
                .payload
                .as_deref()
                .ok_or_else(|| invalid("attach_svg has no staged payload"))?;
            if payload.len() > output_cap {
                return Err(invalid(format!(
                    "SVG lifecycle payload exceeds {} bytes",
                    output_cap
                )));
            }
            match picture.svg_owner() {
                SvgOwnerState::None | SvgOwnerState::Opaque => {},
                SvgOwnerState::Embedded(_) => {
                    return Err(invalid(
                        "selected picture already has an embedded SVG owner",
                    ));
                },
                SvgOwnerState::Linked(_) => {
                    return Err(invalid(
                        "linked SVG owners cannot be replaced by attach_svg",
                    ));
                },
                SvgOwnerState::Ambiguous | SvgOwnerState::Refused => {
                    return Err(invalid(
                        "selected picture has an ambiguous or refused SVG owner",
                    ));
                },
            }
            let relationship_id = allocate_relationship_id(&planning_edges)?;
            let part_uri = allocate_part_uri_with_reservations(
                reserved_uris,
                occupied_part_names,
                occupied_part_prefixes,
                next_part_index,
            )?;
            reserved_uris.insert(part_uri.clone());
            index_part_name(&part_uri, occupied_part_names, occupied_part_prefixes);
            let target_ref = part_uri.relative_ref(state.uri.base_uri());
            planning_edges.try_add_relationship(
                relationship_type.to_owned(),
                target_ref.clone(),
                relationship_id.clone(),
                TargetMode::Internal,
            )?;
            additions.push((
                relationship_type.to_owned(),
                target_ref,
                relationship_id.clone(),
                TargetMode::Internal,
            ));
            let blip = picture.blip_range();
            let extension_prefix = picture
                .ext_list_range()
                .map_or(blip.prefix(), ElementRange::prefix);
            let extension_len =
                generated_extension_size(blip.prefix(), &relationship_id, scanned.dialect());
            let (parent, parent_local, fragment_len) =
                if let Some(ext_list) = picture.ext_list_range() {
                    (
                        ext_list.range().start..ext_list.start_end(),
                        "extLst",
                        extension_len,
                    )
                } else {
                    (
                        blip.range().start..blip.start_end(),
                        "blip",
                        generated_ext_list_size(extension_prefix, extension_len, scanned.dialect()),
                    )
                };
            attachments.push(MixedAttachOperation {
                intent_index: *index,
                relationship_id,
                part_uri: part_uri.clone(),
                parent: parent.clone(),
                parent_empty: if let Some(ext_list) = picture.ext_list_range() {
                    ext_list.is_empty()
                } else {
                    blip.is_empty()
                },
                parent_name_len: element_name_len(
                    if let Some(ext_list) = picture.ext_list_range() {
                        ext_list.prefix()
                    } else {
                        blip.prefix()
                    },
                    parent_local,
                ),
                fragment_len,
            });
            new_uris.push(part_uri);
        } else {
            let owner = match picture.svg_owner() {
                SvgOwnerState::Embedded(owner) => owner,
                SvgOwnerState::None | SvgOwnerState::Opaque => {
                    return Err(invalid("selected picture has no admitted SVG owner"));
                },
                SvgOwnerState::Linked(_) => {
                    return Err(invalid("linked SVG owners cannot be detached"));
                },
                SvgOwnerState::Ambiguous | SvgOwnerState::Refused => {
                    return Err(invalid(
                        "selected picture has an ambiguous or refused SVG owner",
                    ));
                },
            };
            let relationship_id = owner
                .embedded_relationship_id()
                .ok_or_else(|| invalid("embedded SVG owner has no relationship ID"))?;
            // Detach references the source owner captured by the scanner.  An
            // earlier attach in this same mixed batch may reuse the freed ID,
            // so resolving through the evolving edge map could bind the
            // detach to the new target instead of the source relationship.
            let relationship = state
                .current_edges
                .get(relationship_id)
                .cloned()
                .ok_or_else(|| invalid("embedded SVG relationship is missing"))?;
            let target = relationship.target_partname()?;
            validate_svg_target_candidate(workbook, &relationship, &target, pending_parts)?;
            let (opening, removed) = detach_ranges(state.before_xml.bytes(), picture, owner)?;
            detach_operations.push(DetachOperation {
                relationship_id: relationship_id.to_owned(),
                target,
                opening,
                removed,
                owner_range: owner.extension_range(),
                ext_list: picture
                    .ext_list_range()
                    .map(|range| (range.range(), range.start_end())),
            });
            planning_edges.remove(relationship_id);
        }
    }

    let mut xml_removals = Vec::new();
    xml_removals
        .try_reserve(detach_operations.len())
        .map_err(|source| allocation("SVG lifecycle mixed XML ranges", source))?;
    for operation in &detach_operations {
        xml_removals.push(XmlRemoval {
            opening: operation.opening.clone(),
            removed: operation.removed,
        });
    }
    let mut ext_lists = Vec::new();
    ext_lists
        .try_reserve(detach_operations.len())
        .map_err(|source| allocation("SVG lifecycle mixed extension lists", source))?;
    for operation in &detach_operations {
        let Some((range, start_end)) = operation.ext_list else {
            continue;
        };
        if let Some(existing) = ext_lists
            .iter_mut()
            .find(|candidate: &&mut ExtListRemoval| candidate.range == range)
        {
            existing
                .owner_ranges
                .try_reserve(1)
                .map_err(|source| allocation("SVG lifecycle mixed extension owners", source))?;
            existing.owner_ranges.push(operation.owner_range);
        } else {
            let mut owner_ranges = Vec::new();
            owner_ranges
                .try_reserve(1)
                .map_err(|source| allocation("SVG lifecycle mixed extension owners", source))?;
            owner_ranges.push(operation.owner_range);
            ext_lists.push(ExtListRemoval {
                range,
                start_end,
                owner_ranges,
            });
        }
    }
    for ext_list in &ext_lists {
        if !ext_list_contains_only_owner_ranges(
            state.before_xml.bytes(),
            ext_list.range,
            &ext_list.owner_ranges,
        )? {
            continue;
        }
        xml_removals.retain(|removal| {
            removal.removed != ext_list.range
                && !ext_list.owner_ranges.iter().any(|owner| {
                    owner.start == removal.removed.start && owner.end == removal.removed.end
                })
        });
        xml_removals.push(XmlRemoval {
            opening: ext_list.range.start..ext_list.start_end,
            removed: ext_list.range,
        });
    }

    let references = scanned.relationship_references();
    let mut removed_relationships = Vec::new();
    removed_relationships
        .try_reserve(detach_operations.len())
        .map_err(|source| allocation("SVG lifecycle mixed relationship IDs", source))?;
    let mut removed_ranges: Vec<_> = xml_removals.iter().map(|removal| removal.removed).collect();
    removed_ranges.sort_by_key(|range| range.start);
    let mut remaining_references = HashMap::<&str, usize>::new();
    remaining_references
        .try_reserve(references.len())
        .map_err(|source| {
            allocation("SVG lifecycle mixed relationship reference census", source)
        })?;
    let mut removed_range_index = 0usize;
    for reference in references {
        while removed_range_index < removed_ranges.len()
            && removed_ranges[removed_range_index].end <= reference.range().start
        {
            removed_range_index += 1;
        }
        let removed = removed_range_index < removed_ranges.len()
            && ranges_overlap(reference.range(), removed_ranges[removed_range_index]);
        if !removed {
            let entry = remaining_references.entry(reference.id()).or_insert(0);
            *entry = entry
                .checked_add(1)
                .ok_or_else(|| invalid("SVG lifecycle relationship reference count overflow"))?;
        }
    }
    for operation in &detach_operations {
        let remaining = remaining_references
            .get(operation.relationship_id.as_str())
            .copied()
            .unwrap_or(0);
        let final_relationship = planning_edges.get(&operation.relationship_id);
        let source_relationship = state.current_edges.get(&operation.relationship_id);
        let relationship_replaced = final_relationship.is_some()
            && source_relationship.is_some()
            && !same_relationship_option(source_relationship, final_relationship);
        if remaining != 0 && relationship_replaced {
            return Err(invalid(
                "SVG relationship ID is still referenced by opaque drawing XML",
            ));
        }
        if remaining == 0
            && (final_relationship.is_none() || relationship_replaced)
            && !removed_relationships
                .iter()
                .any(|relationship_id: &String| relationship_id == &operation.relationship_id)
        {
            removed_relationships.push(operation.relationship_id.clone());
            if !cleanup_targets
                .iter()
                .any(|candidate| candidate.is_equivalent_to(&operation.target))
            {
                cleanup_targets.push(operation.target.clone());
            }
        }
    }

    let mut relationship_refs = Vec::new();
    relationship_refs
        .try_reserve(additions.len())
        .map_err(|source| allocation("SVG lifecycle mixed relationship references", source))?;
    relationship_refs.extend(additions.iter().map(|(reltype, target, id, mode)| {
        (reltype.as_str(), target.as_str(), id.as_str(), *mode)
    }));
    let mut next_rels = if removed_relationships.is_empty() {
        state.current_rels.clone()
    } else {
        let ids: Vec<&str> = removed_relationships.iter().map(String::as_str).collect();
        state
            .current_rels
            .without_relationships(&ids, relationship_cap)?
    };
    if !relationship_refs.is_empty() {
        next_rels = next_rels.with_relationships(&relationship_refs, relationship_cap)?;
    }

    let mut append_targets = Vec::new();
    append_targets
        .try_reserve(attachments.len())
        .map_err(|source| allocation("SVG lifecycle mixed XML updates", source))?;
    for (fragment_index, operation) in attachments.iter().enumerate() {
        append_targets.push(XmlAppendTarget {
            range: operation.parent.clone(),
            parent_empty: operation.parent_empty,
            parent_name_len: operation.parent_name_len,
            fragment_index,
        });
    }
    let mut output_size = state.before_xml.bytes().len();
    for removal in &xml_removals {
        output_size = output_size
            .checked_sub(removal.removed.len()?)
            .ok_or_else(|| invalid("SVG lifecycle mixed XML ranges overlap"))?;
    }
    let mut expanded_parents: Vec<std::ops::Range<usize>> = Vec::new();
    expanded_parents
        .try_reserve(append_targets.len())
        .map_err(|source| allocation("SVG lifecycle mixed XML parents", source))?;
    for target in &append_targets {
        output_size = output_size
            .checked_add(attachments[target.fragment_index].fragment_len)
            .ok_or_else(|| invalid("SVG lifecycle mixed XML output size overflow"))?;
        if target.parent_empty && !expanded_parents.contains(&target.range) {
            output_size = output_size
                .checked_add(target.parent_name_len.saturating_mul(2).saturating_add(5))
                .ok_or_else(|| invalid("SVG lifecycle mixed XML output size overflow"))?;
            expanded_parents.push(target.range.clone());
        }
    }
    if output_size > output_cap {
        return Err(invalid(format!(
            "SVG lifecycle drawing output exceeds {} bytes",
            output_cap
        )));
    }
    let mut fragments = Vec::new();
    fragments
        .try_reserve(attachments.len())
        .map_err(|source| allocation("SVG lifecycle mixed fragments", source))?;
    pending_parts
        .try_reserve(attachments.len())
        .map_err(|source| allocation("SVG lifecycle mixed media", source))?;
    for operation in &attachments {
        let intent = intents
            .get(operation.intent_index)
            .ok_or_else(|| invalid("SVG lifecycle intent disappeared"))?;
        let picture = scanned.picture(selector_picture(intent.selector))?;
        let blip = picture.blip_range();
        let extension =
            generated_extension(blip.prefix(), &operation.relationship_id, scanned.dialect())?;
        let fragment = if picture.ext_list_range().is_some() {
            extension
        } else {
            generated_ext_list(
                picture
                    .ext_list_range()
                    .map_or(blip.prefix(), ElementRange::prefix),
                &extension,
                scanned.dialect(),
            )?
        };
        if fragment.len() != operation.fragment_len {
            return Err(invalid("SVG lifecycle extension length preflight mismatch"));
        }
        fragments.push(fragment);
        pending_parts.push(SvgPartChange {
            action: GraphAction::Add,
            part: Box::new(BlobPart::new_shared(
                operation.part_uri.clone(),
                "image/svg+xml".to_owned(),
                Arc::clone(
                    intent
                        .payload
                        .as_ref()
                        .ok_or_else(|| invalid("attach_svg has no staged payload"))?,
                ),
            )),
        });
    }
    let mut updates = Vec::new();
    updates
        .try_reserve(xml_removals.len().saturating_add(append_targets.len()))
        .map_err(|source| allocation("SVG lifecycle mixed XML updates", source))?;
    for removal in &xml_removals {
        updates.push(OwnedElementUpdate {
            start_tag: removal.opening.clone(),
            edit: OwnedElementEdit::Remove,
        });
    }
    for target in &append_targets {
        updates.push(OwnedElementUpdate {
            start_tag: target.range.clone(),
            edit: OwnedElementEdit::AppendChild(&fragments[target.fragment_index]),
        });
    }
    updates.sort_by(|left, right| {
        left.start_tag
            .start
            .cmp(&right.start_tag.start)
            .then(left.start_tag.end.cmp(&right.start_tag.end))
    });
    for pair in updates.windows(2) {
        if pair[0].start_tag.end > pair[1].start_tag.start {
            return Err(invalid("SVG lifecycle mixed XML ranges overlap"));
        }
    }
    state.current_xml = state.before_xml.update_elements(&updates, output_cap)?;
    state.current_rels = next_rels;
    state.current_edges = planning_edges;
    if !new_uris.is_empty() {
        *manifest = manifest_add_tokens(
            manifest,
            &new_uris,
            content_types_cap,
            content_type_mapping_cap,
        )?;
    }
    Ok(())
}

fn plan_composed_intent(
    workbook: &Workbook,
    intent: &SvgLifecycleIntent,
    state: &mut DrawingPlanState,
    pending_parts: &mut Vec<SvgPartChange>,
    reserved_uris: &mut HashSet<PackURI>,
    occupied_part_names: &mut HashSet<String>,
    occupied_part_prefixes: &mut HashSet<String>,
    next_part_index: &mut usize,
    manifest: &mut OwnedContentTypes,
    cleanup_targets: &mut Vec<PackURI>,
) -> Result<()> {
    let limits = scan_limits(workbook);
    let output_cap = output_limit(workbook);
    let relationship_cap = relationship_output_limit(workbook);
    let content_types_cap = content_types_output_limit(workbook);
    let content_type_mapping_cap = workbook
        .inner
        .package
        .read_limits()
        .max_content_type_mappings();
    let scanned = SourceDrawing::scan_with_limits(
        state.current_xml.bytes(),
        selector_drawing(intent.selector),
        limits,
    )?;
    let picture = scanned.picture(selector_picture(intent.selector))?;
    validate_raster_fallback_edges(workbook, &state.current_edges, picture)?;

    if intent.attach {
        let payload = intent
            .payload
            .as_deref()
            .ok_or_else(|| invalid("attach_svg has no staged payload"))?;
        if payload.len() > output_cap {
            return Err(invalid(format!(
                "SVG lifecycle payload exceeds {} bytes",
                output_cap
            )));
        }
        match picture.svg_owner() {
            SvgOwnerState::None | SvgOwnerState::Opaque => {},
            SvgOwnerState::Embedded(_) => {
                return Err(invalid(
                    "selected picture already has an embedded SVG owner",
                ));
            },
            SvgOwnerState::Linked(_) => {
                return Err(invalid(
                    "linked SVG owners cannot be replaced by attach_svg",
                ));
            },
            SvgOwnerState::Ambiguous | SvgOwnerState::Refused => {
                return Err(invalid(
                    "selected picture has an ambiguous or refused SVG owner",
                ));
            },
        }
        let relationship_id = allocate_relationship_id(&state.current_edges)?;
        let part_uri = allocate_part_uri_with_reservations(
            reserved_uris,
            occupied_part_names,
            occupied_part_prefixes,
            next_part_index,
        )?;
        reserved_uris.insert(part_uri.clone());
        index_part_name(&part_uri, occupied_part_names, occupied_part_prefixes);
        let target_ref = part_uri.relative_ref(state.uri.base_uri());
        let relationship_type =
            if scanned.relationship_dialect() == source::RelationshipDialect::Strict {
                rt::STRICT_IMAGE
            } else {
                rt::IMAGE
            };
        let next_rels = state.current_rels.with_relationship(
            relationship_type,
            &target_ref,
            &relationship_id,
            TargetMode::Internal,
            relationship_cap,
        )?;
        let next_xml = attach_xml(
            &state.current_xml,
            picture,
            &relationship_id,
            scanned.dialect(),
            output_cap,
        )?;
        let relationship = Relationship::new_with_mode(
            relationship_id.clone(),
            relationship_type.to_owned(),
            target_ref,
            state.uri.base_uri().to_owned(),
            TargetMode::Internal,
        );
        if state.current_edges.len()
            >= workbook
                .inner
                .package
                .read_limits()
                .max_relationships_per_part()
        {
            return Err(invalid("SVG relationship count exceeds caller limit"));
        }
        state.current_edges.try_add_relationship(
            relationship.reltype().to_owned(),
            relationship.target_ref().to_owned(),
            relationship.r_id().to_owned(),
            relationship.target_mode(),
        )?;
        state.current_rels = next_rels;
        state.current_xml = next_xml;
        pending_parts.push(SvgPartChange {
            action: GraphAction::Add,
            part: Box::new(BlobPart::new_shared(
                part_uri.clone(),
                "image/svg+xml".to_owned(),
                Arc::clone(
                    intent
                        .payload
                        .as_ref()
                        .ok_or_else(|| invalid("attach_svg has no staged payload"))?,
                ),
            )),
        });
        *manifest = manifest_add_token(
            manifest,
            &part_uri,
            content_types_cap,
            content_type_mapping_cap,
        )?;
    } else {
        let owner = match picture.svg_owner() {
            SvgOwnerState::Embedded(owner) => owner,
            SvgOwnerState::None | SvgOwnerState::Opaque => return Ok(()),
            SvgOwnerState::Linked(_) => {
                return Err(invalid("linked SVG owners cannot be detached"));
            },
            SvgOwnerState::Ambiguous | SvgOwnerState::Refused => {
                return Err(invalid(
                    "selected picture has an ambiguous or refused SVG owner",
                ));
            },
        };
        let relationship_id = owner
            .embedded_relationship_id()
            .ok_or_else(|| invalid("embedded SVG owner has no relationship ID"))?;
        let relationship = state
            .current_edges
            .get(relationship_id)
            .cloned()
            .ok_or_else(|| invalid("embedded SVG relationship is missing"))?;
        let target = relationship.target_partname()?;
        validate_svg_target_candidate(workbook, &relationship, &target, pending_parts)?;
        let (after_xml, removed_range) = detach_xml(&state.current_xml, picture, owner)?;
        let remaining = scanned
            .relationship_references()
            .iter()
            .filter(|reference| {
                reference.id() == relationship_id
                    && !ranges_overlap(reference.range(), removed_range)
            })
            .count();
        let remove_edge = remaining == 0;
        if remove_edge {
            state.current_rels = state
                .current_rels
                .without_relationship(relationship_id, relationship_cap)?;
            state.current_edges.remove(relationship_id);
            if !cleanup_targets
                .iter()
                .any(|candidate| candidate.is_equivalent_to(&target))
            {
                cleanup_targets.push(target);
            }
        }
        state.current_xml = after_xml;
    }
    if state.current_xml.bytes().len() > output_cap {
        return Err(invalid(format!(
            "SVG lifecycle drawing output exceeds {} bytes",
            output_cap
        )));
    }
    Ok(())
}

/// Plan the common attach-only batch in one source scan and one XML/
/// relationship allocation.  Detach and repeated-selector sequences retain
/// the sequential path below because their source ranges can be created or
/// removed by an earlier operation in the same transaction.
fn plan_composed_attach_batch(
    workbook: &Workbook,
    group: &[usize],
    intents: &[SvgLifecycleIntent],
    state: &mut DrawingPlanState,
    pending_parts: &mut Vec<SvgPartChange>,
    reserved_uris: &mut HashSet<PackURI>,
    occupied_part_names: &mut HashSet<String>,
    occupied_part_prefixes: &mut HashSet<String>,
    next_part_index: &mut usize,
    manifest: &mut OwnedContentTypes,
) -> Result<()> {
    let limits = scan_limits(workbook);
    let output_cap = output_limit(workbook);
    let relationship_cap = relationship_output_limit(workbook);
    let content_types_cap = content_types_output_limit(workbook);
    let content_type_mapping_cap = workbook
        .inner
        .package
        .read_limits()
        .max_content_type_mappings();
    let first_intent = intents
        .get(
            *group
                .first()
                .ok_or_else(|| invalid("empty SVG lifecycle group"))?,
        )
        .ok_or_else(|| invalid("SVG lifecycle intent disappeared"))?;
    let scanned = SourceDrawing::scan_with_limits(
        state.before_xml.bytes(),
        selector_drawing(first_intent.selector),
        limits,
    )?;
    let relationship_type = if scanned.relationship_dialect() == source::RelationshipDialect::Strict
    {
        rt::STRICT_IMAGE
    } else {
        rt::IMAGE
    };
    let mut additions: Vec<(String, String, String, TargetMode)> = Vec::new();
    additions
        .try_reserve(group.len())
        .map_err(|source| allocation("SVG lifecycle relationship batch", source))?;
    let mut append_targets = Vec::new();
    append_targets
        .try_reserve(group.len())
        .map_err(|source| allocation("SVG lifecycle XML update batch", source))?;
    let mut fragment_lengths = Vec::new();
    fragment_lengths
        .try_reserve(group.len())
        .map_err(|source| allocation("SVG lifecycle extension lengths", source))?;
    let mut new_uris = Vec::new();
    new_uris
        .try_reserve(group.len())
        .map_err(|source| allocation("SVG lifecycle media batch", source))?;

    for index in group {
        let intent = intents
            .get(*index)
            .ok_or_else(|| invalid("SVG lifecycle intent disappeared"))?;
        let payload = intent
            .payload
            .as_deref()
            .ok_or_else(|| invalid("attach_svg has no staged payload"))?;
        if payload.len() > output_cap {
            return Err(invalid(format!(
                "SVG lifecycle payload exceeds {} bytes",
                output_cap
            )));
        }
        let picture = scanned.picture(selector_picture(intent.selector))?;
        validate_raster_fallback_edges(workbook, &state.current_edges, picture)?;
        match picture.svg_owner() {
            SvgOwnerState::None | SvgOwnerState::Opaque => {},
            SvgOwnerState::Embedded(_) => {
                return Err(invalid(
                    "selected picture already has an embedded SVG owner",
                ));
            },
            SvgOwnerState::Linked(_) => {
                return Err(invalid(
                    "linked SVG owners cannot be replaced by attach_svg",
                ));
            },
            SvgOwnerState::Ambiguous | SvgOwnerState::Refused => {
                return Err(invalid(
                    "selected picture has an ambiguous or refused SVG owner",
                ));
            },
        }
        let relationship_id = allocate_relationship_id(&state.current_edges)?;
        let part_uri = allocate_part_uri_with_reservations(
            reserved_uris,
            occupied_part_names,
            occupied_part_prefixes,
            next_part_index,
        )?;
        reserved_uris.insert(part_uri.clone());
        index_part_name(&part_uri, occupied_part_names, occupied_part_prefixes);
        let target_ref = part_uri.relative_ref(state.uri.base_uri());
        let next_edges_len = state
            .current_edges
            .len()
            .checked_add(1)
            .ok_or_else(|| invalid("SVG relationship count overflows"))?;
        let maximum_relationships = workbook
            .inner
            .package
            .read_limits()
            .max_relationships_per_part();
        if next_edges_len > maximum_relationships {
            return Err(invalid("SVG relationship count exceeds caller limit"));
        }
        state.current_edges.try_add_relationship(
            relationship_type.to_owned(),
            target_ref.clone(),
            relationship_id.clone(),
            TargetMode::Internal,
        )?;
        additions.push((
            relationship_type.to_owned(),
            target_ref,
            relationship_id.clone(),
            TargetMode::Internal,
        ));

        let blip = picture.blip_range();
        let extension_prefix = picture
            .ext_list_range()
            .map_or(blip.prefix(), ElementRange::prefix);
        let (parent, parent_local, fragment) = if let Some(ext_list) = picture.ext_list_range() {
            (
                ext_list,
                "extLst",
                generated_extension_size(blip.prefix(), &relationship_id, scanned.dialect()),
            )
        } else {
            let extension_size =
                generated_extension_size(blip.prefix(), &relationship_id, scanned.dialect());
            (
                blip,
                "blip",
                generated_ext_list_size(extension_prefix, extension_size, scanned.dialect()),
            )
        };
        fragment_lengths.push(fragment);
        append_targets.push(XmlAppendTarget {
            range: parent.range().start..parent.start_end(),
            parent_empty: parent.is_empty(),
            parent_name_len: element_name_len(parent.prefix(), parent_local),
            fragment_index: fragment_lengths.len() - 1,
        });
        new_uris.push(part_uri.clone());
    }

    let mut relationship_refs = Vec::new();
    relationship_refs
        .try_reserve(additions.len())
        .map_err(|source| allocation("SVG lifecycle relationship references", source))?;
    relationship_refs.extend(additions.iter().map(|(reltype, target, id, mode)| {
        (reltype.as_str(), target.as_str(), id.as_str(), *mode)
    }));
    let next_rels = state
        .current_rels
        .with_relationships(&relationship_refs, relationship_cap)?;

    append_targets.sort_by(|left, right| {
        left.range
            .start
            .cmp(&right.range.start)
            .then(left.range.end.cmp(&right.range.end))
            .then(left.fragment_index.cmp(&right.fragment_index))
    });
    let mut output_size = state.before_xml.bytes().len();
    let mut expanded_parents: Vec<std::ops::Range<usize>> = Vec::new();
    expanded_parents
        .try_reserve(append_targets.len())
        .map_err(|source| allocation("SVG lifecycle empty XML parents", source))?;
    for target in &append_targets {
        output_size = output_size
            .checked_add(fragment_lengths[target.fragment_index])
            .ok_or_else(|| invalid("SVG lifecycle drawing output size overflow"))?;
        if target.parent_empty && !expanded_parents.contains(&target.range) {
            output_size = output_size
                .checked_add(target.parent_name_len.saturating_add(4))
                .ok_or_else(|| invalid("SVG lifecycle drawing output size overflow"))?;
            expanded_parents.push(target.range.clone());
        }
    }
    if output_size > output_cap {
        return Err(invalid(format!(
            "SVG lifecycle drawing output exceeds {} bytes",
            output_cap
        )));
    }
    let mut fragments: Vec<Vec<u8>> = Vec::new();
    fragments
        .try_reserve(group.len())
        .map_err(|source| allocation("SVG lifecycle extension batch", source))?;
    pending_parts
        .try_reserve(group.len())
        .map_err(|source| allocation("SVG lifecycle media batch", source))?;
    for (offset, index) in group.iter().enumerate() {
        let intent = intents
            .get(*index)
            .ok_or_else(|| invalid("SVG lifecycle intent disappeared"))?;
        let picture = scanned.picture(selector_picture(intent.selector))?;
        let blip = picture.blip_range();
        let extension =
            generated_extension(blip.prefix(), &additions[offset].2, scanned.dialect())?;
        let fragment = if picture.ext_list_range().is_some() {
            extension
        } else {
            generated_ext_list(
                picture
                    .ext_list_range()
                    .map_or(blip.prefix(), ElementRange::prefix),
                &extension,
                scanned.dialect(),
            )?
        };
        if fragment.len() != fragment_lengths[offset] {
            return Err(invalid("SVG lifecycle extension length preflight mismatch"));
        }
        fragments.push(fragment);
        let part_uri = new_uris
            .get(offset)
            .ok_or_else(|| invalid("SVG lifecycle media URI disappeared"))?;
        pending_parts.push(SvgPartChange {
            action: GraphAction::Add,
            part: Box::new(BlobPart::new_shared(
                part_uri.clone(),
                "image/svg+xml".to_owned(),
                Arc::clone(
                    intent
                        .payload
                        .as_ref()
                        .ok_or_else(|| invalid("attach_svg has no staged payload"))?,
                ),
            )),
        });
    }
    let mut updates = Vec::new();
    updates
        .try_reserve(append_targets.len())
        .map_err(|source| allocation("SVG lifecycle XML updates", source))?;
    for target in &append_targets {
        updates.push(OwnedElementUpdate {
            start_tag: target.range.clone(),
            edit: OwnedElementEdit::AppendChild(&fragments[target.fragment_index]),
        });
    }
    let next_xml = state.before_xml.update_elements(&updates, output_cap)?;
    state.current_rels = next_rels;
    state.current_xml = next_xml;

    *manifest = manifest_add_tokens(
        manifest,
        &new_uris,
        content_types_cap,
        content_type_mapping_cap,
    )?;
    Ok(())
}

struct XmlAppendTarget {
    range: std::ops::Range<usize>,
    parent_empty: bool,
    parent_name_len: usize,
    fragment_index: usize,
}

fn element_name_len(prefix: &[u8], local: &str) -> usize {
    local.len().saturating_add(if prefix.is_empty() {
        0
    } else {
        prefix.len() + 1
    })
}

fn finalize_svg_target_cleanup(
    workbook: &Workbook,
    states: &[DrawingPlanState],
    ordinary_graph: &[super::model::GraphChange],
    relationship_changes: &[RelationshipChange],
    pending_parts: &mut Vec<SvgPartChange>,
    cleanup_targets: &[PackURI],
    manifest: &mut OwnedContentTypes,
    content_types_cap: usize,
) -> Result<()> {
    let incoming = incoming_relationship_targets_with_states(
        workbook,
        cleanup_targets,
        states,
        ordinary_graph,
        relationship_changes,
    )?;
    let mut manifest_removals = Vec::new();
    manifest_removals
        .try_reserve(cleanup_targets.len())
        .map_err(|source| allocation("SVG lifecycle content-type removals", source))?;
    for target in cleanup_targets {
        if incoming.contains(&target.as_str().to_ascii_lowercase()) {
            continue;
        }
        if let Some(index) = pending_parts.iter().position(|change| {
            change.action == GraphAction::Add && change.part.partname().is_equivalent_to(target)
        }) {
            pending_parts.remove(index);
        } else {
            let part = workbook.inner.package.get_part(target)?;
            let part_uri = part.partname().clone();
            pending_parts.push(SvgPartChange {
                action: GraphAction::Remove,
                part: Box::new(BlobPart::new_shared(
                    part_uri.clone(),
                    part.content_type().to_owned(),
                    part.blob_arc(),
                )),
            });
            manifest_removals.push(part_uri);
            continue;
        }
        manifest_removals.push(target.clone());
    }
    if !manifest_removals.is_empty() {
        *manifest = manifest_remove_tokens(manifest, &manifest_removals, content_types_cap)?;
    }
    Ok(())
}

fn changed_relationship_id(
    before: &Relationships,
    after: &Relationships,
) -> Result<Option<String>> {
    let capacity = before
        .len()
        .checked_add(after.len())
        .ok_or_else(|| invalid("relationship ID count overflows"))?;
    let mut ids = Vec::new();
    ids.try_reserve(capacity)
        .map_err(|source| allocation("SVG lifecycle relationship IDs", source))?;
    ids.extend(
        before
            .iter()
            .map(|relationship| relationship.r_id().to_owned()),
    );
    ids.extend(
        after
            .iter()
            .map(|relationship| relationship.r_id().to_owned()),
    );
    ids.sort_unstable();
    ids.dedup();
    Ok(ids
        .into_iter()
        .find(|id| !same_relationship_option(before.get(id), after.get(id))))
}

fn same_relationship_option(before: Option<&Relationship>, after: Option<&Relationship>) -> bool {
    match (before, after) {
        (None, None) => true,
        (Some(before), Some(after)) => {
            before.r_id() == after.r_id()
                && before.reltype() == after.reltype()
                && before.target_ref() == after.target_ref()
                && before.target_mode() == after.target_mode()
        },
        _ => false,
    }
}

fn validate_raster_fallback_edges(
    workbook: &Workbook,
    relationships: &Relationships,
    picture: &source::PictureSource<'_>,
) -> Result<()> {
    let relationship = relationships
        .get(picture.raster_relationship_id())
        .ok_or_else(|| invalid("picture raster relationship is missing"))?;
    if relationship.target_mode() != TargetMode::Internal
        || !matches!(relationship.reltype(), rt::IMAGE | rt::STRICT_IMAGE)
    {
        return Err(invalid(
            "picture raster fallback relationship is unsupported",
        ));
    }
    let target = relationship.target_partname()?;
    if !target.as_str().starts_with("/xl/media/") {
        return Err(invalid("picture raster fallback is outside /xl/media/"));
    }
    let part = workbook.inner.package.get_part(&target)?;
    if part.content_type() != ct::PNG || !part.rels().is_empty() {
        return Err(invalid("picture raster fallback must be an inert PNG part"));
    }
    Ok(())
}

fn validate_svg_target_candidate(
    workbook: &Workbook,
    relationship: &Relationship,
    target: &PackURI,
    pending_parts: &[SvgPartChange],
) -> Result<()> {
    if relationship.target_mode() != TargetMode::Internal
        || !matches!(relationship.reltype(), rt::IMAGE | rt::STRICT_IMAGE)
        || !target.as_str().starts_with("/xl/media/")
    {
        return Err(invalid("SVG relationship target is unsupported"));
    }
    if let Some(part) = pending_parts
        .iter()
        .find(|change| {
            change.action == GraphAction::Add && change.part.partname().is_equivalent_to(target)
        })
        .map(|change| change.part.as_ref())
    {
        if part.content_type() != "image/svg+xml" || !part.rels().is_empty() {
            return Err(invalid("SVG target must be an inert image/svg+xml part"));
        }
        return Ok(());
    }
    validate_svg_target(workbook, relationship, target)
}

fn record_incoming_target(
    workbook: &Workbook,
    target_set: &HashSet<String>,
    incoming: &mut HashSet<String>,
    relationship: &Relationship,
) -> Result<()> {
    if relationship.target_mode() != TargetMode::Internal {
        return Ok(());
    }
    let Ok(target) = relationship.target_partname() else {
        return Ok(());
    };
    let canonical = workbook
        .inner
        .package
        .get_part(&target)
        .map(|part| part.partname().clone())
        .unwrap_or(target);
    let key = canonical.as_str().to_ascii_lowercase();
    if target_set.contains(&key) {
        incoming.insert(key);
    }
    Ok(())
}

fn visit_incoming_relationships(
    workbook: &Workbook,
    target_set: &HashSet<String>,
    incoming: &mut HashSet<String>,
    changed_relationships: &HashMap<String, HashSet<String>>,
    relationship_overrides: &HashMap<String, HashMap<String, Option<Relationship>>>,
    owner: &str,
    relationships: &Relationships,
) -> Result<()> {
    let owner_changes = changed_relationships.get(owner);
    let owner_overrides = relationship_overrides.get(owner);
    for relationship in relationships.iter() {
        if owner_changes.is_some_and(|ids| ids.contains(relationship.r_id())) {
            continue;
        }
        if let Some(overrides) =
            owner_overrides.and_then(|overrides| overrides.get(relationship.r_id()))
        {
            if let Some(replacement) = overrides {
                record_incoming_target(workbook, target_set, incoming, replacement)?;
            }
        } else {
            record_incoming_target(workbook, target_set, incoming, relationship)?;
        }
    }
    Ok(())
}

fn incoming_relationship_targets_with_states(
    workbook: &Workbook,
    targets: &[PackURI],
    states: &[DrawingPlanState],
    ordinary_graph: &[super::model::GraphChange],
    relationship_changes: &[RelationshipChange],
) -> Result<HashSet<String>> {
    let mut target_set = HashSet::new();
    target_set
        .try_reserve(targets.len())
        .map_err(|source| allocation("SVG lifecycle cleanup targets", source))?;
    target_set.extend(
        targets
            .iter()
            .map(|target| target.as_str().to_ascii_lowercase()),
    );
    let mut incoming = HashSet::new();
    incoming
        .try_reserve(targets.len())
        .map_err(|source| allocation("SVG lifecycle incoming targets", source))?;
    let mut changed_relationships: HashMap<String, HashSet<String>> = HashMap::new();
    changed_relationships
        .try_reserve(ordinary_graph.len())
        .map_err(|source| allocation("SVG lifecycle changed relationship index", source))?;
    for change in ordinary_graph {
        if change.action != GraphAction::Remove {
            continue;
        }
        let owner = change.source.as_str().to_ascii_lowercase();
        changed_relationships
            .try_reserve(1)
            .map_err(|source| allocation("SVG lifecycle changed relationship index", source))?;
        let ids = changed_relationships.entry(owner).or_default();
        if ids.is_empty() {
            ids.try_reserve(1)
                .map_err(|source| allocation("SVG lifecycle changed relationship IDs", source))?;
        }
        ids.insert(change.relationship.r_id().to_owned());
    }
    let mut removed_part_owners = HashSet::new();
    removed_part_owners
        .try_reserve(ordinary_graph.len())
        .map_err(|source| allocation("SVG lifecycle removed graph owners", source))?;
    for change in ordinary_graph {
        if change.action == GraphAction::Remove {
            removed_part_owners.insert(change.part.partname().as_str().to_ascii_lowercase());
        }
    }
    let mut state_relationships: HashMap<String, &Relationships> = HashMap::new();
    state_relationships
        .try_reserve(states.len())
        .map_err(|source| allocation("SVG lifecycle drawing relationship index", source))?;
    for state in states {
        state_relationships.insert(
            state.uri.as_str().to_ascii_lowercase(),
            &state.current_edges,
        );
    }
    let mut relationship_overrides: HashMap<String, HashMap<String, Option<Relationship>>> =
        HashMap::new();
    relationship_overrides
        .try_reserve(relationship_changes.len())
        .map_err(|source| allocation("SVG lifecycle relationship transition index", source))?;
    for change in relationship_changes {
        let owner = change.owner.as_str().to_ascii_lowercase();
        relationship_overrides
            .try_reserve(1)
            .map_err(|source| allocation("SVG lifecycle relationship transition index", source))?;
        let overrides = relationship_overrides.entry(owner).or_default();
        overrides
            .try_reserve(1)
            .map_err(|source| allocation("SVG lifecycle relationship transition IDs", source))?;
        let id = change
            .before
            .as_ref()
            .or(change.after.as_ref())
            .map(|relationship| relationship.r_id().to_owned())
            .ok_or_else(|| invalid("SVG relationship transition has no relationship ID"))?;
        overrides.insert(id, change.after.clone());
    }
    visit_incoming_relationships(
        workbook,
        &target_set,
        &mut incoming,
        &changed_relationships,
        &relationship_overrides,
        "/",
        workbook.inner.package.rels(),
    )?;
    for part in workbook.inner.package.iter_parts() {
        let owner = part.partname().as_str().to_ascii_lowercase();
        if removed_part_owners.contains(&owner) {
            continue;
        }
        let relationships = state_relationships
            .get(&owner)
            .copied()
            .unwrap_or_else(|| part.rels());
        visit_incoming_relationships(
            workbook,
            &target_set,
            &mut incoming,
            &changed_relationships,
            &relationship_overrides,
            &owner,
            relationships,
        )?;
    }
    // A relationship transition may add a previously absent ID, and an
    // ordinary graph addition may carry opaque child edges of its new part.
    for change in relationship_changes {
        if let Some(relationship) = &change.after {
            record_incoming_target(workbook, &target_set, &mut incoming, relationship)?;
        }
    }
    for change in ordinary_graph {
        if change.action == GraphAction::Add {
            record_incoming_target(workbook, &target_set, &mut incoming, &change.relationship)?;
            for relationship in change.part.rels().iter() {
                record_incoming_target(workbook, &target_set, &mut incoming, relationship)?;
            }
        }
    }
    Ok(incoming)
}

fn allocate_part_uri_with_reservations(
    reserved: &HashSet<PackURI>,
    occupied_part_names: &HashSet<String>,
    occupied_part_prefixes: &HashSet<String>,
    next_index: &mut usize,
) -> Result<PackURI> {
    let start = *next_index;
    for offset in 0..MAX_ID_ATTEMPTS {
        let index = start
            .checked_add(offset)
            .ok_or_else(|| invalid("generated SVG media Part index overflows"))?;
        let name = if index == 0 {
            "/xl/media/vector.svg".to_owned()
        } else {
            format!("/xl/media/vector{index}.svg")
        };
        let uri = PackURI::new(name).map_err(litchi_opc::OpcError::InvalidPackUri)?;
        if !reserved.contains(&uri)
            && !part_name_conflicts(&uri, occupied_part_names, occupied_part_prefixes)
        {
            *next_index = index
                .checked_add(1)
                .ok_or_else(|| invalid("generated SVG media Part index overflows"))?;
            return Ok(uri);
        }
    }
    Err(invalid(format!(
        "generated SVG media Part candidates exceed {}",
        MAX_ID_ATTEMPTS
    )))
}

fn part_name_conflicts(
    candidate: &PackURI,
    occupied_part_names: &HashSet<String>,
    occupied_part_prefixes: &HashSet<String>,
) -> bool {
    let name = candidate.as_str().to_ascii_lowercase();
    if occupied_part_names.contains(&name) || occupied_part_prefixes.contains(&name) {
        return true;
    }
    let mut prefix = String::new();
    let mut segments = name.split('/').skip(1).peekable();
    while let Some(segment) = segments.next() {
        prefix.push('/');
        prefix.push_str(segment);
        if segments.peek().is_some() && occupied_part_names.contains(&prefix) {
            return true;
        }
    }
    false
}

fn index_part_name(
    part: &PackURI,
    occupied_part_names: &mut HashSet<String>,
    occupied_part_prefixes: &mut HashSet<String>,
) {
    let name = part.as_str().to_ascii_lowercase();
    occupied_part_names.insert(name.clone());
    let mut prefix = String::new();
    let mut segments = name.split('/').skip(1).peekable();
    while let Some(segment) = segments.next() {
        prefix.push('/');
        prefix.push_str(segment);
        if segments.peek().is_some() {
            occupied_part_prefixes.insert(prefix.clone());
        }
    }
}

fn manifest_add_token(
    before: &OwnedContentTypes,
    uri: &PackURI,
    max_output_bytes: usize,
    max_mappings: usize,
) -> Result<OwnedContentTypes> {
    if manifest_covers_svg(before.bytes(), uri)? {
        return Ok(before.clone());
    }
    check_content_type_mapping_growth(before.bytes(), 1, max_mappings)?;
    before
        .with_part_overrides(&[(uri, "image/svg+xml")], max_output_bytes)
        .map_err(Into::into)
}

fn manifest_add_tokens(
    before: &OwnedContentTypes,
    uris: &[PackURI],
    max_output_bytes: usize,
    max_mappings: usize,
) -> Result<OwnedContentTypes> {
    if uris.is_empty() || manifest_has_default_svg(before.bytes())? {
        return Ok(before.clone());
    }
    let mut overrides = Vec::new();
    overrides
        .try_reserve(uris.len())
        .map_err(|source| allocation("SVG lifecycle content-type overrides", source))?;
    for uri in uris {
        if !manifest_has_override(before.bytes(), uri)? {
            overrides.push((uri, "image/svg+xml"));
        }
    }
    if overrides.is_empty() {
        return Ok(before.clone());
    }
    check_content_type_mapping_growth(before.bytes(), overrides.len(), max_mappings)?;
    before
        .with_part_overrides(&overrides, max_output_bytes)
        .map_err(Into::into)
}

fn check_content_type_mapping_growth(bytes: &[u8], additions: usize, maximum: usize) -> Result<()> {
    let mut reader = Reader::from_reader(bytes);
    reader.config_mut().trim_text(false);
    let mut buffer = Vec::new();
    let mut mappings = 0usize;
    loop {
        let event = reader
            .read_event_into(&mut buffer)
            .map_err(|error| invalid(error.to_string()))?;
        if matches!(&event, Event::Start(element) | Event::Empty(element)
            if matches!(element.local_name().as_ref(), b"Default" | b"Override"))
        {
            mappings = mappings
                .checked_add(1)
                .ok_or_else(|| invalid("SVG lifecycle content-type mappings overflow"))?;
        }
        if mappings
            .checked_add(additions)
            .is_none_or(|count| count > maximum)
        {
            return Err(invalid(format!(
                "SVG lifecycle content-type mappings exceed {maximum}"
            )));
        }
        if matches!(event, Event::Eof) {
            return Ok(());
        }
        buffer.clear();
    }
}

fn manifest_remove_tokens(
    before: &OwnedContentTypes,
    uris: &[PackURI],
    max_output_bytes: usize,
) -> Result<OwnedContentTypes> {
    if uris.is_empty() {
        return Ok(before.clone());
    }
    let mut removals = Vec::new();
    removals
        .try_reserve(uris.len())
        .map_err(|source| allocation("SVG lifecycle content-type targets", source))?;
    removals.extend(uris.iter().cloned());
    before
        .without_parts(&removals, max_output_bytes)
        .map_err(Into::into)
}

fn relationship_xml_event_count(bytes: &[u8], maximum: usize) -> Result<usize> {
    let mut reader = Reader::from_reader(bytes);
    let mut buffer = Vec::new();
    let mut count = 0usize;
    loop {
        count = count
            .checked_add(1)
            .ok_or_else(|| invalid("SVG lifecycle relationship XML event count overflow"))?;
        if count > maximum {
            return Err(invalid(format!(
                "SVG lifecycle relationship XML events exceed {maximum}"
            )));
        }
        let event = reader
            .read_event_into(&mut buffer)
            .map_err(|error| invalid(error.to_string()))?;
        if matches!(event, Event::Eof) {
            return Ok(count);
        }
        buffer.clear();
    }
}

fn resolve_drawing(
    workbook: &Workbook,
    position: usize,
    selector: PictureSelector,
) -> Result<(PackURI, Relationship)> {
    let sheet = workbook
        .inner
        .sheets
        .get(position)
        .ok_or_else(|| invalid("worksheet selector disappeared during SVG planning"))?;
    let worksheet = workbook.inner.package.get_part(&sheet.part_uri)?;
    let references = worksheet_drawing_references(workbook, worksheet.blob())?;
    let relationship_id = references
        .get(selector_drawing(selector))
        .ok_or_else(|| invalid("drawing ordinal is outside worksheet drawings"))?;
    let relationship = worksheet
        .rels()
        .get(relationship_id)
        .cloned()
        .ok_or_else(|| invalid("worksheet drawing reference has no package relationship"))?;
    if !matches!(relationship.reltype(), rt::DRAWING | rt::STRICT_DRAWING) {
        return Err(invalid(
            "worksheet drawing reference has a non-drawing relationship type",
        ));
    }
    if relationship.target_mode() != TargetMode::Internal {
        return Err(invalid("worksheet drawing relationship is external"));
    }
    let target = relationship.target_partname()?;
    let drawing = workbook.inner.package.get_part(&target)?;
    if drawing.content_type() != ct::OFC_DRAWING {
        return Err(invalid(format!(
            "worksheet drawing part has content type '{}', expected '{}'",
            drawing.content_type(),
            ct::OFC_DRAWING
        )));
    }
    Ok((target, relationship))
}

fn worksheet_drawing_references(workbook: &Workbook, source: &[u8]) -> Result<Vec<String>> {
    let limits = crate::drawing::worksheet_source::WorksheetSourceLimits::from_read_limits(
        workbook.inner.package.read_limits(),
    );
    crate::drawing::worksheet_source::scan_worksheet_drawing_references(source, limits)
}

fn validate_raster_fallback_id(
    workbook: &Workbook,
    drawing_part: &dyn Part,
    relationship_id: &str,
) -> Result<()> {
    let relationship = drawing_part
        .rels()
        .get(relationship_id)
        .ok_or_else(|| invalid("picture raster relationship is missing"))?;
    if relationship.target_mode() != TargetMode::Internal
        || !matches!(relationship.reltype(), rt::IMAGE | rt::STRICT_IMAGE)
    {
        return Err(invalid(
            "picture raster fallback relationship is unsupported",
        ));
    }
    let target = relationship.target_partname()?;
    if !target.as_str().starts_with("/xl/media/") {
        return Err(invalid("picture raster fallback is outside /xl/media/"));
    }
    let part = workbook.inner.package.get_part(&target)?;
    if part.content_type() != ct::PNG || !part.rels().is_empty() {
        return Err(invalid("picture raster fallback must be an inert PNG part"));
    }
    Ok(())
}

fn validate_svg_target(
    workbook: &Workbook,
    relationship: &Relationship,
    target: &PackURI,
) -> Result<()> {
    if relationship.target_mode() != TargetMode::Internal
        || !matches!(relationship.reltype(), rt::IMAGE | rt::STRICT_IMAGE)
        || !target.as_str().starts_with("/xl/media/")
    {
        return Err(invalid("SVG relationship target is unsupported"));
    }
    let part = workbook.inner.package.get_part(target)?;
    if part.content_type() != "image/svg+xml" || !part.rels().is_empty() {
        return Err(invalid("SVG target must be an inert image/svg+xml part"));
    }
    Ok(())
}

fn attach_xml(
    before: &OwnedXmlPart,
    picture: &source::PictureSource<'_>,
    relationship_id: &str,
    drawing_dialect: source::DrawingDialect,
    max_output_bytes: usize,
) -> Result<OwnedXmlPart> {
    let blip = picture.blip_range();
    let drawing_prefix = blip.prefix();
    let extension_prefix = picture
        .ext_list_range()
        .map_or(drawing_prefix, ElementRange::prefix);
    let extension_len = generated_extension_size(drawing_prefix, relationship_id, drawing_dialect);
    let replacement = if let Some(ext_list) = picture.ext_list_range() {
        let output_len = before
            .bytes()
            .len()
            .checked_add(extension_len)
            .ok_or_else(|| invalid("SVG lifecycle drawing output size overflow"))?;
        if output_len > max_output_bytes {
            return Err(invalid("SVG lifecycle drawing output exceeds caller limit"));
        }
        let extension = generated_extension(drawing_prefix, relationship_id, drawing_dialect)?;
        before.append_element(ext_list.range().start..ext_list.start_end(), &extension)?
    } else {
        let name_len = if extension_prefix.is_empty() {
            "extLst".len()
        } else {
            extension_prefix.len().saturating_add(7)
        };
        let binding_len = if extension_prefix.is_empty() {
            0
        } else {
            10usize
                .saturating_add(extension_prefix.len())
                .saturating_add(drawing_namespace(drawing_dialect).len())
        };
        let growth = extension_len
            .saturating_add(name_len.saturating_mul(2).saturating_add(5))
            .saturating_add(binding_len);
        let output_len = before
            .bytes()
            .len()
            .checked_add(growth)
            .ok_or_else(|| invalid("SVG lifecycle drawing output size overflow"))?;
        if output_len > max_output_bytes {
            return Err(invalid("SVG lifecycle drawing output exceeds caller limit"));
        }
        let extension = generated_extension(drawing_prefix, relationship_id, drawing_dialect)?;
        let list = generated_ext_list(extension_prefix, &extension, drawing_dialect)?;
        before.append_element(blip.range().start..blip.start_end(), &list)?
    };
    Ok(replacement)
}

fn detach_xml(
    before: &OwnedXmlPart,
    picture: &source::PictureSource<'_>,
    owner: &source::SvgOwner<'_>,
) -> Result<(OwnedXmlPart, source::ByteRange)> {
    let (opening, removed) = detach_ranges(before.bytes(), picture, owner)?;
    Ok((before.remove_element(opening)?, removed))
}

fn detach_ranges(
    source: &[u8],
    picture: &source::PictureSource<'_>,
    owner: &source::SvgOwner<'_>,
) -> Result<(std::ops::Range<usize>, source::ByteRange)> {
    if let Some(ext_list) = picture.ext_list_range() {
        if ext_list_contains_only_owner(source, ext_list, owner)? {
            return Ok((
                ext_list.range().start..ext_list.start_end(),
                ext_list.range(),
            ));
        }
    }
    let extension = owner.extension_range();
    let opening = opening_tag_range(source, extension)?;
    Ok((opening, extension))
}

fn ranges_overlap(left: source::ByteRange, right: source::ByteRange) -> bool {
    left.start < right.end && right.start < left.end
}

fn opening_tag_range(source: &[u8], element: source::ByteRange) -> Result<std::ops::Range<usize>> {
    let bytes = element.slice(source)?;
    let mut reader = Reader::from_reader(bytes);
    let mut buffer = Vec::new();
    let start = reader.buffer_position() as usize;
    let event = reader
        .read_event_into(&mut buffer)
        .map_err(|error| invalid(error.to_string()))?;
    let end = reader.buffer_position() as usize;
    if !matches!(event, Event::Start(_) | Event::Empty(_)) || end <= start {
        return Err(invalid("SVG owner extension has no complete opening tag"));
    }
    Ok(element.start + start..element.start + end)
}

fn ext_list_contains_only_owner(
    source: &[u8],
    ext_list: &ElementRange,
    owner: &source::SvgOwner<'_>,
) -> Result<bool> {
    let bytes = ext_list.range().slice(source)?;
    let selected = owner.extension_range();
    let mut reader = Reader::from_reader(bytes);
    reader.config_mut().trim_text(false);
    reader.config_mut().check_end_names = true;
    let mut depth = 0usize;
    let mut child_count = 0usize;
    let mut child_start = None;
    let mut child_end = None;
    let mut buffer = Vec::new();
    loop {
        let start = reader.buffer_position() as usize;
        let event = reader
            .read_event_into(&mut buffer)
            .map_err(|error| invalid(error.to_string()))?;
        let end = reader.buffer_position() as usize;
        match event {
            Event::Start(element) => {
                if depth == 0 && element.attributes().next().is_some() {
                    return Ok(false);
                }
                if depth == 1 {
                    if child_count != 0 {
                        return Ok(false);
                    }
                    let absolute = ext_list.range().start.saturating_add(start);
                    if absolute != selected.start {
                        return Ok(false);
                    }
                    child_start = Some(absolute);
                    child_count = child_count.saturating_add(1);
                }
                depth = depth.saturating_add(1);
            },
            Event::Empty(element) => {
                if depth == 0 && element.attributes().next().is_some() {
                    return Ok(false);
                }
                if depth == 1 {
                    let absolute = ext_list.range().start.saturating_add(start)
                        ..ext_list.range().start.saturating_add(end);
                    if child_count != 0 || absolute != (selected.start..selected.end) {
                        return Ok(false);
                    }
                    child_start = Some(absolute.start);
                    child_end = Some(absolute.end);
                    child_count = child_count.saturating_add(1);
                }
            },
            Event::End(_) => {
                if depth == 2 {
                    child_end = Some(ext_list.range().start.saturating_add(end));
                }
                depth = depth.saturating_sub(1);
            },
            Event::Comment(_) | Event::PI(_) | Event::CData(_) if depth == 1 => {
                return Ok(false);
            },
            Event::GeneralRef(_) if depth == 1 => return Ok(false),
            Event::Text(text)
                if depth == 1 && !text.as_ref().iter().all(u8::is_ascii_whitespace) =>
            {
                return Ok(false);
            },
            Event::Eof => break,
            _ => {},
        }
        buffer.clear();
    }
    Ok(child_count == 1 && child_start == Some(selected.start) && child_end == Some(selected.end))
}

fn ext_list_contains_only_owner_ranges(
    source: &[u8],
    ext_list: source::ByteRange,
    selected: &[source::ByteRange],
) -> Result<bool> {
    let bytes = ext_list.slice(source)?;
    let mut reader = Reader::from_reader(bytes);
    reader.config_mut().trim_text(false);
    reader.config_mut().check_end_names = true;
    let mut depth = 0usize;
    let mut child_start = None;
    let mut children = Vec::new();
    children
        .try_reserve(selected.len())
        .map_err(|source| allocation("SVG lifecycle extension children", source))?;
    let mut buffer = Vec::new();
    loop {
        let start = reader.buffer_position() as usize;
        let event = reader
            .read_event_into(&mut buffer)
            .map_err(|error| invalid(error.to_string()))?;
        let end = reader.buffer_position() as usize;
        match event {
            Event::Start(element) => {
                if depth == 0 && element.attributes().next().is_some() {
                    return Ok(false);
                }
                if depth == 1 {
                    if child_start.is_some() {
                        return Ok(false);
                    }
                    child_start = Some(ext_list.start.saturating_add(start));
                }
                depth = depth
                    .checked_add(1)
                    .ok_or_else(|| invalid("SVG extension depth overflows"))?;
            },
            Event::Empty(element) => {
                if depth == 0 && element.attributes().next().is_some() {
                    return Ok(false);
                }
                if depth == 1 {
                    children.push(source::ByteRange::new(
                        ext_list.start.saturating_add(start),
                        ext_list.start.saturating_add(end),
                    ));
                }
            },
            Event::End(_) => {
                if depth == 2 {
                    let child_start = child_start
                        .take()
                        .ok_or_else(|| invalid("SVG extension child has no opening tag"))?;
                    children.push(source::ByteRange::new(
                        child_start,
                        ext_list.start.saturating_add(end),
                    ));
                }
                depth = depth
                    .checked_sub(1)
                    .ok_or_else(|| invalid("SVG extension depth underflows"))?;
            },
            Event::Comment(_) | Event::PI(_) | Event::CData(_) if depth == 1 => {
                return Ok(false);
            },
            Event::GeneralRef(_) if depth == 1 => return Ok(false),
            Event::Text(text)
                if depth == 1 && !text.as_ref().iter().all(u8::is_ascii_whitespace) =>
            {
                return Ok(false);
            },
            Event::Eof => break,
            _ => {},
        }
        buffer.clear();
    }
    if depth != 0 || children.len() != selected.len() {
        return Ok(false);
    }
    Ok(children
        .iter()
        .all(|child| selected.iter().any(|owner| owner == child)))
}

fn generated_extension(
    prefix: &[u8],
    relationship_id: &str,
    drawing_dialect: source::DrawingDialect,
) -> Result<Vec<u8>> {
    let qname = |local: &str| {
        if prefix.is_empty() {
            local.to_owned()
        } else {
            format!("{}:{local}", String::from_utf8_lossy(prefix))
        }
    };
    let ext = qname("ext");
    let drawing_namespace = drawing_namespace(drawing_dialect);
    let drawing_binding = if prefix.is_empty() {
        String::new()
    } else {
        format!(
            " xmlns:{}=\"{}\"",
            String::from_utf8_lossy(prefix),
            drawing_namespace
        )
    };
    let value = format!(
        "<{ext}{drawing_binding} uri=\"{SVG_EXTENSION_URI}\"><asvg:svgBlip xmlns:asvg=\"{SVG_NAMESPACE}\" xmlns:r=\"{}\" r:embed=\"{}\"/></{ext}>",
        source::RelationshipDialect::authored_svg_attribute_namespace(),
        relationship_id,
    );
    Ok(value.into_bytes())
}

fn generated_extension_size(
    prefix: &[u8],
    relationship_id: &str,
    drawing_dialect: source::DrawingDialect,
) -> usize {
    let prefix = String::from_utf8_lossy(prefix);
    let ext = if prefix.is_empty() {
        "ext".len()
    } else {
        prefix.len().saturating_add(1).saturating_add("ext".len())
    };
    let drawing_binding = if prefix.is_empty() {
        0
    } else {
        " xmlns:"
            .len()
            .saturating_add(prefix.len())
            .saturating_add(3)
            .saturating_add(drawing_namespace(drawing_dialect).len())
    };
    let authored_namespace = source::RelationshipDialect::authored_svg_attribute_namespace();
    1usize
        .saturating_add(ext)
        .saturating_add(drawing_binding)
        .saturating_add(b" uri=\"".len())
        .saturating_add(SVG_EXTENSION_URI.len())
        .saturating_add(2)
        .saturating_add(b"<asvg:svgBlip xmlns:asvg=\"".len())
        .saturating_add(SVG_NAMESPACE.len())
        .saturating_add(b"\" xmlns:r=\"".len())
        .saturating_add(authored_namespace.len())
        .saturating_add(b"\" r:embed=\"".len())
        .saturating_add(relationship_id.len())
        .saturating_add(b"\"/>".len())
        .saturating_add(2)
        .saturating_add(ext)
        .saturating_add(1)
}

const fn drawing_namespace(dialect: source::DrawingDialect) -> &'static str {
    match dialect {
        source::DrawingDialect::Transitional => DRAWINGML_NAMESPACE,
        source::DrawingDialect::Strict => STRICT_DRAWINGML_NAMESPACE,
    }
}

fn generated_ext_list(
    prefix: &[u8],
    extension: &[u8],
    drawing_dialect: source::DrawingDialect,
) -> Result<Vec<u8>> {
    let name = if prefix.is_empty() {
        "extLst".to_owned()
    } else {
        format!("{}:extLst", String::from_utf8_lossy(prefix))
    };
    let drawing_binding = if prefix.is_empty() {
        String::new()
    } else {
        format!(
            " xmlns:{}=\"{}\"",
            String::from_utf8_lossy(prefix),
            drawing_namespace(drawing_dialect)
        )
    };
    let mut output = Vec::new();
    output
        .try_reserve(
            name.len()
                .saturating_mul(2)
                .saturating_add(extension.len())
                .saturating_add(drawing_binding.len())
                .saturating_add(5),
        )
        .map_err(|source| allocation("SVG lifecycle extension list", source))?;
    output.extend_from_slice(b"<");
    output.extend_from_slice(name.as_bytes());
    output.extend_from_slice(drawing_binding.as_bytes());
    output.extend_from_slice(b">");
    output.extend_from_slice(extension);
    output.extend_from_slice(b"</");
    output.extend_from_slice(name.as_bytes());
    output.push(b'>');
    Ok(output)
}

fn generated_ext_list_size(
    prefix: &[u8],
    extension_size: usize,
    drawing_dialect: source::DrawingDialect,
) -> usize {
    let prefix = String::from_utf8_lossy(prefix);
    let name = if prefix.is_empty() {
        "extLst".len()
    } else {
        prefix
            .len()
            .saturating_add(1)
            .saturating_add("extLst".len())
    };
    let drawing_binding = if prefix.is_empty() {
        0
    } else {
        " xmlns:"
            .len()
            .saturating_add(prefix.len())
            .saturating_add(3)
            .saturating_add(drawing_namespace(drawing_dialect).len())
    };
    1usize
        .saturating_add(name)
        .saturating_add(drawing_binding)
        .saturating_add(1)
        .saturating_add(extension_size)
        .saturating_add(2)
        .saturating_add(name)
        .saturating_add(1)
}

fn allocate_relationship_id(relationships: &Relationships) -> Result<String> {
    for index in 0..MAX_ID_ATTEMPTS {
        let candidate = if index == 0 {
            "rIdSvg".to_owned()
        } else {
            format!("rIdSvg{index}")
        };
        if relationships.get(&candidate).is_none() {
            return Ok(candidate);
        }
    }
    Err(invalid(format!(
        "generated SVG relationship ID candidates exceed {}",
        MAX_ID_ATTEMPTS
    )))
}

fn manifest_covers_svg(bytes: &[u8], uri: &PackURI) -> Result<bool> {
    if manifest_has_override(bytes, uri)? {
        return Ok(true);
    }
    manifest_has_default_svg(bytes)
}

fn manifest_has_override(bytes: &[u8], uri: &PackURI) -> Result<bool> {
    let mut reader = Reader::from_reader(bytes);
    reader.config_mut().trim_text(true);
    let mut buffer = Vec::new();
    loop {
        match reader
            .read_event_into(&mut buffer)
            .map_err(|error| invalid(error.to_string()))?
        {
            Event::Empty(element) | Event::Start(element)
                if element.local_name().as_ref() == b"Override" =>
            {
                let mut part = None;
                let mut content = None;
                for attribute in element.attributes().with_checks(true) {
                    let attribute = attribute.map_err(|error| invalid(error.to_string()))?;
                    match attribute.key.local_name().as_ref() {
                        b"PartName" => {
                            part = Some(
                                attribute
                                    .decoded_and_normalized_value(
                                        XmlVersion::Implicit1_0,
                                        reader.decoder(),
                                    )
                                    .map_err(|error| invalid(error.to_string()))?
                                    .into_owned(),
                            );
                        },
                        b"ContentType" => {
                            content = Some(
                                attribute
                                    .decoded_and_normalized_value(
                                        XmlVersion::Implicit1_0,
                                        reader.decoder(),
                                    )
                                    .map_err(|error| invalid(error.to_string()))?
                                    .into_owned(),
                            );
                        },
                        _ => {},
                    }
                }
                if content.as_deref() == Some("image/svg+xml") {
                    let Some(part) = part else {
                        continue;
                    };
                    let part = PackURI::new(part).map_err(litchi_opc::OpcError::InvalidPackUri)?;
                    if part.is_equivalent_to(uri) {
                        return Ok(true);
                    }
                }
            },
            Event::Eof => return Ok(false),
            _ => {},
        }
        buffer.clear();
    }
}

fn manifest_has_default_svg(bytes: &[u8]) -> Result<bool> {
    let mut reader = Reader::from_reader(bytes);
    reader.config_mut().trim_text(true);
    let mut buffer = Vec::new();
    loop {
        match reader
            .read_event_into(&mut buffer)
            .map_err(|error| invalid(error.to_string()))?
        {
            Event::Empty(element) | Event::Start(element)
                if element.local_name().as_ref() == b"Default" =>
            {
                let mut extension = None;
                let mut content = None;
                for attribute in element.attributes().with_checks(true) {
                    let attribute = attribute.map_err(|error| invalid(error.to_string()))?;
                    match attribute.key.local_name().as_ref() {
                        b"Extension" => {
                            extension = Some(
                                attribute
                                    .decoded_and_normalized_value(
                                        XmlVersion::Implicit1_0,
                                        reader.decoder(),
                                    )
                                    .map_err(|error| invalid(error.to_string()))?
                                    .into_owned(),
                            );
                        },
                        b"ContentType" => {
                            content = Some(
                                attribute
                                    .decoded_and_normalized_value(
                                        XmlVersion::Implicit1_0,
                                        reader.decoder(),
                                    )
                                    .map_err(|error| invalid(error.to_string()))?
                                    .into_owned(),
                            );
                        },
                        _ => {},
                    }
                }
                if extension
                    .as_deref()
                    .is_some_and(|value| value.eq_ignore_ascii_case("svg"))
                    && content.as_deref() == Some("image/svg+xml")
                {
                    return Ok(true);
                }
            },
            Event::Eof => return Ok(false),
            _ => {},
        }
        buffer.clear();
    }
}

const fn selector_drawing(selector: PictureSelector) -> usize {
    selector.drawing
}

const fn selector_picture(selector: PictureSelector) -> usize {
    selector.picture
}
