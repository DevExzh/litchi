use std::io::Cursor;

use litchi_docx::Package;
use litchi_opc::constants::content_type as ct;
use litchi_opc::{BlobPart, OpcPackage, PackURI, PackageWriter};

const W: &str = "http://schemas.openxmlformats.org/wordprocessingml/2006/main";
const R: &str = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
const INK_TYPE: &str = "application/inkml+xml";

fn part(opc: &mut OpcPackage, name: &str, content_type: &str, data: &[u8]) {
    opc.add_part(Box::new(BlobPart::new(
        PackURI::new(name).unwrap(),
        content_type.to_owned(),
        data.to_vec(),
    )));
}

fn edge(opc: &mut OpcPackage, owner: &str, id: &str, target: &str, kind: &str) {
    opc.get_part_mut(&PackURI::new(owner).unwrap())
        .unwrap()
        .rels_mut()
        .add_relationship(kind.to_owned(), target.to_owned(), id.to_owned(), false);
}

fn package_bytes(channel: &str, trace: &str, intermittent: bool) -> Vec<u8> {
    let mut opc = OpcPackage::new();
    let document = format!(
        r#"<w:document xmlns:w="{W}" xmlns:r="{R}"><w:body><w:p><w:r><w:contentPart r:id="ink"/></w:r></w:p></w:body></w:document>"#
    );
    part(
        &mut opc,
        "/word/document.xml",
        ct::WML_DOCUMENT_MAIN,
        document.as_bytes(),
    );
    opc.relate_to("word/document.xml", &format!("{R}/officeDocument"));

    let intermittent_xml = if intermittent {
        r#"<i:intermittentChannels><i:channel name="ignored" type="not-a-type"/><i:future foo="bar"/></i:intermittentChannels>"#
    } else {
        ""
    };
    let ink = format!(
        r##"<i:ink xmlns:i="http://www.w3.org/2003/InkML"><i:definitions><i:context xml:id="ctx0"><i:inkSource xml:id="source0"><i:traceFormat><i:channel name="X" type="integer"/><i:channel name="Y" type="integer"/>{channel}{intermittent_xml}</i:traceFormat></i:inkSource></i:context><i:brush xml:id="br0"/></i:definitions><i:trace contextRef="#ctx0" brushRef="#br0">{trace}</i:trace></i:ink>"##
    );
    part(
        &mut opc,
        "/payload/handwriting.xml",
        INK_TYPE,
        ink.as_bytes(),
    );
    edge(
        &mut opc,
        "/word/document.xml",
        "ink",
        "../payload/handwriting.xml",
        &format!("{R}/customXml"),
    );
    PackageWriter::to_bytes(&opc).unwrap()
}

fn main() {
    let cases = [
        ("T-integer", r#"<i:channel name="T" type="integer"/>"#, "1 2 3", false),
        ("T-omitted", r#"<i:channel name="T"/>"#, "1 2 3", false),
        ("T-decimal", r#"<i:channel name="T" type="decimal"/>"#, "1 2 3", false),
        ("T-boolean", r#"<i:channel name="T" type="boolean"/>"#, "1 2 T", false),
        ("T-integer-decimal-value", r#"<i:channel name="T" type="integer"/>"#, "1 2 3.0", false),
        ("opaque-intermittent", r#"<i:channel name="T" type="integer"/>"#, "1 2 3 1e1 ?", true),
    ];
    for (name, channel, trace, intermittent) in cases {
        let bytes = package_bytes(channel, trace, intermittent);
        let result = Package::from_reader(Cursor::new(bytes)).and_then(|package| {
            let snapshot = package.ink()?;
            Ok(snapshot.annotations().len())
        });
        match result {
            Ok(annotations) => println!("{name}: ACCEPT annotations={annotations}"),
            Err(error) => println!("{name}: REJECT {error:?}"),
        }
    }
}
