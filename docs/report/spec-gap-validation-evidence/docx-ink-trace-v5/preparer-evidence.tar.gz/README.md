42cce54f0e04dafd49c996876e1a569594238101 crates/litchi-docx base commit
995bdaf09352297bde17e6ed7d986360f8c10134 comparison commit; git diff is empty for crates/litchi-docx
candidate: /var/tmp/litchi-docx-ink-trace-v5-git-validation-20260910
harness: /var/tmp/litchi-docx-ink-trace-v5-git-review-20260910
target: /var/tmp/litchi-docx-ink-trace-v5-git-target-20260910
TMPDIR: /var/tmp/litchi-docx-ink-trace-v5-git-tmp-20260910
CPU affinity: 8-31
toolchain: Rust 1.95.0
primary worktree edited by this task: no (pre-existing primary modifications were observed; candidate is an isolated worktree)
staging/commit: none
closure: exactly five tracked modifications plus new crates/litchi-docx/src/ink/trace.rs
--- gate results ---
profile tests: 12 passed
direct Boolean T test: 1 passed
default library: 1067 passed
default inventory: 54 passed
all-features library: 1076 passed
all-features inventory: 54 passed
all-features Clippy -D warnings: passed
all-features rustdoc -D warnings: passed
rustfmt --check: passed
git diff --check and six-path closure: passed
git apply --check and apply from clean 42cce54f0 worktree: passed
--- external harness ---
T-integer: ACCEPT annotations=1
T-omitted: ACCEPT annotations=1
T-decimal: ACCEPT annotations=1
T-boolean: REJECT Invalid("DOCX Ink trace data at byte 5: the T channel requires integer millisecond values")
T-integer-decimal-value: REJECT Invalid("DOCX Ink trace data at byte 7: the T channel requires integer millisecond values")
opaque-intermittent: ACCEPT annotations=1

Artifact hashes:
- v5-git.patch: dce80eda2ec0bb9d5136a078a4a7e92a67d0c9d1f7770f108a63f10fdff2892c
- source-sha256.txt: 7bfbf6a2e2f1a8b7c57333e066ecc7bb51286a5095b84d07f233ca63785afc1f
- harness-main.rs: 3afe00d52f5d34b43b22f5a45758ea1243e551b847720e07e0f0b15a810b3d1a
- harness-Cargo.toml: eb11227ad2e228b12daa36e75e001cda1188eb745943b812046791c05ec9103a
- harness-Cargo.lock: 0f1d0a877ee53f033bf544c3594c83062cd82c523248743c3fb6de455d694553
- harness.log: a24106c5ffebdf01f7f106e0b139c38c1b8dff27388a115eb97a1f1b7ceac186
