#![allow(clippy::unwrap_used, reason = "test assertions use unwrap for clarity")]

use litchi_odf_common::core::PackageWriter;
use litchi_odg::{Drawing, Transition, TransitionSound};

const CONTENT_AUTOMATIC: &str = r##"<?xml version="1.0" encoding="UTF-8"?><office:document-content xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0" xmlns:draw="urn:oasis:names:tc:opendocument:xmlns:drawing:1.0" xmlns:style="urn:oasis:names:tc:opendocument:xmlns:style:1.0" xmlns:presentation="urn:oasis:names:tc:opendocument:xmlns:presentation:1.0" xmlns:smil="urn:oasis:names:tc:opendocument:xmlns:smil-compatible:1.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:xml="http://www.w3.org/XML/1998/namespace" xmlns:foo="urn:example:unknown" office:version="1.4"><office:automatic-styles><style:style style:name="dp1" style:family="drawing-page"><style:drawing-page-properties presentation:transition-type="automatic" presentation:transition-style="fade-from-left" presentation:transition-speed="fast" smil:type="fade" smil:subtype="crossfade" smil:direction="forward" smil:fadeColor="#010203" presentation:duration="PT2S"><presentation:sound xlink:type="simple" xlink:href="media/transition.wav" xlink:actuate="onRequest" xlink:show="replace" presentation:play-full="true" xml:id="sound1"/><foo:unknown foo:value="keep"/></style:drawing-page-properties></style:style></office:automatic-styles><office:body><office:drawing><draw:page draw:name="Page 1" draw:style-name="dp1"/></office:drawing></office:body></office:document-content>"##;

const CONTENT_NAMED: &str = r##"<?xml version="1.0" encoding="UTF-8"?><office:document-content xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0" xmlns:draw="urn:oasis:names:tc:opendocument:xmlns:drawing:1.0" xmlns:xml="http://www.w3.org/XML/1998/namespace" office:version="1.4"><office:body><office:drawing><draw:page draw:name="Page 1" draw:style-name="dp1"/></office:drawing></office:body></office:document-content>"##;

const CONTENT_SHARED: &str = r##"<?xml version="1.0" encoding="UTF-8"?><office:document-content xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0" xmlns:draw="urn:oasis:names:tc:opendocument:xmlns:drawing:1.0" xmlns:style="urn:oasis:names:tc:opendocument:xmlns:style:1.0" xmlns:presentation="urn:oasis:names:tc:opendocument:xmlns:presentation:1.0" xmlns:smil="urn:oasis:names:tc:opendocument:xmlns:smil-compatible:1.0" office:version="1.4"><office:automatic-styles><style:style style:name="dp1" style:family="drawing-page"><style:drawing-page-properties presentation:transition-type="automatic"/></style:style></office:automatic-styles><office:body><office:drawing><draw:page draw:name="Page 1" draw:style-name="dp1"/><draw:page draw:name="Page 2" draw:style-name="dp1"/></office:drawing></office:body></office:document-content>"##;

const CONTENT_3D: &str = r##"<?xml version="1.0" encoding="UTF-8"?><office:document-content xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0" xmlns:draw="urn:oasis:names:tc:opendocument:xmlns:drawing:1.0" xmlns:dr3d="urn:oasis:names:tc:opendocument:xmlns:dr3d:1.0" office:version="1.4"><office:body><office:drawing><draw:page draw:name="Page 1"><dr3d:scene draw:name="Scene"><dr3d:light dr3d:direction="0 0 1"/><dr3d:cube/></dr3d:scene></draw:page></office:drawing></office:body></office:document-content>"##;

const CONTENT_ENHANCED: &str = r##"<?xml version="1.0" encoding="UTF-8"?><office:document-content xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0" xmlns:draw="urn:oasis:names:tc:opendocument:xmlns:drawing:1.0" xmlns:svg="urn:oasis:names:tc:opendocument:xmlns:svg-compatible:1.0" office:version="1.4"><office:body><office:drawing><draw:page draw:name="Page 1"><draw:custom-shape draw:name="Custom"><draw:enhanced-geometry draw:type="rectangle" svg:viewBox="0 0 21600 21600"><draw:equation draw:name="f0" draw:formula="width/2"/><draw:handle draw:handle-position="$0 0"/></draw:enhanced-geometry></draw:custom-shape></draw:page></office:drawing></office:body></office:document-content>"##;

const CONTENT_AUXILIARY: &str = r##"<?xml version="1.0" encoding="UTF-8"?><office:document-content xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0" xmlns:draw="urn:oasis:names:tc:opendocument:xmlns:drawing:1.0" xmlns:svg="urn:oasis:names:tc:opendocument:xmlns:svg-compatible:1.0" xmlns:xlink="http://www.w3.org/1999/xlink" office:version="1.4"><office:body><office:drawing><draw:page draw:name="Page 1"><draw:frame draw:name="Picture"><draw:image xlink:type="simple" xlink:href="media/picture.png"><draw:image-map><draw:area-rectangle svg:x="0cm" svg:y="0cm" svg:width="2cm" svg:height="3cm" xlink:type="simple" xlink:href="https://example.org/target" xlink:show="replace" office:name="area-1"/><draw:area-polygon svg:x="0cm" svg:y="0cm" svg:width="2cm" svg:height="3cm" svg:viewBox="0 0 100 100" draw:points="0,0 100,0 50,100" draw:nohref="nohref"/></draw:image-map><draw:contour-polygon draw:recreate-on-edit="true" svg:width="2cm" svg:height="3cm" svg:viewBox="0 0 100 100" draw:points="0,0 100,0 50,100"/></draw:image><draw:glue-point draw:id="0" svg:x="1cm" svg:y="2cm" draw:escape-direction="auto"/></draw:frame></draw:page></office:drawing></office:body></office:document-content>"##;

const STYLES_NAMED: &str = r##"<?xml version="1.0" encoding="UTF-8"?><office:document-styles xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0" xmlns:style="urn:oasis:names:tc:opendocument:xmlns:style:1.0" xmlns:presentation="urn:oasis:names:tc:opendocument:xmlns:presentation:1.0" xmlns:smil="urn:oasis:names:tc:opendocument:xmlns:smil-compatible:1.0" office:version="1.4"><office:styles><style:style style:name="dp1" style:family="drawing-page"><style:drawing-page-properties presentation:transition-type="manual" smil:type="fade"/></style:style></office:styles></office:document-styles>"##;

const STYLES_PREFIXED_INHERITED: &str = r##"<?xml version="1.0" encoding="UTF-8"?><office:document-styles xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0" xmlns:style="urn:oasis:names:tc:opendocument:xmlns:style:1.0" xmlns:p="urn:oasis:names:tc:opendocument:xmlns:presentation:1.0" xmlns:s="urn:oasis:names:tc:opendocument:xmlns:smil-compatible:1.0" office:version="1.4"><office:styles><style:style style:name="parent" style:family="drawing-page"><style:drawing-page-properties p:transition-speed="slow" s:type="fade"/></style:style><style:style style:name="dp1" style:family="drawing-page" style:parent-style-name="parent"><style:drawing-page-properties p:transition-type="manual"/></style:style></office:styles></office:document-styles>"##;

fn package(content: &str, styles: Option<&str>) -> Vec<u8> {
    let mut writer = PackageWriter::new();
    writer
        .set_mimetype("application/vnd.oasis.opendocument.graphics")
        .unwrap();
    writer.add_file("content.xml", content.as_bytes()).unwrap();
    writer.add_file("media/transition.wav", b"inert").unwrap();
    if let Some(styles) = styles {
        writer.add_file("styles.xml", styles.as_bytes()).unwrap();
    }
    writer.finish_to_bytes().unwrap()
}

fn replacement_transition() -> Transition {
    let mut transition = Transition::new();
    transition.set_transition_type(Some("automatic")).unwrap();
    transition.set_style(Some("dissolve")).unwrap();
    transition.set_speed(Some("medium")).unwrap();
    transition.set_smil_type(Some("fade")).unwrap();
    transition.set_smil_subtype(Some("crossfade")).unwrap();
    transition.set_direction(Some("reverse")).unwrap();
    transition.set_fade_color(Some("#AABBCC")).unwrap();
    transition.set_duration(Some("PT3S")).unwrap();
    let sound = TransitionSound::new("media/transition.wav")
        .unwrap()
        .with_play_full(Some(true))
        .with_actuate_on_request(true)
        .with_show(Some("replace"))
        .unwrap()
        .with_xml_id(Some("sound1"))
        .unwrap();
    transition.set_sound(Some(sound));
    transition
}

#[test]
fn reads_smil_transition_and_reopens_source_bound_edit() {
    let source = Drawing::from_bytes(package(CONTENT_AUTOMATIC, None)).unwrap();
    let transition = source.pages()[0].transition().unwrap();
    assert_eq!(transition.transition_type(), Some("automatic"));
    assert_eq!(transition.style(), Some("fade-from-left"));
    assert_eq!(transition.smil_type(), Some("fade"));
    assert_eq!(transition.duration(), Some("PT2S"));
    assert_eq!(transition.sound().unwrap().href(), "media/transition.wav");
    assert!(transition.sound().unwrap().actuate_on_request());

    let mut edit = source.edit();
    edit.set_page_transition(0, Some(replacement_transition()))
        .unwrap();
    let commit = edit.commit().unwrap();
    let output = commit.snapshot();
    assert!(
        output
            .content_xml()
            .contains("foo:unknown foo:value=\"keep\"")
    );
    assert!(
        output
            .content_xml()
            .contains("presentation:transition-style=\"dissolve\"")
    );
    let reopened = Drawing::from_bytes(output.as_bytes().to_vec()).unwrap();
    assert_eq!(
        reopened.pages()[0].transition(),
        output.pages()[0].transition()
    );
    assert_eq!(
        reopened.pages()[0].transition().unwrap().duration(),
        Some("PT3S")
    );

    let durable = commit.patch().durable().unwrap();
    let replayed = durable.apply(source.snapshot()).unwrap();
    assert_eq!(replayed.as_bytes(), output.as_bytes());
    let restored = durable.inverse().apply(&replayed).unwrap();
    assert_eq!(restored.as_bytes(), source.as_bytes());
}

#[test]
fn edits_named_style_owner_in_styles_xml() {
    let source = Drawing::from_bytes(package(CONTENT_NAMED, Some(STYLES_NAMED))).unwrap();
    assert_eq!(
        source.pages()[0].transition().unwrap().transition_type(),
        Some("manual")
    );
    let mut edit = source.edit();
    edit.set_page_transition(0, Some(replacement_transition()))
        .unwrap();
    let output = edit.commit().unwrap().into_snapshot();
    assert_eq!(output.content_xml(), CONTENT_NAMED);
    assert!(
        output
            .styles_xml()
            .unwrap()
            .contains("presentation:transition-style=\"dissolve\"")
    );
    let reopened = Drawing::from_bytes(output.as_bytes().to_vec()).unwrap();
    assert_eq!(
        reopened.pages()[0].transition().unwrap().style(),
        Some("dissolve")
    );
}

#[test]
fn resolves_prefixed_transition_attributes_and_parent_styles() {
    let source =
        Drawing::from_bytes(package(CONTENT_NAMED, Some(STYLES_PREFIXED_INHERITED))).unwrap();
    let transition = source.pages()[0].transition().unwrap();
    assert_eq!(transition.transition_type(), Some("manual"));
    assert_eq!(transition.speed(), Some("slow"));
    assert_eq!(transition.smil_type(), Some("fade"));
}

#[test]
fn refuses_to_mutate_a_transition_style_shared_by_pages() {
    let source = Drawing::from_bytes(package(CONTENT_SHARED, None)).unwrap();
    let mut edit = source.edit();
    assert!(
        edit.set_page_transition(0, Some(replacement_transition()))
            .is_err()
    );
}

#[test]
fn recognizes_inert_dr3d_shape_owners() {
    let drawing = Drawing::from_bytes(package(CONTENT_3D, None)).unwrap();
    let shapes = drawing.pages()[0].shapes();
    assert_eq!(
        shapes[0].kind(),
        litchi_odg::shape::ShapeKind::ThreeDimensionalScene
    );
    assert_eq!(
        shapes[1].kind(),
        litchi_odg::shape::ShapeKind::ThreeDimensionalLight
    );
    assert_eq!(
        shapes[2].kind(),
        litchi_odg::shape::ShapeKind::ThreeDimensionalCube
    );
}

#[test]
fn reads_inert_enhanced_geometry_equations_and_handles() {
    let drawing = Drawing::from_bytes(package(CONTENT_ENHANCED, None)).unwrap();
    let geometry = drawing.pages()[0].shapes()[0].enhanced_geometry().unwrap();
    assert_eq!(geometry.attributes().len(), 2);
    assert_eq!(geometry.children().len(), 2);
    assert_eq!(
        geometry.children()[0].kind(),
        litchi_odg::EnhancedGeometryChildKind::Equation
    );
    assert_eq!(
        geometry.children()[1].kind(),
        litchi_odg::EnhancedGeometryChildKind::Handle
    );
    assert!(
        geometry.children()[0]
            .attributes()
            .iter()
            .any(|attribute| attribute.local_name() == "formula" && attribute.value() == "width/2")
    );
}

#[test]
fn reads_inert_image_map_contour_and_glue_point_owners() {
    let drawing = Drawing::from_bytes(package(CONTENT_AUXILIARY, None)).unwrap();
    let shape = &drawing.pages()[0].shapes()[0];
    let map = shape.image_map().unwrap();
    assert_eq!(map.areas().len(), 2);
    assert_eq!(map.areas()[0].href(), Some("https://example.org/target"));
    assert_eq!(map.areas()[0].show(), Some("replace"));
    assert!(map.areas()[1].no_href());
    assert_eq!(shape.contours().len(), 1);
    assert_eq!(shape.contours()[0].kind(), litchi_odg::ContourKind::Polygon);
    assert_eq!(shape.glue_points().len(), 1);
    assert_eq!(shape.glue_points()[0].id(), "0");
    assert_eq!(shape.glue_points()[0].escape_direction(), "auto");
}

#[test]
fn image_map_charges_retained_area_and_owner_xml_together() {
    let start = CONTENT_AUXILIARY.find("<draw:area-rectangle").unwrap();
    let end = start + CONTENT_AUXILIARY[start..].find("/>").unwrap();
    for (comment_bytes, accepted) in [(16, true), (5 * 1024 * 1024, false)] {
        let paired = format!(
            "><!--{}--><!--{}--></draw:area-rectangle>",
            "x".repeat(comment_bytes / 2),
            "x".repeat(comment_bytes / 2)
        );
        let mut content = CONTENT_AUXILIARY.to_owned();
        content.replace_range(end..end + 2, &paired);
        let result = Drawing::from_bytes(package(&content, None));
        if accepted {
            assert_eq!(
                result.unwrap().pages()[0].shapes()[0]
                    .image_map()
                    .unwrap()
                    .areas()
                    .len(),
                2
            );
        } else {
            assert!(matches!(result, Err(litchi_core::Error::InvalidFormat(_))));
        }
    }
}

#[test]
fn paired_contours_and_glue_points_accept_empty_content_and_retain_comments() {
    let source = CONTENT_AUXILIARY
        .replace(
            r#"draw:points="0,0 100,0 50,100"/></draw:image>"#,
            r#"draw:points="0,0 100,0 50,100"><!--keep--></draw:contour-polygon></draw:image>"#,
        )
        .replace(
            r#"draw:escape-direction="auto"/>"#,
            r#"draw:escape-direction="auto"><!--glue--></draw:glue-point>"#,
        );
    let drawing = Drawing::from_bytes(package(&source, None)).unwrap();
    let shape = &drawing.pages()[0].shapes()[0];
    assert!(shape.contours()[0].source_xml().contains("<!--keep-->"));
    assert!(shape.glue_points()[0].source_xml().contains("<!--glue-->"));
    let nonempty = source.replace("<!--keep-->", "nonempty");
    assert!(matches!(
        Drawing::from_bytes(package(&nonempty, None)),
        Err(litchi_core::Error::InvalidFormat(_))
    ));
}
