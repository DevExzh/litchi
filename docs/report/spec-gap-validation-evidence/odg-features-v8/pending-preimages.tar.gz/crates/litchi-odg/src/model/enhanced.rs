//! Inert custom-shape enhanced geometry declarations.

use litchi_core::{Error, Result};

const MAX_ATTRIBUTES: usize = 65_536;
const MAX_VALUE_BYTES: usize = 16 * 1024 * 1024;
const MAX_GEOMETRY_BYTES: usize = 8 * 1024 * 1024;

/// Namespace of a recognized enhanced-geometry attribute.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
#[non_exhaustive]
pub enum DrawingAttributeNamespace {
    /// `draw:*`.
    Drawing,
    /// `svg:*`.
    Svg,
    /// `dr3d:*`.
    Dr3d,
}

/// A recognized drawing attribute retained as a bounded lexical value.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct DrawingAttribute {
    namespace: DrawingAttributeNamespace,
    local_name: String,
    value: String,
}

impl DrawingAttribute {
    pub(crate) fn parsed(
        namespace: DrawingAttributeNamespace,
        local_name: String,
        value: String,
    ) -> Result<Self> {
        if local_name.is_empty()
            || local_name.len() > 256
            || !local_name.bytes().enumerate().all(|(index, byte)| {
                byte.is_ascii_alphanumeric() || byte == b'_' || (index > 0 && byte == b'-')
            })
        {
            return Err(Error::InvalidFormat(
                "invalid ODG enhanced-geometry attribute local name".into(),
            ));
        }
        if value.is_empty() || value.len() > MAX_VALUE_BYTES || value.contains('\0') {
            return Err(Error::InvalidFormat(
                "ODG enhanced-geometry attribute exceeds the limit".into(),
            ));
        }
        Ok(Self {
            namespace,
            local_name,
            value,
        })
    }

    /// Attribute namespace.
    #[must_use]
    pub const fn namespace(&self) -> DrawingAttributeNamespace {
        self.namespace
    }

    /// Attribute local name.
    #[must_use]
    pub fn local_name(&self) -> &str {
        &self.local_name
    }

    /// Decoded attribute value.
    #[must_use]
    pub fn value(&self) -> &str {
        &self.value
    }
}

/// Child owner kind in `draw:enhanced-geometry`.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
#[non_exhaustive]
pub enum EnhancedGeometryChildKind {
    /// `draw:equation` formula declaration.
    Equation,
    /// `draw:handle` adjustment handle.
    Handle,
}

/// One inert equation or handle declaration.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct EnhancedGeometryChild {
    kind: EnhancedGeometryChildKind,
    attributes: Vec<DrawingAttribute>,
}

impl EnhancedGeometryChild {
    pub(crate) fn parsed(
        kind: EnhancedGeometryChildKind,
        attributes: Vec<DrawingAttribute>,
    ) -> Self {
        Self { kind, attributes }
    }

    /// Child owner kind.
    #[must_use]
    pub const fn kind(&self) -> EnhancedGeometryChildKind {
        self.kind
    }

    /// Recognized attributes in source order.
    #[must_use]
    pub fn attributes(&self) -> &[DrawingAttribute] {
        &self.attributes
    }
}

/// Inert enhanced geometry attached to a custom shape.
#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub struct EnhancedGeometry {
    attributes: Vec<DrawingAttribute>,
    children: Vec<EnhancedGeometryChild>,
}

impl EnhancedGeometry {
    pub(crate) fn parsed(
        attributes: Vec<DrawingAttribute>,
        children: Vec<EnhancedGeometryChild>,
    ) -> Result<Self> {
        if attributes.len().saturating_add(children.len()) > MAX_ATTRIBUTES {
            return Err(Error::InvalidFormat(
                "ODG enhanced-geometry aggregate exceeds the limit".into(),
            ));
        }
        let bytes = attributes
            .iter()
            .map(|attribute| {
                attribute
                    .local_name
                    .len()
                    .saturating_add(attribute.value.len())
            })
            .chain(children.iter().flat_map(|child| {
                child.attributes.iter().map(|attribute| {
                    attribute
                        .local_name
                        .len()
                        .saturating_add(attribute.value.len())
                })
            }))
            .try_fold(0usize, |total, value| total.checked_add(value))
            .ok_or_else(|| Error::InvalidFormat("ODG enhanced-geometry size overflow".into()))?;
        if bytes > MAX_GEOMETRY_BYTES {
            return Err(Error::InvalidFormat(
                "ODG enhanced-geometry aggregate exceeds the byte limit".into(),
            ));
        }
        Ok(Self {
            attributes,
            children,
        })
    }

    /// Recognized geometry attributes in source order.
    #[must_use]
    pub fn attributes(&self) -> &[DrawingAttribute] {
        &self.attributes
    }

    /// Equations and handles in source order.
    #[must_use]
    pub fn children(&self) -> &[EnhancedGeometryChild] {
        &self.children
    }
}
