# Graph authoring freeze citations

This evidence is for the isolated candidate at
`/var/tmp/litchi-ppt-ograph-authoring-validation-20260910`, reconstructed by
applying `ograph-authoring-final.patch` to commit
`6bba8c3d48fc7d360c50f2fda607afc173e10d98`. The cited specifications are the
checked-in Markdown copies under `3rdparty/specs/`; no online material is
needed.

## Normative OGraph records and profile choices

- `[MS-OGRAPH]` `2 Structures/2.1 File Structure.md`, §§2.1.1–2.1.7.3,
  lines 5–33 and 85–105: OLE compound-file requirement, BIFF record framing,
  exactly one `Workbook` stream, globals first, and one following chart-sheet
  substream.
- `[MS-OGRAPH]` `2 Structures/2.2 Conceptual Overview.md`, §§2.2.1.1–2.2.1.4,
  lines 19–109 and 115–163: `DATASHEET`, `CHARTFORMATS`, `AXISPARENT`, title
  `ATTACHEDLABEL`/`ObjectLink(wLinkObj=1)`, pie no-axis rule, category-axis
  requirement, and line `fStacked=0` series-axis/Chart3d requirement. The
  candidate therefore emits horizontal Bar (`fTranspose=1`), stacked Line
  (`fStacked=1`) with category/value axes, and Pie with no axes.
- `[MS-OGRAPH]` `2 Structures/2.2 Conceptual Overview.md`, lines 208–234 and
  294–338: chart-group type classification, required first-group series
  ownership, and `Series`/`BRAI` row-column meaning.
- `[MS-OGRAPH]` `2 Structures/2.4 Records.md`, §§2.4.18, 2.4.21–2.4.26,
  2.4.31, 2.4.33, 2.4.40, 2.4.42, 2.4.46–2.4.47, 2.4.51, 2.4.64–2.4.66,
  2.4.72–2.4.73, 2.4.85, 2.4.89–2.4.94, 2.4.96, 2.4.98, 2.4.101,
  2.4.104–2.4.106: typed payload and reserved-field rules for the emitted
  Graph records (`BRAI`, `Chart`, `ChartFormat`, `Country`, `CrtLink`,
  `Dimensions`, `End`, `Exclude*`, `FontX`, `MainWindow`, `MaxStatus`,
  `ObjectLink`, `Orient`, `Selection`, `Series`, `SeriesText`, `SerToCrt`,
  `ShtProps`, `StartObject`, `Text`, `Units`, and data-sheet windows).
- `[MS-OGRAPH]` `3 Structure Examples/3.1 Graph - Column Chart.md` and
  `3.2 Graph - Pie Chart.md`: checked-in producer examples used as layout and
  record-order cross-checks; the candidate deliberately uses its scoped
  horizontal-Bar/stacked-Line/axis-free-Pie profile rather than claiming all
  chart families.

## Normative PPT host closure

- `[MS-PPT]` `2 Structures/2.1 File Streams and Storages.md`, lines 123–145:
  `ExObjListContainer` discovery, `ExOleEmbedContainer`, `persistIdRef`, and
  the persisted `ExOleObjStg` record.
- `[MS-PPT]` `2 Structures/2.10 External Object Types.md`, §§2.10.1–2.10.3,
  2.10.12, 2.10.14, 2.10.27, and 2.10.34–2.10.36: external-object list,
  `ExOleObjAtom` identity/subtype/persist binding, `ProgIDAtom`, embedded OLE
  container, and uncompressed storage payload.
- `[MS-PPT]` `2 Structures/2.7 Shape Types.md`, §§2.7.3 and 2.7.7: OfficeArt
  client data and `ExObjRefAtom` shape-to-external-object ownership.
- `[MS-PPT]` `3 Structure Examples/3.3 Persist Objects.md`: persist-directory
  and object-offset closure example.

## Accepted local ADRs and audit boundary

- `docs/adr/0002-crate-topology.md:603-606,634-642`: `litchi-ograph`
  owns neutral OGraph grammar/package encoding; PPT owns presentation frames
  and embedded-object integration; PPT must not reuse the concrete XLS owner.
- `docs/adr/0001-priorities-and-api-layers.md:18-35,39-52`: correctness and
  safety priority, validated typed construction, and typed refusal for
  unsupported editing.
- `docs/adr/0006-validation-security-and-compatibility.md:8-28`: preserve
  unknown data, validation does not mutate, normative specs control writers,
  and compatibility quirks are not silently baked into fresh output.
- `docs/adr/0025-ograph-chart-area-transactions.md:16-33,37-40`: bounded
  source-preserving OGraph edits, exact ownership, no rendering/evaluation,
  and fixed chart-record grammar.
- `docs/report/spec-gap-audit.md:315-325,348-352`: original PPT Graph write
  gap and explicit boundaries: Excel-hosted authoring, arbitrary semantic
  mutation, rendering/evaluation, and execution remain outside this batch.

The candidate does not modify PhotoAlbum, ProgTags, DocInfoList, or PP10 owner
files. Its PPT closure is limited to the chart's existing external-object and
OfficeArt frame path.
