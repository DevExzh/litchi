# Frozen Graph authoring handoff

Use `source-manifest.json` as the authoritative manifest (manifest SHA-256 is
recorded in `source-manifest.sha256`). Reconstruct the candidate from a clean
checkout at the recorded `base_revision` by applying
`ograph-authoring-final.patch`; `reconstruction.log` records a successful
`git apply --check`, application, and all 18 candidate-path hash comparisons.
`base-preimages/` and `candidate-paths/` contain all 18 exact changed path
images. `citations.md` records the local Markdown specification and ADR
sections used for review. Gate logs and their hashes are listed in the
manifest.

The candidate worktree was left untouched after source capture; no candidate
source edits, staging, or commits were performed during the gate run.
