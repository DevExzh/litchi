# Calculation Chain checked publication allocation A/B

This isolated A/B compares the frozen c40 source against the private checked
publication seam. The control harness is `/var/tmp/litchi-xlsb-calculation-chain-breakdown-control-ab` and the candidate harness
is `/var/tmp/litchi-xlsb-calculation-chain-breakdown-checked`. Both use Rust 1.95, the same Cargo.lock, the same synthetic
profiles, three warmups, and fifteen allocation-only samples per profile and
operation. No wall-clock timer was admitted.

The candidate source changes only `calculation_chain/patch.rs` and
`calculation_chain/workbook.rs` relative to the c40 source. It preflights the
source once before each facade clone, checks publication policy, clones one
caller-owned candidate, and runs `apply_checked` without another source scan or
package clone. Final candidate readback and Package facade validation remain.

| operation/profile | control bytes / allocs | candidate bytes / allocs | delta |
| --- | ---: | ---: | ---: |
| `remove_apply` large | 3,996,014 / 48,997 | 2,884,209 / 35,096 | -1,111,805 / -13,901 |
| `inverse_apply` large | 3,995,523 / 48,980 | 2,891,804 / 35,241 | -1,103,719 / -13,739 |
| `remove_plan_commit` large | 2,466,709 / 29,050 | 2,466,709 / 29,050 | 0 / 0 |
| `snapshot_read` large | 892,717 / 10,721 | 892,624 / 10,717 | -93 / -4 |

The large `remove_apply` result is a measured allocation reduction of
1,111,805 bytes and 13,901 allocation calls. The prior direct-probe prediction was 1,111,704 bytes and 13,896 calls; this run is within 101 bytes and 5 calls. `remove_plan_commit` is unchanged. Snapshot peak live bytes are unchanged, and correctness/native inventory rows match after ignoring the source label.

These are allocation/count results only. They do not establish a latency, throughput,
RSS, or syscall improvement. Reopen-inverse rows vary by archive map ordering, so
medians are used. Full raw hashes and provenance are in
`checked-apply-allocation-ab-receipt.json`.
