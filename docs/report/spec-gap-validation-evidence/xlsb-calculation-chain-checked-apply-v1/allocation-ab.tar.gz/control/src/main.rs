#![allow(clippy::cast_possible_truncation)]
#![allow(clippy::cast_sign_loss)]
#![allow(clippy::large_enum_variant)]
#![allow(clippy::too_many_lines)]

//! Opt-in absolute benchmark for the public XLSB Calculation Chain owner.
//!
//! The harness is deliberately outside the production workspace.  It measures
//! bounded opaque-byte snapshot and source-bound remove/inverse publication
//! work from the committed Calculation Chain API.  It does not invent a
//! Calculation Chain record grammar, and it refuses timed operations unless
//! `ALLOW_TIMED_RUN=1` is explicitly present in the environment.

use litchi_opc::{
    BlobPart, OpcPackage, OwnedContentTypes, OwnedRelationships, PackURI, ReadLimits, TargetMode,
};
use litchi_xlsb::Package;
use litchi_xlsb::calculation_chain::{CONTENT_TYPE, Commit, Patch, Snapshot};
use serde_json::{Value, json};
use sha2::{Digest, Sha256};
use soapberry_zip::office::ArchiveReader;
use std::alloc::{GlobalAlloc, Layout, System};
use std::collections::BTreeMap;
use std::env;
use std::error::Error;
use std::fs;
use std::hint::black_box;
use std::path::Path;
use std::sync::atomic::{AtomicUsize, Ordering};
use std::time::Instant;

type AnyResult<T> = Result<T, Box<dyn Error>>;

const SOURCE_COMMIT: &str = "c40e4522309167bef1232ea22d36923c8f31d7b3";

struct CountingAllocator;

struct Counters {
    alloc_calls: AtomicUsize,
    allocated_bytes: AtomicUsize,
    realloc_calls: AtomicUsize,
    reallocated_bytes: AtomicUsize,
    dealloc_calls: AtomicUsize,
    deallocated_bytes: AtomicUsize,
    live_bytes: AtomicUsize,
    peak_live_bytes: AtomicUsize,
    phase_peak_live_bytes: AtomicUsize,
}

#[derive(Clone, Copy, Debug)]
struct CounterSnapshot {
    alloc_calls: usize,
    allocated_bytes: usize,
    realloc_calls: usize,
    reallocated_bytes: usize,
    dealloc_calls: usize,
    deallocated_bytes: usize,
    live_bytes: usize,
}

#[derive(Clone, Copy, Debug)]
struct CounterDelta {
    alloc_calls: usize,
    allocated_bytes: usize,
    realloc_calls: usize,
    reallocated_bytes: usize,
    dealloc_calls: usize,
    deallocated_bytes: usize,
    peak_live_bytes: usize,
    end_live_delta: usize,
}

#[global_allocator]
static ALLOCATOR: CountingAllocator = CountingAllocator;

static COUNTERS: Counters = Counters {
    alloc_calls: AtomicUsize::new(0),
    allocated_bytes: AtomicUsize::new(0),
    realloc_calls: AtomicUsize::new(0),
    reallocated_bytes: AtomicUsize::new(0),
    dealloc_calls: AtomicUsize::new(0),
    deallocated_bytes: AtomicUsize::new(0),
    live_bytes: AtomicUsize::new(0),
    peak_live_bytes: AtomicUsize::new(0),
    phase_peak_live_bytes: AtomicUsize::new(0),
};

unsafe impl GlobalAlloc for CountingAllocator {
    unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
        // SAFETY: this forwards the allocator contract to the system allocator.
        let pointer = unsafe { System.alloc(layout) };
        if !pointer.is_null() {
            record_alloc(layout.size());
        }
        pointer
    }

    unsafe fn dealloc(&self, pointer: *mut u8, layout: Layout) {
        // SAFETY: the caller supplies the original pointer/layout pair.
        unsafe { System.dealloc(pointer, layout) };
        record_dealloc(layout.size());
    }

    unsafe fn realloc(&self, pointer: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
        // SAFETY: this forwards the allocator contract to the system allocator.
        let new_pointer = unsafe { System.realloc(pointer, layout, new_size) };
        if !new_pointer.is_null() {
            record_realloc(layout.size(), new_size);
        }
        new_pointer
    }
}

fn record_alloc(size: usize) {
    COUNTERS.alloc_calls.fetch_add(1, Ordering::Relaxed);
    COUNTERS.allocated_bytes.fetch_add(size, Ordering::Relaxed);
    add_live(size);
}

fn record_dealloc(size: usize) {
    COUNTERS.dealloc_calls.fetch_add(1, Ordering::Relaxed);
    COUNTERS
        .deallocated_bytes
        .fetch_add(size, Ordering::Relaxed);
    subtract_live(size);
}

fn record_realloc(old_size: usize, new_size: usize) {
    COUNTERS.realloc_calls.fetch_add(1, Ordering::Relaxed);
    COUNTERS
        .reallocated_bytes
        .fetch_add(new_size, Ordering::Relaxed);
    if new_size >= old_size {
        let growth = new_size - old_size;
        COUNTERS.alloc_calls.fetch_add(1, Ordering::Relaxed);
        COUNTERS
            .allocated_bytes
            .fetch_add(growth, Ordering::Relaxed);
        add_live(growth);
    } else {
        subtract_live(old_size - new_size);
    }
}

fn add_live(size: usize) {
    let live = COUNTERS
        .live_bytes
        .fetch_add(size, Ordering::Relaxed)
        .saturating_add(size);
    update_max(&COUNTERS.peak_live_bytes, live);
    update_max(&COUNTERS.phase_peak_live_bytes, live);
}

fn subtract_live(size: usize) {
    let _ = COUNTERS
        .live_bytes
        .fetch_update(Ordering::Relaxed, Ordering::Relaxed, |old| {
            Some(old.saturating_sub(size))
        });
}

fn update_max(target: &AtomicUsize, value: usize) {
    let _ = target.fetch_update(Ordering::Relaxed, Ordering::Relaxed, |old| {
        (value > old).then_some(value)
    });
}

fn counters() -> CounterSnapshot {
    CounterSnapshot {
        alloc_calls: COUNTERS.alloc_calls.load(Ordering::Relaxed),
        allocated_bytes: COUNTERS.allocated_bytes.load(Ordering::Relaxed),
        realloc_calls: COUNTERS.realloc_calls.load(Ordering::Relaxed),
        reallocated_bytes: COUNTERS.reallocated_bytes.load(Ordering::Relaxed),
        dealloc_calls: COUNTERS.dealloc_calls.load(Ordering::Relaxed),
        deallocated_bytes: COUNTERS.deallocated_bytes.load(Ordering::Relaxed),
        live_bytes: COUNTERS.live_bytes.load(Ordering::Relaxed),
    }
}

fn begin_phase() -> CounterSnapshot {
    let before = counters();
    COUNTERS
        .phase_peak_live_bytes
        .store(before.live_bytes, Ordering::Relaxed);
    before
}

fn end_phase(before: CounterSnapshot) -> CounterDelta {
    let after = counters();
    let phase_peak = COUNTERS.phase_peak_live_bytes.load(Ordering::Relaxed);
    CounterDelta {
        alloc_calls: after.alloc_calls.saturating_sub(before.alloc_calls),
        allocated_bytes: after.allocated_bytes.saturating_sub(before.allocated_bytes),
        realloc_calls: after.realloc_calls.saturating_sub(before.realloc_calls),
        reallocated_bytes: after
            .reallocated_bytes
            .saturating_sub(before.reallocated_bytes),
        dealloc_calls: after.dealloc_calls.saturating_sub(before.dealloc_calls),
        deallocated_bytes: after
            .deallocated_bytes
            .saturating_sub(before.deallocated_bytes),
        peak_live_bytes: phase_peak.saturating_sub(before.live_bytes),
        end_live_delta: after.live_bytes.saturating_sub(before.live_bytes),
    }
}

struct Timed<T> {
    output: T,
    elapsed_ns: u128,
    counters: CounterDelta,
}

fn timed<T, F>(operation: F) -> AnyResult<Timed<T>>
where
    F: FnOnce() -> AnyResult<T>,
{
    let before = begin_phase();
    let started = Instant::now();
    let output = operation()?;
    let output = black_box(output);
    let elapsed_ns = started.elapsed().as_nanos();
    let counters = end_phase(before);
    Ok(Timed {
        output,
        elapsed_ns,
        counters,
    })
}

struct Counted<T> {
    output: T,
    counters: CounterDelta,
}

/// Run one operation with allocator counters only. This path deliberately
/// does not call `Instant::now()` or collect wall-clock samples.
fn counted<T, F>(operation: F) -> AnyResult<Counted<T>>
where
    F: FnOnce() -> AnyResult<T>,
{
    let before = begin_phase();
    let output = operation()?;
    let output = black_box(output);
    let counters = end_phase(before);
    Ok(Counted { output, counters })
}

#[derive(Debug)]
struct MemberInventory {
    members: BTreeMap<String, Vec<u8>>,
    sha256: String,
    total_decompressed_bytes: usize,
}

fn hex_digest(bytes: &[u8]) -> String {
    const HEX: &[u8; 16] = b"0123456789abcdef";
    let mut output = String::with_capacity(bytes.len() * 2);
    for &byte in bytes {
        output.push(HEX[usize::from(byte >> 4)] as char);
        output.push(HEX[usize::from(byte & 0x0f)] as char);
    }
    output
}

fn digest_bytes(bytes: &[u8]) -> String {
    hex_digest(&Sha256::digest(bytes))
}

fn member_inventory(bytes: &[u8]) -> AnyResult<MemberInventory> {
    let archive = ArchiveReader::new(bytes)?;
    let names = archive.file_names().map(str::to_owned).collect::<Vec<_>>();
    let mut members = BTreeMap::new();
    for name in names {
        let data = archive.read(&name)?;
        members.insert(name, data);
    }
    let mut digest = Sha256::new();
    let mut total = 0usize;
    for (name, data) in &members {
        digest.update(name.as_bytes());
        digest.update([0]);
        digest.update((data.len() as u64).to_le_bytes());
        digest.update(data);
        total = total.saturating_add(data.len());
    }
    Ok(MemberInventory {
        members,
        sha256: hex_digest(&digest.finalize()),
        total_decompressed_bytes: total,
    })
}

#[derive(Clone, Copy, Debug)]
struct Profile {
    name: &'static str,
    payload_bytes: usize,
    unrelated_relationships: usize,
}

const SMALL: Profile = Profile {
    name: "small",
    payload_bytes: 256,
    unrelated_relationships: 4,
};

const LARGE: Profile = Profile {
    name: "large",
    payload_bytes: 1 << 20,
    unrelated_relationships: 512,
};

fn profile(name: &str) -> AnyResult<Vec<Profile>> {
    match name {
        "small" => Ok(vec![SMALL]),
        "large" => Ok(vec![LARGE]),
        "all" => Ok(vec![SMALL, LARGE]),
        other => fail(format!(
            "unknown --profile {other}; use small, large, or all"
        )),
    }
}

fn opaque_payload(length: usize) -> Vec<u8> {
    // This is deliberately not a claimed BIFF12 or Calculation Chain grammar.
    // The owner contract preserves the stream as opaque source bytes.
    (0..length)
        .map(|index| {
            let value = (index as u64)
                .wrapping_mul(0x9e37_79b9)
                .wrapping_add(0x243f_6a88);
            value.to_le_bytes()[index % 8]
        })
        .collect()
}

fn package_with_chain(spec: Profile) -> AnyResult<Package> {
    let mut package = Package::create()?.into_opc();
    let workbook_name = package.main_document_part()?.partname().clone();
    let chain_name = PackURI::new("/xl/calcChain.bin")?;
    package.add_part(Box::new(BlobPart::new(
        chain_name,
        CONTENT_TYPE.to_owned(),
        opaque_payload(spec.payload_bytes),
    )));
    let workbook = package.get_part_mut(&workbook_name)?;
    let relationships = workbook.rels_mut();
    relationships.try_add_relationship(
        litchi_xlsb::calculation_chain::RELATIONSHIP_TYPE.to_owned(),
        "calcChain.bin".to_owned(),
        "rIdCalcChain".to_owned(),
        TargetMode::Internal,
    )?;
    for index in 0..spec.unrelated_relationships {
        relationships.try_add_relationship(
            "urn:litchi:benchmark:unrelated".to_owned(),
            format!("https://example.test/unrelated/{index:05}"),
            format!("rIdBench{index:05}"),
            TargetMode::External,
        )?;
    }
    Ok(Package::from_opc(package)?)
}

fn relationship_count(package: &Package) -> usize {
    let opc = package.opc_package();
    opc.rels().iter().count().saturating_add(
        opc.iter_parts()
            .map(|part| part.rels().iter().count())
            .sum(),
    )
}

fn logical_chain_bytes(snapshot: &Snapshot) -> usize {
    snapshot.part().map_or(0, |part| {
        part.len()
            .saturating_add(part.part_name().len())
            .saturating_add(part.content_type().len())
    })
}

struct Workload {
    spec: Profile,
    source_package: Package,
    source_snapshot: Snapshot,
    commit: Commit,
    inverse: Patch,
    changed_package: Package,
    source_bytes: Vec<u8>,
    changed_bytes: Vec<u8>,
    source_members: MemberInventory,
    changed_members: MemberInventory,
    part_count: usize,
    relationship_count: usize,
}

fn workload(spec: Profile) -> AnyResult<Workload> {
    let source_package = package_with_chain(spec)?;
    let source_snapshot = source_package.calculation_chain()?;
    check(
        source_snapshot.is_present(),
        "synthetic source owner is absent",
    )?;
    let source_part = source_snapshot
        .part()
        .ok_or_else(|| error("synthetic source owner is absent"))?;
    check(
        source_part.len() == spec.payload_bytes,
        "synthetic source payload length differs from profile",
    )?;
    let mut transaction = source_snapshot.edit();
    check(
        transaction.remove()?,
        "synthetic owner removal was not staged",
    )?;
    let commit = transaction.commit()?;
    check(
        commit.changed(),
        "synthetic removal did not publish a change",
    )?;
    let inverse = commit.patch().inverse();
    let changed_package = source_package.apply_calculation_chain(&commit)?;
    check(
        !changed_package.calculation_chain()?.is_present(),
        "synthetic removal publication still has an owner",
    )?;
    let source_bytes = source_package.to_bytes()?;
    let changed_bytes = changed_package.to_bytes()?;
    let source_members = member_inventory(&source_bytes)?;
    let changed_members = member_inventory(&changed_bytes)?;
    let part_count = source_package.opc_package().part_count();
    let relationship_count = relationship_count(&source_package);
    Ok(Workload {
        spec,
        source_package,
        source_snapshot,
        commit,
        inverse,
        changed_package,
        source_bytes,
        changed_bytes,
        source_members,
        changed_members,
        part_count,
        relationship_count,
    })
}

fn error(message: impl Into<String>) -> std::io::Error {
    std::io::Error::new(std::io::ErrorKind::InvalidData, message.into())
}

fn fail<T>(message: impl Into<String>) -> AnyResult<T> {
    Err(error(message).into())
}

fn check(condition: bool, message: impl Into<String>) -> AnyResult<()> {
    if condition { Ok(()) } else { fail(message) }
}

#[derive(Clone, Copy, Debug)]
enum Operation {
    SnapshotRead,
    SnapshotClone,
    OpcPackageClone,
    WorkbookRelationships,
    ChangedWorkbookRelationships,
    WithoutWorkbookRelationship,
    RootRelationships,
    RemovedSnapshotRead,
    ContentTypes,
    NoopEditCommit,
    RemovePlanCommit,
    RemoveApply,
    InverseApply,
    SaveToBytes,
    ReopenInverse,
}

impl Operation {
    fn parse(value: &str) -> AnyResult<Self> {
        match value {
            "snapshot_read" | "read" => Ok(Self::SnapshotRead),
            "snapshot_clone" | "clone" => Ok(Self::SnapshotClone),
            "opc_package_clone" | "package_clone" => Ok(Self::OpcPackageClone),
            "workbook_relationships" | "workbook_rels" => Ok(Self::WorkbookRelationships),
            "changed_workbook_relationships" | "changed_workbook_rels" => {
                Ok(Self::ChangedWorkbookRelationships)
            }
            "without_workbook_relationship" | "without_workbook_rel" => {
                Ok(Self::WithoutWorkbookRelationship)
            }
            "root_relationships" | "root_rels" => Ok(Self::RootRelationships),
            "removed_snapshot_read" | "removed_read" => Ok(Self::RemovedSnapshotRead),
            "content_types" | "content_types_capture" => Ok(Self::ContentTypes),
            "noop_edit_commit" | "noop" => Ok(Self::NoopEditCommit),
            "remove_plan_commit" | "remove" => Ok(Self::RemovePlanCommit),
            "remove_apply" | "apply" => Ok(Self::RemoveApply),
            "inverse_apply" | "inverse" => Ok(Self::InverseApply),
            "save_to_bytes" | "save" => Ok(Self::SaveToBytes),
            "reopen_inverse" | "reopen" => Ok(Self::ReopenInverse),
            other => fail(format!("unknown --op {other}")),
        }
    }

    const fn name(self) -> &'static str {
        match self {
            Self::SnapshotRead => "snapshot_read",
            Self::SnapshotClone => "snapshot_clone",
            Self::OpcPackageClone => "opc_package_clone",
            Self::WorkbookRelationships => "workbook_relationships",
            Self::ChangedWorkbookRelationships => "changed_workbook_relationships",
            Self::WithoutWorkbookRelationship => "without_workbook_relationship",
            Self::RootRelationships => "root_relationships",
            Self::RemovedSnapshotRead => "removed_snapshot_read",
            Self::ContentTypes => "content_types",
            Self::NoopEditCommit => "noop_edit_commit",
            Self::RemovePlanCommit => "remove_plan_commit",
            Self::RemoveApply => "remove_apply",
            Self::InverseApply => "inverse_apply",
            Self::SaveToBytes => "save_to_bytes",
            Self::ReopenInverse => "reopen_inverse",
        }
    }
}

enum TimedOutput {
    Snapshot(Snapshot),
    Commit(Commit),
    Package(Package),
    OpcPackage(OpcPackage),
    Relationships(OwnedRelationships),
    ContentTypes(OwnedContentTypes),
    Bytes(Vec<u8>),
}

fn timed_operation(operation: Operation, input: &Workload) -> AnyResult<Timed<TimedOutput>> {
    match operation {
        Operation::SnapshotRead => timed(|| {
            Ok(TimedOutput::Snapshot(
                input.source_package.calculation_chain()?,
            ))
        }),
        Operation::SnapshotClone => {
            timed(|| Ok(TimedOutput::Snapshot(input.source_snapshot.clone())))
        }
        Operation::OpcPackageClone => timed(|| {
            Ok(TimedOutput::OpcPackage(
                input.source_package.opc_package().clone(),
            ))
        }),
        Operation::WorkbookRelationships => {
            let workbook_name = input
                .source_package
                .opc_package()
                .main_document_part()?
                .partname()
                .clone();
            timed(|| {
                Ok(TimedOutput::Relationships(
                    input
                        .source_package
                        .opc_package()
                        .source_relationships_with_limits(&workbook_name, ReadLimits::default())?,
                ))
            })
        }
        Operation::ChangedWorkbookRelationships => {
            let workbook_name = input
                .changed_package
                .opc_package()
                .main_document_part()?
                .partname()
                .clone();
            timed(|| {
                Ok(TimedOutput::Relationships(
                    input
                        .changed_package
                        .opc_package()
                        .source_relationships_with_limits(&workbook_name, ReadLimits::default())?,
                ))
            })
        }
        Operation::WithoutWorkbookRelationship => {
            let workbook_name = input
                .source_package
                .opc_package()
                .main_document_part()?
                .partname()
                .clone();
            let relationships = input
                .source_package
                .opc_package()
                .source_relationships_with_limits(&workbook_name, ReadLimits::default())?;
            timed(|| {
                Ok(TimedOutput::Relationships(
                    relationships.without_relationship(
                        "rIdCalcChain",
                        ReadLimits::default().max_relationship_xml_bytes(),
                    )?,
                ))
            })
        }
        Operation::RootRelationships => {
            let root_name = PackURI::new("/")?;
            timed(|| {
                Ok(TimedOutput::Relationships(
                    input
                        .source_package
                        .opc_package()
                        .source_relationships_with_limits(&root_name, ReadLimits::default())?,
                ))
            })
        }
        Operation::RemovedSnapshotRead => timed(|| {
            Ok(TimedOutput::Snapshot(
                input.changed_package.calculation_chain()?,
            ))
        }),
        Operation::ContentTypes => timed(|| {
            Ok(TimedOutput::ContentTypes(
                input
                    .source_package
                    .opc_package()
                    .source_content_types_with_limits(ReadLimits::default())?,
            ))
        }),
        Operation::NoopEditCommit => {
            timed(|| Ok(TimedOutput::Commit(input.source_snapshot.edit().commit()?)))
        }
        Operation::RemovePlanCommit => timed(|| {
            let mut transaction = input.source_snapshot.edit();
            transaction.remove()?;
            Ok(TimedOutput::Commit(transaction.commit()?))
        }),
        Operation::RemoveApply => timed(|| {
            Ok(TimedOutput::Package(
                input
                    .source_package
                    .apply_calculation_chain(&input.commit)?,
            ))
        }),
        Operation::InverseApply => timed(|| {
            Ok(TimedOutput::Package(
                input
                    .changed_package
                    .apply_calculation_chain_patch(&input.inverse)?,
            ))
        }),
        Operation::SaveToBytes => {
            timed(|| Ok(TimedOutput::Bytes(input.changed_package.to_bytes()?)))
        }
        Operation::ReopenInverse => {
            let changed_bytes = input.changed_bytes.clone();
            timed(|| {
                let reopened = Package::from_bytes(changed_bytes)?;
                Ok(TimedOutput::Package(
                    reopened.apply_calculation_chain_patch(&input.inverse)?,
                ))
            })
        }
    }
}

fn counted_operation(operation: Operation, input: &Workload) -> AnyResult<Counted<TimedOutput>> {
    match operation {
        Operation::SnapshotRead => counted(|| {
            Ok(TimedOutput::Snapshot(
                input.source_package.calculation_chain()?,
            ))
        }),
        Operation::SnapshotClone => {
            counted(|| Ok(TimedOutput::Snapshot(input.source_snapshot.clone())))
        }
        Operation::OpcPackageClone => counted(|| {
            Ok(TimedOutput::OpcPackage(
                input.source_package.opc_package().clone(),
            ))
        }),
        Operation::WorkbookRelationships => {
            let workbook_name = input
                .source_package
                .opc_package()
                .main_document_part()?
                .partname()
                .clone();
            counted(|| {
                Ok(TimedOutput::Relationships(
                    input
                        .source_package
                        .opc_package()
                        .source_relationships_with_limits(&workbook_name, ReadLimits::default())?,
                ))
            })
        }
        Operation::ChangedWorkbookRelationships => {
            let workbook_name = input
                .changed_package
                .opc_package()
                .main_document_part()?
                .partname()
                .clone();
            counted(|| {
                Ok(TimedOutput::Relationships(
                    input
                        .changed_package
                        .opc_package()
                        .source_relationships_with_limits(&workbook_name, ReadLimits::default())?,
                ))
            })
        }
        Operation::WithoutWorkbookRelationship => {
            let workbook_name = input
                .source_package
                .opc_package()
                .main_document_part()?
                .partname()
                .clone();
            let relationships = input
                .source_package
                .opc_package()
                .source_relationships_with_limits(&workbook_name, ReadLimits::default())?;
            counted(|| {
                Ok(TimedOutput::Relationships(
                    relationships.without_relationship(
                        "rIdCalcChain",
                        ReadLimits::default().max_relationship_xml_bytes(),
                    )?,
                ))
            })
        }
        Operation::RootRelationships => {
            let root_name = PackURI::new("/")?;
            counted(|| {
                Ok(TimedOutput::Relationships(
                    input
                        .source_package
                        .opc_package()
                        .source_relationships_with_limits(&root_name, ReadLimits::default())?,
                ))
            })
        }
        Operation::RemovedSnapshotRead => counted(|| {
            Ok(TimedOutput::Snapshot(
                input.changed_package.calculation_chain()?,
            ))
        }),
        Operation::ContentTypes => counted(|| {
            Ok(TimedOutput::ContentTypes(
                input
                    .source_package
                    .opc_package()
                    .source_content_types_with_limits(ReadLimits::default())?,
            ))
        }),
        Operation::NoopEditCommit => {
            counted(|| Ok(TimedOutput::Commit(input.source_snapshot.edit().commit()?)))
        }
        Operation::RemovePlanCommit => counted(|| {
            let mut transaction = input.source_snapshot.edit();
            transaction.remove()?;
            Ok(TimedOutput::Commit(transaction.commit()?))
        }),
        Operation::RemoveApply => counted(|| {
            Ok(TimedOutput::Package(
                input
                    .source_package
                    .apply_calculation_chain(&input.commit)?,
            ))
        }),
        Operation::InverseApply => counted(|| {
            Ok(TimedOutput::Package(
                input
                    .changed_package
                    .apply_calculation_chain_patch(&input.inverse)?,
            ))
        }),
        Operation::SaveToBytes => {
            counted(|| Ok(TimedOutput::Bytes(input.changed_package.to_bytes()?)))
        }
        Operation::ReopenInverse => {
            let changed_bytes = input.changed_bytes.clone();
            counted(|| {
                let reopened = Package::from_bytes(changed_bytes)?;
                Ok(TimedOutput::Package(
                    reopened.apply_calculation_chain_patch(&input.inverse)?,
                ))
            })
        }
    }
}

fn operation_result(
    operation: Operation,
    input: &Workload,
    timed: Timed<TimedOutput>,
    sample: usize,
) -> AnyResult<Value> {
    let mut result = json!({
        "schema": 1,
        "kind": "xlsb_calculation_chain_measurement",
        "source_commit": SOURCE_COMMIT,
        "profile": input.spec.name,
        "operation": operation.name(),
        "payload_bytes": input.spec.payload_bytes,
        "unrelated_relationships": input.spec.unrelated_relationships,
        "part_count": input.part_count,
        "relationship_count": input.relationship_count,
        "source_archive_bytes": input.source_bytes.len(),
        "changed_archive_bytes": input.changed_bytes.len(),
        "source_member_count": input.source_members.members.len(),
        "changed_member_count": input.changed_members.members.len(),
        "source_decompressed_bytes": input.source_members.total_decompressed_bytes,
        "changed_decompressed_bytes": input.changed_members.total_decompressed_bytes,
        "sample": sample,
        "elapsed_ns": timed.elapsed_ns,
        "alloc_calls": timed.counters.alloc_calls,
        "allocated_bytes": timed.counters.allocated_bytes,
        "realloc_calls": timed.counters.realloc_calls,
        "reallocated_bytes": timed.counters.reallocated_bytes,
        "dealloc_calls": timed.counters.dealloc_calls,
        "deallocated_bytes": timed.counters.deallocated_bytes,
        "peak_live_bytes": timed.counters.peak_live_bytes,
        "end_live_delta": timed.counters.end_live_delta,
        "end_live_delta_note": "saturating subtraction; zero is not a leak proof",
    });
    let object = result
        .as_object_mut()
        .ok_or_else(|| error("measurement JSON must be an object"))?;
    match timed.output {
        TimedOutput::Snapshot(snapshot) => {
            object.insert(
                "result_kind".to_owned(),
                Value::String("snapshot".to_owned()),
            );
            object.insert("present".to_owned(), Value::Bool(snapshot.is_present()));
            object.insert(
                "logical_output_bytes".to_owned(),
                Value::from(logical_chain_bytes(&snapshot)),
            );
        }
        TimedOutput::Commit(commit) => {
            object.insert("result_kind".to_owned(), Value::String("commit".to_owned()));
            object.insert("changed".to_owned(), Value::Bool(commit.changed()));
            object.insert(
                "patch_empty".to_owned(),
                Value::Bool(commit.patch().is_empty()),
            );
            object.insert(
                "logical_output_bytes".to_owned(),
                Value::from(logical_chain_bytes(commit.snapshot())),
            );
        }
        TimedOutput::Package(package) => {
            let snapshot = package.calculation_chain()?;
            object.insert(
                "result_kind".to_owned(),
                Value::String("package".to_owned()),
            );
            object.insert("present".to_owned(), Value::Bool(snapshot.is_present()));
            object.insert(
                "logical_output_bytes".to_owned(),
                Value::from(logical_chain_bytes(&snapshot)),
            );
            drop(snapshot);
            drop(package);
        }
        TimedOutput::OpcPackage(package) => {
            object.insert(
                "result_kind".to_owned(),
                Value::String("opc_package".to_owned()),
            );
            object.insert(
                "part_count_output".to_owned(),
                Value::from(package.part_count()),
            );
            drop(package);
        }
        TimedOutput::Relationships(relationships) => {
            object.insert(
                "result_kind".to_owned(),
                Value::String("relationships".to_owned()),
            );
            object.insert(
                "logical_output_bytes".to_owned(),
                Value::from(relationships.bytes().len()),
            );
            object.insert(
                "member_present".to_owned(),
                Value::Bool(relationships.member_present()),
            );
            drop(relationships);
        }
        TimedOutput::ContentTypes(content_types) => {
            object.insert(
                "result_kind".to_owned(),
                Value::String("content_types".to_owned()),
            );
            object.insert(
                "logical_output_bytes".to_owned(),
                Value::from(content_types.bytes().len()),
            );
            drop(content_types);
        }
        TimedOutput::Bytes(bytes) => {
            object.insert("result_kind".to_owned(), Value::String("bytes".to_owned()));
            object.insert("output_bytes".to_owned(), Value::from(bytes.len()));
            object.insert(
                "output_sha256".to_owned(),
                Value::String(digest_bytes(&bytes)),
            );
        }
    }
    Ok(result)
}

fn allocation_result(
    operation: Operation,
    input: &Workload,
    counted: Counted<TimedOutput>,
    sample: usize,
) -> AnyResult<Value> {
    let logical_read_bytes = if matches!(operation, Operation::ReopenInverse) {
        input.changed_bytes.len()
    } else {
        0
    };
    let logical_read_calls = usize::from(logical_read_bytes != 0);
    let mut result = json!({
        "schema": 1,
        "kind": "xlsb_calculation_chain_allocation",
        "source_commit": SOURCE_COMMIT,
        "profile": input.spec.name,
        "operation": operation.name(),
        "payload_bytes": input.spec.payload_bytes,
        "unrelated_relationships": input.spec.unrelated_relationships,
        "part_count": input.part_count,
        "relationship_count": input.relationship_count,
        "source_archive_bytes": input.source_bytes.len(),
        "changed_archive_bytes": input.changed_bytes.len(),
        "source_member_count": input.source_members.members.len(),
        "changed_member_count": input.changed_members.members.len(),
        "source_decompressed_bytes": input.source_members.total_decompressed_bytes,
        "changed_decompressed_bytes": input.changed_members.total_decompressed_bytes,
        "sample": sample,
        "timed": false,
        "allocation_only": true,
        "clock_started": false,
        "prepared_input_clone_bytes": if matches!(operation, Operation::ReopenInverse) {
            input.changed_bytes.len()
        } else {
            0
        },
        "prepared_input_clone_note": "reopen input Vec clone is setup outside the allocator phase",
        "logical_memory_read_bytes": logical_read_bytes,
        "logical_memory_read_calls": logical_read_calls,
        "logical_memory_write_bytes": 0,
        "logical_memory_write_calls": 0,
        "io_accounting_note": "logical in-memory archive boundaries only; no OS file descriptors or syscalls",
        "alloc_calls": counted.counters.alloc_calls,
        "allocated_bytes": counted.counters.allocated_bytes,
        "realloc_calls": counted.counters.realloc_calls,
        "reallocated_bytes": counted.counters.reallocated_bytes,
        "dealloc_calls": counted.counters.dealloc_calls,
        "deallocated_bytes": counted.counters.deallocated_bytes,
        "peak_live_bytes": counted.counters.peak_live_bytes,
        "end_live_delta": counted.counters.end_live_delta,
        "end_live_delta_note": "saturating subtraction; zero is not a leak proof",
    });
    let object = result
        .as_object_mut()
        .ok_or_else(|| error("allocation JSON must be an object"))?;
    match counted.output {
        TimedOutput::Snapshot(snapshot) => {
            object.insert(
                "result_kind".to_owned(),
                Value::String("snapshot".to_owned()),
            );
            object.insert("present".to_owned(), Value::Bool(snapshot.is_present()));
            object.insert(
                "logical_output_bytes".to_owned(),
                Value::from(logical_chain_bytes(&snapshot)),
            );
        }
        TimedOutput::Commit(commit) => {
            object.insert("result_kind".to_owned(), Value::String("commit".to_owned()));
            object.insert("changed".to_owned(), Value::Bool(commit.changed()));
            object.insert(
                "patch_empty".to_owned(),
                Value::Bool(commit.patch().is_empty()),
            );
            object.insert(
                "logical_output_bytes".to_owned(),
                Value::from(logical_chain_bytes(commit.snapshot())),
            );
        }
        TimedOutput::Package(package) => {
            let snapshot = package.calculation_chain()?;
            object.insert(
                "result_kind".to_owned(),
                Value::String("package".to_owned()),
            );
            object.insert("present".to_owned(), Value::Bool(snapshot.is_present()));
            object.insert(
                "logical_output_bytes".to_owned(),
                Value::from(logical_chain_bytes(&snapshot)),
            );
            drop(snapshot);
            drop(package);
        }
        TimedOutput::OpcPackage(package) => {
            object.insert(
                "result_kind".to_owned(),
                Value::String("opc_package".to_owned()),
            );
            object.insert(
                "part_count_output".to_owned(),
                Value::from(package.part_count()),
            );
            drop(package);
        }
        TimedOutput::Relationships(relationships) => {
            object.insert(
                "result_kind".to_owned(),
                Value::String("relationships".to_owned()),
            );
            object.insert(
                "logical_output_bytes".to_owned(),
                Value::from(relationships.bytes().len()),
            );
            object.insert(
                "member_present".to_owned(),
                Value::Bool(relationships.member_present()),
            );
            drop(relationships);
        }
        TimedOutput::ContentTypes(content_types) => {
            object.insert(
                "result_kind".to_owned(),
                Value::String("content_types".to_owned()),
            );
            object.insert(
                "logical_output_bytes".to_owned(),
                Value::from(content_types.bytes().len()),
            );
            drop(content_types);
        }
        TimedOutput::Bytes(bytes) => {
            object.insert("result_kind".to_owned(), Value::String("bytes".to_owned()));
            object.insert("output_bytes".to_owned(), Value::from(bytes.len()));
            object.insert(
                "output_sha256".to_owned(),
                Value::String(digest_bytes(&bytes)),
            );
            object.insert(
                "logical_memory_write_bytes".to_owned(),
                Value::from(bytes.len()),
            );
            object.insert("logical_memory_write_calls".to_owned(), Value::from(1));
        }
    }
    Ok(result)
}

fn correctness(input: &Workload) -> AnyResult<Value> {
    let source_part = input
        .source_snapshot
        .part()
        .ok_or_else(|| error("correctness source owner is absent"))?;
    check(
        source_part.len() == input.spec.payload_bytes,
        "correctness source payload length differs from profile",
    )?;
    check(
        source_part.bytes() == opaque_payload(input.spec.payload_bytes).as_slice(),
        "correctness source payload changed",
    )?;
    let planned = input.commit.snapshot();
    check(!planned.is_present(), "planned removal still has an owner")?;
    check(
        input.commit.changed(),
        "planned removal is not marked changed",
    )?;
    check(
        !input.commit.patch().is_empty(),
        "planned removal patch is empty",
    )?;

    let changed_snapshot = input.changed_package.calculation_chain()?;
    check(
        !changed_snapshot.is_present(),
        "published removal still has an owner",
    )?;
    let reopened = Package::from_bytes(input.changed_bytes.clone())?;
    check(
        !reopened.calculation_chain()?.is_present(),
        "reopened removal still has an owner",
    )?;
    let restored = reopened.apply_calculation_chain_patch(&input.inverse)?;
    let restored_snapshot = restored.calculation_chain()?;
    check(
        restored_snapshot == input.source_snapshot,
        "inverse snapshot differs from source snapshot",
    )?;
    let restored_part = restored_snapshot
        .part()
        .ok_or_else(|| error("inverse source owner is absent"))?;
    check(
        restored_part.bytes() == source_part.bytes(),
        "inverse source payload differs from source payload",
    )?;
    let restored_bytes = restored.to_bytes()?;
    let restored_members = member_inventory(&restored_bytes)?;
    check(
        restored_members.members == input.source_members.members,
        "inverse decompressed-member map differs from source",
    )?;
    Ok(json!({
        "schema": 1,
        "kind": "xlsb_calculation_chain_correctness",
        "source_commit": SOURCE_COMMIT,
        "profile": input.spec.name,
        "payload_bytes": input.spec.payload_bytes,
        "unrelated_relationships": input.spec.unrelated_relationships,
        "part_count": input.part_count,
        "relationship_count": input.relationship_count,
        "source_archive_bytes": input.source_bytes.len(),
        "changed_archive_bytes": input.changed_bytes.len(),
        "source_member_count": input.source_members.members.len(),
        "changed_member_count": input.changed_members.members.len(),
        "source_decompressed_bytes": input.source_members.total_decompressed_bytes,
        "changed_decompressed_bytes": input.changed_members.total_decompressed_bytes,
        "source_members_sha256": input.source_members.sha256,
        "changed_members_sha256": input.changed_members.sha256,
        "restored_members_sha256": restored_members.sha256,
        "exact_decompressed_member_inverse": true,
        "opaque_payload_only": true,
        "timed": false,
    }))
}

const NATIVE_FIXTURES: &[&str] = &[
    "ooxml/xlsb/sample.xlsb",
    "ooxml/xlsb/bug66682.xlsb",
    "ooxml/xlsb/universal-content.xlsb",
    "ooxml/xlsb/62815.xlsb",
    "poi/test-data/spreadsheet/testVarious.xlsb",
    "poi/test-data/spreadsheet/62815.xlsb",
    "libreoffice-core/sc/qa/unit/data/xlsb/tdf108017_calcProtection.xlsb",
];

fn native_inventory(root: &Path) -> AnyResult<Value> {
    let mut fixtures = Vec::with_capacity(NATIVE_FIXTURES.len());
    for relative in NATIVE_FIXTURES {
        let path = root.join(relative);
        if !path.is_file() {
            fixtures.push(json!({
                "path": relative,
                "available": false,
            }));
            continue;
        }
        let bytes = fs::read(&path)?;
        let inventory = member_inventory(&bytes)?;
        let mut row = json!({
            "path": relative,
            "available": true,
            "archive_bytes": bytes.len(),
            "archive_sha256": digest_bytes(&bytes),
            "member_count": inventory.members.len(),
            "decompressed_bytes": inventory.total_decompressed_bytes,
            "members_sha256": inventory.sha256,
        });
        let object = row
            .as_object_mut()
            .ok_or_else(|| error("native inventory row must be an object"))?;
        match Package::from_bytes(bytes) {
            Ok(package) => match package.calculation_chain() {
                Ok(snapshot) => {
                    object.insert(
                        "calculation_chain_present".to_owned(),
                        Value::Bool(snapshot.is_present()),
                    );
                    if let Some(part) = snapshot.part() {
                        object.insert(
                            "calculation_chain_bytes".to_owned(),
                            Value::from(part.len()),
                        );
                        object.insert(
                            "calculation_chain_part_name".to_owned(),
                            Value::String(part.part_name().to_owned()),
                        );
                    }
                }
                Err(error) => {
                    object.insert(
                        "calculation_chain_error".to_owned(),
                        Value::String(error.to_string()),
                    );
                }
            },
            Err(error) => {
                object.insert("package_error".to_owned(), Value::String(error.to_string()));
            }
        }
        fixtures.push(row);
    }
    Ok(json!({
        "schema": 1,
        "kind": "xlsb_calculation_chain_native_inventory",
        "source_commit": SOURCE_COMMIT,
        "native_root": root,
        "fixtures": fixtures,
        "timed": false,
        "opaque_inventory_only": true,
    }))
}

fn argument(args: &[String], name: &str) -> Option<String> {
    args.windows(2)
        .find(|pair| pair[0] == name)
        .map(|pair| pair[1].clone())
}

fn timing_enabled() -> AnyResult<()> {
    if env::var("ALLOW_TIMED_RUN").ok().as_deref() == Some("1") {
        Ok(())
    } else {
        fail(
            "timed operations are disabled; set ALLOW_TIMED_RUN=1 only during the coordinated timing window",
        )
    }
}

fn main() -> AnyResult<()> {
    let args = env::args().collect::<Vec<_>>();
    let operation_name = argument(&args, "--op").unwrap_or_else(|| "correctness".to_owned());
    if operation_name == "native_inventory" {
        let root = argument(&args, "--native-root")
            .ok_or_else(|| error("native_inventory requires --native-root"))?;
        println!(
            "{}",
            serde_json::to_string(&native_inventory(Path::new(&root))?)?
        );
        return Ok(());
    }
    let profiles = profile(&argument(&args, "--profile").unwrap_or_else(|| "all".to_owned()))?;
    if operation_name == "correctness" {
        for spec in profiles {
            println!(
                "{}",
                serde_json::to_string(&correctness(&workload(spec)?)?)?
            );
        }
        return Ok(());
    }
    let mode = argument(&args, "--mode").unwrap_or_else(|| "timed".to_owned());
    if mode == "allocation" || mode == "allocations" || mode == "count" {
        let operation = Operation::parse(&operation_name)?;
        let warmups = argument(&args, "--warmups")
            .unwrap_or_else(|| "3".to_owned())
            .parse::<usize>()?;
        let samples = argument(&args, "--samples")
            .unwrap_or_else(|| "15".to_owned())
            .parse::<usize>()?;
        if samples == 0 {
            return fail("--samples must be greater than zero");
        }
        for spec in profiles {
            let input = workload(spec)?;
            for _ in 0..warmups {
                drop(counted_operation(operation, &input)?);
            }
            for sample in 0..samples {
                let measurement = counted_operation(operation, &input)?;
                println!(
                    "{}",
                    serde_json::to_string(&allocation_result(
                        operation,
                        &input,
                        measurement,
                        sample,
                    )?)?
                );
            }
        }
        return Ok(());
    }
    if mode != "timed" {
        return fail(format!("unknown --mode {mode}; use allocation or timed"));
    }
    timing_enabled()?;
    let operation = Operation::parse(&operation_name)?;
    let warmups = argument(&args, "--warmups")
        .unwrap_or_else(|| "3".to_owned())
        .parse::<usize>()?;
    let samples = argument(&args, "--samples")
        .unwrap_or_else(|| "15".to_owned())
        .parse::<usize>()?;
    if samples == 0 {
        return fail("--samples must be greater than zero");
    }
    for spec in profiles {
        let input = workload(spec)?;
        for _ in 0..warmups {
            drop(timed_operation(operation, &input)?);
        }
        for sample in 0..samples {
            let measurement = timed_operation(operation, &input)?;
            println!(
                "{}",
                serde_json::to_string(&operation_result(operation, &input, measurement, sample)?)?
            );
        }
    }
    Ok(())
}
