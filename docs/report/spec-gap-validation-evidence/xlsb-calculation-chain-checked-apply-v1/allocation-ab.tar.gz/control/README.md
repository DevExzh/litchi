# XLSB Calculation Chain allocation-only harness

This separate harness counts allocator and logical in-memory archive work for
the public Calculation Chain owner from committed source
`c40e4522309167bef1232ea22d36923c8f31d7b3`. It lives outside the repository so
the production checkout and the historical Volatile Dependencies evidence stay
unchanged. The source checkout is
`/var/tmp/litchi-xlsb-calculation-chain-source-c40`; the native fixture copy is
`/var/tmp/litchi-xlsb-calculation-chain-native-c40-selected`.

The timing harness and its earlier correctness artifacts remain at
`/var/tmp/litchi-xlsb-calculation-chain-harness-c40`. This copy adds a separate
`--mode allocation` path and writes new raw results, leaving those artifacts
unchanged.

The owner is intentionally opaque. The local XLSB specification does not
provide a normative Calculation Chain payload grammar, so synthetic payloads
are deterministic byte streams used only to exercise bounded preservation and
source-bound remove/inverse publication. The harness never calls the generic
BIFF12 diagnostic and makes no semantic payload claim.

## Workload

Each setup starts with `Package::create()`, adds one Workbook-owned
`application/vnd.ms-excel.calcChain` part, and adds unrelated external
Workbook relationships. Setup serializes and inventories the source and
removed packages before any timed or allocation phase. The two profiles are:

| profile | opaque owner bytes | unrelated external relationships |
| --- | ---: | ---: |
| `small` | 256 | 4 |
| `large` | 1,048,576 | 512 |

The relationship count and compressed/decompressed archive sizes are emitted
with every row. The dimensions vary part payload and relationship metadata
together so whole-package and source-token clone costs remain visible. The
payload is generated from a fixed byte function and is never decoded.

The operation names map to these public API boundaries:

| operation | measured call |
| --- | --- |
| `snapshot_read` | `Package::calculation_chain()` |
| `snapshot_clone` | `Snapshot::clone()` |
| `noop_edit_commit` | detached no-op transaction commit |
| `remove_plan_commit` | detached removal transaction commit |
| `remove_apply` | source-checked removal publication |
| `inverse_apply` | source-checked inverse publication |
| `save_to_bytes` | changed package `to_bytes()` |
| `reopen_inverse` | `from_bytes` followed by inverse publication |

The CRUD checklist is represented by snapshot capture/read, a no-op edit, an
owner removal, source publication, and inverse restoration. The correctness
command proves the no-op/removal state distinctions and the decompressed-member
inverse; it does not treat an opaque payload as a typed update case.

Each allocation-only operation black-boxes its returned object before closing
the allocator phase. The global counting allocator reports allocation and
deallocation calls and bytes, reallocations, phase peak live bytes, and the
end live-byte delta. `end_live_delta` is a retained-result indicator with
saturating subtraction; it is not a leak proof. Archive member inventories and
correctness checks run outside the measured closure.

The allocation mode never calls `Instant::now()` and emits
`clock_started=false`. `logical_memory_read_*` and
`logical_memory_write_*` count only the in-memory archive boundaries: inverse
reopen accounts for the changed archive bytes consumed by `from_bytes`, and
`save_to_bytes` accounts for the bytes returned by `to_bytes`. They are not OS
syscall counters; the operations use no filesystem descriptors.
`prepared_input_clone_bytes` records the caller-side `Vec` clone deliberately
kept outside the allocator phase for `reopen_inverse`.

## Correctness and native inventory

The default command is untimed correctness validation. It checks source and
removed presence, source payload bytes, changed and inverse snapshots, reopened
source publication, and equality of decompressed archive member maps after
inverse publication. It reports `opaque_payload_only=true` and
`timed=false`.

`native_inventory` reads a fixed list of XLSB fixtures from a separately copied
native root. It records raw archive SHA-256, member inventory SHA-256, member
count, decompressed bytes, and whether the public owner API observes a chain.
It does not assert a Calculation Chain grammar. Missing fixtures are reported
as unavailable rather than substituted silently.

## Build and validation

All commands use the pinned toolchain and an isolated target:

```text
RUSTUP_HOME=/tmp/litchi-spec-gap-rustup
CARGO_TARGET_DIR=/var/tmp/litchi-xlsb-calculation-chain-target-195
cargo +1.95.0 build --release --locked
cargo +1.95.0 check --locked
cargo +1.95.0 clippy --locked -- -D warnings
```

Validation commands used for this harness are:

```text
target/release/xlsb-calculation-chain-performance --op correctness --profile all
target/release/xlsb-calculation-chain-performance \
  --op native_inventory \
  --native-root /var/tmp/litchi-xlsb-calculation-chain-native-c40-selected
```

The allocation-only command is:

```text
target/release/xlsb-calculation-chain-performance \
  --mode allocation --op snapshot_read --profile all \
  --warmups 3 --samples 15
```

Run the same command for each operation listed above. It requires no timing
environment variable and produces allocation/count results only. Timed
operations still refuse to start unless `ALLOW_TIMED_RUN=1` is explicitly set.
No wall-clock timing samples are part of this allocation receipt. A later
runner must use the immutable source and native roots, retain the exact
`Cargo.lock`, use a quiet host window, and report any CPU or I/O isolation
limits. These are absolute allocation/count measurements only; they contain no
legacy baseline and support no performance improvement claim by themselves.
