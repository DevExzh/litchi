# `litchi-opc` README pending-delta review

Reviewed the 13-line pending `crates/litchi-opc/README.md` delta in `/home/zhuhe/code/litchi-spec-gaps` against committed source and tests at `8b2cca3c7559be36e96cc1b862ed5fafbc93f634`. Dirty worktree files and external probes were excluded.

The exact README preimage (committed blob) is SHA-256 `33bb795481f235cc87a16faff0645cd9cd70bf4a2d2c83bace106874141b734e`. The pending postimage is `44ec111b12d296995017e6301da71cf93ed10f0e91a60e1a5db69d1cbdd56276`; the binary git diff hash is `f637dd9c05993d6831d7f7a1aeebd48a298b6b5ccc808e6bdd688b1f9640f190`.

All claims are supported:

- Custom Data storage, connection UID rebinding, source proofs, and exact inverse publication are implemented in `custom_data/package.rs:171-184,432-480,563-591,735-743`; tests at `1615-1665`, `1844-1866`, and `1941-2020` cover the claim.
- Data Model load-version edits, descriptor creation/removal, source-bound publication, and inverse restoration are implemented in `workbook/data_model/package.rs:763-803,908-1000,1034-1084`, exposed by `package.rs:269-312`, and tested in `data_model_opaque_context.rs`, `data_model_native.rs`, and package tests. Existing opaque inner structural replacement remains intentionally refused without identity proof; the README does not overclaim it.
- Survey scalar edits build one `OwnedAttributeUpdate` batch in `survey/source.rs:300-319,443-453`; the committed scalar test at `survey.rs:4392-4506` verifies comments, namespaces, lexical source context, and inverse restoration.
- Survey property insert/remove/replace operations build schema-ordered `OwnedElementUpdate` batches in `survey/source/properties.rs:219-283`; tests at `survey.rs:4244-4361` verify neighboring source and inverse behavior.
- Question sequence rewriting retains/copies source children under one original parent through `replace_child_sequence` (`survey/source/questions.rs:97-193`); table-owned column-name resolution is in `survey.rs:3361-3409,3463-3476`; tests at `4094-4162` and `5455-5472` cover both.
- Survey entries retain `source_xml_part` proofs at `survey.rs:1843-1856`, and patch/remove inverse restoration is covered at `4510-4520` and `5508-5534`.
- `SourceXmlPart` remains publicly exported by `litchi-opc/src/lib.rs:85-88`; positional range proofs, bounded splices, output precharging, and validation remain in `xml_splice.rs:48-127,148-203,400-550`.

**CLEAR.** No wording correction is required. The integration README delta is accurate as written. No primary or integration files were modified.
