# Exact CRUD selector registry v2 candidate

Base: `8b2cca3c7559be36e96cc1b862ed5fafbc93f634`

This immutable candidate hardens the schema-v2 non-iWork CRUD matrix binding. It
lexes the authoritative Rust source with nested block-comment, raw-string, and
escaped-string handling, then accepts only the unit-variant `Case` enum and an
exhaustive direct `Case::name` match with literal results. Unsupported syntax,
missing arms, duplicate arms, wildcard arms, and expression results fail closed.
The production selector source remains untouched.

The registry contains `443` names in exact
`Case::name` order with SHA-256
`13730d7842c6572d48389b7d297a1437ee87b45e21b9144490d0998fdb070026`; the matrix has 33 representative
mappings and 410 explicit exclusions. The historical
`crud-coverage-index-v1.json` remains byte-stable. This feature adds no timing or
performance-completion claim.

The focused tests include nested comments, escaped and raw literals, a commented
arm plus wildcard substitution, a missing arm, and a non-literal arm expression.
Review `candidate-manifest.json`, `candidate.patch`, `preimages/`, and
`verification.log`; root should apply only the six listed owned paths.

## Review provenance

The copied `independent-review-receipt.json` is retained unchanged as the V1
blocker record and is not V2 identity evidence. The actual V2 independent review
is `independent-review-v2-receipt.md` (SHA-256
`78c6936364173462da959ec0ae0cca4c049bcdd526315e28ddddffd198abd93d`).
`v2-supersession-binding.json` binds that receipt to the current candidate
manifest SHA-256 `2aa05aa7fa0f73c82f1b5ec3c4f219a485ca736fedf2607ded2acc10a946e329`,
the current patch SHA-256
`76710f748911d17e72593eab077fce4a2dfd2ac5b2e4645814f3d991ba930602`, and all
six owned source artifacts.
