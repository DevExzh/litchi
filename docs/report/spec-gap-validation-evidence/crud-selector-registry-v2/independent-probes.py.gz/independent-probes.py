import copy
import hashlib
import json
import sys
from pathlib import Path

root = Path('/var/tmp/litchi-crud-selector-exact-v2-candidate-20260910')
sys.path.insert(0, str(root))
from tools.validate_crud_coverage_index import (  # noqa: E402
    ValidationError,
    _selector_registry_names,
    validate_index,
)

source_path = root / 'tools/perf-baseline/src/lib.rs'
source = source_path.read_text(encoding='utf-8')
index = json.loads((root / 'docs/performance/crud-coverage-index-v2.json').read_text(encoding='utf-8'))
catalog = json.loads((root / 'docs/performance/results/perf-corpus-manifest-v2.json').read_text(encoding='utf-8'))
checklist = (root / 'docs/CRUD_Scenario_Checklist.md').read_text(encoding='utf-8')

names = _selector_registry_names(source)
assert len(names) == 443
assert hashlib.sha256(''.join(name + '\n' for name in names).encode()).hexdigest() == '13730d7842c6572d48389b7d297a1437ee87b45e21b9144490d0998fdb070026'
assert names == index['selector_registry']['selector_names']
assert validate_index(index, catalog, source, checklist, repo_root=root) == (15, 33)

results = {'baseline': 'pass', 'accepted': [], 'rejected': []}
def accept(label, mutated):
    got = _selector_registry_names(mutated)
    assert got == names, label
    results['accepted'].append(label)
def reject(label, mutated):
    try:
        _selector_registry_names(mutated)
    except ValidationError:
        results['rejected'].append(label)
    else:
        raise AssertionError(label + ' was accepted')

# Lexer must ignore nested comments, normal escaped strings, and raw strings.
noise = ('/* outer /* Self::Fake => "fake", */ */\n'
         'const _ESCAPED: &str = "Self::Fake => \\\"fake\\\",";\n'
         'const _RAW: &str = r###"Self::Raw => "raw", /* nested */"###;\n')
accept('nested-comments-and-string-literals', source.replace('enum Case {', noise + 'enum Case {', 1))

# Valid literal forms supported by the lexer/grammar.
accept('raw-selector-literal', source.replace('Self::ZipIndex => "zip_index",', 'Self::ZipIndex => r#"zip_index"#,', 1))
accept('escaped-selector-literal', source.replace('Self::ZipIndex => "zip_index",', r'Self::ZipIndex => "zip\x5findex",', 1))
accept('unicode-selector-literal', source.replace('Self::ZipIndex => "zip_index",', r'Self::ZipIndex => "zip_\u{69}ndex",', 1))

# Every lexical adversary must fail closed.
commented = source.replace('            Self::ZipIndex => "zip_index",', '            // Self::ZipIndex => "zip_index",', 1)
commented = commented.replace('            Self::OdsFileSourceCellBatchSweep => "ods_file_source_cell_batch_sweep",', '            Self::OdsFileSourceCellBatchSweep => "ods_file_source_cell_batch_sweep",\n            _ => "wrong_zip_index",', 1)
reject('commented-arm-plus-wildcard', commented)
reject('missing-arm', source.replace('            Self::ZipIndex => "zip_index",\n', '', 1))
reject('expression-arm', source.replace('            Self::ZipIndex => "zip_index",', '            Self::ZipIndex => concat!("zip", "_index"),', 1))
reject('byte-string-arm', source.replace('            Self::ZipIndex => "zip_index",', '            Self::ZipIndex => b"zip_index",', 1))
reject('duplicate-arm', source.replace('            Self::ZipIndex => "zip_index",', '            Self::ZipIndex => "zip_index",\n            Self::ZipIndex => "zip_index_2",', 1))
reject('tuple-variant', source.replace('    ZipIndex,', '    ZipIndex(),', 1))
reject('unterminated-nested-comment', source.replace('enum Case {', '/* unterminated /* enum Case {', 1))
reject('unclosed-string', source.replace('            Self::ZipIndex => "zip_index",', '            Self::ZipIndex => "zip_index,', 1))
reject('invalid-selector-escape', source.replace('            Self::ZipIndex => "zip_index",', r'Self::ZipIndex => "zip\qindex",', 1))

# Coverage and binding adversaries are checked against the real source and catalog.
for label, mutate in [
    ('registry-name-reorder', lambda i: (i['selector_registry']['selector_names'].__setitem__(slice(0, 2), i['selector_registry']['selector_names'][1::-1]), i)[1]),
    ('registry-name-delete', lambda i: (i['selector_registry']['selector_names'].pop(), i)[1]),
    ('coverage-exclusion-delete', lambda i: (i['selector_registry']['coverage']['excluded'].pop(), i)[1]),
    ('mapped-status-mismatch', lambda i: (i['selector_registry']['coverage']['mapped'][0].__setitem__('status', 'correctness-only' if i['selector_registry']['coverage']['mapped'][0]['status'] == 'measured' else 'measured'), i)[1]),
]:
    candidate = copy.deepcopy(index)
    mutate(candidate)
    try:
        validate_index(candidate, catalog, source, checklist, repo_root=root)
    except ValidationError:
        results['rejected'].append(label)
    else:
        raise AssertionError(label + ' was accepted')

# True source binding: changing the authoritative source output must fail even
# if an attacker recomputes the registry digest/list around the mutation.
source_mutated = source.replace('Self::ZipIndex => "zip_index",', 'Self::ZipIndex => "zip_index_attacker",', 1)
try:
    validate_index(index, catalog, source_mutated, checklist, repo_root=root)
except ValidationError:
    results['rejected'].append('source-output-mutation')
else:
    raise AssertionError('source-output-mutation was accepted')

# Count/list/partition facts.
coverage = index['selector_registry']['coverage']
assert len(coverage['mapped']) == 33
assert len(coverage['excluded']) == 410
assert {x['selector'] for x in coverage['mapped']} | {x['selector'] for x in coverage['excluded']} == set(names)
assert all(x['reason'] == 'not-selected-in-representative-matrix' for x in coverage['excluded'])
assert all(x['category_id'] in {c['id'] for c in index['categories']} for x in coverage['mapped'])
results['counts'] = {'selectors': len(names), 'mapped': len(coverage['mapped']), 'excluded': len(coverage['excluded'])}
print(json.dumps(results, sort_keys=True))
