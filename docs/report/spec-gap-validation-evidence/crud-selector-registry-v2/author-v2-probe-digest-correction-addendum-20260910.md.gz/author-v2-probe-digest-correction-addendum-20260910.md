# Selector V2 probe-digest correction addendum

Date: 2026-09-10 UTC

This is an additive provenance correction. It does not modify the retained V1 receipt or the existing V2 review.

- Retained V1 receipt: `independent-review-receipt.json`, SHA-256 `42e3e9169ce286c034c713247560e112d6507b32e6f82384a5097f94dd365fb2`.
- Existing V2 review: `independent-review-v2-receipt.md`, SHA-256 `78c6936364173462da959ec0ae0cca4c049bcdd526315e28ddddffd198abd93d`.
- Existing V2 supersession binding: `v2-supersession-binding.json`, SHA-256 `2680bf599d3ad1ef348b36ce41bf4d091130000ed4d8119d88a03e43bd46ce60`.

The V2 review line for `/var/tmp/litchi-crud-selector-v2-independent-probes-20260910.py` recorded the truncated/incorrect digest `673701c3b7772eee8f039a95785cb4aa909eaad67260cbf9080f2d9c18bc28d`. The actual immutable source file digest is:

- `/var/tmp/litchi-crud-selector-v2-independent-probes-20260910.py`: `673701c3b7772eee8f039a95785cb4aa9090eaad67260cbf9080f2d9c18bc28d`
- `/var/tmp/litchi-crud-selector-v2-independent-probes-20260910.json`: `cbe635c64054ec2b350a079fd5f8c320d59ee2f4143eaed8d010882937b1ede7`

The additive V2 publication is provenance-complete only when this correction is included with the existing supersession binding. It explicitly supersedes the one incorrect probe-digest assertion while retaining both historical receipts byte-for-byte. Root's V2 gate independently completed 110 Python tests and all five commands; this correction changes no production source, registry, candidate, patch, or functional result.
