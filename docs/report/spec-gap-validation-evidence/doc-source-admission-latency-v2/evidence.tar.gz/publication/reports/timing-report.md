# DOC/common source-admission latency A/B — corrected v2

This corrected run repeats v1 with output-equality validation outside the timed closure. It reports compound API observations only.

## Method

- Same frozen c859 control, eight-file candidate overlay, eight fixture hashes, CPU 0, release `+1.95.0 --locked`, and direct binaries as v1.
- Six alternating control/candidate rounds, five warmups and twenty timed samples per invocation; monotonic `Instant`; no allocator instrumentation.
- Fixture reads, Vec cloning, replacement setup, source snapshot setup for replacement, JSON writing, and result drops were outside the operation timer.
- `timed()` now applies `black_box` to the completed operation result before capturing elapsed time. No-op output equality is checked by `run_timed_samples` after the timer returns.
- Separate correctness gate: 34 boolean checks per side, all true.

## Aggregate compound observations

| Scenario | Control median | Candidate median | Candidate/control | Candidate p95/control p95 | Observation |
|---|---:|---:|---:|---:|---|
| `embedded_object_snapshot_open/small` | 0.027 ms | 0.026 ms | 0.994 (-0.6%) | 0.983 (-1.7%) | small-input result near timing/noise scale |
| `embedded_object_snapshot_open/large` | 0.974 ms | 0.795 ms | 0.816 (-18.4%) | 0.849 (-15.1%) | consistent large-input open reduction |
| `embedded_object_snapshot_open_noop_finish/small` | 0.027 ms | 0.027 ms | 0.983 (-1.7%) | 0.968 (-3.2%) | small-input result near timing/noise scale |
| `embedded_object_snapshot_open_noop_finish/large` | 1.138 ms | 1.396 ms | 1.227 (+22.7%) | 1.220 (+22.0%) | consistent large-input compound open+finish regression |
| `embedded_object_replace_storage_success_commit/small` | 0.144 ms | 0.140 ms | 0.976 (-2.4%) | 1.002 (+0.2%) | small-input result near timing/noise scale |
| `embedded_object_replace_storage_success_commit/large` | 6.749 ms | 6.554 ms | 0.971 (-2.9%) | 0.980 (-2.0%) | consistent median/tail reduction in this replacement compound |
| `common_editor_open_unique_noop_finish/small` | 0.014 ms | 0.014 ms | 1.003 (+0.3%) | 1.191 (+19.1%) | small-input result near timing/noise scale |
| `common_editor_open_unique_noop_finish/large` | 0.896 ms | 0.717 ms | 0.800 (-20.0%) | 0.809 (-19.1%) | consistent large-input compound open+finish reduction |

## Scope

- Large direct embedded `Snapshot::open`: candidate median 0.816x and p95 0.849x; paired invocation medians are 0.815x, while the aggregate p99 includes a host outlier (1.167x).
- Large embedded `Snapshot::open` plus no-op `finish`: candidate median 1.227x and p95 1.220x; p99 is 1.297x. The v1 regression persists after moving equality validation outside timing; this is a compound API observation, not a pure finish-only claim.
- Large successful replacement plus outer commit: candidate median 0.971x, p95 0.980x, p99 0.996x; all paired rounds remain below control (0.956–0.978).
- Large common unique open plus finish: candidate median 0.800x, p95 0.809x, and p99 0.805x; paired rounds range 0.796–0.803.
- Small cases remain near the timing/noise scale. This is one host, one pinned core, two deterministic sizes, one release profile, and one toolchain; it makes no broad performance or native-compatibility claim.

Raw samples, per-invocation load readings, commands, source/fixture manifests, correctness, environment, and provenance are in `reports/`.
