#!/usr/bin/env python3
"""Build, correctness-check, and optionally reproduce the latency publication.

The wrapper verifies the publication and two hashed source checkouts, copies the
bundle to a disposable work tree, builds both release binaries itself, runs a
fresh correctness gate, and (unless --build-and-check-only is used) invokes the
bundled latency runner only with those just-built binaries.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
from typing import Any

BINARY_NAME = "litchi-embedded-doc-allocation-v2"
CONTROL_COMMIT = "c85997bc0d93ea523731d6e7622b2300e1747255"
CANDIDATE_COMMIT = "b2e2ff8e1fdabd4ab16a67ddf077e6968bf5e668"
TOOLCHAIN = "+1.95.0"
# Keep repeated verification from writing unlisted bytecode into the bundle.
sys.dont_write_bytecode = True
CLEAR_ENV_EXACT = {
    "CARGO_BUILD_RUSTC",
    "CARGO_BUILD_TARGET",
    "CARGO_BUILD_RUSTFLAGS",
    "CARGO_BUILD_JOBS",
    "CARGO_BUILD_PIPELINING",
    "CARGO_INCREMENTAL",
    "CARGO_TARGET_CPU",
    "CARGO_TARGET_DIR",
    "RUSTC",
    "RUSTC_BOOTSTRAP",
    "RUSTC_WORKSPACE_WRAPPER",
    "RUSTC_WRAPPER",
    "RUSTFLAGS",
    "CARGO_ENCODED_RUSTFLAGS",
}
KNOWN_RELEVANT_BUILD_ENV = {
    "CARGO_BUILD_JOBS",
    "CARGO_BUILD_PIPELINING",
    "CARGO_BUILD_RUSTC",
    "CARGO_BUILD_RUSTFLAGS",
    "CARGO_BUILD_TARGET",
    "CARGO_INCREMENTAL",
    "CARGO_TARGET_CPU",
    "CARGO_TARGET_DIR",
    "CARGO_ENCODED_RUSTFLAGS",
    "RUSTC",
    "RUSTC_BOOTSTRAP",
    "RUSTC_WORKSPACE_WRAPPER",
    "RUSTC_WRAPPER",
    "RUSTFLAGS",
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def json_write(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + "\n")


def path_is_inside(path: Path, parent: Path) -> bool:
    try:
        path.relative_to(parent)
    except ValueError:
        return False
    return True


def verify_archive(bundle: Path) -> dict[str, Any]:
    manifest_path = bundle / "archive-manifest.json"
    manifest = json.loads(manifest_path.read_text())
    members = manifest["members"]
    checked = 0
    for entry in members:
        relative = Path(entry["path"])
        if relative.is_absolute() or ".." in relative.parts:
            raise RuntimeError(f"unsafe archive member path: {entry['path']}")
        path = bundle / relative
        if not path.is_file() or path.is_symlink():
            raise RuntimeError(f"archive member is not a regular file: {entry['path']}")
        if path.stat().st_size != entry["bytes"] or sha256(path) != entry["sha256"]:
            raise RuntimeError(f"archive member hash mismatch: {entry['path']}")
        checked += 1
    actual = {
        path.relative_to(bundle).as_posix()
        for path in bundle.rglob("*")
        if path.is_file() and path != manifest_path
    }
    listed = {entry["path"] for entry in members}
    if actual != listed:
        raise RuntimeError(f"archive member set mismatch: missing={listed - actual}, extra={actual - listed}")
    return {
        "manifest": "archive-manifest.json",
        "manifest_sha256": sha256(manifest_path),
        "members_checked": checked,
        "self_excluded": manifest.get("self_excluded", False),
    }


def load_latency_runner(bundle: Path):
    path = bundle / "run_latency.py"
    spec = importlib.util.spec_from_file_location("published_latency_runner", path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load latency runner: {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def verify_sources_and_fixtures(bundle: Path, control: Path, candidate: Path) -> dict[str, Any]:
    runner = load_latency_runner(bundle)
    source_manifest, fixture_manifest, source_counts, fixture_counts = runner.verify_sources_and_fixtures(
        control, candidate
    )
    return {
        "source_manifest": "reports/source-manifest.json",
        "source_manifest_sha256": sha256(bundle / "reports/source-manifest.json"),
        "source_base_commit": source_manifest["base_commit"],
        "candidate_overlay_commit": source_manifest["candidate_overlay_matches_commit"],
        "source_files_verified_per_side": source_counts,
        "fixture_manifest": "reports/fixture-manifest.json",
        "fixture_manifest_sha256": sha256(bundle / "reports/fixture-manifest.json"),
        "fixture_files_verified_per_side": fixture_counts,
        "fixture_count": len(fixture_manifest),
    }


def env_names_to_clear(environment: dict[str, str]) -> list[str]:
    names = set()
    for name in environment:
        upper = name.upper()
        if (
            name in CLEAR_ENV_EXACT
            or upper.startswith("CARGO_PROFILE_")
            or upper.startswith("CARGO_BUILD_")
            or upper.startswith("CARGO_TARGET_")
            or "RUSTFLAGS" in upper
            or upper.endswith("TARGET_CPU")
        ):
            names.add(name)
    return sorted(names)


def environment_record(original: dict[str, str], names: list[str]) -> dict[str, Any]:
    profile_overrides = sorted(name for name in original if name.upper().startswith("CARGO_PROFILE_"))
    profile_release_overrides = sorted(
        name for name in original if name.upper().startswith("CARGO_PROFILE_RELEASE_")
    )
    build_overrides = sorted(name for name in original if name.upper().startswith("CARGO_BUILD_"))
    target_overrides = sorted(name for name in original if name.upper().startswith("CARGO_TARGET_"))
    target_cpu_names = sorted(
        name for name in original
        if name.upper().endswith("TARGET_CPU") or "RUSTFLAGS" in name.upper()
    )
    relevant_names = sorted(set(names) | KNOWN_RELEVANT_BUILD_ENV)
    return {
        "cleared_environment_names": names,
        "cleared_environment_values": {name: original[name] for name in names},
        "checked_relevant_environment_values": {
            name: original.get(name) for name in relevant_names
        },
        "cargo_profile_overrides": {
            "all_present": profile_overrides,
            "release_present": profile_release_overrides,
        },
        "cargo_build_overrides_present": build_overrides,
        "cargo_target_overrides_present": target_overrides,
        "target_cpu_related_names_present": target_cpu_names,
    }


def sanitized_build_environment(target_dir: Path) -> tuple[dict[str, str], dict[str, Any]]:
    original = dict(os.environ)
    names = env_names_to_clear(original)
    environment = dict(original)
    record = environment_record(original, names)
    for name in names:
        environment.pop(name, None)
    previous_target_dir = original.get("CARGO_TARGET_DIR")
    environment["CARGO_TARGET_DIR"] = str(target_dir)
    record.update({
        "overridden_environment_values": {
            "CARGO_TARGET_DIR": {
                "before": previous_target_dir,
                "after": str(target_dir),
            }
        },
        "target_cpu_overrides_cleared": True,
        "release_profile_overrides_cleared": True,
    })
    return environment, record


def sanitized_runtime_environment(harness_root: Path) -> tuple[dict[str, str], dict[str, Any]]:
    original = dict(os.environ)
    names = env_names_to_clear(original)
    environment = dict(original)
    for name in names:
        environment.pop(name, None)
    environment["HARNESS_ROOT"] = str(harness_root)
    record = environment_record(original, names)
    record["set_environment_values"] = {"HARNESS_ROOT": str(harness_root)}
    return environment, record


def command_record(
    name: str,
    argv: list[str],
    cwd: Path,
    log: Path | None,
    environment: dict[str, Any] | None = None,
) -> dict[str, Any]:
    value: dict[str, Any] = {
        "name": name,
        "argv": argv,
        "cwd": str(cwd),
    }
    if log is not None:
        value["log"] = str(log)
    if environment is not None:
        value["environment"] = environment
    return value


def run_build(
    *,
    side: str,
    bundle: Path,
    target: Path,
    output: Path,
    records: list[dict[str, Any]],
) -> tuple[Path, dict[str, Any]]:
    target.mkdir(parents=True, exist_ok=True)
    environment, environment_record = sanitized_build_environment(target)
    argv = [
        "cargo",
        TOOLCHAIN,
        "build",
        "--release",
        "--locked",
        "--jobs",
        "4",
    ]
    if side == "candidate":
        argv += ["--features", "candidate"]
    argv += ["--manifest-path", str(bundle / side / "Cargo.toml")]
    log = output / f"build-{side}.log"
    record = command_record(side + "-build", argv, bundle / side, log, environment_record)
    records.append(record)
    with log.open("w") as stream:
        subprocess.run(argv, cwd=bundle / side, env=environment, stdout=stream, stderr=subprocess.STDOUT, check=True)
    binary = target / "release" / BINARY_NAME
    if not binary.is_file():
        raise RuntimeError(f"build did not produce {binary}")
    metadata = {
        "side": side,
        "source_commit": CONTROL_COMMIT,
        "candidate_overlay_commit": CANDIDATE_COMMIT if side == "candidate" else None,
        "manifest": f"{side}/Cargo.toml",
        "lockfile": f"{side}/Cargo.lock",
        "target_dir": str(target),
        "binary": str(binary),
        "binary_bytes": binary.stat().st_size,
        "binary_sha256": sha256(binary),
        "built_by_wrapper": True,
        "build_command_index": len(records) - 1,
    }
    return binary, metadata


def run_fresh_correctness(
    *,
    side: str,
    bundle: Path,
    binary: Path,
    output: Path,
    records: list[dict[str, Any]],
) -> dict[str, Any]:
    environment, environment_record = sanitized_runtime_environment(bundle / side)
    argv = [str(binary), "correctness"]
    log = output / f"correctness-{side}.log"
    records.append(command_record(side + "-correctness", argv, bundle / side, log, environment_record))
    with log.open("w") as stream:
        subprocess.run(argv, cwd=bundle / side, env=environment, stdout=stream, stderr=subprocess.STDOUT, check=True)
    report_path = bundle / side / "reports/correctness.json"
    report = json.loads(report_path.read_text())
    booleans = [
        value
        for profile in report["embedded_object"].values()
        for value in profile.values()
        if isinstance(value, bool)
    ]
    if len(booleans) != 34 or not all(booleans):
        raise RuntimeError(f"fresh correctness failed for {side}: {len(booleans)} checks")
    if report.get("source_commit") != CONTROL_COMMIT:
        raise RuntimeError(f"fresh correctness source commit mismatch for {side}")
    if report.get("timed") is not False:
        raise RuntimeError(f"fresh correctness report is unexpectedly timed for {side}")
    fresh_path = output / f"fresh-correctness-{side}.json"
    shutil.copy2(report_path, fresh_path)
    return {
        "side": side,
        "report": str(fresh_path),
        "boolean_checks": len(booleans),
        "all_boolean_checks_true": all(booleans),
        "source_commit": report["source_commit"],
        "timed": report["timed"],
        "binary_sha256_before_latency": sha256(binary),
    }


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--control-source", required=True, type=Path)
    parser.add_argument("--candidate-source", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path,
                        help="new directory for build/correctness receipt and optional latency output")
    parser.add_argument("--build-and-check-only", action="store_true",
                        help="build and fresh-check both binaries without running the latency samples")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    bundle = Path(__file__).resolve().parent
    control_source = args.control_source.resolve()
    candidate_source = args.candidate_source.resolve()
    output = args.output.resolve()
    if path_is_inside(output, bundle):
        raise SystemExit("--output must be outside the publication bundle")
    if output.exists() and any(output.iterdir()):
        raise SystemExit(f"--output must be a new or empty directory: {output}")
    output.mkdir(parents=True, exist_ok=True)
    archive_record = verify_archive(bundle)
    records: list[dict[str, Any]] = []
    receipt: dict[str, Any] = {
        "format": "litchi-doc-latency-v2-reproduction/1",
        "publication": archive_record,
        "sources": {
            "control": str(control_source),
            "candidate": str(candidate_source),
            "control_commit": CONTROL_COMMIT,
            "candidate_overlay_commit": CANDIDATE_COMMIT,
        },
        "build": {
            "toolchain": TOOLCHAIN,
            "release": True,
            "locked": True,
            "allocator_instrumentation": False,
        },
        "commands": records,
        "fresh_correctness": {},
        "latency": {"executed": False},
    }

    with tempfile.TemporaryDirectory(prefix="litchi-doc-latency-v2-work-", dir=str(output.parent)) as temporary:
        work = Path(temporary) / "bundle"
        shutil.copytree(bundle, work, symlinks=False)
        receipt["work_bundle"] = "throwaway bundle copy"
        receipt["throwaway_archive"] = verify_archive(work)
        preflight = verify_sources_and_fixtures(work, control_source, candidate_source)
        receipt["preflight"] = preflight
        json_write(output / "preflight-source-fixture-verification.json", preflight)

        links = work / "source-checkouts"
        links.mkdir()
        (links / "control").symlink_to(control_source)
        (links / "candidate").symlink_to(candidate_source)
        targets = {
            "control": work / "target-control",
            "candidate": work / "target-candidate",
        }
        binaries: dict[str, Path] = {}
        binary_metadata: dict[str, Any] = {}
        for side in ("control", "candidate"):
            binary, metadata = run_build(
                side=side,
                bundle=work,
                target=targets[side],
                output=output,
                records=records,
            )
            binaries[side] = binary
            binary_metadata[side] = metadata
            receipt["build"][side] = metadata
            json_write(output / "reproduction.json", receipt)

        for side in ("control", "candidate"):
            receipt["fresh_correctness"][side] = run_fresh_correctness(
                side=side,
                bundle=work,
                binary=binaries[side],
                output=output,
                records=records,
            )
            json_write(output / "reproduction.json", receipt)

        if not args.build_and_check_only:
            latency_output = output / "latency"
            latency_argv = [
                sys.executable,
                str(work / "run_latency.py"),
                "--control-source",
                str(control_source),
                "--candidate-source",
                str(candidate_source),
                "--control-target",
                str(targets["control"]),
                "--candidate-target",
                str(targets["candidate"]),
                "--run-dir",
                str(latency_output),
            ]
            latency_log = output / "latency-runner.log"
            runtime_environment, runtime_record = sanitized_runtime_environment(work)
            records.append(command_record("latency-runner", latency_argv, work, latency_log, runtime_record))
            with latency_log.open("w") as stream:
                subprocess.run(
                    latency_argv,
                    cwd=work,
                    env=runtime_environment,
                    stdout=stream,
                    stderr=subprocess.STDOUT,
                    check=True,
                )
            post_hashes = {side: sha256(binaries[side]) for side in ("control", "candidate")}
            for side in ("control", "candidate"):
                if post_hashes[side] != binary_metadata[side]["binary_sha256"]:
                    raise RuntimeError(f"built binary changed before/after latency run: {side}")
            receipt["latency"] = {
                "executed": True,
                "runner": "run_latency.py",
                "output": str(latency_output),
                "binary_sha256_before_and_after": post_hashes,
                "binary_provenance": {
                    side: {
                        "built_by_wrapper": binary_metadata[side]["built_by_wrapper"],
                        "build_command_index": binary_metadata[side]["build_command_index"],
                        "sha256": binary_metadata[side]["binary_sha256"],
                    }
                    for side in ("control", "candidate")
                },
            }

    receipt["commands"] = records
    receipt["completed"] = True
    json_write(output / "reproduction.json", receipt)
    print(f"wrote {output / 'reproduction.json'}")


if __name__ == "__main__":
    main()
