# DOC/common source-admission latency: corrected v2 publication

This directory is a relocatable evidence bundle for the corrected v2 wall-clock
run. It contains the final reports, the identical control/candidate harnesses,
eight fixtures for each side, the 769-path source manifest, and the reviewed
eight-file candidate overlay. It intentionally contains no source checkout and
no Cargo target directory.

The frozen comparison is control commit
`c85997bc0d93ea523731d6e7622b2300e1747255` versus the candidate content named by
overlay commit `b2e2ff8e1fdabd4ab16a67ddf077e6968bf5e668`. The candidate overlay
is recorded in `candidate-source.patch` and `reports/candidate-overlay-manifest.json`.
The manifest and patch are sufficient to verify either pre-existing clones or a
candidate clone made by applying the patch to the frozen control checkout.

## What was measured

The run uses six alternating rounds, five warmups, twenty timed samples per
invocation, `std::time::Instant`, CPU 0, Rust `+1.95.0`, release mode, and
`--locked`. Fixture reads, construction of the `common_targets()`/
`common_limits()` setup, and per-sample cloning of those common targets/limits
are outside the operation timer. Replacement setup, source snapshot setup,
JSON output, and result drops are also outside the timer. The harness
black-boxes a completed operation before stopping the timer; no-op output
comparison is performed after timing. The four operation names and both sizes
are fixed in `run_latency.py`.

The large `embedded_object_snapshot_open_noop_finish` result is a **1.227x
candidate/control compound open+finish observation** (p95 1.220x). It includes
finish output allocation and must not be described as a finish-only regression.
`common_editor_open_unique_noop_finish` is measured and reported; only its
common target/limit setup and cloning are outside the timed closure. Small
inputs remain near the timing/noise scale; the result is one host, one pinned
CPU, one release profile, and one toolchain.

`reports/timing-report.md` contains the final v2 table and caveats. The raw
per-invocation JSON and logs are under `reports/raw/`; correctness, build
flags, commands, source provenance, fixture provenance, and the independent
`opc_capture_review` clearance are recorded beside them. `source-review.json`
is provenance context for the historical allocation-v2 review of the same eight
source changes; its metrics are allocated bytes and allocation calls only and it
does not scope or certify wall-clock latency. The overlay manifest retains names
and hashes for historical validation logs and allocation-v2 auxiliary receipts
that live outside this bundle; those external corroboration artifacts are not
missing latency evidence, which is fully represented by the reports and raw
samples here.

## Prepare source checkouts

Set shell variables to paths of two local source checkouts. They may live
anywhere outside this publication:

```sh
export CONTROL_SOURCE='<path-to-frozen-control-checkout>'
export CANDIDATE_SOURCE='<path-to-candidate-checkout>'
```

The control checkout must contain commit
`c85997bc0d93ea523731d6e7622b2300e1747255`. The candidate checkout must match
all candidate hashes in `reports/source-manifest.json`. To make it from the
control checkout without copying linked-worktree metadata, create a detached
worktree at a new path and apply the reviewed patch:

```sh
git -C "$CONTROL_SOURCE" worktree add --detach "$CANDIDATE_SOURCE" \
  c85997bc0d93ea523731d6e7622b2300e1747255
git -C "$CANDIDATE_SOURCE" apply "$PWD/candidate-source.patch"
```

`CANDIDATE_SOURCE` must be an unused path for `git worktree add`. A source-only
copy is also valid if its `.git` entry is excluded and the patch is applied with
`patch -p1`; never copy a linked-worktree checkout's `.git` file as ordinary
source metadata. A git clone is not required by the verification script; the
769 file hashes are authoritative.

The harness Cargo manifests use relative paths through temporary links. The
integrated wrapper creates these links inside its throwaway copy. For the manual
path, create them only while building or auditing, and remove them before
hashing the publication:

```sh
mkdir -p source-checkouts
ln -s "$CONTROL_SOURCE" source-checkouts/control
ln -s "$CANDIDATE_SOURCE" source-checkouts/candidate
```

## Integrated reproduction (recommended)

The wrapper is the simplest audit entry point. It verifies the archive and both
source/fixture manifests, copies this bundle to a throwaway work directory,
builds both release binaries with `+1.95.0 --locked`, clears and records
`RUSTFLAGS`, encoded flags, all `CARGO_PROFILE_RELEASE_*` settings, relevant
Cargo build/target overrides, target selection, and target-CPU overrides, hashes
the binaries, runs fresh 34-check correctness gates, and then invokes
`run_latency.py` only with those binaries:

```sh
python3 reproduce.py \
  --control-source "$CONTROL_SOURCE" \
  --candidate-source "$CANDIDATE_SOURCE" \
  --output '<path-to-new-reproduction-output>'
```

Use `--build-and-check-only` to stop after fresh builds and correctness without
starting another timing run. The output contains `reproduction.json`, actual
commands and environment-clearing records, build/correctness logs, fresh
correctness reports, binary SHA-256 values, and (for the default path) a
`latency/` directory with the runner's new report set. The wrapper establishes
binary provenance by building the binaries in its own throwaway copy; a direct
call to `run_latency.py` alone accepts caller-supplied target binaries and is
therefore a manual diagnostic path, not a self-authenticating binary audit.

## Manual build and correctness gate

The manual path is useful when inspecting individual commands. It uses
throwaway target directories outside the publication. The recorded build
flags are release, `--locked`, toolchain `+1.95.0`, and no `RUSTFLAGS` or
`CARGO_ENCODED_RUSTFLAGS`.

```sh
export TARGET_ROOT='<path-to-disposable-target-root>'
mkdir -p "$TARGET_ROOT/control" "$TARGET_ROOT/candidate"
env -u RUSTFLAGS -u CARGO_ENCODED_RUSTFLAGS \
  CARGO_TARGET_DIR="$TARGET_ROOT/control" \
  cargo +1.95.0 build --release --locked \
  --manifest-path control/Cargo.toml
env -u RUSTFLAGS -u CARGO_ENCODED_RUSTFLAGS \
  CARGO_TARGET_DIR="$TARGET_ROOT/candidate" \
  cargo +1.95.0 build --release --locked --features candidate \
  --manifest-path candidate/Cargo.toml

export HARNESS_ROOT="$PWD/control"
"$TARGET_ROOT/control/release/litchi-embedded-doc-allocation-v2" correctness
export HARNESS_ROOT="$PWD/candidate"
"$TARGET_ROOT/candidate/release/litchi-embedded-doc-allocation-v2" correctness
```

The correctness gate expects 34 boolean checks per side and all must be true.
Running the gate refreshes the per-side `reports/correctness.json`; use a
throwaway copy of this bundle if preserving the published file bytes during an
audit matters.

## Verify and reproduce

The first command verifies both source clones (769 paths each), both fixture
sets (8 files each), and the recorded correctness reports without timing:

```sh
python3 run_latency.py \
  --control-source "$CONTROL_SOURCE" \
  --candidate-source "$CANDIDATE_SOURCE" \
  --run-dir '<path-to-disposable-verification-output>' \
  --verify-only
```

After the release binaries are built, run the corrected v2 timing harness into
another disposable directory. The timing closure and constants match the final
v2 run; only the output location and source/target paths are supplied by the
caller:

```sh
python3 run_latency.py \
  --control-source "$CONTROL_SOURCE" \
  --candidate-source "$CANDIDATE_SOURCE" \
  --control-target "$TARGET_ROOT/control" \
  --candidate-target "$TARGET_ROOT/candidate" \
  --run-dir '<path-to-disposable-timing-output>'
```

The runner performs all source and fixture checks before invoking a binary. It
writes new `reports/environment.json`, `correctness-gate.json`,
`commands.json`, `raw.json`, and `summary.json` below the caller's run
 directory; it never writes a target directory and does not require a shared
Cargo target.

## Bundle integrity

`archive-manifest.json` lists every publication member other than itself and
its SHA-256 hash. The manifest excludes runtime `source-checkouts` links and
all target artifacts; `self_excluded` documents the standard non-self-hashing
rule. `candidate-source.patch` has SHA-256
`7279ba1326965ff5189acf036c6b4bf656b892fe148d7eb9739652abb5da5ad4`, as also
recorded by the overlay manifest.

The historical v2 hashes are retained as `recorded_*` fields in
`reports/provenance.json`; the unprefixed publication hashes cover the
relocatable copies in this directory. Source and fixture entry hashes remain
unchanged.

The integrated wrapper limits each build to four Cargo jobs and disables Python
bytecode writes so repeated verification leaves the publication unchanged.
