# iWork example/build-fix independent review

Date: 2026-09-10 UTC

## Frozen candidate

- Candidate: `/var/tmp/litchi-iwork-example-fixes-20260910`
- Base commit: `8b2cca3c7559be36e96cc1b862ed5fafbc93f634`
- Manifest: `/var/tmp/litchi-iwork-example-fixes-20260910-manifest.json`
- Manifest SHA-256: `9f3d6a923a4d94531c46fe9dc81774d99e931b1da72fb1333512148e522be8cd`
- Patch: `/var/tmp/litchi-iwork-example-fixes-20260910.patch`
- Patch SHA-256: `24d7afcce49bea19e02bc3cd0a1b4535845f8387534ac2b5b3c063f95a028198`
- Candidate lock SHA-256: `4a21c97ea2b3dd2ee65a471de1d8034780c8cb1d0c0f2503279d5190ad1f5214`
- Candidate toolchain: Rust `1.95.0 (59807616e 2026-04-14)`.
- The five manifest-bound candidate source hashes were independently recomputed and all matched the manifest.

## Scoped verdict: CLEAR

The five-path overlay is clear for this feature batch. The global release gate remains open as stated by the owner because broad all-target Clippy still reports pre-existing diagnostics in untouched tests/examples/generated fields; that is not a failure in these five paths.

## Example inventory and collision review

Cargo metadata from the frozen candidate reports:

- Keynote: 22 example targets, 22 files, no missing or unlisted file.
- Numbers: 23 example targets, 23 files, no missing or unlisted file.
- Pages: 12 example targets, 12 files, no missing or unlisted file.
- `litchi-iwa::create_keynote_audio`: one target, with no required feature.
- All 57 affected example targets have `required-features=[]`; none is silently disabled.
- The complete workspace metadata contains 496 example targets with 496 unique target names.

`autoexamples = false` is paired with an explicit entry for every example in each affected package. The only renamed names are the actual cross-package filename collisions:

- Keynote: `keynote_edit_chart_arrangement`, `keynote_edit_image_adjustments`, `keynote_edit_table_cell_number_format`, `keynote_save_package`.
- Numbers: `numbers_edit_chart_arrangement`, `numbers_edit_image_adjustments`, `numbers_edit_table_cell_number_format`, `numbers_save_package`.
- Pages: `pages_edit_image_adjustments`, `pages_save_package`.

All non-colliding example names remain their filename stems. No repository documentation or workflow references to the old colliding `--example` names were found. The renamed target names are therefore an intentional CLI compatibility change required by the workspace-wide uniqueness policy, with the package prefix identifying the former package owner.

## Audio projection review

`create_keynote_audio.rs` now imports `MediaLoopMode` and `MediaVolume` from the public `litchi_keynote::slide::media` vocabulary, reopens the newly built bytes through `litchi_keynote::Package`, reads the source-ordered slide media playback projection, changes only loop mode and volume, commits through `edit_slide_movie_playback_settings`, and reopens the committed bytes through `KeynoteEditor` before saving.

This is the correct type boundary: `KeynoteSlideAudioInfo::playback` is the common IWA creation projection, while `Package::slide_movie_playback_settings` returns the Keynote-owned playback value consumed by the package edit. The package route retains the existing end/start/poster fields while applying the requested repeat/volume values.

A bounded smoke used the checked-in `tone.wav` fixture:

```
taskset -c 8-31 cargo +1.95.0 run -p litchi-iwa --example create_keynote_audio --all-features --offline --locked -- <output.key> <tone.wav> 1.0
```

It exited 0, printed `created Keynote audio 152 backed by data 1`, reopened the committed package, and produced:

- Output package SHA-256: `e938ffa0765053124b982d9598350b7010e6619cbee1cb41d59188921f290de9`
- Output size: 202,405 bytes
- Smoke log SHA-256: `ca6baebdf06ecca7b93482d14554aa8175dbed4ba3eff66bfc00e0d0daa10c0f`

## Verification evidence

Owner-provided candidate logs show:

- all-feature checks: Keynote 22, Numbers 23, Pages 12, plus IWA audio passed;
- no-default-feature checks: all 57 affected examples plus IWA audio passed;
- strict focused Clippy passed for the changed IWA example, Keynote library, Numbers library, and Pages library;
- Rustfmt and `git diff --check` passed.

The broad candidate Clippy log is `/var/tmp/litchi-iwork-example-fixes-20260910-clippy.log` (SHA-256 `9f8a7b3c0536ddd96424130b4e233569fa0c82a559cc178ea61da1a27df77ee`). Its diagnostics are all outside the five owned paths: deprecated generated fields in `slide_movie_playback.rs`, old test/example `needless-*`/`manual-*` findings, and `chart_arrangement.rs`/`image_adjustments.rs` test-code findings.

To verify the baseline rather than waive it, I built a clean base control at commit `8b2cca3c7559be36e96cc1b862ed5fafbc93f634`, copied the candidate lockfile, and ran the pinned all-target affected-package Clippy command offline. It exited 101 with a separate log:

- `/var/tmp/litchi-iwork-example-clean-control-20260910-clippy.log`
- SHA-256: `8d55ea1d72b09931a822e41e5fe19c2c1656e050511962946dd8710bcd17dbd5`

The control reproduced pre-existing deprecated generated-field, `manual-contains`, `needless-update`, and `needless-borrow` diagnostics in untouched paths. The exact set varies with Clippy's fail-fast target scheduling, but neither control nor candidate diagnostics identify any of the five owned files.

The temporary clean-control source and target were removed only after an exact `/proc` cwd/fd/command-line scan found zero live references. Cleanup receipt:

- `/var/tmp/litchi-iwork-example-clean-control-cleanup-20260910.json`
- SHA-256: `44a8b592d8bfed462ce8b9718cdbb17495d53281d24ccaad2e4dd23a3faf4ca3`
- Bytes reclaimed: 3,654,323,561

No candidate or primary source was edited, staged, or committed during this review.
