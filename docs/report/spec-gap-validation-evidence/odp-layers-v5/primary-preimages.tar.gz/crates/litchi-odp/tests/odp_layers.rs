#![allow(
    clippy::unwrap_used,
    reason = "integration-test assertions panic on failure by design"
)]

use litchi_odp::core::{OwnedPackage, PackageWriter};
use litchi_odp::{edit, layer};

const DRAW: &str = "urn:oasis:names:tc:opendocument:xmlns:drawing:1.0";
const OFFICE: &str = "urn:oasis:names:tc:opendocument:xmlns:office:1.0";
const STYLE: &str = "urn:oasis:names:tc:opendocument:xmlns:style:1.0";

fn source_bytes(include_local_set: bool) -> Vec<u8> {
    let local = if include_local_set {
        r#"<d:layer-set><!-- retained layer comment --><d:layer d:name="base" draw:display="screen" d:protected="false"/></d:layer-set>"#
    } else {
        ""
    };
    let content = format!(
        r#"<office:document-content xmlns:office="{OFFICE}" xmlns:d="{DRAW}" xmlns:draw="{DRAW}" xmlns:style="{STYLE}" xmlns:vendor="urn:example:vendor"><office:body><office:presentation><d:page d:name="one"><vendor:opaque vendor:token="keep"/>{local}<d:frame d:name="shape" d:layer="base" vendor:untouched="yes"/></d:page><d:page d:name="two"/></office:presentation></office:body></office:document-content>"#
    );
    let styles = format!(
        r#"<office:document-styles xmlns:office="{OFFICE}" xmlns:d="{DRAW}" xmlns:style="{STYLE}"><office:master-styles><d:layer-set><d:layer d:name="global"/></d:layer-set></office:master-styles><style:master-page style:name="Master"/></office:document-styles>"#
    );
    let mut writer = PackageWriter::new();
    writer
        .set_mimetype("application/vnd.oasis.opendocument.presentation")
        .unwrap();
    writer.add_file("content.xml", content.as_bytes()).unwrap();
    writer.add_file("styles.xml", styles.as_bytes()).unwrap();
    writer.finish_to_bytes().unwrap()
}

#[test]
fn inventory_reads_alternate_prefixes_and_owners() {
    let snapshot = edit::Snapshot::from_bytes(source_bytes(true)).unwrap();
    let inventory = snapshot.layers().unwrap();
    assert_eq!(inventory.page(0).unwrap().layers()[0].name(), "base");
    assert_eq!(
        inventory.master_styles().unwrap().layers()[0].name(),
        "global"
    );
    assert!(inventory.master_page("Master").is_none());
    assert_eq!(
        inventory.page(0).unwrap().layers()[0].display(),
        Some("screen")
    );
    assert_eq!(
        inventory.page(0).unwrap().layers()[0].protected(),
        Some(false)
    );
}

#[test]
fn rename_updates_declaration_and_shape_reference_with_exact_patch() {
    let source = edit::Snapshot::from_bytes(source_bytes(true)).unwrap();
    let source_bytes = source.bytes().to_vec();
    let mut transaction = source.transaction().unwrap();
    transaction.rename_page_layer(0, "base", "renamed").unwrap();
    let commit = transaction.commit().unwrap();
    assert!(commit.changed());
    let package = OwnedPackage::from_bytes(commit.snapshot().bytes().to_vec()).unwrap();
    let content = String::from_utf8(package.get_file("content.xml").unwrap()).unwrap();
    assert!(content.contains(r#"d:name="renamed""#));
    assert!(content.contains(r#"d:layer="renamed""#));
    assert!(content.contains(r#"vendor:token="keep""#));
    assert!(content.contains("retained layer comment"));
    assert_eq!(
        commit.patch().apply(&source).unwrap().bytes(),
        commit.snapshot().bytes()
    );
    assert_eq!(
        commit
            .patch()
            .inverse()
            .apply(commit.snapshot())
            .unwrap()
            .bytes(),
        source_bytes
    );
    assert_eq!(
        commit
            .snapshot()
            .layers()
            .unwrap()
            .page(0)
            .unwrap()
            .layers()[0]
            .name(),
        "renamed"
    );
}

#[test]
fn remove_referenced_layer_is_refused_and_add_creates_missing_set() {
    let source = edit::Snapshot::from_bytes(source_bytes(false)).unwrap();
    let mut refused = source.transaction().unwrap();
    assert!(refused.remove_page_layer(0, "base").is_err());
    let noop = refused.commit().unwrap();
    assert!(!noop.changed());
    assert_eq!(noop.snapshot().bytes(), source.bytes());

    let mut transaction = source.transaction().unwrap();
    transaction
        .add_page_layer(0, layer::Layer::new("base").unwrap())
        .unwrap();
    let commit = transaction.commit().unwrap();
    assert_eq!(
        commit
            .snapshot()
            .layers()
            .unwrap()
            .page(0)
            .unwrap()
            .layers()[0]
            .name(),
        "base"
    );
    let package = OwnedPackage::from_bytes(commit.snapshot().bytes().to_vec()).unwrap();
    let content = String::from_utf8(package.get_file("content.xml").unwrap()).unwrap();
    assert!(content.contains("<d:layer-set"));
    assert!(content.contains(r#"d:name="base""#));
}

#[test]
fn stale_patch_is_rejected_for_layer_commit() {
    let source = edit::Snapshot::from_bytes(source_bytes(true)).unwrap();
    let mut transaction = source.transaction().unwrap();
    transaction.rename_global_layer("global", "all").unwrap();
    let commit = transaction.commit().unwrap();
    let other = edit::Snapshot::from_bytes(source_bytes(false)).unwrap();
    assert!(commit.patch().apply(&other).is_err());
}

#[test]
fn reversing_layer_renames_retains_the_exact_source_package() {
    let source = edit::Snapshot::from_bytes(source_bytes(true)).unwrap();
    let mut transaction = source.transaction().unwrap();
    transaction
        .rename_page_layer(0, "base", "temporary")
        .unwrap();
    transaction
        .rename_global_layer("global", "temporary-global")
        .unwrap();
    transaction
        .rename_page_layer(0, "temporary", "base")
        .unwrap();
    transaction
        .rename_global_layer("temporary-global", "global")
        .unwrap();
    let commit = transaction.commit().unwrap();
    assert!(!commit.changed());
    assert_eq!(commit.snapshot().bytes(), source.bytes());
    assert_eq!(
        commit.patch().apply(&source).unwrap().bytes(),
        source.bytes()
    );
}

#[test]
fn global_and_master_page_additions_use_existing_style_owners() {
    let source = edit::Snapshot::from_bytes(source_bytes(true)).unwrap();
    let mut transaction = source.transaction().unwrap();
    transaction
        .add_global_layer(layer::Layer::new("new-global").unwrap())
        .unwrap();
    transaction
        .add_master_page_layer("Master", layer::Layer::new("master-local").unwrap())
        .unwrap();
    let commit = transaction.commit().unwrap();
    let inventory = commit.snapshot().layers().unwrap();
    assert_eq!(
        inventory
            .master_styles()
            .unwrap()
            .layers()
            .last()
            .unwrap()
            .name(),
        "new-global"
    );
    assert_eq!(
        inventory
            .master_page("Master")
            .unwrap()
            .layers()
            .last()
            .unwrap()
            .name(),
        "master-local"
    );
}

#[test]
fn missing_empty_owner_elements_are_expanded_losslessly() {
    let source = edit::Snapshot::from_bytes(source_bytes(false)).unwrap();
    let mut transaction = source.transaction().unwrap();
    transaction
        .add_page_layer(1, layer::Layer::new("second").unwrap())
        .unwrap();
    let commit = transaction.commit().unwrap();
    assert_eq!(
        commit
            .snapshot()
            .layers()
            .unwrap()
            .page(1)
            .unwrap()
            .layers()[0]
            .name(),
        "second"
    );
    let package = OwnedPackage::from_bytes(commit.snapshot().bytes().to_vec()).unwrap();
    let content = String::from_utf8(package.get_file("content.xml").unwrap()).unwrap();
    assert!(content.contains(r#"<d:page d:name="two"><d:layer-set"#));
    assert!(content.contains(r#"</d:page>"#));
}
