//! Shared bounded OPC exercise paths for libFuzzer and the deterministic smoke
//! binary. The parser receives only caller-owned byte slices; it never
//! resolves paths, opens resources, fetches relationship targets, or executes
//! embedded content.

use std::hint::black_box;
use std::io::Cursor;

use litchi_opc::{
    AuthoredXmlFragment, OpcError, OpcPackage, PackURI, ReadLimits, ReadResource,
    SourceBackedPackage, SourceTopologyPlan, probe_package_catalog_from_reader_with_limits,
};

/// Maximum fuzzer input retained by one exercise.
pub const MAX_INPUT_BYTES: usize = 1 << 20;
const MAX_ARCHIVE_MEMBERS: usize = 64;
const MAX_PARTS: usize = 64;
const MAX_RELATIONSHIP_PARTS: usize = 32;
const MAX_MEMBER_BYTES: u64 = 256 << 10;
const MAX_ARCHIVE_TOTAL_BYTES: u64 = 1 << 20;
const MAX_RELATIONSHIP_XML_BYTES: usize = 64 << 10;
const MAX_TOTAL_RELATIONSHIP_XML_BYTES: usize = 256 << 10;
const MAX_RELATIONSHIPS_PER_PART: usize = 64;
const MAX_TOTAL_RELATIONSHIPS: usize = 256;
const MAX_XML_EVENTS: usize = 512;
const MAX_TOTAL_XML_EVENTS: usize = 2048;
const MAX_XML_DEPTH: usize = 32;
const MAX_XML_ATTRIBUTE_BYTES: usize = 16 << 10;
const MAX_RELATIONSHIP_TARGET_BYTES: usize = 4 << 10;

/// Results of the three public ingress paths for one input.
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
pub struct ExerciseStats {
    /// Whether the source-backed constructor admitted the input.
    pub source_backed_ok: bool,
    /// Whether the eager constructor admitted the input.
    pub eager_ok: bool,
    /// Whether the metadata-only catalog probe admitted the input.
    pub probe_ok: bool,
}

/// The deliberately tight policy used by this harness.
#[must_use]
pub fn tight_limits() -> ReadLimits {
    limits_for_input(MAX_INPUT_BYTES as u64)
}

fn limits_for_input(max_input_bytes: u64) -> ReadLimits {
    ReadLimits::builder()
        .max_input_bytes(max_input_bytes.max(1))
        .expect("nonzero fuzzer input ceiling")
        .max_archive_members(MAX_ARCHIVE_MEMBERS)
        .expect("nonzero archive-member ceiling")
        .max_parts(MAX_PARTS)
        .expect("nonzero part ceiling")
        .max_relationship_parts(MAX_RELATIONSHIP_PARTS)
        .expect("nonzero relationship-part ceiling")
        .max_archive_member_name_bytes(4 << 10)
        .expect("nonzero member-name ceiling")
        .max_archive_metadata_bytes(64 << 10)
        .expect("nonzero archive-metadata ceiling")
        .max_archive_compressed_bytes(MAX_MEMBER_BYTES)
        .expect("nonzero compressed-byte ceiling")
        .max_archive_entry_bytes(MAX_MEMBER_BYTES)
        .expect("nonzero entry-byte ceiling")
        .max_archive_total_bytes(MAX_ARCHIVE_TOTAL_BYTES)
        .expect("nonzero archive-total ceiling")
        .max_part_bytes(MAX_MEMBER_BYTES)
        .expect("nonzero part-byte ceiling")
        .max_total_part_bytes(MAX_ARCHIVE_TOTAL_BYTES)
        .expect("nonzero total-part ceiling")
        .max_content_types_bytes(MAX_RELATIONSHIP_XML_BYTES)
        .expect("nonzero content-types ceiling")
        .max_content_type_mappings(MAX_RELATIONSHIPS_PER_PART)
        .expect("nonzero content-type mapping ceiling")
        .max_relationship_xml_bytes(MAX_RELATIONSHIP_XML_BYTES)
        .expect("nonzero relationship-XML ceiling")
        .max_total_relationship_xml_bytes(MAX_TOTAL_RELATIONSHIP_XML_BYTES)
        .expect("nonzero total relationship-XML ceiling")
        .max_relationships_per_part(MAX_RELATIONSHIPS_PER_PART)
        .expect("nonzero per-part relationship ceiling")
        .max_total_relationships(MAX_TOTAL_RELATIONSHIPS)
        .expect("nonzero total relationship ceiling")
        .max_relationship_graph_nodes(MAX_TOTAL_RELATIONSHIPS)
        .expect("nonzero graph-node ceiling")
        .max_xml_events(MAX_XML_EVENTS)
        .expect("nonzero XML-event ceiling")
        .max_total_relationship_xml_events(MAX_TOTAL_XML_EVENTS)
        .expect("nonzero total XML-event ceiling")
        .max_xml_depth(MAX_XML_DEPTH)
        .expect("nonzero XML-depth ceiling")
        .max_xml_attribute_bytes(MAX_XML_ATTRIBUTE_BYTES)
        .expect("nonzero XML-attribute ceiling")
        .max_relationship_target_bytes(MAX_RELATIONSHIP_TARGET_BYTES)
        .expect("nonzero relationship-target ceiling")
        .build()
        .expect("consistent bounded OPC profile")
}

fn source_xml_insertion(bytes: &[u8]) -> Option<usize> {
    bytes.windows(2).rposition(|window| window == b"</")
}

/// Exercise all bounded public ingress paths and safe read/probe operations.
///
/// This function intentionally ignores ordinary parse errors: malformed input
/// is a first-class fuzz case. Internal consistency checks remain assertions,
/// so a panic is a harness failure rather than an accepted parse result.
#[must_use]
pub fn exercise(data: &[u8]) -> ExerciseStats {
    if data.len() > MAX_INPUT_BYTES {
        return ExerciseStats::default();
    }

    let limits = tight_limits();
    let probe_ok = probe_package(data, limits);
    let source_backed_ok = exercise_source_backed(data, limits);
    let eager_ok = exercise_eager(data, limits);
    ExerciseStats {
        source_backed_ok,
        eager_ok,
        probe_ok,
    }
}

fn probe_package(data: &[u8], limits: ReadLimits) -> bool {
    let mut reader = Cursor::new(data);
    probe_package_catalog_from_reader_with_limits(&mut reader, limits).is_ok()
}

fn exercise_source_backed(data: &[u8], limits: ReadLimits) -> bool {
    let Ok(package) = SourceBackedPackage::from_vec_with_limits(data.to_vec(), limits) else {
        return false;
    };

    let mut source_xml_mutated = false;
    let mut plan = SourceTopologyPlan::new();
    for part in package.iter_parts() {
        black_box(part.partname());
        black_box(part.content_type());
        let _ = black_box(part.declared_uncompressed_size());

        // Capture the source-authorized precompressed member through cold and
        // warm paths, then verify that both retained tokens can be published.
        if let Ok((cold, token)) = part.data_and_authorize_precompressed() {
            if let Ok((warm, warm_token)) = part.data_and_authorize_precompressed() {
                assert_eq!(cold.as_bytes(), warm.as_bytes());
                drop(warm_token);
            }
            let retained = token.into_retained();
            let copy = retained.clone();
            let first = retained.authorize_for_publication();
            let second = copy.authorize_for_publication();
            drop(first);
            drop(second);
        }

        // Exercise source XML proof/publication only when this admitted part
        // exposes XML source. Binary parts remain opaque and bounded.
        if !source_xml_mutated
            && let Ok(source_xml) = part.source_xml()
            && let Some(insertion) = source_xml_insertion(source_xml.bytes())
            && let Ok(proof) = source_xml.checked_range(insertion..insertion, &[])
            && let Ok(fragment) = AuthoredXmlFragment::markup(b"<litchi-fuzz/>".to_vec())
            && let Ok(mut publication) = source_xml.into_publication()
            && publication.replace(proof, fragment).is_ok()
            && let Ok(edited) = publication.finish()
        {
            source_xml_mutated = true;
            let target = part.partname().clone();
            if plan
                .try_replace_source_xml_part(target, edited.clone())
                .is_ok()
                && let Ok(copy_name) = PackURI::new("/litchi-fuzz-source-copy.xml")
            {
                let _ = plan.try_add_source_xml_part(copy_name, edited);
            }
        }
    }

    // This relationship is deliberately external and inert. No target is
    // resolved or fetched by the harness or by the package writer.
    if let Ok(owner) = PackURI::new("/")
        && plan
            .try_add_external_relationship(
                owner,
                "rIdLitchiFuzzAppend",
                "urn:litchi:fuzz:external",
                "https://example.invalid/fuzz",
            )
            .is_ok()
    {
        let _ = package.write_topology_to_stream(std::io::sink(), plan);
    }
    true
}

fn exercise_eager(data: &[u8], limits: ReadLimits) -> bool {
    let Ok(package) = OpcPackage::from_bytes_with_limits(data, limits) else {
        return false;
    };

    for rel in package.rels().iter() {
        black_box(rel.r_id());
        black_box(rel.reltype());
        black_box(rel.target_ref());
        black_box(rel.is_external());
        let _ = black_box(rel.target_partname());
    }
    for part in package.iter_parts() {
        black_box(part.partname());
        black_box(part.content_type());
        black_box(part.blob().len());
        for rel in part.rels().iter() {
            black_box(rel.r_id());
            black_box(rel.reltype());
            black_box(rel.target_ref());
            black_box(rel.is_external());
            let _ = black_box(rel.target_partname());
        }
    }
    let _ = black_box(package.main_document_part());
    black_box(package.part_count());
    true
}

/// Exercise the explicit input-byte rejection path on a nonempty seed.
#[allow(
    dead_code,
    reason = "the libFuzzer target shares this helper with the smoke binary"
)]
pub fn exercise_input_limit(data: &[u8]) {
    assert!(!data.is_empty(), "limit seed must be nonempty");
    let maximum = u64::try_from(data.len() - 1).expect("bounded seed length");
    let limits = limits_for_input(maximum);
    assert!(matches!(
        SourceBackedPackage::from_vec_with_limits(data.to_vec(), limits),
        Err(OpcError::ReadLimit {
            resource: ReadResource::InputBytes,
            ..
        })
    ));
    assert!(matches!(
        OpcPackage::from_bytes_with_limits(data, limits),
        Err(OpcError::ReadLimit {
            resource: ReadResource::InputBytes,
            ..
        })
    ));
    let mut reader = Cursor::new(data);
    assert!(matches!(
        probe_package_catalog_from_reader_with_limits(&mut reader, limits),
        Err(OpcError::ReadLimit {
            resource: ReadResource::InputBytes,
            ..
        })
    ));
}
