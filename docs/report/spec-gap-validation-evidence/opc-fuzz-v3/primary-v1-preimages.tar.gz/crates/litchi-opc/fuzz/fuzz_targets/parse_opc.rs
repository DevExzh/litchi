#![no_main]

use libfuzzer_sys::fuzz_target;

#[path = "opc_harness.rs"]
mod opc_harness;

fuzz_target!(|data: &[u8]| {
    let _ = opc_harness::exercise(data);
});
