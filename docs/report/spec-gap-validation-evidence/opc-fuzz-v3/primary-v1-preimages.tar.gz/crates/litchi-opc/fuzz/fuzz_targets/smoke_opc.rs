#![allow(
    clippy::expect_used,
    clippy::panic,
    clippy::unwrap_used,
    reason = "the bounded deterministic smoke binary fails closed on harness regressions"
)]

use std::fs;
use std::panic::{self, AssertUnwindSafe};
use std::path::{Path, PathBuf};

use soapberry_zip::office::StreamingArchiveWriter;

#[path = "opc_harness.rs"]
mod opc_harness;

const CONTENT_TYPES_NS: &str = "http://schemas.openxmlformats.org/package/2006/content-types";
const RELATIONSHIPS_NS: &str = "http://schemas.openxmlformats.org/package/2006/relationships";
const OFFICE_DOCUMENT_REL: &str =
    "http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument";
const DOCUMENT_CONTENT_TYPE: &str =
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml";

fn archive_bytes(content_types: &[u8], root_rels: &[u8], document_rels: &[u8]) -> Vec<u8> {
    let mut writer = StreamingArchiveWriter::new();
    writer
        .write_stored("[Content_Types].xml", content_types)
        .expect("deterministic content types member");
    writer
        .write_stored("_rels/.rels", root_rels)
        .expect("deterministic root relationships member");
    writer
        .write_stored("word/_rels/document.xml.rels", document_rels)
        .expect("deterministic document relationships member");
    writer
        .write_deflated_sized(
            "word/document.xml",
            br#"<?xml version="1.0"?><document><body>fuzz</body></document>"#,
        )
        .expect("deterministic document member");
    writer
        .write_stored("custom/data.bin", &[0xa5; 37])
        .expect("deterministic binary member");
    writer.finish_to_bytes().expect("deterministic OPC archive")
}

fn valid_seed() -> Vec<u8> {
    let content_types = format!(
        r#"<Types xmlns="{CONTENT_TYPES_NS}"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="{DOCUMENT_CONTENT_TYPE}"/><Override PartName="/custom/data.bin" ContentType="application/octet-stream"/></Types>"#
    );
    let root_rels = format!(
        r#"<Relationships xmlns="{RELATIONSHIPS_NS}"><Relationship Id="rId1" Type="{OFFICE_DOCUMENT_REL}" Target="word/document.xml"/></Relationships>"#
    );
    let document_rels = format!(
        r#"<Relationships xmlns="{RELATIONSHIPS_NS}"><Relationship Id="rIdExternal" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink" Target="https://example.invalid/fuzz" TargetMode="External"/><Relationship Id="rIdData" Type="urn:litchi:fuzz:data" Target="../custom/data.bin"/></Relationships>"#
    );
    archive_bytes(
        content_types.as_bytes(),
        root_rels.as_bytes(),
        document_rels.as_bytes(),
    )
}

fn malformed_seeds(valid: &[u8]) -> Vec<Vec<u8>> {
    let mut seeds = vec![
        Vec::new(),
        b"not an OPC package".to_vec(),
        b"PK\x03\x04\x14\x00\x00\x00".to_vec(),
        valid[..valid.len() / 2].to_vec(),
        valid[..valid.len() - 1].to_vec(),
    ];

    let root_rels = format!(
        r#"<Relationships xmlns="{RELATIONSHIPS_NS}"><Relationship Id="rId1" Target="word/document.xml"></Relationships>"#
    );
    seeds.push(archive_bytes(
        b"<Types>",
        b"<Relationships>",
        root_rels.as_bytes(),
    ));
    seeds
}

fn seed_files(valid: &[u8], malformed: &[Vec<u8>]) -> Vec<(String, Vec<u8>)> {
    let mut files = vec![("valid-opc.zip".to_owned(), valid.to_vec())];
    files.extend(
        malformed
            .iter()
            .enumerate()
            .map(|(index, bytes)| (format!("malformed-{index:02}.bin"), bytes.clone())),
    );
    files
}

fn write_seeds(path: &Path, valid: &[u8], malformed: &[Vec<u8>]) {
    fs::create_dir_all(path).expect("explicit seed output directory");
    for (name, bytes) in seed_files(valid, malformed) {
        fs::write(path.join(name), bytes).expect("explicit deterministic seed output");
    }
}

fn seed_output_argument() -> Option<PathBuf> {
    std::env::args()
        .skip(1)
        .find_map(|argument| argument.strip_prefix("--write-seeds=").map(PathBuf::from))
}

fn main() {
    let valid = valid_seed();
    let malformed = malformed_seeds(&valid);
    if let Some(path) = seed_output_argument() {
        write_seeds(&path, &valid, &malformed);
    }

    let valid_stats = panic::catch_unwind(AssertUnwindSafe(|| opc_harness::exercise(&valid)))
        .expect("valid deterministic seed must not panic");
    assert_eq!(
        valid_stats,
        opc_harness::ExerciseStats {
            source_backed_ok: true,
            eager_ok: true,
            probe_ok: true,
        },
        "valid seed must reach all three public ingress paths"
    );

    for (index, seed) in malformed.iter().enumerate() {
        panic::catch_unwind(AssertUnwindSafe(|| opc_harness::exercise(seed)))
            .unwrap_or_else(|_| panic!("malformed deterministic seed {index} panicked"));
    }

    // The valid package is also a deterministic input-limit seed. All three
    // public paths must reject before ZIP/XML parsing when input is one byte
    // over the selected explicit ceiling.
    opc_harness::exercise_input_limit(&valid);
    println!(
        "bounded OPC smoke passed: valid=1 malformed={} input_limit=1 bytes={}",
        malformed.len(),
        valid.len()
    );
}
