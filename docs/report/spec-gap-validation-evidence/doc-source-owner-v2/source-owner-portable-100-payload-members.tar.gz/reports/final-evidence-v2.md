# Final c4aa source-owner evidence (corrected aggregation labels)

Matched scope: `c4aa19e1930b79bec7db499a9248fe711ac3cf43` control/candidate, 780 source files per side, four frozen candidate files, patch `22de95bda65f683fa7725e4f5315acc08a9a4a91be8479d39e13c7fb093512e6`. Source and fixture manifests were verified before and after both runs.

## Release latency

Commands and exact toolchain/environment are in `reproduction.json` and `latency/reports/environment.json`; binaries and hashes are recorded there.

| Scenario | Control pooled median | Candidate pooled median | Paired round ratio median |
| --- | ---: | ---: | ---: |
| `embedded_object_snapshot_open/small` | 27190 ns | 26420 ns | 0.9688× |
| `embedded_object_snapshot_open/large` | 798803 ns | 861023 ns | 1.0788× |
| `embedded_object_snapshot_open_noop_finish/small` | 27430 ns | 27030 ns | 0.9837× |
| `embedded_object_snapshot_open_noop_finish/large` | 1405045 ns | 1135394 ns | 0.8054× |
| `embedded_object_replace_storage_success_commit/small` | 142120 ns | 140561 ns | 0.9843× |
| `embedded_object_replace_storage_success_commit/large` | 6467414 ns | 6274793 ns | 0.9664× |
| `common_editor_open_unique_noop_finish/small` | 14340 ns | 14560 ns | 1.0112× |
| `common_editor_open_unique_noop_finish/large` | 716413 ns | 716992 ns | 0.9989× |
| `embedded_object_snapshot_bytes_first/small` | 30 ns | 300 ns | 15.0000× |
| `embedded_object_snapshot_bytes_first/large` | 30 ns | 270081 ns | 13345.0500× |
| `embedded_object_snapshot_bytes_shared_first/small` | 30 ns | 300 ns | 10.0000× |
| `embedded_object_snapshot_bytes_shared_first/large` | 30 ns | 269921 ns | 8990.3667× |
| `embedded_object_snapshot_bytes_shared_cached/small` | 30 ns | 40 ns | 1.3333× |
| `embedded_object_snapshot_bytes_shared_cached/large` | 30 ns | 40 ns | 1.3333× |
| `embedded_object_snapshot_open_bytes/small` | 27170 ns | 26800 ns | 0.9866× |
| `embedded_object_snapshot_open_bytes/large` | 798543 ns | 797613 ns | 0.9962× |
| `embedded_object_snapshot_open_bytes_shared/small` | 27370 ns | 26860 ns | 0.9842× |
| `embedded_object_snapshot_open_bytes_shared/large` | 1133284 ns | 1130545 ns | 0.9986× |

Six alternating rounds used 5 warmups and 20 samples per invocation on CPU 0. Timing-record load average first-field range was 5.73–5.97; this was a contended host run, not an idle-host claim.

## Allocation companion

Each side produced 240 untimed rows: 8 operations × 2 profiles × 15 samples. All 32 allocator correctness booleans passed per side.

The allocation common-editor rows construct `common_targets()` and `common_limits()` inside the counted closure, so those target/limit allocations are included in the common rows. Fixture construction and caller-owned source/replacement clones happen outside the counted closure. `allocated_bytes` counts fresh allocations plus positive growth from successful reallocations; shrinking reallocations do not add to that field. The separate latency `bytes_first`/`bytes_shared_first` rows measure fresh public-view materialization and are not allocator-row substitutes.

| Scenario | Allocated bytes control | Allocated bytes candidate | Candidate/control | Peak live control | Peak live candidate |
| --- | ---: | ---: | ---: | ---: | ---: |
| `common_editor_open_snapshot_noop_finish/large` | 9285612 | 9285612 | 1.0000× | 5292199 | 5292199 |
| `common_editor_open_snapshot_noop_finish/small` | 69665 | 69665 | 1.0000× | 37100 | 37100 |
| `common_editor_open_unique_noop_finish/large` | 7958328 | 7958328 | 1.0000× | 5292199 | 5292199 |
| `common_editor_open_unique_noop_finish/small` | 58733 | 58733 | 1.0000× | 37100 | 37100 |
| `embedded_object_replace_storage_malformed_replacement/large` | 715 | 715 | 1.0000× | 292 | 292 |
| `embedded_object_replace_storage_malformed_replacement/small` | 715 | 715 | 1.0000× | 292 | 292 |
| `embedded_object_replace_storage_oversized_replacement/large` | 752 | 752 | 1.0000× | 292 | 292 |
| `embedded_object_replace_storage_oversized_replacement/small` | 752 | 752 | 1.0000× | 292 | 292 |
| `embedded_object_replace_storage_success_commit/large` | 47423753 | 45143337 | 0.9519× | 13622208 | 12230665 |
| `embedded_object_replace_storage_success_commit/small` | 598163 | 571571 | 0.9555× | 147256 | 135279 |
| `embedded_object_snapshot_open/large` | 12412349 | 10131933 | 0.8163× | 6855733 | 5464190 |
| `embedded_object_snapshot_open/small` | 139113 | 116617 | 0.8383× | 67405 | 51292 |
| `embedded_object_snapshot_open_malformed_admission/large` | 0 | 0 | - | 0 | 0 |
| `embedded_object_snapshot_open_malformed_admission/small` | 0 | 0 | - | 0 | 0 |
| `embedded_object_snapshot_open_noop_finish/large` | 14692797 | 12412381 | 0.8448× | 9136181 | 6855765 |
| `embedded_object_snapshot_open_noop_finish/small` | 161641 | 139145 | 0.8608× | 89933 | 67437 |

The source-admission reduction appears in embedded snapshot open and successful replacement paths; common-editor and rejected-admission counters are equal in this harness.

## Ratio definition

The displayed control/candidate medians are pooled over 6 rounds × 20 samples. The primary ratio is the median of six paired round-level invocation-median ratios; it is not the direct division of pooled medians. The large first `bytes()` row illustrates this: pooled medians are 30 ns and 270,081 ns, while the paired ratio is 13,345.05× because control invocation medians vary between 20 and 40 ns.

## Focused repeat

A fresh-process repeat at the exact v1 binary hashes measured large `snapshot_open`, `open+noop finish`, `open+bytes`, successful replacement, and the common-editor control. Direct `snapshot_open` stayed at 1.0826× (all six rounds 1.0613–1.0941×), while `open+noop finish` was 0.8036×, `open+bytes` 1.0002×, successful replacement 0.9561×, and the common control 1.0040×. See `evidence/focused-repeat/focused-diagnosis.md`.

The allocator `peak_live_bytes` value is a counted-phase allocator high-water delta from the setup baseline. Setup allocations/frees are excluded, Held results remain alive through the snapshot, and teardown drops occur after the row; this is diagnostic and is not RSS or whole-workflow residency.

## Evidence paths

- Latency run: `evidence/v1`
- Allocation run: `allocation/evidence-v1`
- Versioned JSON: `reports/final-evidence-v2.json`

The DOC-specific rustdoc gate passed. The broad boundary checker remains blocked by the separate existing `litchi-xlsb` → `soapberry-zip` dev-dependency policy annotation diagnostic; these scoped results do not assert whole-workspace boundary-gate success.
