# DOC SourceOwner portable publication

This directory is a portable evidence artifact for the four-file DOC SourceOwner candidate against the frozen `c4aa19e1930b79bec7db499a9248fe711ac3cf43` control. It contains the source and fixture manifests, both relative Cargo harnesses and lockfiles, the exact candidate working-tree patch, corrected v2 evidence, the focused repeat, the separate allocation companion, and wrappers that rebuild from caller-supplied source checkouts.

The publication is a candidate artifact, not a general latency approval. The dedicated integration receipt `reports/integration-root-gates-v2.json` records the final correctness context at proof commit `6da91778c4003b6c9819e5c25168cfe9a847359`, while all measured timing and allocation blobs remain scoped to `c4aa19e1930b79bec7db499a9248fe711ac3cf43`; the integration receipt makes no timing attribution to `6da`. It contains no source checkout, Cargo target directory, linked worktree, symlink, or arbitrary prebuilt binary.

## Reproduce the latency evidence

Prepare two source checkouts from the same repository without copying a linked-worktree `.git` file:

```text
git -C /path/to/repository worktree add --detach /path/to/control c4aa19e1930b79bec7db499a9248fe711ac3cf43
git -C /path/to/repository worktree add --detach /path/to/candidate c4aa19e1930b79bec7db499a9248fe711ac3cf43
git -C /path/to/candidate apply /path/to/publication/candidate-working-tree.patch
```

Run the portable wrapper from this directory. It verifies all 780 manifest paths and eight fixtures per side, copies both caller checkouts into a disposable bundle with `.git` ignored and symlinks rejected, builds both release harnesses with `+1.95.0 --locked --features candidate`, runs fresh 34-boolean correctness checks, records SHA-256 hashes of both binaries, and runs `run_latency.py` only with those binaries:

```text
python3 reproduce.py \
  --control-source /path/to/control \
  --candidate-source /path/to/candidate \
  --output /path/to/source-owner-reproduction-output
```

Use `--build-and-check-only` to stop after the build and fresh correctness gate. The wrapper clears and records every present `CARGO_PROFILE_*` variable, including `CARGO_PROFILE_RELEASE_*`, all `CARGO_BUILD_*` and `CARGO_TARGET_*` overrides, target-CPU names, `RUSTFLAGS`, encoded Rust flags, compiler wrappers, and related release settings. It records the effective toolchain and hashes each binary before the optional latency run. The bundled latency runner remains a measurement driver; the wrapper supplies its binary provenance.

For wall-clock cases, fixture construction, caller-owned clones, and common targets/limits are setup outside each timer; the common unique open+finish operation itself is measured and reported. The `bytes_first`/`bytes_shared_first` cases keep admission outside the timer and measure the fresh first public view; cached shared access is a separate setup state. The timer uses six alternating rounds, five warmups, and 20 samples per invocation on CPU 0. The displayed pooled medians and paired ratios are both retained; the primary ratio is the median of six paired round-level invocation medians.

For the separate allocation companion, `common_targets()` and `common_limits()` are constructed inside the counted closure for common rows, so those allocations are intentionally included. Its `allocated_bytes` field covers fresh allocations and positive realloc growth; shrinking reallocations do not increase that field.

## Allocation companion

Allocation evidence is kept separate from wall-clock evidence. The companion verifies the same source and fixture manifests, builds the allocator-instrumented harness, checks 32 correctness booleans per side, and can emit 240 untimed rows per side (eight operations, two profiles, 15 samples):

```text
python3 allocation/reproduce_allocation.py \
  --control-source /path/to/control \
  --candidate-source /path/to/candidate \
  --output /path/to/source-owner-allocation-output
```

Add `--build-and-check-only` to skip allocation measurement. The historical receipt and commands are under `allocation/evidence-v1/`; its JSONL files are the raw scoped allocation rows. Allocation counters and `peak_live_bytes` are diagnostic counted-phase values and are not RSS or whole-workflow residency.

## What the evidence says

The corrected report is `reports/final-evidence-v2.{json,md}`; `reports/final-evidence-v1.{json,md}` and `evidence/v1/` preserve the immutable first run. `evidence/focused-repeat/` contains the fresh large-profile repeat and raw timing records.

The focused repeat keeps the large standalone `embedded_object_snapshot_open` regression stable at `1.0826x` (about `+8.3%`, with all six paired ratios from `1.0613x` to `1.0941x`). The compound `open+noop finish` path is about `0.804x` (about `-19.6%`). The candidate defers the first large public `bytes()`/`bytes_shared()` materialization by about 270 microseconds; cached shared access is about 40 ns. The large allocation admission row is `0.8163x`, about `18.4%` fewer allocated bytes.

The retained decision is an explicit allocation/compound-workflow tradeoff, not a general DOC latency win. Direct-open profiling remains open. These artifacts make no broad speed, peak, RSS, or whole-workflow residency claim.

The supplemental `diagnostics/perf-stat/` capture is process-wide corroboration only: multiplexed `perf stat` showed higher candidate cycles/instructions/branches and minor faults in the same direct-open direction, but the kernel did not provide user callchains and the counters include process setup. It makes no function-level causal claim and does not change the decision above.


`reports/root-gates-v1.json` retains the original boundary diagnostic. `reports/root-gates-v2.json` records the later pass using the separately committed external policy, while preserving the original failure and its scope. `reports/integration-root-gates-v2.json` is the dedicated clean integration receipt at proof commit `6da91778c4003b6c9819e5c25168cfe9a847359`; it shares the four measured source blobs but is a correctness/tooling proof, not a timing result. The gate states are provenance, not a claim that this publication reran them.

## Artifact provenance

`reports/publication-provenance.json` records hashes of the frozen inputs and normalized historical reports. Path strings in copied receipts and Markdown are rewritten to publication-relative labels; measured values, raw timing payloads, allocation JSONL, source manifests, fixture bytes, and the exact patch are copied without semantic edits. Build targets, redundant per-invocation log files, and intermediate work directories are intentionally excluded.
