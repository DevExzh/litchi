#![allow(clippy::cast_possible_truncation)]
#![allow(clippy::cast_sign_loss)]
#![allow(clippy::too_many_arguments)]
#![allow(clippy::too_many_lines)]

//! Matched release wall-clock harness for DOC/common source admission.
//!
//! Control and candidate use this same source; only dependency roots and the
//! candidate feature differ. Fixture and caller-owned setup are outside timing.

use litchi_cfb::{OleFile, OleWriter};
use litchi_doc::embedded_object::{
    Editor as EmbeddedEditor, Limits as EmbeddedLimits, Snapshot as EmbeddedSnapshot, WriteOptions,
};
use litchi_doc::writer::Writer;
use litchi_ole_common::object::{
    Editor as CommonEditor, Limits as CommonLimits, Snapshot as CommonSnapshot, Target, Targets,
};
use serde_json::{Value, json};
use sha2::{Digest, Sha256};
use std::collections::BTreeMap;
use std::env;
use std::error::Error;
use std::fs;
use std::hint::black_box;
use std::io::Cursor;
use std::path::{Path, PathBuf};
use std::sync::Arc;

type AnyResult<T> = Result<T, Box<dyn Error>>;

const SOURCE_COMMIT: &str = "c4aa19e1930b79bec7db499a9248fe711ac3cf43";
const CANDIDATE_MANIFEST_SHA256: &str =
    "24c6246c0c2fc166d8d63291227806f7f7411ef979f9f3ebfe7b35e769e81345";
const STORAGE_ID: u32 = 42;

#[allow(dead_code, reason = "held values keep measured results alive")]
struct Held {
    common_snapshot: Option<CommonSnapshot>,
    snapshot: Option<EmbeddedSnapshot>,
    commit: Option<litchi_doc::embedded_object::Commit>,
    bytes: Option<Vec<u8>>,
    accepted: bool,
}

struct Timed {
    held: Held,
    elapsed_ns: u128,
}

fn timed<F>(operation: F) -> AnyResult<Timed>
where
    F: FnOnce() -> AnyResult<Held>,
{
    let start = std::time::Instant::now();
    let result = operation();
    // Anchor successful operation completion before stopping the clock. Any
    // correctness inspection of held bytes happens in run_timed_samples.
    let held = black_box(result?);
    let elapsed_ns = start.elapsed().as_nanos();
    Ok(Timed { held, elapsed_ns })
}

struct ViewHeld {
    snapshot: EmbeddedSnapshot,
    shared: Option<Arc<[u8]>>,
    retained: Option<Arc<[u8]>>,
    marker: Option<(usize, usize)>,
}

struct ViewTimed {
    held: ViewHeld,
    elapsed_ns: u128,
}

fn timed_view<F>(operation: F) -> AnyResult<ViewTimed>
where
    F: FnOnce() -> AnyResult<ViewHeld>,
{
    let start = std::time::Instant::now();
    let result = operation();
    // Anchor successful view completion before stopping the clock. Output
    // checks and snapshot/result drops happen after the clock in the runner.
    let held = black_box(result?);
    let elapsed_ns = start.elapsed().as_nanos();
    Ok(ViewTimed { held, elapsed_ns })
}

fn run_view_timed_samples<F, V>(
    warmups: usize,
    samples: usize,
    mut run_once: F,
    mut validate: V,
) -> AnyResult<Vec<u128>>
where
    F: FnMut() -> AnyResult<ViewTimed>,
    V: FnMut(&ViewHeld) -> bool,
{
    for _ in 0..warmups {
        let timed = run_once()?;
        if !validate(&timed.held) {
            return Err("view warmup correctness failed".into());
        }
        drop(timed);
    }
    let mut durations = Vec::with_capacity(samples);
    for _ in 0..samples {
        let timed = run_once()?;
        if !validate(&timed.held) {
            return Err("view sample correctness failed".into());
        }
        durations.push(timed.elapsed_ns);
        drop(timed);
    }
    Ok(durations)
}

fn first_bytes_marker(snapshot: &EmbeddedSnapshot) -> (usize, usize) {
    let bytes = snapshot.bytes();
    black_box((bytes.as_ptr() as usize, bytes.len()))
}

fn source_view_contract(operation: &str) -> &'static str {
    match operation {
        "embedded_object_snapshot_bytes_first" => {
            "snapshot open and input clone outside timer; first bytes() inside timer"
        }
        "embedded_object_snapshot_bytes_shared_first" => {
            "snapshot open and input clone outside timer; first bytes_shared() inside timer"
        }
        "embedded_object_snapshot_bytes_shared_cached" => {
            "snapshot open and first bytes_shared() outside timer; cached clone inside timer"
        }
        "embedded_object_snapshot_open_bytes" => {
            "input clone outside timer; open plus first bytes() inside timer"
        }
        "embedded_object_snapshot_open_bytes_shared" => {
            "input clone outside timer; open plus first bytes_shared() inside timer"
        }
        _ => "not a source-view scenario",
    }
}

#[derive(Clone)]
struct Fixtures {
    common_small: Vec<u8>,
    common_large: Vec<u8>,
    embedded_small: Vec<u8>,
    embedded_large: Vec<u8>,
    replacement_small: Vec<u8>,
    replacement_large: Vec<u8>,
    malformed_small: Vec<u8>,
    malformed_large: Vec<u8>,
}

fn write_cfb(
    build: impl FnOnce(&mut OleWriter) -> Result<(), litchi_cfb::OleError>,
) -> AnyResult<Vec<u8>> {
    let mut writer = OleWriter::new();
    build(&mut writer)?;
    let mut output = Cursor::new(Vec::new());
    writer.write_to(&mut output)?;
    Ok(output.into_inner())
}

fn pattern(size: usize, seed: u8) -> Vec<u8> {
    (0..size)
        .map(|index| seed.wrapping_add((index as u8).wrapping_mul(31)))
        .collect()
}

fn picture_data(storage_id: u32) -> Vec<u8> {
    let mut value = 12u32.to_le_bytes().to_vec();
    value.extend_from_slice(&storage_id.to_le_bytes());
    value.extend_from_slice(&[0; 4]);
    value
}

fn common_object_fixture(payload_size: usize, seed: u8) -> AnyResult<Vec<u8>> {
    let payload = pattern(payload_size, seed);
    let opaque = pattern(payload_size / 4 + 17, seed.wrapping_add(3));
    write_cfb(|writer| {
        writer.set_root_state_bits(0x1020_3040);
        writer.set_root_creation_time_from_source(0x0102_0304_0506_0708);
        writer.set_root_modified_time(0x1112_1314_1516_1718);
        writer.create_storage(&["ObjectPool", "_42"])?;
        writer.set_storage_metadata(
            &["ObjectPool", "_42"],
            0xA1A2_A3A4,
            0x2122_2324_2526_2728,
            0x3132_3334_3536_3738,
        )?;
        writer.create_stream(&["WordDocument"], b"host-document-bytes")?;
        writer.create_stream_with_metadata(
            &["ObjectPool", "_42", "\u{3}ObjInfo"],
            &[0x40, 0, 2, 0],
            0xB1B2_B3B4,
            0x4142_4344_4546_4748,
            0x5152_5354_5556_5758,
        )?;
        writer.create_stream_with_metadata(
            &["ObjectPool", "_42", "\u{1}CompObj"],
            b"opaque-compobj-metadata",
            0xC1C2_C3C4,
            0x6162_6364_6566_6768,
            0x7172_7374_7576_7778,
        )?;
        writer.create_stream_with_metadata(
            &["ObjectPool", "_42", "\u{3}PRINT"],
            &opaque,
            0xD1D2_D3D4,
            0x8182_8384_8586_8788,
            0x9192_9394_9596_9798,
        )?;
        writer.create_stream(&["ObjectPool", "_42", "Payload"], &payload)?;
        Ok(())
    })
}

fn common_limits() -> CommonLimits {
    CommonLimits {
        max_object_size: 4 * 1024 * 1024,
        ..CommonLimits::default()
    }
}

fn common_targets() -> Targets {
    Targets::one(Target::new("object", ["ObjectPool", "_42"]).expect("valid target"))
}

#[cfg(feature = "candidate")]
fn common_input_survives(
    editor: &CommonEditor,
    expected_pointer: usize,
    expected_capacity: usize,
) -> bool {
    let retained = editor.source_shared();
    retained.as_ref().as_ptr() as usize == expected_pointer
        && retained.capacity() == expected_capacity
}

#[cfg(not(feature = "candidate"))]
fn common_input_survives(
    _editor: &CommonEditor,
    _expected_pointer: usize,
    _expected_capacity: usize,
) -> bool {
    // The frozen control does not expose the retained source handle. Its
    // consumed Vec is nevertheless moved into the common owner; allocation
    // counts cover the observable comparison boundary.
    true
}

fn standalone_object(payload_size: usize, seed: u8) -> AnyResult<Vec<u8>> {
    let comp_obj = litchi_doc::writer::ole_metadata::generate_compobj_stream();
    let ole = litchi_doc::writer::ole_metadata::generate_ole_stream();
    let obj_info = [0x00, 0x00, 0x03, 0x00, 0x00, 0x00];
    let unknown = [0x10, 0x20, 0x30, 0x40];
    let payload = pattern(payload_size, seed);
    write_cfb(|writer| {
        writer.create_stream(&["\u{1}CompObj"], &comp_obj)?;
        writer.create_stream(&["\u{1}Ole"], &ole)?;
        writer.create_stream(&["\u{3}ObjInfo"], &obj_info)?;
        writer.create_stream(&["VendorMetadata"], &unknown)?;
        writer.create_stream(&["OpaquePayload", "Binary"], &payload)?;
        Ok(())
    })
}

fn base_doc(paragraphs: usize, width: usize) -> AnyResult<Vec<u8>> {
    let mut writer = Writer::new();
    for index in 0..paragraphs {
        writer.add_paragraph(&format!("{index:08}: {}", "x".repeat(width)))?;
    }
    let mut output = Cursor::new(Vec::new());
    writer.write_to(&mut output)?;
    Ok(output.into_inner())
}

fn embedded_doc_fixture(
    payload_size: usize,
    paragraphs: usize,
    width: usize,
    seed: u8,
) -> AnyResult<Vec<u8>> {
    let base = base_doc(paragraphs, width)?;
    let mut editor = EmbeddedEditor::open(base, EmbeddedLimits::default())?;
    editor.add(WriteOptions::new(
        STORAGE_ID,
        standalone_object(payload_size, seed)?,
        picture_data(STORAGE_ID),
    ))?;
    Ok(editor.finish()?)
}

fn generate_fixtures(dir: &Path) -> AnyResult<()> {
    fs::create_dir_all(dir)?;
    let fixtures = [
        ("common-small.cfb", common_object_fixture(4 * 1024, 0x11)?),
        (
            "common-large.cfb",
            common_object_fixture(1024 * 1024, 0x22)?,
        ),
        (
            "embedded-small.doc",
            embedded_doc_fixture(4 * 1024, 2, 64, 0x11)?,
        ),
        (
            "embedded-large.doc",
            embedded_doc_fixture(1024 * 1024, 2_048, 256, 0x22)?,
        ),
        ("replacement-small.cfb", standalone_object(8 * 1024, 0x33)?),
        (
            "replacement-large.cfb",
            standalone_object(1024 * 1024, 0x44)?,
        ),
        ("malformed-small.bin", vec![0u8; 16 * 1024]),
        ("malformed-large.bin", vec![0u8; 1024 * 1024]),
    ];
    for (name, bytes) in fixtures {
        fs::write(dir.join(name), bytes)?;
    }
    Ok(())
}

fn read_fixtures(dir: &Path) -> AnyResult<Fixtures> {
    let read = |name: &str| -> AnyResult<Vec<u8>> { Ok(fs::read(dir.join(name))?) };
    Ok(Fixtures {
        common_small: read("common-small.cfb")?,
        common_large: read("common-large.cfb")?,
        embedded_small: read("embedded-small.doc")?,
        embedded_large: read("embedded-large.doc")?,
        replacement_small: read("replacement-small.cfb")?,
        replacement_large: read("replacement-large.cfb")?,
        malformed_small: read("malformed-small.bin")?,
        malformed_large: read("malformed-large.bin")?,
    })
}

fn replacement_limits(profile: &str) -> EmbeddedLimits {
    EmbeddedLimits {
        max_object_size: if profile == "small" {
            256 * 1024
        } else {
            4 * 1024 * 1024
        },
        ..EmbeddedLimits::default()
    }
}

fn source_hash(bytes: &[u8]) -> String {
    let mut digest = Sha256::new();
    digest.update(bytes);
    digest
        .finalize()
        .iter()
        .map(|byte| format!("{byte:02x}"))
        .collect()
}

fn inventory_projection(snapshot: &EmbeddedSnapshot) -> AnyResult<Value> {
    let inventory = snapshot.inventory()?;
    let mut entries = Vec::new();
    for entry in inventory.iter() {
        let metadata = entry.metadata();
        entries.push(json!({
            "storage_id": entry.storage_id(),
            "reference": {
                "storage_id": entry.reference().storage_id,
                "storage_name": entry.reference().storage_name,
                "start_cp": entry.reference().start_cp,
                "separator_cp": entry.reference().separator_cp,
                "end_cp": entry.reference().end_cp,
                "data_offset": entry.reference().data_offset,
            },
            "class_id": metadata.class_id(),
            "comp_obj": metadata.comp_obj().map(|value| source_hash(value.bytes())),
            "ole": metadata.ole().map(|value| source_hash(value.bytes())),
            "obj_info": metadata.obj_info().map(|value| format!("{value:?}")),
            "unknown": metadata.unknown().iter().map(|value| {
                json!({
                    "path": value.path(),
                    "bytes": value.bytes().len(),
                    "sha256": source_hash(value.bytes()),
                })
            }).collect::<Vec<_>>(),
        }));
    }
    Ok(Value::Array(entries))
}

fn cfb_stream(bytes: &[u8], path: &[&str]) -> AnyResult<Vec<u8>> {
    let mut file = OleFile::open(Cursor::new(bytes.to_vec()))?;
    Ok(file.open_stream(path)?.to_vec())
}

fn correctness(fixtures: &Fixtures) -> AnyResult<Value> {
    let mut profiles = BTreeMap::new();
    for (profile, source, replacement) in [
        (
            "small",
            &fixtures.embedded_small,
            &fixtures.replacement_small,
        ),
        (
            "large",
            &fixtures.embedded_large,
            &fixtures.replacement_large,
        ),
    ] {
        let limits = replacement_limits(profile);
        let source_snapshot = EmbeddedSnapshot::open(source.clone(), limits)?;
        let before_objects = source_snapshot.objects()?;
        let before_inventory = inventory_projection(&source_snapshot)?;
        let source_shared = source_snapshot.bytes_shared();
        let no_op_exact = source_snapshot.finish() == *source;
        let noop_commit = source_snapshot.edit().commit()?;
        let no_op_commit_exact = noop_commit.snapshot().finish() == *source;
        let no_op_shared = Arc::ptr_eq(&source_shared, &noop_commit.snapshot().bytes_shared());

        let mut success_transaction = source_snapshot.edit();
        success_transaction.replace_storage(STORAGE_ID, replacement.clone())?;
        let success_commit = success_transaction.commit()?;
        let after = success_commit.snapshot();
        let after_inventory = inventory_projection(after)?;
        let replacement_payload = cfb_stream(
            after.bytes(),
            &["ObjectPool", "_42", "OpaquePayload", "Binary"],
        )?;
        let expected_payload = cfb_stream(replacement, &["OpaquePayload", "Binary"])?;
        let metadata_core_preserved = before_inventory
            .as_array()
            .zip(after_inventory.as_array())
            .is_some_and(|(before, after)| {
                before.len() == after.len()
                    && before.iter().zip(after).all(|(before, after)| {
                        before.get("storage_id") == after.get("storage_id")
                            && before.get("reference") == after.get("reference")
                            && before.get("class_id") == after.get("class_id")
                            && before.get("comp_obj") == after.get("comp_obj")
                            && before.get("ole") == after.get("ole")
                            && before.get("obj_info") == after.get("obj_info")
                    })
            });

        let malformed = if profile == "small" {
            &fixtures.malformed_small
        } else {
            &fixtures.malformed_large
        };
        let mut malformed_transaction = source_snapshot.edit();
        let malformed_rejected = malformed_transaction
            .replace_storage(STORAGE_ID, malformed.clone())
            .is_err();
        let malformed_commit = malformed_transaction.commit()?;
        let malformed_source_exact = malformed_commit.snapshot().bytes() == source;
        let malformed_refs_preserved = malformed_commit.snapshot().objects()? == before_objects;
        let malformed_inventory_preserved =
            inventory_projection(malformed_commit.snapshot())? == before_inventory;
        let malformed_shared =
            Arc::ptr_eq(&source_shared, &malformed_commit.snapshot().bytes_shared());

        let oversized = vec![0u8; limits.max_object_size as usize + 1];
        let mut oversized_transaction = source_snapshot.edit();
        let oversized_rejected = oversized_transaction
            .replace_storage(STORAGE_ID, oversized)
            .is_err();
        let oversized_commit = oversized_transaction.commit()?;
        let oversized_source_exact = oversized_commit.snapshot().bytes() == source;
        let oversized_shared =
            Arc::ptr_eq(&source_shared, &oversized_commit.snapshot().bytes_shared());
        let oversized_refs_preserved = oversized_commit.snapshot().objects()? == before_objects;
        let oversized_inventory_preserved =
            inventory_projection(oversized_commit.snapshot())? == before_inventory;
        profiles.insert(
            profile,
            json!({
                "source_bytes": source.len(),
                "source_sha256": source_hash(source),
                "replacement_bytes": replacement.len(),
                "replacement_sha256": source_hash(replacement),
                "source_reference_count": before_objects.len(),
                "snapshot_no_op_exact": no_op_exact,
                "snapshot_noop_commit_exact": no_op_commit_exact,
                "snapshot_noop_shared_source": no_op_shared,
                "valid_replacement_accepted": success_commit.changed(),
                "valid_replacement_payload_exact": replacement_payload == expected_payload,
                "valid_replacement_references_preserved": after.objects()? == before_objects,
                "valid_replacement_core_metadata_preserved": metadata_core_preserved,
                "malformed_rejected": malformed_rejected,
                "malformed_source_exact": malformed_source_exact,
                "malformed_references_preserved": malformed_refs_preserved,
                "malformed_inventory_preserved": malformed_inventory_preserved,
                "malformed_shared_source": malformed_shared,
                "oversized_rejected": oversized_rejected,
                "oversized_source_exact": oversized_source_exact,
                "oversized_shared_source": oversized_shared,
                "oversized_references_preserved": oversized_refs_preserved,
                "oversized_inventory_preserved": oversized_inventory_preserved,
            }),
        );
    }
    Ok(json!({
        "source_commit": SOURCE_COMMIT,
        "candidate_manifest_sha256": CANDIDATE_MANIFEST_SHA256,
        "timed": false,
        "allocation_only": false,
        "timing_harness": true,
        "embedded_object": profiles,
    }))
}

fn percentile(sorted: &[u128], numerator: usize, denominator: usize) -> u128 {
    let index = sorted.len().saturating_sub(1).saturating_mul(numerator) / denominator;
    sorted[index]
}

fn timing_summary(
    operation: &str,
    profile: &str,
    input_kind: &str,
    input_bytes: usize,
    source_bytes: usize,
    replacement_bytes: Option<usize>,
    source_sha256: &str,
    replacement_sha256: Option<&str>,
    warmups: usize,
    durations: &[u128],
) -> AnyResult<Value> {
    if durations.is_empty() {
        return Err(format!("no timings for {operation}/{profile}").into());
    }
    let mut sorted = durations.to_vec();
    sorted.sort_unstable();
    let total: u128 = durations.iter().copied().sum();
    Ok(json!({
        "source_commit": SOURCE_COMMIT,
        "candidate_manifest_sha256": CANDIDATE_MANIFEST_SHA256,
        "timed": true,
        "allocator_instrumentation": false,
        "clock": "std::time::Instant monotonic",
        "operation": operation,
        "profile": profile,
        "input_kind": input_kind,
        "input_bytes": input_bytes,
        "source_bytes": source_bytes,
        "replacement_bytes": replacement_bytes,
        "source_view_contract": source_view_contract(operation),
        "source_sha256": source_sha256,
        "replacement_sha256": replacement_sha256,
        "setup_teardown_excluded": true,
        "warmups": warmups,
        "samples": durations.len(),
        "elapsed_ns": durations,
        "min_ns": sorted[0],
        "median_ns": percentile(&sorted, 50, 100),
        "p95_ns": percentile(&sorted, 95, 100),
        "p99_ns": percentile(&sorted, 99, 100),
        "max_ns": sorted[sorted.len() - 1],
        "mean_ns": total / durations.len() as u128,
    }))
}

fn run_timed_samples<F, V>(
    warmups: usize,
    samples: usize,
    mut run_once: F,
    mut validate: V,
) -> AnyResult<Vec<u128>>
where
    F: FnMut() -> AnyResult<Timed>,
    V: FnMut(&Held) -> bool,
{
    for _ in 0..warmups {
        let timed = run_once()?;
        if !timed.held.accepted || !validate(&timed.held) {
            return Err("warmup correctness failed".into());
        }
        drop(timed);
    }
    let mut durations = Vec::with_capacity(samples);
    for _ in 0..samples {
        let timed = run_once()?;
        if !timed.held.accepted || !validate(&timed.held) {
            return Err("sample correctness failed".into());
        }
        durations.push(timed.elapsed_ns);
        drop(timed);
    }
    Ok(durations)
}

fn measure_case(
    fixtures: &Fixtures,
    operation: &str,
    profile: &str,
    warmups: usize,
    samples: usize,
) -> AnyResult<Value> {
    let common = operation == "common_editor_open_unique_noop_finish";
    let source = match (common, profile) {
        (true, "small") => &fixtures.common_small,
        (true, "large") => &fixtures.common_large,
        (false, "small") => &fixtures.embedded_small,
        (false, "large") => &fixtures.embedded_large,
        (_, other) => return Err(format!("unknown profile {other:?}").into()),
    };
    let replacement = match profile {
        "small" => &fixtures.replacement_small,
        "large" => &fixtures.replacement_large,
        other => return Err(format!("unknown profile {other:?}").into()),
    };
    let source_hash_value = source_hash(source);
    let replacement_hash_value = source_hash(replacement);
    let embedded_limits = EmbeddedLimits::default();
    let common_targets = common_targets();
    let common_limits = common_limits();
    let (input_kind, input_bytes, replacement_bytes, durations) =
        match operation {
            "embedded_object_snapshot_bytes_first" => {
                let durations = run_view_timed_samples(
                    warmups,
                    samples,
                    || {
                        // Admission is setup for this first-view-only scenario.
                        let snapshot = EmbeddedSnapshot::open(source.clone(), embedded_limits)?;
                        timed_view(|| {
                            let marker = first_bytes_marker(&snapshot);
                            Ok(ViewHeld {
                                snapshot,
                                shared: None,
                                retained: None,
                                marker: Some(marker),
                            })
                        })
                    },
                    |held| held.marker.is_some() && held.snapshot.bytes() == source.as_slice(),
                )?;
                ("source", source.len(), None, durations)
            }
            "embedded_object_snapshot_bytes_shared_first" => {
                let durations = run_view_timed_samples(
                    warmups,
                    samples,
                    || {
                        // Admission is setup; only the first public shared view is timed.
                        let snapshot = EmbeddedSnapshot::open(source.clone(), embedded_limits)?;
                        timed_view(|| {
                            let shared = black_box(snapshot.bytes_shared());
                            Ok(ViewHeld {
                                snapshot,
                                shared: Some(shared),
                                retained: None,
                                marker: None,
                            })
                        })
                    },
                    |held| {
                        held.shared.as_deref() == Some(source.as_slice())
                            && held.shared.as_ref().is_some_and(|shared| {
                                held.snapshot.bytes().as_ptr() == shared.as_ptr()
                            })
                    },
                )?;
                ("source", source.len(), None, durations)
            }
            "embedded_object_snapshot_bytes_shared_cached" => {
                let durations = run_view_timed_samples(
                    warmups,
                    samples,
                    || {
                        // Both admission and first-view materialization are setup.
                        let snapshot = EmbeddedSnapshot::open(source.clone(), embedded_limits)?;
                        let first = snapshot.bytes_shared();
                        timed_view(|| {
                            let shared = black_box(snapshot.bytes_shared());
                            Ok(ViewHeld {
                                snapshot,
                                shared: Some(shared),
                                retained: Some(first),
                                marker: None,
                            })
                        })
                    },
                    |held| {
                        held.shared.as_deref() == Some(source.as_slice())
                            && held
                                .shared
                                .as_ref()
                                .zip(held.retained.as_ref())
                                .is_some_and(|(shared, first)| Arc::ptr_eq(shared, first))
                    },
                )?;
                ("source", source.len(), None, durations)
            }
            "embedded_object_snapshot_open_bytes" => {
                let durations = run_view_timed_samples(
                    warmups,
                    samples,
                    || {
                        let bytes = source.clone();
                        timed_view(|| {
                            let snapshot = EmbeddedSnapshot::open(bytes, embedded_limits)?;
                            let marker = first_bytes_marker(&snapshot);
                            Ok(ViewHeld {
                                snapshot,
                                shared: None,
                                retained: None,
                                marker: Some(marker),
                            })
                        })
                    },
                    |held| held.marker.is_some() && held.snapshot.bytes() == source.as_slice(),
                )?;
                ("source", source.len(), None, durations)
            }
            "embedded_object_snapshot_open_bytes_shared" => {
                let durations = run_view_timed_samples(
                    warmups,
                    samples,
                    || {
                        let bytes = source.clone();
                        timed_view(|| {
                            let snapshot = EmbeddedSnapshot::open(bytes, embedded_limits)?;
                            let shared = black_box(snapshot.bytes_shared());
                            Ok(ViewHeld {
                                snapshot,
                                shared: Some(shared),
                                retained: None,
                                marker: None,
                            })
                        })
                    },
                    |held| {
                        held.shared.as_deref() == Some(source.as_slice())
                            && held.shared.as_ref().is_some_and(|shared| {
                                held.snapshot.bytes().as_ptr() == shared.as_ptr()
                            })
                    },
                )?;
                ("source", source.len(), None, durations)
            }
            "embedded_object_snapshot_open" => {
                let durations = run_timed_samples(
                    warmups,
                    samples,
                    || {
                        let bytes = source.clone();
                        timed(|| {
                            let snapshot = EmbeddedSnapshot::open(bytes, embedded_limits)?;
                            Ok(Held {
                                common_snapshot: None,
                                snapshot: Some(snapshot),
                                commit: None,
                                bytes: None,
                                accepted: true,
                            })
                        })
                    },
                    |_| true,
                )?;
                ("source", source.len(), None, durations)
            }
            "embedded_object_snapshot_open_noop_finish" => {
                let durations = run_timed_samples(
                    warmups,
                    samples,
                    || {
                        let bytes = source.clone();
                        timed(|| {
                            let snapshot = EmbeddedSnapshot::open(bytes, embedded_limits)?;
                            let output = snapshot.finish();
                            Ok(Held {
                                common_snapshot: None,
                                snapshot: Some(snapshot),
                                commit: None,
                                bytes: Some(output),
                                accepted: true,
                            })
                        })
                    },
                    |held| held.bytes.as_deref() == Some(source.as_slice()),
                )?;
                ("source", source.len(), None, durations)
            }
            "common_editor_open_unique_noop_finish" => {
                let durations = run_timed_samples(
                    warmups,
                    samples,
                    || {
                        let bytes = source.clone();
                        let targets = common_targets.clone();
                        let limits = common_limits;
                        timed(|| {
                            let editor = CommonEditor::open(bytes, targets, limits)?;
                            let output = editor.finish()?;
                            Ok(Held {
                                common_snapshot: None,
                                snapshot: None,
                                commit: None,
                                bytes: Some(output),
                                accepted: true,
                            })
                        })
                    },
                    |held| held.bytes.as_deref() == Some(source.as_slice()),
                )?;
                ("source", source.len(), None, durations)
            }
            "embedded_object_replace_storage_success_commit" => {
                // Source admission is deliberately setup: this case measures the
                // actual replace_storage plus the outer transaction commit.
                let source_snapshot =
                    EmbeddedSnapshot::open(source.clone(), replacement_limits(profile))?;
                let replacement_template = replacement.clone();
                let durations = run_timed_samples(
                    warmups,
                    samples,
                    || {
                        let mut transaction = source_snapshot.edit();
                        let replacement = replacement_template.clone();
                        timed(|| {
                            transaction.replace_storage(STORAGE_ID, replacement)?;
                            let commit = transaction.commit()?;
                            Ok(Held {
                                common_snapshot: None,
                                snapshot: None,
                                commit: Some(commit),
                                bytes: None,
                                accepted: true,
                            })
                        })
                    },
                    |_| true,
                )?;
                (
                    "replacement",
                    replacement.len(),
                    Some(replacement.len()),
                    durations,
                )
            }
            other => return Err(format!("unknown operation {other:?}").into()),
        };
    timing_summary(
        operation,
        profile,
        input_kind,
        input_bytes,
        source.len(),
        replacement_bytes,
        &source_hash_value,
        (!common).then_some(replacement_hash_value.as_str()),
        warmups,
        &durations,
    )
}

fn timing_operations() -> [&'static str; 9] {
    [
        "embedded_object_snapshot_open",
        "embedded_object_snapshot_open_noop_finish",
        "embedded_object_replace_storage_success_commit",
        "common_editor_open_unique_noop_finish",
        "embedded_object_snapshot_bytes_first",
        "embedded_object_snapshot_bytes_shared_first",
        "embedded_object_snapshot_bytes_shared_cached",
        "embedded_object_snapshot_open_bytes",
        "embedded_object_snapshot_open_bytes_shared",
    ]
}

fn write_json(path: &Path, value: &Value) -> AnyResult<()> {
    fs::write(path, serde_json::to_vec_pretty(value)?)?;
    Ok(())
}

fn main() -> AnyResult<()> {
    let mut args = env::args().skip(1);
    let mode = args.next().unwrap_or_else(|| "measure".to_owned());
    let root = PathBuf::from(env::var("HARNESS_ROOT").unwrap_or_else(|_| ".".to_owned()));
    let fixture_dir = root.join("fixtures");
    let report_dir = root.join("reports");
    fs::create_dir_all(&report_dir)?;

    match mode.as_str() {
        "correctness" => {
            let fixtures = read_fixtures(&fixture_dir)?;
            write_json(
                &report_dir.join("correctness.json"),
                &correctness(&fixtures)?,
            )?;
        }
        "measure" => {
            let operation = args.next().ok_or("missing operation")?;
            let profile = args.next().ok_or("missing profile")?;
            let warmups: usize = args.next().unwrap_or_else(|| "5".to_owned()).parse()?;
            let samples: usize = args.next().unwrap_or_else(|| "25".to_owned()).parse()?;
            let output = args
                .next()
                .map(PathBuf::from)
                .unwrap_or_else(|| report_dir.join(format!("{operation}-{profile}.json")));
            if !timing_operations().contains(&operation.as_str()) {
                return Err(format!("unsupported operation {operation:?}").into());
            }
            let fixtures = read_fixtures(&fixture_dir)?;
            write_json(
                &output,
                &measure_case(&fixtures, &operation, &profile, warmups, samples)?,
            )?;
        }
        other => return Err(format!("unknown mode {other:?}").into()),
    }
    Ok(())
}
