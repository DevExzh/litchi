# Direct-open owner/copy perf experiment

Experiment name: `direct-open-owner-vs-copy-perf-stat`.

Hypothesis: the candidate's direct-open timing increase comes from the changed owner/allocator-state path (`Arc<SourceOwner>` with an uninitialized `OnceLock`) and different large-block reuse, while control performs one eager `Arc<[u8]>` allocation/copy. This experiment does not claim that `OnceLock` alone is causal.

The matched large DOC fixture is 2,280,448 bytes. Both binaries are the already frozen release binaries:

- control SHA256 `442fcf3d80629c4b84683644ac85d535bbe16c23762b1f894a7524b1bfbb8c3a`
- candidate SHA256 `2a668ffaf2b24354555ff3e1b314a0a3e32d815622f091f2803e517de929e516`

Each command was pinned to CPU 0 and ran `embedded_object_snapshot_open large` with 5 warmups and 100 timed samples. The harness's own `Instant` timer excludes fixture/input setup and drops. `perf stat` covered the complete process, so its counters are supporting evidence about the process/allocator state rather than a per-operation breakdown.

| Counter | Control | Candidate | Candidate/control |
| --- | ---: | ---: | ---: |
| `cycles` | 472,996,300 | 504,291,602 | 1.066x |
| `instructions` | 959,022,202 | 1,065,499,333 | 1.111x |
| `cache-references` | 0 | 0 | n/a |
| `cache-misses` | 14,880,351 | 11,112,493 | 0.747x |
| `branches` | 165,167,337 | 186,128,082 | 1.127x |
| `branch-misses` | 515,376 | 860,717 | 1.670x |
| `page-faults` | 123,851 | 146,446 | 1.182x |
| `minor-faults` | 123,851 | 146,446 | 1.182x |
| `major-faults` | 0 | 0 | n/a |


The selected events were multiplexed by perf (mostly 85–86% running; branch-miss 68–69%); `cache-references` was unavailable and reported zero. The same run's library-timer medians were 868,723 ns control and 951,614 ns candidate. The focused repeat's six-round median was 1.0826x; this 100-sample perf run was 1.1000x. The direction is consistent, but the counters include process setup.

The allocator companion gives the attributable ownership delta. For open-only large, both sides made 504 allocation calls and 79 reallocations. Control allocated 12,412,349 bytes and reached 6,855,733 counted live bytes; candidate allocated 10,131,933 bytes and reached 5,464,190. The 2,280,416-byte difference equals the control's extra `Arc<[u8]>` allocation after accounting for allocation headers; it is not an extra allocation call. For open plus `finish`, the same one-copy difference remains because `finish()` makes the caller-visible Vec copy on both sides.

The candidate path is `SourceOwner { bytes: Arc<Vec<u8>>, shared: OnceLock<Arc<[u8]>> }`. `Snapshot::open` stores `editor.package.source_shared()` in that owner; `bytes()`/`bytes_shared()` materialize the slice allocation lazily; internal comparisons borrow the common Vec. Control eagerly creates `Arc<[u8]>` from the common source slice during `open`.

A callgraph recording was attempted for both binaries, but the kernel reported restricted kallsyms and the perf header recorded `exclude_callchain_user=1`; user frames were unresolved. No function-level cause is inferred from that recording.

Artifacts:

- `diagnostics/perf-stat/experiment.json`
- `diagnostics/perf-stat/control.perf.csv` and `diagnostics/perf-stat/candidate.perf.csv`
- The binary `perf.data` recordings are intentionally omitted; the retained CSV counters and JSON reports contain the published raw counter evidence.
- `diagnostics/perf-stat/control.json` and `diagnostics/perf-stat/candidate.json`

Frozen evidence and source manifests were only read. The experiment does not justify an additional production change; it supports retaining the documented allocation/compound tradeoff and treating direct-open timing as an allocator/cache-state follow-up.
