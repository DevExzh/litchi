# Focused c4aa SourceOwner repeat diagnosis

The repeat uses the same frozen c4aa source pair and the exact v1 binary hashes. v1 remains immutable. The focused receipt is `evidence/focused-repeat/focused-repeat-receipt.json`.

## Per-round ratios

| Scenario | v1 paired median | Focus paired median | Focus round range |
| --- | ---: | ---: | ---: |
| `embedded_object_snapshot_open/large` | 1.0788× | 1.0826× | 1.0613–1.0941× |
| `embedded_object_snapshot_open_noop_finish/large` | 0.8054× | 0.8036× | 0.7969–0.8071× |
| `embedded_object_snapshot_open_bytes/large` | 0.9962× | 1.0002× | 0.9945–1.0040× |
| `embedded_object_replace_storage_success_commit/large` | 0.9664× | 0.9561× | 0.8891–0.9877× |
| `common_editor_open_unique_noop_finish/large` | 0.9989× | 1.0040× | 0.9936–1.0185× |

Direct large `snapshot_open` remains a stable regression: every v1 paired ratio was 1.0738–1.1025×, and every focused-repeat ratio was 1.0613–1.0941×. The result is consistent in alternating control-first and candidate-first rounds. `open+noop finish` remains about 0.804×, `open+bytes` is 1.000×, and the common-editor control is about 1.004× in the focused repeat. Successful replacement is faster but noisier (0.889–0.988×).

## Ratio aggregation

The displayed `control_median_ns` and `candidate_median_ns` are pooled medians over 6 rounds × 20 samples. The reported candidate/control ratio is the median of six paired round-level invocation medians. It is intentionally not computed by dividing the two pooled medians. For v1 large first `bytes()`, pooled medians are 30 ns and 270,081 ns (9002.7× by direct division), while the paired-round median is 13,345.05× because control invocation medians vary between 20 and 40 ns. The absolute deferred candidate cost is about 270 µs.

## Allocation peak-live scope

The allocator `peak_live_bytes` field is the high-water delta of the live-byte counter from the counted closure baseline. For common-editor allocation rows, `common_targets()` and `common_limits()` are constructed inside that closure; fixture and caller-owned input/replacement clones are outside it. Setup allocations and setup frees are outside the phase; the Held result stays alive through the snapshot, and teardown drops happen after the row is recorded. In-closure frees remain in deallocation counters. This is a diagnostic allocator high-water measure, not RSS or whole-workflow residency.

## Recommendation

The direct large-open regression is a stable >5% GOAL review trigger, so the candidate is not gate-clean and should not be presented as a general DOC latency win. Retain it only as an explicit allocation/compound-workflow tradeoff or measured enabler with follow-up: it removes a duplicate admitted-source copy from workflows that finish without requesting public bytes, improving large open+finish to about 0.804× and reducing counted admission allocations. It defers one full `Arc<[u8]>` materialization to first `bytes()`/`bytes_shared()` (about 270 µs for the large fixture); cached shared access is about 40 ns. If the >5% direct-open trigger must be cleared, the current candidate needs a design change that removes the measured direct-open overhead or should be reverted.

Focused receipt: `evidence/focused-repeat/focused-repeat-receipt.json`
Diagnosis JSON: `evidence/focused-repeat/focused-diagnosis.json`
