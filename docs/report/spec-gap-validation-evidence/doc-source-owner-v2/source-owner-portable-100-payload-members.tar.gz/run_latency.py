#!/usr/bin/env python3
"""Reproduce the corrected v2 DOC/common source-admission latency run.

The publication contains the final v2 harness, fixtures, reports and source
hash manifest, but no source checkout or build target. Supply two frozen source
checkouts and two caller-owned target directories. Source and fixture admission
is verified before any timed invocation.
"""
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import platform
import statistics
import subprocess
import time

ROOT = Path(__file__).resolve().parent
SOURCE_MANIFEST = ROOT / 'reports/source-manifest.json'
FIXTURE_MANIFEST = ROOT / 'reports/fixture-manifest.json'
OPERATIONS = [
    'embedded_object_snapshot_open',
    'embedded_object_snapshot_open_noop_finish',
    'embedded_object_replace_storage_success_commit',
    'common_editor_open_unique_noop_finish',
    'embedded_object_snapshot_bytes_first',
    'embedded_object_snapshot_bytes_shared_first',
    'embedded_object_snapshot_bytes_shared_cached',
    'embedded_object_snapshot_open_bytes',
    'embedded_object_snapshot_open_bytes_shared',
]
PROFILES = ['small', 'large']
SIDES = ['control', 'candidate']
ROUNDS = 6
WARMUPS = 5
SAMPLES = 20
BINARY_NAME = 'litchi-embedded-doc-allocation-v2'


def sha256(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def loadavg():
    return Path('/proc/loadavg').read_text().strip()


def command_text(argv):
    return subprocess.check_output(argv, text=True, stderr=subprocess.STDOUT).strip()


def percentile(values, numerator, denominator):
    ordered = sorted(values)
    index = (len(ordered) - 1) * numerator // denominator
    return ordered[index]


def stats(values):
    if not values:
        raise ValueError('empty timing set')
    return {
        'count': len(values),
        'min_ns': min(values),
        'median_ns': percentile(values, 50, 100),
        'p95_ns': percentile(values, 95, 100),
        'p99_ns': percentile(values, 99, 100),
        'max_ns': max(values),
        'mean_ns': sum(values) / len(values),
        'stdev_ns': statistics.pstdev(values) if len(values) > 1 else 0.0,
        'cv': (statistics.pstdev(values) / statistics.mean(values)) if len(values) > 1 and statistics.mean(values) else 0.0,
    }


def verify_sources_and_fixtures(control_source, candidate_source):
    source_manifest = json.loads(SOURCE_MANIFEST.read_text())
    if len(source_manifest['files']) != 780:
        raise RuntimeError(f"expected 780 source entries, got {len(source_manifest['files'])}")
    roots = {'control': control_source, 'candidate': candidate_source}
    checked = {side: 0 for side in SIDES}
    for entry in source_manifest['files']:
        relative = Path(entry['path'])
        if relative.is_absolute() or '..' in relative.parts:
            raise RuntimeError(f'unsafe source manifest path: {entry["path"]}')
        for side, root in roots.items():
            actual_path = root / relative
            if not actual_path.is_file():
                raise RuntimeError(f'missing source file {side}/{entry["path"]}')
            actual = sha256(actual_path)
            expected = entry[f'{side}_sha256']
            if actual != expected:
                raise RuntimeError(f'source mismatch {side}/{entry["path"]}: {actual} != {expected}')
            if actual_path.stat().st_size != entry[f'{side}_bytes']:
                raise RuntimeError(f'source size mismatch {side}/{entry["path"]}')
            checked[side] += 1
    if checked != {'control': 780, 'candidate': 780}:
        raise RuntimeError(f'incomplete source verification: {checked}')

    fixture_manifest = json.loads(FIXTURE_MANIFEST.read_text())['fixtures']
    if len(fixture_manifest) != 8:
        raise RuntimeError(f'expected 8 fixtures, got {len(fixture_manifest)}')
    fixture_counts = {}
    for side in SIDES:
        count = 0
        for name, expected in fixture_manifest.items():
            actual_path = ROOT / side / 'fixtures' / name
            if not actual_path.is_file():
                raise RuntimeError(f'missing fixture {side}/{name}')
            actual = sha256(actual_path)
            if actual != expected['sha256'] or actual_path.stat().st_size != expected['bytes']:
                raise RuntimeError(f'fixture mismatch {side}/{name}')
            count += 1
        fixture_counts[side] = count
    if fixture_counts != {'control': 8, 'candidate': 8}:
        raise RuntimeError(f'incomplete fixture verification: {fixture_counts}')
    return source_manifest, fixture_manifest, checked, fixture_counts


def verify_correctness():
    result = {}
    for side in SIDES:
        report = json.loads((ROOT / side / 'reports/correctness.json').read_text())
        bools = [value for profile in report['embedded_object'].values() for value in profile.values() if isinstance(value, bool)]
        result[side] = {
            'all_boolean_checks_true': all(bools),
            'boolean_checks': len(bools),
            'source_commit': report['source_commit'],
            'timed': report['timed'],
        }
        if len(bools) != 34 or not all(bools):
            raise RuntimeError(f'correctness failed for {side}: {len(bools)} checks')
    return result


def run_one(side, operation, profile, round_index, side_index, target_roots, run_root):
    binary = target_roots[side] / 'release' / BINARY_NAME
    if not binary.is_file():
        raise RuntimeError(f'missing built binary: {binary}')
    output = run_root / 'reports/raw' / f'{round_index:02d}-{side_index:02d}-{side}-{operation}-{profile}.json'
    output.parent.mkdir(parents=True, exist_ok=True)
    env = os.environ.copy()
    env.pop('RUSTFLAGS', None)
    env.pop('CARGO_ENCODED_RUSTFLAGS', None)
    env['HARNESS_ROOT'] = str((ROOT / side).resolve())
    argv = [
        'taskset', '-c', '0', str(binary), 'measure', operation, profile,
        str(WARMUPS), str(SAMPLES), str(output),
    ]
    before = loadavg()
    started = time.time_ns()
    log = output.with_suffix('.log')
    with log.open('w') as stream:
        subprocess.run(argv, cwd=ROOT / side, env=env, stdout=stream, stderr=subprocess.STDOUT, check=True)
    finished = time.time_ns()
    after = loadavg()
    row = json.loads(output.read_text())
    return {
        'side': side,
        'operation': operation,
        'profile': profile,
        'round': round_index,
        'side_index': side_index,
        'order': 'control-first' if side_index == 0 else 'candidate-first',
        'argv': argv,
        'cwd': str((ROOT / side).resolve()),
        'env': {
            'HARNESS_ROOT': env['HARNESS_ROOT'],
            'RUSTFLAGS': None,
            'CARGO_ENCODED_RUSTFLAGS': None,
            'RUSTUP_HOME': env.get('RUSTUP_HOME'),
        },
        'host_loadavg_before': before,
        'host_loadavg_after': after,
        'driver_wall_start_ns': started,
        'driver_wall_end_ns': finished,
        'timing': row,
    }


def aggregate(raw):
    grouped = {}
    for record in raw:
        key = (record['operation'], record['profile'])
        grouped.setdefault(key, {}).setdefault(record['side'], []).append(record)
    result = {}
    for (operation, profile), sides in grouped.items():
        side_summary = {}
        for side, records in sides.items():
            values = [value for record in records for value in record['timing']['elapsed_ns']]
            invocation_medians = [record['timing']['median_ns'] for record in records]
            side_summary[side] = {
                'invocations': len(records),
                'samples_per_invocation': SAMPLES,
                'timing': stats(values),
                'invocation_medians': invocation_medians,
                'invocation_median_stats': stats(invocation_medians),
                'loads_before': [record['host_loadavg_before'] for record in records],
                'loads_after': [record['host_loadavg_after'] for record in records],
            }
        control = {record['round']: record['timing']['median_ns'] for record in sides['control']}
        candidate = {record['round']: record['timing']['median_ns'] for record in sides['candidate']}
        pairs = []
        for round_index in sorted(set(control) & set(candidate)):
            c = control[round_index]
            d = candidate[round_index]
            pairs.append({
                'round': round_index,
                'control_median_ns': c,
                'candidate_median_ns': d,
                'candidate_over_control': d / c if c else math.nan,
                'difference_ns': d - c,
            })
        ratios = [pair['candidate_over_control'] for pair in pairs]
        side_summary['paired'] = {
            'pairs': pairs,
            'ratio_stats': stats(ratios) if ratios else None,
            'median_ratio': statistics.median(ratios) if ratios else None,
        }
        result[f'{operation}/{profile}'] = side_summary
    return result


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--control-source', required=True, type=Path,
                        help='checkout matching the control hashes in reports/source-manifest.json')
    parser.add_argument('--candidate-source', required=True, type=Path,
                        help='checkout matching the candidate hashes in reports/source-manifest.json')
    parser.add_argument('--control-target', type=Path,
                        help='release target directory containing the control binary')
    parser.add_argument('--candidate-target', type=Path,
                        help='release target directory containing the candidate binary')
    parser.add_argument('--run-dir', required=True, type=Path,
                        help='empty or disposable directory for new reports/raw and summary')
    parser.add_argument('--verify-only', action='store_true',
                        help='verify 780 source paths, 8 fixtures per side, and correctness without timing')
    return parser.parse_args()


def main():
    args = parse_args()
    control_source = args.control_source.resolve()
    candidate_source = args.candidate_source.resolve()
    run_root = args.run_dir.resolve()
    run_root.mkdir(parents=True, exist_ok=True)
    (run_root / 'reports').mkdir(parents=True, exist_ok=True)
    source_manifest, fixture_manifest, source_counts, fixture_counts = verify_sources_and_fixtures(
        control_source, candidate_source)
    correctness = verify_correctness()
    environment = {
        'date_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
        'hostname': platform.node(),
        'uname': platform.platform(),
        'cpu_count': os.cpu_count(),
        'affinity': sorted(os.sched_getaffinity(0)) if hasattr(os, 'sched_getaffinity') else None,
        'initial_loadavg': loadavg(),
        'rustc': command_text(['rustc', '+1.95.0', '-Vv']),
        'cargo': command_text(['cargo', '+1.95.0', '-V']),
        'lscpu': command_text(['lscpu']),
        'source_manifest_sha256': sha256(SOURCE_MANIFEST),
        'fixture_manifest_sha256': sha256(FIXTURE_MANIFEST),
        'source_overlay_commit': source_manifest['candidate_overlay_matches_commit'],
        'source_base_commit': source_manifest['base_commit'],
        'source_files_verified_per_side': source_counts,
        'fixture_count': len(fixture_manifest),
        'fixture_files_verified_per_side': fixture_counts,
        'release_profile': True,
        'locked': True,
        'toolchain': '+1.95.0',
        'allocator_instrumentation': False,
        'timed_cpu_affinity': [0],
        'rounds': ROUNDS,
        'warmups_per_invocation': WARMUPS,
        'samples_per_invocation': SAMPLES,
        'correctness_comparison_outside_timer': True,
        'held_result_black_box_before_elapsed_capture': True,
    }
    (run_root / 'reports/environment.json').write_text(json.dumps(environment, indent=2) + '\n')
    (run_root / 'reports/correctness-gate.json').write_text(json.dumps(correctness, indent=2) + '\n')
    if args.verify_only:
        print(f'Verified {source_counts} source files and {fixture_counts} fixtures per side: {run_root}')
        return
    if args.control_target is None or args.candidate_target is None:
        raise SystemExit('--control-target and --candidate-target are required unless --verify-only is used')
    target_roots = {
        'control': args.control_target.resolve(),
        'candidate': args.candidate_target.resolve(),
    }
    commands = []
    raw = []
    for round_index in range(ROUNDS):
        order = SIDES if round_index % 2 == 0 else list(reversed(SIDES))
        for operation in OPERATIONS:
            for profile in PROFILES:
                for side_index, side in enumerate(order):
                    print(f'round={round_index} side={side} operation={operation} profile={profile}', flush=True)
                    record = run_one(side, operation, profile, round_index, side_index, target_roots, run_root)
                    raw.append(record)
                    commands.append({
                        'round': round_index,
                        'side': side,
                        'side_index': side_index,
                        'operation': operation,
                        'profile': profile,
                        'argv': record['argv'],
                        'cwd': record['cwd'],
                        'environment': record['env'],
                    })
    (run_root / 'reports/commands.json').write_text(json.dumps(commands, indent=2) + '\n')
    (run_root / 'reports/raw.json').write_text(json.dumps(raw, indent=2) + '\n')
    summary = {
        'source_commit': source_manifest['base_commit'],
        'candidate_overlay_commit': source_manifest['candidate_overlay_matches_commit'],
        'fixture_count': len(fixture_manifest),
        'operations': OPERATIONS,
        'profiles': PROFILES,
        'rounds': ROUNDS,
        'warmups_per_invocation': WARMUPS,
        'samples_per_invocation': SAMPLES,
        'alternating_order': True,
        'setup_teardown_excluded': True,
        'allocator_instrumentation': False,
        'summary': aggregate(raw),
    }
    (run_root / 'reports/summary.json').write_text(json.dumps(summary, indent=2, allow_nan=False) + '\n')
    print(f'wrote {run_root / "reports/summary.json"}')


if __name__ == '__main__':
    main()
