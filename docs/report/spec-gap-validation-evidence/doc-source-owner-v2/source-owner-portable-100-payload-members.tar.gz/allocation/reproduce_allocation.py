#!/usr/bin/env python3
"""Rebuild and rerun the untimed allocation companion from caller sources.

This runner is separate from the wall-clock publication. It verifies source and
fixture manifests, copies caller checkouts into a disposable bundle without
symlinks, builds the allocator-instrumented harness with sanitized release
settings, runs fresh 32-boolean correctness checks, and optionally records 240
allocation rows per side. It never produces latency measurements.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
from typing import Any

BASE_COMMIT = "c4aa19e1930b79bec7db499a9248fe711ac3cf43"
TOOLCHAIN = "+1.95.0"
BINARY_NAME = "litchi-embedded-doc-allocation-v2"
sys.dont_write_bytecode = True


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def json_write(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + "\n")


def env_names_to_clear(environment: dict[str, str]) -> list[str]:
    names = []
    for name in environment:
        upper = name.upper()
        if (
            upper.startswith("CARGO_PROFILE_")
            or upper.startswith("CARGO_BUILD_")
            or upper.startswith("CARGO_TARGET_")
            or "RUSTFLAGS" in upper
            or upper.endswith("TARGET_CPU")
            or name in {
                "CARGO_INCREMENTAL",
                "RUSTC",
                "RUSTC_BOOTSTRAP",
                "RUSTC_WORKSPACE_WRAPPER",
                "RUSTC_WRAPPER",
            }
        ):
            names.append(name)
    return sorted(names)


def sanitized_environment(
    original: dict[str, str], *, target_dir: Path | None = None, harness_root: Path | None = None
) -> tuple[dict[str, str], dict[str, Any]]:
    names = env_names_to_clear(original)
    environment = dict(original)
    cleared = {name: original[name] for name in names}
    for name in names:
        environment.pop(name, None)
    profile = sorted(name for name in original if name.upper().startswith("CARGO_PROFILE_"))
    release_profile = sorted(name for name in original if name.upper().startswith("CARGO_PROFILE_RELEASE_"))
    build = sorted(name for name in original if name.upper().startswith("CARGO_BUILD_"))
    target = sorted(name for name in original if name.upper().startswith("CARGO_TARGET_"))
    overrides: dict[str, Any] = {}
    if target_dir is not None:
        overrides["CARGO_TARGET_DIR"] = {"before": original.get("CARGO_TARGET_DIR"), "after": str(target_dir)}
        environment["CARGO_TARGET_DIR"] = str(target_dir)
    if harness_root is not None:
        overrides["HARNESS_ROOT"] = {"before": original.get("HARNESS_ROOT"), "after": str(harness_root)}
        environment["HARNESS_ROOT"] = str(harness_root)
    relevant_names = sorted(set(names) | {
        "CARGO_BUILD_JOBS", "CARGO_BUILD_PIPELINING", "CARGO_BUILD_RUSTC", "CARGO_BUILD_RUSTFLAGS",
        "CARGO_BUILD_TARGET", "CARGO_INCREMENTAL", "CARGO_TARGET_CPU", "CARGO_TARGET_DIR",
        "CARGO_ENCODED_RUSTFLAGS", "RUSTC", "RUSTC_BOOTSTRAP", "RUSTC_WORKSPACE_WRAPPER",
        "RUSTC_WRAPPER", "RUSTFLAGS", "RUSTUP_TOOLCHAIN",
    })
    return environment, {
        "cleared_environment_names": names,
        "cleared_environment_values": cleared,
        "cargo_profile_overrides": {"all_present": profile, "release_present": release_profile},
        "cargo_build_overrides_present": build,
        "cargo_target_overrides_present": target,
        "target_cpu_related_names_present": sorted(
            name for name in original if name.upper().endswith("TARGET_CPU") or "RUSTFLAGS" in name.upper()
        ),
        "checked_relevant_environment_values": {name: original.get(name) for name in relevant_names},
        "overrides": overrides,
        "release_profile_overrides_cleared": True,
        "target_cpu_overrides_cleared": True,
    }


def command_record(name: str, argv: list[str], cwd: Path, log: Path | None, env_record: dict[str, Any]) -> dict[str, Any]:
    return {
        "name": name,
        "argv": argv,
        "cwd": str(cwd),
        "log": str(log) if log else None,
        "environment": env_record,
    }


def bool_values(value: Any) -> list[bool]:
    if isinstance(value, bool):
        return [value]
    if isinstance(value, dict):
        values: list[bool] = []
        for child in value.values():
            values.extend(bool_values(child))
        return values
    if isinstance(value, list):
        values: list[bool] = []
        for child in value:
            values.extend(bool_values(child))
        return values
    return []


def load_runner(bundle: Path):
    spec = importlib.util.spec_from_file_location("published_latency_runner", bundle / "run_latency.py")
    if spec is None or spec.loader is None:
        raise RuntimeError("cannot load bundled source verifier")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def reject_source_symlinks(source: Path) -> None:
    """Reject links before copytree can follow them into the work bundle."""
    if source.is_symlink():
        raise RuntimeError(f"source checkout root is a symlink: {source}")
    for current, directories, files in os.walk(source, followlinks=False):
        for name in (*directories, *files):
            path = Path(current) / name
            if path.is_symlink():
                raise RuntimeError(f"source checkout contains a symlink: {path}")


def copy_source(source: Path, destination: Path) -> None:
    reject_source_symlinks(source)
    shutil.copytree(source, destination, symlinks=False, ignore=shutil.ignore_patterns(".git"))
    if any(path.is_symlink() for path in destination.rglob("*")):
        raise RuntimeError(f"copied source tree contains a symlink: {destination}")


def verify_allocation_fixtures(work: Path, fixture_manifest: dict[str, Any]) -> dict[str, int]:
    counts: dict[str, int] = {}
    for side in ("control", "candidate"):
        count = 0
        for name, expected in fixture_manifest.items():
            path = work / "allocation" / side / "fixtures" / name
            if not path.is_file() or path.stat().st_size != expected["bytes"] or sha256(path) != expected["sha256"]:
                raise RuntimeError(f"allocation fixture mismatch: {side}/{name}")
            count += 1
        counts[side] = count
    return counts


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--control-source", required=True, type=Path)
    parser.add_argument("--candidate-source", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument(
        "--build-and-check-only",
        action="store_true",
        help="build and run fresh correctness only; skip the 240-row allocation measurements",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    bundle = Path(__file__).resolve().parent.parent
    control_source = args.control_source.resolve()
    candidate_source = args.candidate_source.resolve()
    output = args.output.resolve()
    if output == bundle or bundle in output.parents:
        raise SystemExit("--output must be outside the publication bundle")
    if output.exists() and any(output.iterdir()):
        raise SystemExit(f"--output must be new or empty: {output}")
    output.mkdir(parents=True, exist_ok=True)

    runner = load_runner(bundle)
    source_manifest, fixture_manifest, source_counts, fixture_counts = runner.verify_sources_and_fixtures(
        control_source, candidate_source
    )
    preflight = {
        "source_manifest_sha256": sha256(bundle / "reports/source-manifest.json"),
        "fixture_manifest_sha256": sha256(bundle / "reports/fixture-manifest.json"),
        "source_base_commit": source_manifest["base_commit"],
        "candidate_overlay_commit": source_manifest["candidate_overlay_matches_commit"],
        "source_files_verified_per_side": source_counts,
        "fixture_count": len(fixture_manifest),
        "fixture_files_verified_per_side": fixture_counts,
    }
    if preflight["source_base_commit"] != BASE_COMMIT or preflight["source_manifest_sha256"] != "24c6246c0c2fc166d8d63291227806f7f7411ef979f9f3ebfe7b35e769e81345":
        raise RuntimeError("source manifest provenance mismatch")
    json_write(output / "preflight-source-fixture-verification.json", preflight)

    records: list[dict[str, Any]] = []
    receipt: dict[str, Any] = {
        "format": "litchi-doc-source-owner-portable-allocation/1",
        "publication": "portable source-owner bundle",
        "sources": {
            "control": str(control_source),
            "candidate": str(candidate_source),
            "control_commit": BASE_COMMIT,
            "candidate_overlay_commit": None,
        },
        "preflight": preflight,
        "build": {
            "toolchain": TOOLCHAIN,
            "release": True,
            "locked": True,
            "features": ["candidate"],
            "allocator_instrumentation": True,
        },
        "commands": records,
        "correctness": {},
        "measure": {},
        "measurement_executed": not args.build_and_check_only,
    }

    with tempfile.TemporaryDirectory(prefix="litchi-doc-source-owner-allocation-", dir=str(output.parent)) as temporary:
        work = Path(temporary) / "bundle"
        (work / "allocation").mkdir(parents=True)
        for side in ("control", "candidate"):
            shutil.copytree(bundle / "allocation" / side, work / "allocation" / side, symlinks=False)
        source_links = work / "source-checkouts"
        source_links.mkdir()
        copy_source(control_source, source_links / "control")
        copy_source(candidate_source, source_links / "candidate")
        copied_source, copied_fixtures, copied_counts, copied_fixture_counts = runner.verify_sources_and_fixtures(
            source_links / "control", source_links / "candidate"
        )
        copied_preflight = {
            "source_manifest_sha256": sha256(bundle / "reports/source-manifest.json"),
            "fixture_manifest_sha256": sha256(bundle / "reports/fixture-manifest.json"),
            "source_base_commit": copied_source["base_commit"],
            "candidate_overlay_commit": copied_source["candidate_overlay_matches_commit"],
            "source_files_verified_per_side": copied_counts,
            "fixture_count": len(copied_fixtures),
            "fixture_files_verified_per_side": copied_fixture_counts,
        }
        json_write(output / "preflight-copied-source-verification.json", copied_preflight)
        receipt["source_copy_mode"] = "recursive copy with .git ignored; symlinks rejected"
        receipt["copied_preflight"] = copied_preflight
        allocation_fixture_counts = verify_allocation_fixtures(work, fixture_manifest)
        receipt["allocation_fixture_files_verified_per_side"] = allocation_fixture_counts

        original_env = dict(os.environ)
        binaries: dict[str, Path] = {}
        for side in ("control", "candidate"):
            side_root = work / "allocation" / side
            target = work / f"target-{side}"
            target.mkdir(parents=True, exist_ok=True)
            environment, env_record = sanitized_environment(original_env, target_dir=target)
            argv = [
                "cargo", TOOLCHAIN, "build", "--release", "--locked", "--features", "candidate",
                "--manifest-path", str(side_root / "Cargo.toml"),
            ]
            log = output / f"build-{side}.log"
            records.append(command_record(f"{side}-build", argv, side_root, log, env_record))
            with log.open("w") as stream:
                subprocess.run(argv, cwd=side_root, env=environment, stdout=stream, stderr=subprocess.STDOUT, check=True)
            binary = target / "release" / BINARY_NAME
            if not binary.is_file():
                raise RuntimeError(f"missing built binary: {binary}")
            binaries[side] = binary
            receipt["build"][side] = {
                "side": side,
                "argv": argv,
                "manifest": str(side_root / "Cargo.toml"),
                "target_dir": str(target),
                "binary": str(binary),
                "binary_bytes": binary.stat().st_size,
                "binary_sha256": sha256(binary),
                "built_by_wrapper": True,
            }
            json_write(output / "allocation-receipt-progress.json", receipt)

        for side in ("control", "candidate"):
            side_root = work / "allocation" / side
            environment, env_record = sanitized_environment(original_env, harness_root=side_root)
            binary = binaries[side]
            argv = [str(binary), "correctness"]
            log = output / f"correctness-{side}.log"
            records.append(command_record(f"{side}-correctness", argv, side_root, log, env_record))
            with log.open("w") as stream:
                subprocess.run(argv, cwd=side_root, env=environment, stdout=stream, stderr=subprocess.STDOUT, check=True)
            report_path = side_root / "reports" / "correctness.json"
            report = json.loads(report_path.read_text())
            booleans = bool_values(report.get("embedded_object"))
            if len(booleans) != 32 or not all(booleans):
                raise RuntimeError(f"allocation correctness failed for {side}: {len(booleans)} checks")
            if report.get("source_commit") != BASE_COMMIT or report.get("candidate_manifest_sha256") != preflight["source_manifest_sha256"]:
                raise RuntimeError(f"allocation correctness provenance failed for {side}")
            if report.get("timed") is not False or report.get("allocation_only") is not True:
                raise RuntimeError(f"allocation correctness mode failed for {side}")
            shutil.copy2(report_path, output / f"correctness-{side}.json")
            receipt["correctness"][side] = {
                "report": str(output / f"correctness-{side}.json"),
                "boolean_checks": len(booleans),
                "all_boolean_checks_true": True,
                "timed": False,
                "allocation_only": True,
                "binary_sha256_before_measure": sha256(binary),
            }

        if not args.build_and_check_only:
            for side in ("control", "candidate"):
                side_root = work / "allocation" / side
                environment, env_record = sanitized_environment(original_env, harness_root=side_root)
                binary = binaries[side]
                out_jsonl = output / f"allocation-{side}.jsonl"
                log = output / f"measure-{side}.log"
                argv = [str(binary), "measure", str(out_jsonl)]
                records.append(command_record(f"{side}-measure", argv, side_root, log, env_record))
                with log.open("w") as stream:
                    subprocess.run(argv, cwd=side_root, env=environment, stdout=stream, stderr=subprocess.STDOUT, check=True)
                rows = [json.loads(line) for line in out_jsonl.read_text().splitlines() if line.strip()]
                if len(rows) != 240:
                    raise RuntimeError(f"allocation row count for {side}: {len(rows)}")
                for row in rows:
                    if row.get("source_commit") != BASE_COMMIT or row.get("candidate_manifest_sha256") != preflight["source_manifest_sha256"]:
                        raise RuntimeError(f"allocation row provenance failed for {side}")
                    if row.get("timed") is not False or row.get("clock_started") is not False or row.get("allocation_only") is not True:
                        raise RuntimeError(f"allocation row mode failed for {side}")
                receipt["measure"][side] = {
                    "output": str(out_jsonl),
                    "rows": len(rows),
                    "unique_operations": sorted({row["operation"] for row in rows}),
                    "profiles": sorted({row["profile"] for row in rows}),
                    "samples_per_operation_profile": 15,
                    "binary_sha256_after_measure": sha256(binary),
                }

    receipt["commands"] = records
    receipt["completed"] = True
    json_write(output / "allocation-receipt.json", receipt)
    json_write(output / "commands.json", {"format": "litchi-doc-source-owner-portable-allocation-commands/1", "commands": records})
    print(json.dumps({"output": str(output), "measurement_executed": not args.build_and_check_only}, indent=2))


if __name__ == "__main__":
    main()
