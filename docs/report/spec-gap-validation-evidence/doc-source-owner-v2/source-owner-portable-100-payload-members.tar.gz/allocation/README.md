# Allocation companion

This directory contains the allocator harness and a separate portable runner. It is deliberately independent of the wall-clock runner: it builds with allocator instrumentation, verifies 32 correctness booleans per side, and optionally records 240 untimed rows per side.

Use `reproduce_allocation.py` with two frozen source checkouts prepared from the base commit plus `candidate-working-tree.patch`. `--build-and-check-only` performs source/fixture verification, sanitized release builds, and fresh correctness without measuring. A normal run writes `allocation-receipt.json`, `commands.json`, correctness reports, and one 240-row JSONL file per side to the caller output directory.

The retained `evidence-v1` directory is historical and immutable. Its receipt commands and raw JSONL are not combined with latency measurements. `peak_live_bytes` is a counted-phase allocator high-water delta from the setup baseline; it is not RSS or whole-workflow residency.

The common-editor allocation rows deliberately construct `common_targets()` and `common_limits()` inside the counted closure, so those target/limit allocations are included. Fixture creation and caller-owned source/replacement clones are outside the closure. `allocated_bytes` reports fresh allocations plus positive realloc growth; shrinking reallocations affect the separate realloc/live counters without increasing `allocated_bytes`.
