# OLE1 native validation v3 receipt

This bundle is bounded native OLE1 validation for candidate commit `9aa761f071b37edfbb898664338e2819c81e728d`.
It contains only external evidence; the candidate and primary worktrees were not
edited or staged by this validation. v2 remains immutable at
`/var/tmp/ole1-native-validation-v2-20260909`.

## Candidate source binding

Candidate root: `/var/tmp/litchi-ole-streams-validation-20260909`

`candidate-source.sha256` binds the three candidate source files used by the
harness:

- `crates/litchi-ole-common/src/lib.rs`: `3b049cd35ed805ddc84e03238562dc899b829ab058e5a7d8ade4e67bf937ecde`
- `crates/litchi-ole-common/src/ole1.rs`: `b4d2912b5f45b21c1c3b83fd94e54f2a135f07b3a92cc8586726cb3669ab18cd`
- `crates/litchi-ole-common/tests/ole1.rs`: `2ef811dfccf958d2f066b54de1c941a9d6fca99bacf03da3fd2e6d5e94554fe5`

## Harness and commands

Harness root: `/var/tmp/ole1-native-validation-v3-20260909`

`harness-inputs.sha256` binds the harness code, manifest, lockfile, and Cargo
configuration. `commands.txt` records the exact commands. The external harness
was run with:

```text
cargo +1.95.0 run --offline
```

The candidate integration test was run with a separate target:

```text
CARGO_TARGET_DIR=/var/tmp/litchi-ole1-candidate-v3-test-target-20260909 cargo +1.95.0 test --offline -p litchi-ole-common --test ole1
```

Bound log hashes:

- `run-v3.notiming.log`: `6ce3e21acc1563eb460e86b842818731c056d4a3ff738e58f80ddee6bf14d55e`
- `candidate-ole1-tests.notiming.log`: `0273cba841f377edb9dab28c056a7354c4159134c05b862f903908266ccfeb8f`

The bound logs retain pass/fail output while removing Cargo timing suffixes.
No runtime, throughput, or performance measurement was collected.

## Original fixture binding and decoded objects

The `.ole` files below are RTF containers carrying `\objdata`; the harness
extracts only hexadecimal object data through the containing group brace.
`fixture-sources.sha256` records original source hashes and lengths.

| Fixture | Original source | Source bytes | Source SHA-256 | Decoded artifact | Decoded bytes | Decoded SHA-256 |
|---|---|---:|---|---|---:|---|
| `paint-ole` | `/home/zhuhe/code/litchi-spec-gaps/3rdparty/libreoffice-core/sw/qa/extras/htmlexport/data/paint-ole.ole` | 49418 | `5d676d5253fdfc473ed4e318266cfed36f1023b51da53465c88de7a10573b5d2` | `out/paint-ole.decoded.bin` | 24432 | `7b01ea06b83b63477bcaaca21d3b21791d9a6bfbdb826601c27652d035bf5830` |
| `ole2` | `/home/zhuhe/code/litchi-spec-gaps/3rdparty/libreoffice-core/sw/qa/extras/htmlexport/data/ole2.ole` | 80913 | `d6108f2814fcbb82fa13a9fb536d9df2211eaeaafcf59001e83b0db2997013a4` | `out/ole2.decoded.bin` | 38418 | `f7dff8d2109b6e7afda00a9bc94a89a15df1b5cd76e130a05af57dca21eb6da9` |
| `reqif-ole-odg` | `/home/zhuhe/code/litchi-spec-gaps/3rdparty/libreoffice-core/sw/qa/extras/htmlexport/data/reqif-ole-odg.ole` | 18667 | `89aa1ed2eee75a01b1089c196642254e5aa99d312da9f444178f66c147f71904` | `out/reqif-ole-odg.decoded.bin` | 9240 | `067000341cd7f5aa3cef340aa4a04a9260e1664679ccb26693e10736e96fa413` |
| `ole-inline-rtf` | `/home/zhuhe/code/litchi-spec-gaps/test-data/libreoffice-core/sw/qa/extras/rtfimport/data/ole-inline.rtf` | 19374 | `719a9bb8700c46df4ba2b7e1165053e038433056cc89da7ef3d4c9617bcaa751` | `out/ole-inline-rtf.decoded.bin` | 3115 | `e1728ff0e40aae367fcbac004fa606f16c8d4aa5d2f10c3e8422c98edc1e2330` |

Decoded source and payload artifacts are bound by `outputs.sha256`:

| Artifact | Bytes | SHA-256 |
|---|---:|---|
| `out/paint-ole.native.bin` | 17408 | `9f127b9443f60f07bacae309f9f134563d56268bf81df7d1ea61de59a98e9b84` |
| `out/paint-ole.presentation.bin` | 6948 | `311f2ef2a83d7e8417f193a7b85a5c71d7928e795b89c791d12814e8ccc6b0d8` |
| `out/ole2.native.bin` | 37888 | `224c957682a29b95323d026678d434b78514e90126d4263f06065b2330dbc650` |
| `out/ole2.presentation.bin` | 442 | `64afc9a6888c66da2f840db0dca221a80c6d9a1a781a9e62678d7334af0bafe7` |
| `out/reqif-ole-odg.native.bin` | 9216 | `b2a92c8c4abf7cd0f5a7c5a5e9b164df9e2e0ea83129f340e0e84929fe486e41` |
| `out/ole-inline-rtf.native.bin` | 3072 | `54adc05a4590b3598b4ec01aa0b1a2b2012ad205cf4d40ae1344e881cb676720` |
| `out/synthetic-empty-presentation.object.bin` | 46 | `d187d2349e6dd62b67511a5a353fd4160967c08cf7e7d0d204940ed45095626f` |
| `out/synthetic-empty-presentation.native.bin` | 10 | `79e22d92d4a81dcc2597ba6877cbdc2d3a18f4171770be5a4063c073d2334108` |

## Observed behavior

- `paint-ole.ole`: Strict accepted as embedded `PBrush`; native 17,408 bytes;
  typed `MetaFile` presentation, 6,993 bytes, dimensions `1609 x -1609`,
  reserved words `[8, 1609, 1609, 0]`.
- `ole2.ole`: Strict accepted as embedded `PowerPoint.Show.12`; native 37,888
  bytes; typed `MetaFile` presentation, 487 bytes, dimensions `17674 x -9944`,
  reserved words `[8, 17674, 9944, 0]`.
- `reqif-ole-odg.ole`: Strict and `EmptyPresentationHeader` rejected;
  `MissingPresentation` accepted with 9,216 opaque native bytes and no
  presentation.
- `ole-inline.rtf`: Strict and `MissingPresentation` rejected;
  `EmptyPresentationHeader` accepted as source-only `RawFormatZero`; the
  Equation.3 native payload is 3,072 opaque OLE2 bytes and the empty header is
  exactly 8 bytes.
- The synthetic 46-byte empty-header object had the same profile matrix:
  Strict rejected, `EmptyPresentationHeader` accepted, and
  `MissingPresentation` rejected.
- Every admitted source passed exact byte preservation, shared `Arc` identity on
  no-op commit, and inverse restoration where typed rewrites are safe.
- Every admitted source rejected one-byte truncation. Exact ceilings admitted
  valid data; `max_bytes`, native, and presentation ceilings reduced by one
  returned `LimitExceeded` before parsing where applicable.

The candidate integration test log reports 15 passed, 0 failed, and 1 ignored;
the ignored test requires the externally supplied decoded LibreOffice corpus,
which this external harness supplies independently.
