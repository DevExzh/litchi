use litchi_ole_common::ole1::{
    Compatibility, Limits, ObjectRef, ObjectSnapshot,
};
use std::fs;
use std::path::PathBuf;
use std::sync::Arc;

const OUT: &str = "/var/tmp/ole1-native-validation-v3-20260909/out";

#[derive(Clone, Copy)]
struct Fixture {
    name: &'static str,
    path: &'static str,
}

const FIXTURES: &[Fixture] = &[
    Fixture {
        name: "paint-ole",
        path: "/home/zhuhe/code/litchi-spec-gaps/3rdparty/libreoffice-core/sw/qa/extras/htmlexport/data/paint-ole.ole",
    },
    Fixture {
        name: "ole2",
        path: "/home/zhuhe/code/litchi-spec-gaps/3rdparty/libreoffice-core/sw/qa/extras/htmlexport/data/ole2.ole",
    },
    Fixture {
        name: "reqif-ole-odg",
        path: "/home/zhuhe/code/litchi-spec-gaps/3rdparty/libreoffice-core/sw/qa/extras/htmlexport/data/reqif-ole-odg.ole",
    },
    Fixture {
        name: "ole-inline-rtf",
        path: "/home/zhuhe/code/litchi-spec-gaps/test-data/libreoffice-core/sw/qa/extras/rtfimport/data/ole-inline.rtf",
    },
];

fn decode_objdata(source: &[u8]) -> Result<Vec<u8>, String> {
    let marker = b"\\objdata";
    let start = source
        .windows(marker.len())
        .position(|window| window == marker)
        .ok_or_else(|| "missing \\objdata marker".to_owned())?
        + marker.len();
    let end = source[start..]
        .iter()
        .position(|byte| *byte == b'}')
        .map(|offset| start + offset)
        .ok_or_else(|| "unterminated \\objdata group".to_owned())?;
    let body = &source[start..end];
    let mut nibbles = Vec::with_capacity(body.len());
    for byte in body {
        match *byte {
            b'0'..=b'9' | b'a'..=b'f' | b'A'..=b'F' => nibbles.push(*byte),
            b' ' | b'\r' | b'\n' | b'\t' => {},
            other => return Err(format!("unexpected objdata byte 0x{other:02x}")),
        }
    }
    if nibbles.len() % 2 != 0 {
        return Err(format!("odd objdata hex digit count {}", nibbles.len()));
    }
    let mut decoded = Vec::with_capacity(nibbles.len() / 2);
    for pair in nibbles.chunks_exact(2) {
        let high = (pair[0] as char).to_digit(16).expect("validated hex");
        let low = (pair[1] as char).to_digit(16).expect("validated hex");
        decoded.push(((high << 4) | low) as u8);
    }
    Ok(decoded)
}

fn limits_exact(len: usize) -> Limits {
    let ceiling = len.max(1);
    Limits {
        max_bytes: ceiling,
        max_native_bytes: ceiling,
        max_presentation_bytes: ceiling,
        max_string_bytes: ceiling,
        max_registered_format_bytes: ceiling,
    }
}

fn compat_name(value: Compatibility) -> &'static str {
    match value {
        Compatibility::Strict => "Strict",
        Compatibility::EmptyPresentationHeader => "EmptyPresentationHeader",
        Compatibility::MissingPresentation => "MissingPresentation",
    }
}

fn short_hex(bytes: &[u8]) -> String {
    const MAX: usize = 96;
    let shown = &bytes[..bytes.len().min(MAX)];
    let mut output = String::with_capacity(shown.len() * 2 + 16);
    for byte in shown {
        output.push_str(&format!("{byte:02x}"));
    }
    if shown.len() != bytes.len() {
        output.push_str(&format!("...(+{} bytes)", bytes.len() - shown.len()));
    }
    output
}

fn write_artifact(name: &str, suffix: &str, bytes: &[u8]) {
    let path = PathBuf::from(OUT).join(format!("{name}{suffix}"));
    fs::write(path, bytes).expect("write external validation artifact");
}

fn report_header(name: &str, object: &ObjectRef<'_>) {
    let header = object.header();
    println!("{name}: object kind={:?} version=0x{:08x} format_id={} rewrite_safe={}", object.kind(), header.ole_version(), header.format_id(), object.rewrite_safe());
    println!(
        "{name}: class={:?}/{:?} topic={:?}/{:?} item={:?}/{:?}",
        header.class_name().encoding(),
        short_hex(header.class_name().payload()),
        header.topic_name().encoding(),
        short_hex(header.topic_name().payload()),
        header.item_name().encoding(),
        short_hex(header.item_name().payload()),
    );
    if let Some(native) = object.native_data() {
        println!("{name}: native len={} head={}", native.len(), short_hex(native));
        write_artifact(name, ".native.bin", native);
    }
    if let Some(network) = object.network_name() {
        println!("{name}: network={:?}/{}", network.encoding(), short_hex(network.payload()));
    }
    println!("{name}: link_update={:?}", object.link_update_option());
    let presentation = object.presentation();
    println!(
        "{name}: presentation kind={:?} bytes={} format_id={} version=0x{:08x} rewrite_safe={}",
        presentation.kind(),
        presentation.bytes().len(),
        presentation.format_id(),
        presentation.ole_version(),
        presentation.rewrite_safe(),
    );
    if let Some(class) = presentation.class_name() {
        println!("{name}: presentation class={:?}/{}", class.encoding(), short_hex(class.payload()));
    }
    println!(
        "{name}: dimensions={:?}x{:?} reserved={:?} clipboard={:?} registered_form={:?}",
        presentation.width(),
        presentation.height(),
        presentation.metafile_reserved(),
        presentation.clipboard_format(),
        presentation.registered_form(),
    );
    if let Some(name_ref) = presentation.registered_format_name() {
        println!("{name}: registered name={:?}/{}", name_ref.encoding(), short_hex(name_ref.payload()));
    }
    if let Some(data) = presentation.data() {
        println!("{name}: presentation data len={} head={}", data.len(), short_hex(data));
        write_artifact(name, ".presentation.bin", data);
    }
    write_artifact(name, ".object.bin", object.bytes());
}

fn run_snapshot_checks(
    name: &str,
    bytes: &[u8],
    limits: Limits,
    compatibility: Compatibility,
    borrowed: &ObjectRef<'_>,
) -> Result<(), String> {
    let source: Arc<[u8]> = Arc::from(bytes.to_vec());
    let snapshot = ObjectSnapshot::parse_shared(Arc::clone(&source), limits, compatibility)
        .map_err(|error| format!("shared snapshot parse failed: {error:?}"))?;
    if !Arc::ptr_eq(&source, &snapshot.bytes_shared()) {
        return Err("parse_shared did not retain the source Arc".to_owned());
    }
    if snapshot.bytes() != bytes {
        return Err("snapshot bytes differ from source".to_owned());
    }
    let commit = snapshot
        .edit()
        .commit()
        .map_err(|error| format!("no-op commit failed: {error:?}"))?;
    if commit.changed() || !commit.patch().is_noop() {
        return Err("no-op commit reported a change".to_owned());
    }
    if !Arc::ptr_eq(&source, &commit.snapshot().bytes_shared()) {
        return Err("no-op commit did not share source Arc".to_owned());
    }
    if commit.snapshot().bytes() != bytes {
        return Err("no-op commit changed source bytes".to_owned());
    }
    if borrowed.rewrite_safe() {
        let presentation = borrowed.presentation();
        if let Some(width) = presentation.width() {
            let mut edit = snapshot.edit();
            let changed = edit
                .set_width(width.wrapping_add(1))
                .map_err(|error| format!("typed width edit failed: {error:?}"))?;
            if !changed {
                return Err("typed width edit did not change".to_owned());
            }
            let changed_commit = edit
                .commit()
                .map_err(|error| format!("typed width commit failed: {error:?}"))?;
            let restored = changed_commit
                .patch()
                .inverse()
                .apply(changed_commit.snapshot())
                .map_err(|error| format!("inverse patch failed: {error:?}"))?;
            if restored.bytes() != bytes {
                return Err("inverse patch did not restore exact source bytes".to_owned());
            }
        }
    }
    println!("{name}: shared Arc/no-op/inverse checks passed");
    if bytes.len() > 1 {
        let truncated = &bytes[..bytes.len() - 1];
        let result = ObjectRef::parse_with_limits_and_compatibility(
            truncated,
            limits,
            compatibility,
        );
        println!("{name}: truncation(len-1) => {:?}", result.as_ref().err());
        if result.is_ok() {
            return Err(format!("{name}: truncated source was accepted"));
        }
    }
    Ok(())
}

fn parse_status(bytes: &[u8], limits: Limits, compatibility: Compatibility) -> String {
    match ObjectRef::parse_with_limits_and_compatibility(bytes, limits, compatibility) {
        Ok(object) => format!("ok(kind={:?}, presentation={:?})", object.kind(), object.presentation().kind()),
        Err(error) => format!("err({error:?})"),
    }
}

fn push_u32(output: &mut Vec<u8>, value: u32) {
    output.extend_from_slice(&value.to_le_bytes());
}

fn synthetic_empty_presentation() -> Vec<u8> {
    let native = b"{\\rtf1 xyz";
    let mut bytes = Vec::new();
    push_u32(&mut bytes, 0x501);
    push_u32(&mut bytes, 2);
    push_u32(&mut bytes, 4);
    bytes.extend_from_slice(b"RTF\0");
    push_u32(&mut bytes, 0);
    push_u32(&mut bytes, 0);
    push_u32(&mut bytes, native.len() as u32);
    bytes.extend_from_slice(native);
    push_u32(&mut bytes, 0x501);
    push_u32(&mut bytes, 0);
    bytes
}

fn main() -> Result<(), String> {
    fs::create_dir_all(OUT).map_err(|error| error.to_string())?;
    let profiles = [
        Compatibility::Strict,
        Compatibility::EmptyPresentationHeader,
        Compatibility::MissingPresentation,
    ];
    for fixture in FIXTURES {
        let source = fs::read(fixture.path).map_err(|error| format!("{}: {error}", fixture.path))?;
        let decoded = decode_objdata(&source)?;
        write_artifact(fixture.name, ".decoded.bin", &decoded);
        let limits = limits_exact(decoded.len());
        println!("=== {} source={} decoded={} ===", fixture.name, fixture.path, decoded.len());
        println!("{}: strict/default={}", fixture.name, match ObjectRef::parse(&decoded) {
            Ok(object) => format!("ok(kind={:?}, presentation={:?})", object.kind(), object.presentation().kind()),
            Err(error) => format!("err({error:?})"),
        });
        for compatibility in profiles {
            println!("{}: profile {} => {}", fixture.name, compat_name(compatibility), parse_status(&decoded, limits, compatibility));
        }
        let selected = profiles.into_iter().find_map(|compatibility| {
            ObjectRef::parse_with_limits_and_compatibility(&decoded, limits, compatibility)
                .ok()
                .map(|object| (compatibility, object))
        });
        if let Some((compatibility, object)) = selected {
            println!("{}: selected profile {}", fixture.name, compat_name(compatibility));
            report_header(fixture.name, &object);
            run_snapshot_checks(fixture.name, &decoded, limits, compatibility, &object)?;
            let mut too_small = limits;
            too_small.max_bytes = decoded.len() - 1;
            too_small.max_native_bytes = too_small.max_bytes;
            too_small.max_presentation_bytes = too_small.max_bytes;
            too_small.max_string_bytes = too_small.max_bytes;
            too_small.max_registered_format_bytes = too_small.max_bytes;
            let too_small_result = ObjectRef::parse_with_limits_and_compatibility(&decoded, too_small, compatibility);
            println!("{}: max_bytes=len-1 => {:?}", fixture.name, too_small_result.as_ref().err());
            if !matches!(too_small_result, Err(litchi_cfb::OleError::LimitExceeded { .. })) {
                return Err(format!("{}: max_bytes len-1 did not produce LimitExceeded", fixture.name));
            }
            if let Some(native) = object.native_data() {
                if !native.is_empty() {
                    let mut too_small_native = limits;
                    too_small_native.max_native_bytes = native.len() - 1;
                    let result = ObjectRef::parse_with_limits_and_compatibility(&decoded, too_small_native, compatibility);
                    println!("{}: max_native=len-1 => {:?}", fixture.name, result.as_ref().err());
                    if !matches!(result, Err(litchi_cfb::OleError::LimitExceeded { .. })) {
                        return Err(format!("{}: native ceiling did not produce LimitExceeded", fixture.name));
                    }
                }
            }
            let presentation_len = object.presentation().bytes().len();
            if presentation_len > 0 {
                let mut too_small_presentation = limits;
                too_small_presentation.max_presentation_bytes = presentation_len - 1;
                let result = ObjectRef::parse_with_limits_and_compatibility(&decoded, too_small_presentation, compatibility);
                println!("{}: max_presentation=len-1 => {:?}", fixture.name, result.as_ref().err());
                if !matches!(result, Err(litchi_cfb::OleError::LimitExceeded { .. })) {
                    return Err(format!("{}: presentation ceiling did not produce LimitExceeded", fixture.name));
                }
            }
        } else {
            println!("{}: no profile admitted decoded bytes", fixture.name);
        }
    }
    let synthetic = synthetic_empty_presentation();
    let synthetic_limits = limits_exact(synthetic.len());
    write_artifact("synthetic-empty-presentation", ".object.bin", &synthetic);
    println!("=== synthetic empty presentation header decoded={} ===", synthetic.len());
    for compatibility in profiles {
        println!("synthetic-empty-presentation: profile {} => {}", compat_name(compatibility), parse_status(&synthetic, synthetic_limits, compatibility));
    }
    let synthetic_object = ObjectRef::parse_with_limits_and_compatibility(
        &synthetic,
        synthetic_limits,
        Compatibility::EmptyPresentationHeader,
    )
    .map_err(|error| format!("synthetic EmptyPresentationHeader admission failed: {error:?}"))?;
    report_header("synthetic-empty-presentation", &synthetic_object);
    run_snapshot_checks(
        "synthetic-empty-presentation",
        &synthetic,
        synthetic_limits,
        Compatibility::EmptyPresentationHeader,
        &synthetic_object,
    )?;
    let mut synthetic_too_small = synthetic_limits;
    synthetic_too_small.max_bytes = synthetic.len() - 1;
    synthetic_too_small.max_native_bytes = synthetic_too_small.max_bytes;
    synthetic_too_small.max_presentation_bytes = synthetic_too_small.max_bytes;
    synthetic_too_small.max_string_bytes = synthetic_too_small.max_bytes;
    synthetic_too_small.max_registered_format_bytes = synthetic_too_small.max_bytes;
    let result = ObjectRef::parse_with_limits_and_compatibility(
        &synthetic,
        synthetic_too_small,
        Compatibility::EmptyPresentationHeader,
    );
    println!("synthetic-empty-presentation: max_bytes=len-1 => {:?}", result.as_ref().err());
    if !matches!(result, Err(litchi_cfb::OleError::LimitExceeded { .. })) {
        return Err("synthetic empty presentation max_bytes ceiling did not produce LimitExceeded".to_owned());
    }
    println!("ALL EXTERNAL OLE1 CHECKS PASSED");
    Ok(())
}
