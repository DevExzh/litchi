# Cumulative independent adjudication — MS-OVBA pending candidate V1–V5

Date: 2026-09-10 UTC

Candidate under adjudication: `/var/tmp/litchi-vba-pending-validation-v5-20260910`
Base: `5953a2ed1a036179042b55f96a4ee333e554b659`
V5 manifest SHA-256: `e76e15b3e448ef98ce65107f81deb7419a171a5943ef5823ad143d6119e9e6b7`

## Adjudication

**SCOPED CLEAR.** Across the cumulative V1–V5 review chain, every previously
reported blocker is closed for the supported bounded inert feature. The
pending five-path VBA feature remains intact, and no known release blocker
remains within that scope. The candidate and primary worktree were not edited,
staged, or committed by this review.

The earlier receipts are the durable findings record:

* V2 receipt: `/var/tmp/litchi-vba-independent-review-v2-receipt-20260910.md`
  (V2 blocker classes: strict owned admission, lexical acceptance, current
  cache/no-op limits, count/aggregate preallocation, and designer/source
  preservation).
* V3 receipt: `/var/tmp/litchi-vba-independent-review-v3-receipt-20260910.md`
  (workspace grammar/ownership, fresh versus source-bound names, projected
  known-reference sizing, changed-path limits, and PROJECTwm reservation).
* V4 receipt: `/var/tmp/litchi-vba-independent-review-v4-receipt-20260910.md`
  (all five V3 closures, with the remaining non-ASCII precharge blocker).
* V5 receipt: `/var/tmp/litchi-vba-independent-v5-review-receipt.md`
  (chunked non-ASCII MBCS/UTF-16 preflight, all-code-page and exact-wire
  boundary verification).

V5 independently reproduced the inherited V2–V4 closure probes and exercised
all 30 supported byte-stream code pages. Registered, project, control, and
original references produced exact expected bytes across multi-byte chunk
boundaries; fresh and source-bound name paths precharged before whole-value
allocation. Root's frozen V5 gates pass 47 tests with zero ignored tests,
strict all-target/all-feature Clippy and rustdoc, pinned rustfmt, and diff
checks.

## Supported boundary

This adjudication covers bounded, inert MS-OVBA CFB projects: `_VBA_PROJECT`,
`PROJECT`, `PROJECTwm`, optional `PROJECTlk`, `VBA/dir`, compressed module
source streams, typed external references (registered/project/control/original
plus bounded opaque records), source-bound reference edits, project-window and
host-extender metadata, and the finite `VBFrame` designer metadata path. It
covers strict owned-payload admission, deferred low-level source-reader
compatibility where documented, current-limit enforcement, source-preserving
no-ops/inverse edits, and bounded authoring for those APIs. References remain
metadata; the crate does not resolve libraries, execute or compile macros, or
activate controls.

This is not a claim of complete MS-OVBA coverage. Password-hash work, broad
unmodeled records/producer extensions, macro semantics, and other MS-OVBA
features outside the five owned paths remain separate scope.

The V5 receipt records one intentional diagnostic ordering: an over-limit giant
malformed non-ASCII Libid can return `LimitExceeded` before deferred full
Libid grammar validation, while default limits return `InvalidData`. The
operation is refused and no malformed wire value is emitted; this is not an
unresolved blocker for the bounded precharge contract.
