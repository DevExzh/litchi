# MS-OVBA V5 non-ASCII reference preflight validation

This is an uncommitted, unstaged V5 candidate for the pending VBA feature. It is based on `5953a2ed1a036179042b55f96a4ee333e554b659` and carries the frozen V4 five-path overlay from `/var/tmp/litchi-vba-pending-validation-v4-20260910`. V4 evidence remains at `/var/tmp/litchi-vba-pending-validation-v4-evidence-20260910`; its manifest SHA is recorded in `candidate-manifest-v5.json`.

V5 closes the independent V4 finding that non-ASCII `Mbcs::encode` could allocate an entire known reference before the projected `dir` limit rejected it. `dir.rs` now measures strict MBCS output in 256-byte UTF-8-boundary chunks, checks representability and encoded NULs, and only performs whole-value encoding after aggregate checks pass. `push_string_pair` and `push_mbcs_pair` preflight their MBCS and UTF-16 record sizes before full encoding. The source-bound name path therefore keeps its prior MBCS-record diagnostic (`actual=90006`) while avoiding the 262144-byte allocation.

The actual writer still performs the existing full encoding and Libid/Project grammar validation after the size preflight succeeds. This preserves exact bytes and strict no-replacement behavior for successful authoring. Source-backed references continue to copy retained wire bytes except for the explicitly edited name record.

Validation completed with Rust `1.95.0`:

* 42 library tests, 5 integration tests, and 0 doctests passed;
* all-target/all-feature Clippy with `-D warnings` passed;
* warning-denied rustdoc passed;
* pinned rustfmt and `git diff --check` passed; and
* the independent deep probe reduced the three V4 non-ASCII cases to max allocations 4096 (fresh registered), 512 (changed source-bound reference), and 512 (source-bound name edit), while preserving the source-bound `actual=90006` diagnostic.

A separate probe exercised all 30 supported `Mbcs` byte-stream code pages with a representable non-ASCII character and a 90000-character reference under the same 1000-byte decompressed-stream ceiling. Every case stayed below the 64 KiB probe threshold; its raw output and source are included here. The independent allocation probe and all package logs are also included. These are diagnostic probes, not production timing claims.

Use `candidate-manifest-v5.json` for the exact five source hashes and evidence hashes. Use `commands.txt` for the exact commands. No files in the primary worktree were edited, staged, or committed.
