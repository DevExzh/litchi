# Independent review receipt: litchi-vba frozen V3

Date: 2026-09-10 UTC
Candidate: `/var/tmp/litchi-vba-pending-validation-v3-20260910`
Base: `5953a2ed1a036179042b55f96a4ee333e554b659`
Manifest: `/var/tmp/litchi-vba-pending-validation-v3-evidence-20260910/candidate-manifest-v3.json`
Manifest SHA-256: `4715fd1835556f86ec5edc32280b125847ec6acf120832444d0fbdda49614247`

This was a read-only review. No candidate or primary files were edited, staged, or committed. The five manifest-owned source hashes and fourteen evidence-file hashes independently matched the frozen manifest; candidate status remains exactly five modified VBA paths at the manifest base.

## Verification

On CPU set 8-31 with Rust `+1.95.0`, independently ran:

* `cargo +1.95.0 test -p litchi-vba --all-features`: 41 library tests, 5 real-fixture integration tests, and 0 doctests passed.
* Inspected the frozen warning-denied clippy, rustdoc, pinned rustfmt, and diff-check logs; all report success.
* Re-ran the frozen V3 semantic probe (`reviewer-v3-probe.rs`, SHA-256 `76a20d0007675e8185ebae1dbe910adf3a11d1b616b3803cd6d9a4a89321a023`; output SHA-256 `9ad5e9e7b66dd713545291702d159916965b43a7b1d24588d755c1d8f5fffc17`). It rejects dir trailing bytes, PROJECT Name mismatch, missing/extra module closure, partial PROJECT text, invalid fresh project/reference names, and all three max-modules cache/no-op calls while retaining permissive direct partial `ProjectText::parse`.
* Re-ran the frozen V3 allocator probe (`allocation-v3-probe.rs`, SHA-256 `ad9029a47b74d84dbddebd7e78ba3aec4506c1194aa09d81d3be717107884a59`; output SHA-256 `3d8ec4a6195f553de77f14678dcd6ea24d33e879727e266fa48274e280cedb25`). It reports the claimed maxima: PROJECTlk short count `max_alloc=1664`, opaque 100,000-byte reference under a 1,000-byte ceiling `max_alloc=1`, fresh opaque reference `max_alloc=4096`, and short dir module count `max_alloc=256`.
* Additional focused source/limit probe `/var/tmp/litchi-vba-independent-v3-sourcecompat2/src/main.rs` (SHA-256 `acf128f3584e7bcbc30b31e82573f944d063b9af527a5ad43f4a5fd14c6c0bfe`), output `/var/tmp/litchi-vba-independent-v3-sourcecompat2.log` (SHA-256 `b0e507bcb3d7d4282d9f6c1bad036c5cdfb3db30dfca9b11e2f229cec880ea25`).
* Additional allocator probe `/var/tmp/litchi-vba-independent-v3-alloc-wm/src/bin/alloc.rs` (SHA-256 `8ad85b4bddc6069d2f85abe29e7cdad1ac622487143d2be55e37c7691d2d3bfd`), output `/var/tmp/litchi-vba-independent-v3-alloc-wm.log` (SHA-256 `7de40b7301524d30a49cd356fc0cf13276378d660887de43a85785bd235cad40`).

Normative checks used local Markdown under `3rdparty/specs/[MS-OVBA]/2 Structures/2.1 Conventions.md`, `2.2 File Structure.md`, `2.3 Record Types.md`, and `[MS-VBAL]/3 Lexical Rules for VBA Programs/3.3 Lexical Tokens.md`. The relevant rules are PROJECT grammar 2.3.1, ProjectWindowRecord 2.3.1.20, MODULE/ProjectModule closure 2.3.1.3 and 2.3.4.2.3.2, ReferenceName 2.3.4.2.2.2, and the finite resource bounds in the accepted ADRs.

## Findings

### 1. Strict PROJECT admission still accepts invalid workspace ownership and missing separator

`ProjectWindowRecord` MUST have a corresponding `ProjectModule` (local `[MS-OVBA]` 2.3.1.20). `validate_payload_structure` checks duplicate window names but never checks a window's module name against the PROJECT module declarations or the directory modules (`crates/litchi-vba/src/project.rs:576-593`). Starting from a valid one-module payload, appending:

```
\r\n[Workspace]\r\nGhost=0, 0, 0, 0, C\r\n
```

returned `payload-workspace-ghost: Ok(1)` from `Payload::read`; it must be rejected. The same probe appended `[Workspace]` directly after the Host Extender header, without the grammar's extra `NWLN` separator, and got `payload-workspace-no-separator: Ok(1)`. The strict checker accepts `WorkspaceSection` directly at the host loop (`project.rs:551-575`) even though the ABNF is `[NWLN ProjectWorkspace]`.

### 2. Source compatibility for `stdole-edited` leaks into fresh invalid authoring

The local ReferenceName rule is `RefProjectName = VbaIdentifier` and `RefLibraryName = Identifier` (`[MS-OVBA]` 2.3.4.2.2.2). The source-bound compatibility edit is correct: `edit_name_source_bound("stdole-edited")` succeeds and the edited directory re-encodes (`source-bound-stdole-edited: Ok(201)`). But V3's shared Library validator explicitly allows `'-'` (`crates/litchi-vba/src/dir.rs:1279-1305`) and the fresh builder path uses that validator from `encoded_reference_size` and `encode_reference_inner` (`dir.rs:976-980`, `1174-1187`). Independent fresh authoring returned:

```
fresh-library-ref-name-stdole-edited: Ok(3584)
fresh-control-extended-name-stdole-edited: Ok(3584)
```

The source-bound exception needs to remain confined to retained source wire/edit paths; the fresh `Reference::registered` and nested extended control-name paths must refuse the hyphenated C706 Identifier.

### 3. Aggregate directory bound is still checked after allocating large known reference fields

The V3 opaque-reference probe is fixed, but `encoded_reference_size` still calls `encode_libid_reference_bytes` before `encode_reference` performs the projected stream-size check (`dir.rs:991-1018` versus `dir.rs:955-964`). A fresh registered reference with a valid approximately 99 KiB LibidPath and `max_decompressed_stream_bytes=1000` returned the expected limit error, but the counting allocator observed:

```
fresh-registered-dir-result=Err(LimitExceeded { limit: "decompressed VBA stream bytes", actual: 99196, maximum: 1000 }) max_alloc=99049
```

The precharge must calculate/validate the encoded size without materializing a reference-sized temporary, or otherwise reject against the projected aggregate before that allocation. The same shape applies to project/control/original known reference bodies.

### 4. Changed source-bound directory edits bypass current module/reference limits

`Project::encode_dir_with_references` checks the replacement slice's reference count but, on a changed-reference path, parses and copies the existing module suffix without charging the source module count, and parses existing references without charging the source reference count (`crates/litchi-vba/src/dir.rs:802-864`). With one source module and one source registered reference, the independent probe returned:

```
changed-dir-max-modules-zero: Ok(186)
changed-dir-max-references-zero: Ok(118)
```

The no-op path calls `Dir::parse_decompressed` and correctly rejects these limits, so the mutation path is inconsistent with the documented `Limits` ceilings and the accepted ADR's per-operation budget rule.

### 5. PROJECTwm still reserves the module vector before a minimum-record preflight

`parse_project_wm` checks `modules.len() <= max_modules`, then immediately executes `Vec::with_capacity(modules.len())` before checking whether the source contains even one MBCS/Unicode pair per module (`crates/litchi-vba/src/project.rs:1362-1425`). A generated 4,096-module project with a one-byte PROJECTwm stream produced:

```
project-wm-short-4096-result=Err(InvalidData("PROJECTwm MBCS module name is empty")) max_alloc=196608
```

This is the same count-before-structural-preflight class as the fixed PROJECTlk and dir-module paths; it needs a minimum byte preflight before `Vec` reservation.

## Verdict

**BLOCKED.** The V3 changes close the four originally observed V2 probes, but strict workspace grammar/ownership, fresh-vs-source-bound ReferenceName separation, complete projected-output precharge, mutation limit charging, and PROJECTwm minimum preflight remain release blockers. The durable receipt is this file. No candidate or primary mutation, staging, or commit was performed.
