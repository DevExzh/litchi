# Independent VBA V5 review receipt — 2026-09-10

Candidate: `/var/tmp/litchi-vba-pending-validation-v5-20260910`
Evidence: `/var/tmp/litchi-vba-pending-validation-v5-evidence-20260910`
Base: `5953a2ed1a036179042b55f96a4ee333e554b659`
Manifest SHA-256: `e76e15b3e448ef98ce65107f81deb7419a171a5943ef5823ad143d6119e9e6b7`

## Verdict

**SCOPED CLEAR for the V5 non-ASCII preflight change.** The candidate and
primary worktree were not edited, staged, or committed by this review.

The five candidate source files still match the supplied manifest. V5 is the
V4 overlay plus the chunking/preflight changes in `dir.rs`; no unrelated source
path changed. The prior V4 receipt's five semantic and allocation closures
remain applicable.

## Independent checks

* The pinned independent deep probe reproduced the V4 fresh/changed/source
  limits: fresh registered non-ASCII rejection stayed at max allocation 4096;
  changed registered and source-bound non-ASCII name rejection stayed at 512;
  cached current-limit checks and source-bound name grammar checks remained
  bounded and correct.
* The all-code-page probe exercised all 30 `Mbcs` IDs admitted by this source
  (`866, 874, 932, 936, 949, 950, 1250..1258, 10000, 20866, 20932, 21866,
  28592..28598, 28603, 28605, 54936, 65001`). Every representable
  non-ASCII boundary case was emitted successfully and stayed below the
  64-KiB allocation probe threshold.
* A raw decoded `VBA/dir` comparison used 255 ASCII bytes followed by 300
  copies of a page-specific multi-byte character. All 30 encoded Libid byte
  sequences exactly matched one-shot `Mbcs::encode` output, including the
  256-byte UTF-8 chunk boundary. The supported `Mbcs` set contains no
  stateful encoder; all accepted byte-stream adapters are stateless, so the
  boundary method has no untested state transition in this API.
* Non-ASCII `REFERENCENAME` and nested control-name probes rejected projected
  output before whole-value MBCS/UTF-16 allocation (fresh max allocation
  4096; source-bound name edit 512), and retained the expected
  `decompressed VBA stream bytes` diagnostics.
* Pinned owner/root evidence reports 42 library + 5 integration tests, zero
  ignored, all-target/all-feature warnings-denied Clippy/rustdoc, pinned
  rustfmt, and diff checks passing. The root V5 overlay independently reports
  the same 47-test source gates.

Probe source/log hashes:

* boundary source `9d9620c7fbc8a348401076ff8f9e041774a4976c25c05a41bcdb97e533081bb0`, log `4abc4ea786a93c3af269a7fd6d9fa287aeea9f23ae1cba82882633db89f9727`;
* malformed-precedence source `8778ebce14bc0050df6cd825b646575c3344d68d401398b701f84ade4a497922`, log `9161babff8257432304e5e4a7729935c49878848d8d5088198cfe60ceef4024a`;
* string-pair source `61f33d0fda0bed9e338c5fad999097f65983731b6cc5a8823b797c25bc0cecbe`, log `9deacc28318d8c95109b48e1bdda5b84935ca32b4bed73d21dcf0a6ffc174d60`.

One intentional diagnostic ordering is observable: a giant malformed
non-ASCII Libid under `max_decompressed_stream_bytes = 1000` returns the
projected `LimitExceeded` before the deferred full Libid grammar check; with
default limits it returns `InvalidData`. V5 documents this ordering because
full grammar validation would require the allocation that the precharge is
designed to avoid. No malformed value is emitted or accepted. I did not count
this as a blocker because the operation is refused under the configured
resource ceiling and the local MS-OVBA requirements govern emitted records;
lexical-first error precedence would be a separate policy requirement.

A route probe also exercised the same boundary value through all four typed
reference routes (registered, project, control, and original) on pages 932,
936, 949, 950, 20932, 54936, and 65001; every raw Libid/project-path sequence
matched direct encoding. Route source SHA-256 is
`31375637322e70539e349793a87ef041e05296fb7353749d32bff9190e33d687`, and its
log SHA-256 is
`72d35557fa992c85697d8dd78c477700a2fc140e7420c08fb7d895d01c748d26`.
