use litchi_codepage::Mbcs;
use litchi_vba::{Limits, build::{Module, Project}, dir::Reference};
use std::{alloc::{GlobalAlloc, Layout, System}, sync::atomic::{AtomicUsize, Ordering}};

static MAX_ALLOC: AtomicUsize = AtomicUsize::new(0);
struct Counting;
unsafe impl GlobalAlloc for Counting {
    unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
        MAX_ALLOC.fetch_max(layout.size(), Ordering::Relaxed);
        System.alloc(layout)
    }
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout) { System.dealloc(ptr, layout); }
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, size: usize) -> *mut u8 {
        MAX_ALLOC.fetch_max(size, Ordering::Relaxed);
        System.realloc(ptr, layout, size)
    }
}
#[global_allocator]
static GLOBAL: Counting = Counting;

fn main() {
    let ids = [866, 874, 932, 936, 949, 950, 1250, 1251, 1252, 1253, 1254, 1255, 1256, 1257, 1258, 10000, 20866, 20932, 21866, 28592, 28593, 28594, 28595, 28596, 28597, 28598, 28603, 28605, 54936, 65001];
    let choices = ["é", "界", "Ж", "א", "Ω", "ش", "あ", "한", "€", "ø", "ñ", "😀"];
    let limits = Limits { max_decompressed_stream_bytes: 1_000, max_string_bytes: 100_000, ..Limits::default() };
    for id in ids {
        let page = Mbcs::new(id).expect("listed page");
        let choice = choices.iter().find(|candidate| page.encode(candidate).is_ok()).expect("one non-ASCII test character is representable");
        let libid = format!("*\\G{{00000000-0000-0000-0000-000000000000}}#0.0#0#{}#", choice.repeat(90_000));
        MAX_ALLOC.store(0, Ordering::Relaxed);
        let result = Project::new("P")
            .page(page)
            .module(Module::standard("M", ""))
            .reference(Reference::registered("stdole", libid))
            .finish(&limits);
        let max = MAX_ALLOC.load(Ordering::Relaxed);
        println!("page={id} choice={choice} result={result:?} max_alloc={max}");
        assert!(max < 64 * 1024, "page {id} materialized an oversized buffer: {max}");
    }
}
