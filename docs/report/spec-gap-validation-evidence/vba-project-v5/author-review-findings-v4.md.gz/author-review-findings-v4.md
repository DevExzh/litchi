# V4 independent blocker closure

V4 is a detached, uncommitted overlay of the frozen V3 candidate at the same
base commit. V3 and the primary worktree remain untouched.

The V3 review identified five blockers. V4 addresses them as follows:

1. The local MS-OVBA grammar is `VBAPROJECTText = ProjectProperties NWLN
   HostExtenders [NWLN ProjectWorkspace]`. Strict owned admission now rejects a
   direct Workspace section after Host Extender Info, and each ProjectWindowRecord
   must name exactly one PROJECT module and exactly one directory MODULE. A
   matching window with the required separator remains accepted. Low-level
   ProjectText parsing remains deferred/permissive.
2. Fresh ReferenceName authoring now applies `RefProjectName = VbaIdentifier`
   and `RefLibraryName = Identifier` without the compatibility hyphen. The
   source-bound name-edit API uses a separate validator so an existing retained
   `stdole-edited` spelling can still be rewritten with its source reserved
   fields intact. Nested fresh control names use the strict path.
3. Reference size preflight no longer calls the allocating MBCS encoder for
   ASCII known fields. Registered, project, control, original, and string-pair
   paths use the same validated length helper before the projected directory
   limit is checked. The actual encoder runs only after the reference fits the
   remaining output budget.
4. Changed reference-array edits now count and limit the source reference
   records and the preserved PROJECTMODULES count before building replacement
   output. The exact no-op path continues to reparse the complete source under
   current limits.
5. PROJECTwm rejects any input shorter than six bytes per non-empty MBCS/
   Unicode pair plus its two-byte stream terminator before reserving its map
   vector; reservation is fallible.

The direct source reader still preserves its deferred behavior and ignored
reserved fields. The strict changes are confined to the owned admission and
authoring paths described above.
