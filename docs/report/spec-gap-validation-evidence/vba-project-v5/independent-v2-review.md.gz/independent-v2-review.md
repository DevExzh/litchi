# Independent review receipt: litchi-vba frozen V2

Date: 2026-09-10 UTC
Candidate: `/var/tmp/litchi-vba-pending-validation-v2-20260910`
Base: `5953a2ed1a036179042b55f96a4ee333e554b659`
Manifest: `/var/tmp/litchi-vba-pending-validation-v2-evidence-20260910/candidate-manifest-v2.json`
Manifest SHA: `0c65ef009fe8a4efd51e621a12794d8a6d69d91a4c655ed46e03ae75758925ee`

This is a read-only review. No candidate or primary files were edited, staged, or
committed. The five manifest-owned source hashes and all evidence-file hashes
independently matched the manifest. The candidate worktree remains exactly five
modified VBA paths at the manifest base.

## Verification run

On CPU set 8-31 with Rust `+1.95.0`, independently ran:

* `cargo +1.95.0 test -p litchi-vba --all-features`: 40 library tests, 5 real-fixture integration tests, and 0 doctests passed.
* The frozen evidence's clippy, rustdoc, rustfmt, and diff-check logs were inspected; the author evidence reports the same 40/5 suite and warning-denied checks.
* Focused probe source: `/var/tmp/litchi-vba-independent-v2-probe/src/main.rs`, SHA-256 `76a20d0007675e8185ebae1dbe910adf3a11d1b616b3803cd6d9a4a89321a023`; output `/var/tmp/litchi-vba-independent-v2-probe.log`, SHA-256 `78b15e799f6f4cf33248dae94b69a6122aa49d0df3f69020e10a999d8e8162ee`.
* Allocation probe source: `/var/tmp/litchi-vba-independent-v2-probe/src/bin/alloc.rs`, SHA-256 `db135d89ff6a3e35330ed81cd4270c9cb8f270f97613054dd91f92b2f5ae41bb`; output `/var/tmp/litchi-vba-independent-v2-alloc.log`, SHA-256 `f2f1786212ff02843b0f4d8980f587ae32b1d805986e654c65948504038b92bd`.

Normative checks used the local Markdown under `3rdparty/specs/[MS-OVBA]/`, especially
`2 Structures/2.1 Conventions.md`, `2 Structures/2.2 File Structure.md`,
`2 Structures/2.3 Record Types.md`, and local `[MS-VBAL]/3 Lexical Rules for VBA Programs/3.3 Lexical Tokens.md`.

## Fixed in V2

* `Payload::read` now eagerly parses malformed root `PROJECT` and `PROJECTwm` streams and rejects a designer whose `BaseClass` has no unique `VBFrame`; the independent payload probes returned errors for all three. Direct `Project::open` remains deferred as documented, and its typed accessors report the malformed stream.
* Cached PROJECT text, exact PROJECT encode, cached/exact PROJECTwm encode, and exact directory no-op paths reapply string/decompressed limits. Independent max-string/max-decompressed probes returned `LimitExceeded`.
* The module-source loop bounds each codec decode by the remaining aggregate source budget. An independent `max_total_source_bytes=1` read returned `LimitExceeded { limit: "aggregate VBA module source bytes", ... }` before a later source allocation.
* The V2 ModuleIdentifier change correctly permits the local spec's arbitrary module-character form (`1 Module`) while retaining the 31-character and line/null bounds. The QUOTEDCHAR parser accepts tab, DEL, and C1 bytes. HEXINT32 signed overflow, duplicate window-state flags, case-insensitive tokens, and source-bound reference name edits remained correct.
* Known VBFrame properties now reject out-of-order, duplicate, and post-End records, while an unknown property line remains readable and source-preserved. Independent probe: `vbframe-unknown-preserved: Ok((1, true))`.
* Fresh top-level empty REFERENCENAME values now fail; unchanged source-bound references still retain their wire spans and ignored reserved fields, and remove/re-add/opaque-reference probes remain byte/source preserving.

## Remaining release blockers

### 1. Payload admission is not structurally strict across PROJECT text

`Payload::read` calls `ProjectText::parse` at `crates/litchi-vba/src/build.rs:701-704`,
but `ProjectText::parse` at `crates/litchi-vba/src/project.rs:390-440` accepts a
partial/unknown record sequence and `validate_designer_ownership` checks only the
BaseClass/VBFrame subset. It does not enforce the required PROJECT grammar or
cross-stream identities.

Independent mutations of a valid payload all returned `Ok(1)` from `Payload::read`:

* `PROJECT` `Name="Q"` while dir `PROJECTNAME` remains `P` (`ProjectName` MUST equal `PROJECTNAME`).
* `PROJECT` with no `Module=M` record (each `MODULE` MUST have a `ProjectModule`).
* `PROJECT` with an extra `Module=Ghost` record (each `ProjectModule` MUST have a corresponding `MODULE`).
* `PROJECT` containing only `Name="P"\r\n`, with required ID/module/protection/host-extender records absent.

The local rules are `[MS-OVBA] 2.3.1` (`VBAPROJECTText = ProjectProperties NWLN HostExtenders [NWLN ProjectWorkspace]`), 2.3.1.3 / 2.3.1.11 (module correspondence and Name equality), and 2.3.4.2.3.2 (every MODULE has a ProjectModule). `Project::open` may remain deferred/permissive per the V2 contract, but the same acceptance through `Payload::read` contradicts the advertised strict owned-payload admission.

The same payload probe appended two bytes after the dir-stream terminator and `Payload::read` still returned `Ok(1)`. `find_references_and_modules` does not require its reader to end after the 0x0010 terminator/reserved field, although local 2.3.4.2 defines that terminator as the end of the version-independent stream.

### 2. PROJECTNAME and ReferenceName lexical grammar remain unchecked

`build.rs:792-807` only checks PROJECTNAME nonempty, length, and QUOTEDCHAR;
`dir.rs:1408-1416` does the same on read. Independent fresh builder probes all
returned `Ok` for `1Project`, `Project Name`, reserved `End`, and `P!`.
The local `[MS-OVBA] 2.3.4.2.1.6` record requires a VBA identifier for PROJECTNAME.
The text-level `Name` rule permits arbitrary QUOTEDCHAR, but it MUST equal that
identifier, so accepting arbitrary values for the shared builder name creates an
invalid PROJECTNAME record.

`dir.rs:1048-1060` only rejects empty/newline ReferenceName values. Independent
fresh project and registered-reference probes returned `Ok` for `Bad Name`,
`1Bad`, `End`, and `P!`. Local `[MS-OVBA] 2.3.4.2.2.2` requires
`RefProjectName = VbaIdentifier` and `RefLibraryName = Identifier`. The optional
nested extended name emitted in `encode_control_reference` is not passed through
the new validator either (`dir.rs:1249`). This is a grammar gap; no ModuleIdentifier
restriction should be added because that local rule explicitly permits arbitrary
module strings up to 31 characters.

### 3. Current max_modules is bypassed by typed/cache/no-op PROJECTwm paths

After opening and caching a one-module project under default limits, the independent
probe called all of these with `Limits { max_modules: 0, ..default }`:

* `project.project_text(...)` -> `Ok(())`
* `project.project_wm(...)` -> `Ok(Some(1))`
* `project.encode_project_wm(parsed_maps, ...)` -> `Ok(8)`

`ProjectText::parse` has no module-count charge, `parse_project_wm` only checks
stream/string bytes, and `encode_project_wm` has no current module-count check.
If `Limits` is a per-call bound as the cache/no-op API contract states, these are
remaining bypasses; the fix needs to charge the current module/map count before
returning a cached or exact source result.

### 4. Count and aggregate output allocations still occur before structural/projected checks

The V2 delta did not fix the following precharge gaps:

* `project.rs:1537-1546` checks `max_licenses` and then calls
  `Vec::with_capacity(count)` before checking that the input contains the minimum
  fixed bytes for `count` LICENSEINFO records. A six-byte PROJECTlk with count
  4096 returned the expected truncation error, but an independent counting global
  allocator observed a largest allocation of 196,608 bytes before that error.
* `dir.rs:798-811` accumulates `encoded_references`, and `dir.rs:901-911`
  allocates a complete temporary `encoded` reference before checking the projected
  aggregate `decompressed VBA stream bytes`. A 100,000-byte opaque reference with
  `max_decompressed_stream_bytes=1000` returned the limit error only after a
  100,006-byte allocation.
* `dir.rs:673-760` similarly grows the fresh directory output and checks the
  aggregate ceiling only after each record has been appended. `dir.rs:1665`
  reserves the declared module count before a minimum-record-size preflight.
  These remain relevant to the strict bounds-before-allocation requirement even
  though the count fields are capped by ordinary defaults.

## Verdict

**BLOCKED.** The V2 fixes close the claimed malformed-stream, cache-string/stream,
source-aggregate, ModuleIdentifier/QUOTEDCHAR, VBFrame-order, and fresh-empty-name
regressions, but the four remaining classes above prevent a scoped CLEAR for a
strict, bounded MS-OVBA payload feature. The durable independent receipt is this
file; no candidate/primary mutation, staging, or commit was performed.
