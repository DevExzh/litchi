VBA V4 independent review receipt — 2026-09-10

Candidate: /var/tmp/litchi-vba-pending-validation-v4-20260910
Evidence: /var/tmp/litchi-vba-pending-validation-v4-evidence-20260910
Base: 5953a2ed1a036179042b55f96a4ee333e554b659
Manifest: candidate-manifest-v4.json
Manifest SHA-256: 6261e5057ac01d5055c4a17c379f5d5289b56d4dc769784fb556f3f9c1c4590c
Owned source hashes matched the manifest. Candidate and primary remained unedited by this review; no staging or commit.

Validation:
- Candidate pinned Rust +1.95.0 test -p litchi-vba --all-features: 41 library, 5 real-fixture integration, 0 doctests passed.
- Frozen strict Clippy, warnings-denied rustdoc, rustfmt, and diff-check logs passed.
- Independent V4 semantic probe source SHA-256 acf128f3584e7bcbc30b31e82573f944d063b9af527a5ad43f4a5fd14c6c0bfe; run log SHA-256 167168fd6dc7b5d296f90c7a9a619214592ac444814692c7b0876db7c7e85082.
- Independent V4 allocation probe source SHA-256 8ad85b4bddc6069d2f85abe29e7cdad1ac622487143d2be55e37c7691d2d3bfd; run output reproduced PROJECTlk max_alloc=1664, dir module max_alloc=256, and PROJECTwm max_alloc=104.
- Broader independent probe source SHA-256 47b9496c8e993b7faa4d2abdcd935529cdfea5fcd2e3c56e18ab78488bf7d080; log SHA-256 3ac43161d98429443aff7999577708952c905ddb39d7702591c7f69bac458f07.

The five V3 blockers are fixed and independently reproduced:
- owned Payload rejects a workspace Ghost window and a missing NWLN separator;
- fresh registered/control library names reject stdole-edited while source-bound retained spelling succeeds;
- changed source-bound directory edits enforce zero max_modules/max_references;
- known ASCII registered/project/control/original reference projected sizing rejects before large field materialization;
- PROJECTwm short 4096-module input rejects before map reservation.

Verdict: BLOCKED on a remaining non-ASCII reference precharge gap. With Limits { max_decompressed_stream_bytes: 1000, max_string_bytes: 100000 }, fresh registered LibidReference containing 90,000 CP1252-encodable U+00E9 path characters returns the correct projected-size LimitExceeded but max_alloc=262144. A changed source-bound directory replacement with the same non-ASCII registered LibidReference has max_alloc=262144 before the same rejection. A source-bound edit_name_source_bound replacement name of 90,000 U+00E9 characters likewise returns LimitExceeded (actual 90006, maximum 1000) with max_alloc=262144. ASCII controls remain bounded (fresh max_alloc=4096, changed max_alloc=1).

The gap is in crates/litchi-vba/src/dir.rs:1606-1640: encoded_reference_value_len borrows only the ASCII path but calls encoding.encode(value) for non-ASCII before encoded_reference_size can check the projected directory limit. The source-bound name route at lines 203-249 has the same pre-output encoding behavior. This is a real aggregate-limit-before-materialization failure under the candidate’s stated projected known-reference precharge contract.

Cached current-limit checks passed independently for project text, PROJECTwm, exact project-text encoding, exact PROJECTwm encoding, and no-op dir encoding with max_string_bytes=0. Normative checks used local MS-OVBA 2.3.1, 2.3.3, 2.3.4.2.1.6, 2.3.4.2.2.2 and MS-VBAL 3.3.5.

