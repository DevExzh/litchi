//! Batch 0/1 read-only integration coverage for worksheet form controls.
//!
//! The fixture corpus is deliberately exercised through the public worksheet
//! facades.  ZIP rewrites below only create bounded, structurally valid test
//! inputs for a single targeted refusal or fallback rule; no test writes an
//! XLSX result or claims native application acceptance.
#![allow(
    clippy::unwrap_used,
    reason = "focused fixture assertions panic on failure"
)]
#![allow(
    clippy::expect_used,
    reason = "focused fixture assertions panic on failure"
)]

use std::io::{self, Cursor};
use std::path::{Path, PathBuf};
use std::sync::Arc;
use std::sync::atomic::{AtomicU64, AtomicUsize, Ordering};

use litchi_core::{EvidenceDigest, ReadAt, SourceVersion};
use litchi_opc::{OpcError, ReadLimits};
use litchi_xlsx::form_control::{
    ControlSelector, FormControlDiagnosticCode, KnownOrUnknown, OwnerLimits, OwnerProfile,
    Properties,
};
use litchi_xlsx::{Error, SourceBackedWorkbook, Workbook};
use serde_json::Value;
use soapberry_zip::office::{ArchiveReader, StreamingArchiveWriter};

const FORM_CONTROL_NAMESPACE: &str =
    "http://schemas.microsoft.com/office/spreadsheetml/2009/9/main";
const SML_NAMESPACE: &str = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
const STRICT_SML_NAMESPACE: &str = "http://purl.oclc.org/ooxml/spreadsheetml/main";
const CONTROL_PROPERTIES_CONTENT_TYPE: &str = "application/vnd.ms-excel.controlproperties+xml";
const ACTIVEX_CONTENT_TYPE: &str = "application/vnd.ms-office.activeX+xml";
const CONTROL_PROPERTIES_RELATIONSHIP: &str =
    "http://schemas.openxmlformats.org/officeDocument/2006/relationships/ctrlProp";
const ACTIVEX_RELATIONSHIP: &str =
    "http://schemas.openxmlformats.org/officeDocument/2006/relationships/control";
const STRICT_ACTIVEX_RELATIONSHIP: &str =
    "http://purl.oclc.org/ooxml/officeDocument/relationships/control";
const NATIVE_CORPUS: &str = include_str!(concat!(
    env!("CARGO_MANIFEST_DIR"),
    "/../../docs/report/spec-gap-validation-evidence/xlsx-form-control-properties/native-corpus.json"
));

/// Deterministically flips the source revision immediately before one version
/// observation, so the owner final fence can be exercised without a timing
/// race in the test.
struct VersionFlipSource {
    bytes: Vec<u8>,
    version_calls: AtomicUsize,
    revision: AtomicU64,
    flip_before_call: Option<usize>,
}

impl VersionFlipSource {
    fn new(bytes: Vec<u8>, flip_before_call: Option<usize>) -> Self {
        Self {
            bytes,
            version_calls: AtomicUsize::new(0),
            revision: AtomicU64::new(0),
            flip_before_call,
        }
    }
}

impl ReadAt for VersionFlipSource {
    fn len(&self) -> io::Result<u64> {
        Ok(self.bytes.len() as u64)
    }

    fn read_at(&self, offset: u64, output: &mut [u8]) -> io::Result<usize> {
        let offset = usize::try_from(offset)
            .map_err(|_| io::Error::new(io::ErrorKind::InvalidInput, "offset too large"))?;
        if offset >= self.bytes.len() {
            return Ok(0);
        }
        let count = output.len().min(self.bytes.len() - offset);
        output[..count].copy_from_slice(&self.bytes[offset..offset + count]);
        Ok(count)
    }

    fn version(&self) -> io::Result<SourceVersion> {
        let call = self.version_calls.fetch_add(1, Ordering::SeqCst) + 1;
        if self.flip_before_call == Some(call) {
            self.revision.store(1, Ordering::SeqCst);
        }
        Ok(SourceVersion::new(92, self.revision.load(Ordering::SeqCst)))
    }
}

#[derive(Clone, Copy)]
struct Fixture {
    file: &'static str,
    names: &'static [&'static str],
    shape_ids: &'static [u64],
    object_types: &'static [&'static str],
    vml_ids: &'static [&'static str],
    vml_spids: &'static [Option<&'static str>],
}

const FIXTURES: &[Fixture] = &[
    Fixture {
        file: "button-form-control.xlsx",
        names: &["Button 1"],
        shape_ids: &[1025],
        object_types: &["Button"],
        vml_ids: &["_x0000_s1025"],
        vml_spids: &[None],
    },
    Fixture {
        file: "checkbox-form-control.xlsx",
        names: &["Check Box 1"],
        shape_ids: &[1025],
        object_types: &["CheckBox"],
        vml_ids: &["_x0000_s1025"],
        vml_spids: &[None],
    },
    Fixture {
        file: "singlecontrol.xlsx",
        names: &["Check Box 2"],
        shape_ids: &[1026],
        object_types: &["CheckBox"],
        vml_ids: &["_x0000_s1026"],
        vml_spids: &[None],
    },
    Fixture {
        file: "tdf120301_xmlSpaceParsing.xlsx",
        names: &["Check Box 1", "Option Button 2"],
        shape_ids: &[1025, 1026],
        object_types: &["CheckBox", "Radio"],
        vml_ids: &["_x0000_s1025", "_x0000_s1026"],
        vml_spids: &[None, None],
    },
    Fixture {
        file: "tdf134769.xlsx",
        names: &["Check Box 1"],
        shape_ids: &[1025],
        object_types: &["CheckBox"],
        vml_ids: &["_x0000_s1025"],
        vml_spids: &[None],
    },
    Fixture {
        file: "tdf161365.xlsx",
        names: &["Check Box 4", "Check Box 4"],
        shape_ids: &[1026, 1027],
        object_types: &["CheckBox", "CheckBox"],
        vml_ids: &["Check_x0020_Box_x0020_4", "_x0000_s1027"],
        vml_spids: &[Some("_x0000_s1026"), None],
    },
    Fixture {
        file: "tdf60673.xlsx",
        names: &["Button 1", "Button 2"],
        shape_ids: &[1025, 1026],
        object_types: &["Button", "Button"],
        vml_ids: &["_x0000_s1025", "_x0000_s1026"],
        vml_spids: &[None, None],
    },
];

fn fixture_path(file: &str) -> PathBuf {
    Path::new(env!("CARGO_MANIFEST_DIR"))
        .join("tests/fixtures/form_control_properties")
        .join(file)
}

fn fixture_bytes(file: &str) -> Vec<u8> {
    std::fs::read(fixture_path(file)).unwrap()
}

fn json_string<'a>(value: &'a Value, key: &str) -> &'a str {
    value[key].as_str().unwrap()
}

fn known_token<T: std::fmt::Display>(value: Option<&KnownOrUnknown<T>>) -> Option<String> {
    value.map(|value| match value {
        KnownOrUnknown::Known(value) => value.to_string(),
        KnownOrUnknown::Unknown(value) => value.clone(),
    })
}

fn rewrite_member(source: &[u8], member: &str, edit: impl FnOnce(String) -> String) -> Vec<u8> {
    let archive = ArchiveReader::new(source).unwrap();
    let updated = edit(String::from_utf8(archive.read(member).unwrap()).unwrap()).into_bytes();
    let mut writer = StreamingArchiveWriter::new();
    for name in archive.file_names() {
        let bytes = if name == member {
            updated.clone()
        } else {
            archive.read(name).unwrap()
        };
        writer.write_deflated(name, &bytes).unwrap();
    }
    writer.finish_to_bytes().unwrap()
}

fn add_member(source: &[u8], member: &str, bytes: &[u8]) -> Vec<u8> {
    let archive = ArchiveReader::new(source).unwrap();
    let mut writer = StreamingArchiveWriter::new();
    for name in archive.file_names() {
        writer
            .write_deflated(name, &archive.read(name).unwrap())
            .unwrap();
    }
    writer.write_deflated(member, bytes).unwrap();
    writer.finish_to_bytes().unwrap()
}

fn rewrite_members(source: &[u8], edits: &[(&str, &dyn Fn(String) -> String)]) -> Vec<u8> {
    let archive = ArchiveReader::new(source).unwrap();
    let mut writer = StreamingArchiveWriter::new();
    for name in archive.file_names() {
        let mut value = String::from_utf8(archive.read(name).unwrap())
            .unwrap_or_else(|_| panic!("member {name} is not text; omit it from rewrite_members"));
        for (target, edit) in edits {
            if *target == name {
                value = edit(value);
            }
        }
        writer.write_deflated(name, value.as_bytes()).unwrap();
    }
    writer.finish_to_bytes().unwrap()
}

fn expected_fixture(file: &str) -> Fixture {
    FIXTURES
        .iter()
        .copied()
        .find(|fixture| fixture.file == file)
        .unwrap()
}

fn assert_native_attributes(properties: &Properties, attributes: &serde_json::Map<String, Value>) {
    for (name, expected) in attributes {
        let expected = expected.as_str().unwrap();
        match name.as_str() {
            "objectType" => assert_eq!(
                known_token(properties.object_type()),
                Some(expected.to_owned())
            ),
            "checked" => assert_eq!(known_token(properties.checked()), Some(expected.to_owned())),
            "fmlaLink" => assert_eq!(
                properties.fmla_link().map(|value| value.as_str()),
                Some(expected)
            ),
            "lockText" => assert_eq!(properties.lock_text(), Some(expected == "1")),
            "noThreeD" => assert_eq!(properties.no_three_d(), Some(expected == "1")),
            "firstButton" => assert_eq!(properties.first_button(), Some(expected == "1")),
            other => panic!("uncovered native form-control attribute {other}"),
        }
    }
}

fn assert_shape(
    view: &litchi_xlsx::form_control::FormControlView,
    fixture: Fixture,
    position: usize,
) {
    let shape = view.shape();
    assert_eq!(shape.shape_id(), fixture.shape_ids[position]);
    assert_eq!(shape.drawing_name(), Some(fixture.names[position]));
    assert_eq!(
        shape.compat_spid(),
        format!("_x0000_s{}", fixture.shape_ids[position])
    );
    assert_eq!(shape.vml_id(), fixture.vml_ids[position]);
    assert_eq!(shape.vml_spid(), fixture.vml_spids[position]);
    assert_eq!(shape.object_type(), fixture.object_types[position]);
}

fn source_collection(bytes: &[u8]) -> litchi_xlsx::form_control::FormControlCollection {
    let workbook = SourceBackedWorkbook::from_reader(Cursor::new(bytes)).unwrap();
    workbook.sheet(0).unwrap().unwrap().form_controls().unwrap()
}

#[test]
fn native_corpus_inventory_shape_closure_and_source_bytes() {
    let corpus: Value = serde_json::from_str(NATIVE_CORPUS).unwrap();
    let fixtures = corpus["fixtures"].as_array().unwrap();
    assert_eq!(fixtures.len(), FIXTURES.len());
    let mut part_count = 0;

    for manifest in fixtures {
        let file = Path::new(json_string(manifest, "retained_path"))
            .file_name()
            .unwrap()
            .to_str()
            .unwrap();
        let fixture = expected_fixture(file);
        let source = fixture_bytes(file);
        assert_eq!(
            source.len(),
            manifest["bytes"].as_u64().unwrap() as usize,
            "retained fixture byte count drifted for {file}"
        );
        assert_eq!(
            EvidenceDigest::of(&source).to_string(),
            json_string(manifest, "sha256"),
            "retained fixture SHA-256 drifted for {file}"
        );
        let archive = ArchiveReader::new(&source).unwrap();
        let eager = Workbook::from_bytes(source.clone())
            .unwrap()
            .sheet(0)
            .unwrap()
            .unwrap()
            .form_controls()
            .unwrap();
        let deferred = source_collection(&source);
        assert_eq!(eager.profile(), OwnerProfile::canonical());
        assert_eq!(deferred.profile(), OwnerProfile::canonical());
        assert!(eager.diagnostics().is_empty());
        assert!(deferred.diagnostics().is_empty());
        assert!(eager.read_set().is_none());
        assert!(deferred.read_set().is_some());
        assert_eq!(eager.len(), fixture.names.len());
        assert_eq!(deferred.len(), eager.len());

        let parts = manifest["form_control_parts"].as_array().unwrap();
        assert_eq!(parts.len(), eager.len());
        for (position, part) in parts.iter().enumerate() {
            part_count += 1;
            let member = json_string(part, "member");
            let raw_properties = archive.read(member).unwrap();
            assert_eq!(
                raw_properties.len(),
                part["bytes"].as_u64().unwrap() as usize,
                "retained member byte count drifted for {file}:{member}"
            );
            assert_eq!(
                EvidenceDigest::of(&raw_properties).to_string(),
                json_string(part, "sha256"),
                "retained member SHA-256 drifted for {file}:{member}"
            );
            let attributes = part["attributes"].as_object().unwrap();
            let eager_view = eager
                .get(ControlSelector::position(position))
                .unwrap()
                .unwrap();
            let deferred_view = deferred
                .get(ControlSelector::position(position))
                .unwrap()
                .unwrap();

            assert_eq!(eager_view.position(), position);
            assert_eq!(eager_view.name(), Some(fixture.names[position]));
            assert_eq!(eager_view, deferred_view);
            assert_eq!(eager_view.anchor_profile(), Some("LoSmlAnchorV1"));
            assert_eq!(
                eager_view.properties().source_bytes(),
                Some(raw_properties.as_slice())
            );
            assert_native_attributes(eager_view.properties(), attributes);
            assert_eq!(
                known_token(eager_view.properties().object_type()),
                Some(fixture.object_types[position].to_owned())
            );
            assert_shape(eager_view, fixture, position);

            let selected = eager.get(ControlSelector::name(fixture.names[position]));
            if fixture
                .names
                .iter()
                .filter(|name| **name == fixture.names[position])
                .count()
                == 1
            {
                assert_eq!(selected.unwrap().unwrap(), eager_view);
            } else {
                assert!(selected.is_err());
            }
        }
    }
    assert_eq!(
        part_count, 10,
        "the owner must reopen all ten retained native parts"
    );
}

#[test]
fn duplicate_name_selector_is_ambiguous_but_positions_remain_checked() {
    let source = fixture_bytes("tdf161365.xlsx");
    let workbook = Workbook::from_bytes(source.clone()).unwrap();
    let sheet = workbook.sheet(0).unwrap().unwrap();
    let controls = sheet.form_controls().unwrap();
    assert_eq!(controls.len(), 2);
    assert!(controls.get(ControlSelector::name("Check Box 4")).is_err());
    assert!(
        sheet
            .form_control(ControlSelector::name("Check Box 4"))
            .is_err()
    );
    assert_eq!(
        sheet
            .form_control(ControlSelector::position(0))
            .unwrap()
            .unwrap()
            .name(),
        Some("Check Box 4")
    );
    assert_eq!(
        sheet.form_control(ControlSelector::position(2)).unwrap(),
        None
    );

    let source_sheet = SourceBackedWorkbook::from_reader(Cursor::new(source))
        .unwrap()
        .sheet(0)
        .unwrap()
        .unwrap();
    assert!(
        source_sheet
            .form_controls()
            .unwrap()
            .get(ControlSelector::name("Check Box 4"))
            .is_err()
    );
    assert!(
        source_sheet
            .form_control(ControlSelector::name("Check Box 4"))
            .is_err()
    );
}

#[test]
fn aliases_and_xml_entities_preserve_semantic_owner_reads() {
    let source = fixture_bytes("checkbox-form-control.xlsx");
    let aliased = rewrite_members(
        &source,
        &[
            ("xl/worksheets/sheet1.xml", &|xml: String| {
                xml.replace("Requires=\"x14\"", "Requires=\"x14Alias\"")
                        .replace(
                            "<mc:Choice Requires=\"x14Alias\">",
                            &format!(
                                "<mc:Choice xmlns:x14Alias=\"{FORM_CONTROL_NAMESPACE}\" Requires=\"x14Alias\">"
                            ),
                        )
                        .replace("name=\"Check Box 1\"", "name=\"Check &amp; Box 1\"")
            }),
            ("xl/drawings/drawing1.xml", &|xml: String| {
                xml.replace(
                        "xmlns:a14=\"http://schemas.microsoft.com/office/drawing/2010/main\" Requires=\"a14\"",
                        "xmlns:z14=\"http://schemas.microsoft.com/office/drawing/2010/main\" Requires=\"z14\"",
                    )
                    .replace("mc:Ignorable=\"a14\"", "mc:Ignorable=\"z14\"")
                    .replace("name=\"Check Box 1\"", "name=\"Check &amp; Box 1\"")
                    .replace("a14:", "z14:")
            }),
        ],
    );
    let workbook = Workbook::from_bytes(aliased.clone()).unwrap();
    let view = workbook
        .sheet(0)
        .unwrap()
        .unwrap()
        .form_control(ControlSelector::position(0))
        .unwrap()
        .unwrap();
    assert_eq!(view.name(), Some("Check & Box 1"));
    assert_eq!(view.shape().drawing_name(), Some("Check & Box 1"));

    let source_view = SourceBackedWorkbook::from_reader(Cursor::new(aliased))
        .unwrap()
        .sheet(0)
        .unwrap()
        .unwrap()
        .form_control(ControlSelector::position(0))
        .unwrap()
        .unwrap();
    assert_eq!(source_view.name(), Some("Check & Box 1"));

    let properties_alias = rewrite_member(&source, "xl/ctrlProps/ctrlProp1.xml", |xml| {
        xml.replace(
            &format!("<formControlPr xmlns=\"{FORM_CONTROL_NAMESPACE}\""),
            &format!("<fc:formControlPr xmlns:fc=\"{FORM_CONTROL_NAMESPACE}\""),
        )
        .replace("</formControlPr>", "</fc:formControlPr>")
    });
    let properties_view = Workbook::from_bytes(properties_alias)
        .unwrap()
        .sheet(0)
        .unwrap()
        .unwrap()
        .form_control(ControlSelector::position(0))
        .unwrap()
        .unwrap();
    assert_eq!(properties_view.properties().no_three_d(), Some(true));
}

#[test]
fn strict_and_activex_relationship_dialects_are_refused() {
    let source = fixture_bytes("checkbox-form-control.xlsx");
    let strict = rewrite_member(&source, "xl/worksheets/sheet1.xml", |xml| {
        xml.replacen(SML_NAMESPACE, STRICT_SML_NAMESPACE, 1)
    });
    let strict_result = Workbook::from_bytes(strict)
        .unwrap()
        .sheet(0)
        .unwrap()
        .unwrap()
        .form_controls();
    assert!(strict_result.is_err());

    for relationship in [ACTIVEX_RELATIONSHIP, STRICT_ACTIVEX_RELATIONSHIP] {
        let mutated = rewrite_member(&source, "xl/worksheets/_rels/sheet1.xml.rels", |xml| {
            xml.replacen(CONTROL_PROPERTIES_RELATIONSHIP, relationship, 1)
        });
        let result = Workbook::from_bytes(mutated)
            .unwrap()
            .sheet(0)
            .unwrap()
            .unwrap()
            .form_controls();
        assert!(
            result.is_err(),
            "ActiveX relationship {relationship} was admitted"
        );
    }

    let wrong_content_type = rewrite_member(&source, "[Content_Types].xml", |xml| {
        xml.replace(CONTROL_PROPERTIES_CONTENT_TYPE, ACTIVEX_CONTENT_TYPE)
    });
    assert!(
        Workbook::from_bytes(wrong_content_type)
            .unwrap()
            .sheet(0)
            .unwrap()
            .unwrap()
            .form_controls()
            .is_err()
    );
}

#[test]
fn identity_geometry_and_object_profile_mismatches_are_refused() {
    let source = fixture_bytes("checkbox-form-control.xlsx");
    let missing_drawing_identity = rewrite_member(&source, "xl/drawings/drawing1.xml", |xml| {
        xml.replace("cNvPr id=\"1025\"", "cNvPr id=\"1026\"")
    });
    assert!(
        Workbook::from_bytes(missing_drawing_identity)
            .unwrap()
            .sheet(0)
            .unwrap()
            .unwrap()
            .form_controls()
            .is_err()
    );

    let bad_object_type = rewrite_member(&source, "xl/drawings/vmlDrawing1.vml", |xml| {
        xml.replace("ObjectType=\"Checkbox\"", "ObjectType=\"Button\"")
    });
    let bad_object_type_view = Workbook::from_bytes(bad_object_type)
        .unwrap()
        .sheet(0)
        .unwrap()
        .unwrap()
        .form_control(ControlSelector::position(0))
        .unwrap()
        .unwrap();
    assert_eq!(bad_object_type_view.shape().vml_object_type(), "Button");
    assert!(
        bad_object_type_view
            .diagnostics()
            .iter()
            .any(|diagnostic| diagnostic.code() == FormControlDiagnosticCode::UnprovenMirror)
    );

    let missing_anchor_endpoint = rewrite_member(&source, "xl/drawings/drawing1.xml", |xml| {
        let start = xml.find("<xdr:to>").unwrap();
        let end = xml[start..].find("</xdr:to>").unwrap() + start + "</xdr:to>".len();
        format!("{}{}", &xml[..start], &xml[end..])
    });
    assert!(
        Workbook::from_bytes(missing_anchor_endpoint)
            .unwrap()
            .sheet(0)
            .unwrap()
            .unwrap()
            .form_controls()
            .is_err()
    );

    let malformed_spid = rewrite_member(&source, "xl/drawings/drawing1.xml", |xml| {
        xml.replace("spid=\"_x0000_s1025\"", "spid=\"_x0000_sbad\"")
    });
    assert!(
        Workbook::from_bytes(malformed_spid)
            .unwrap()
            .sheet(0)
            .unwrap()
            .unwrap()
            .form_controls()
            .is_err()
    );

    let disagreement = rewrite_member(
        &fixture_bytes("tdf161365.xlsx"),
        "xl/drawings/vmlDrawing1.vml",
        |xml| {
            xml.replace(
                "id=\"_x0000_s1027\" type=\"#_x0000_t201\"",
                "id=\"_x0000_s1027\" o:spid=\"_x0000_s1026\" type=\"#_x0000_t201\"",
            )
        },
    );
    assert!(
        Workbook::from_bytes(disagreement)
            .unwrap()
            .sheet(0)
            .unwrap()
            .unwrap()
            .form_controls()
            .is_err()
    );
}

fn has_mirror_detail(
    collection: &litchi_xlsx::form_control::FormControlCollection,
    position: usize,
    fragment: &str,
) -> bool {
    collection
        .get(ControlSelector::position(position))
        .unwrap()
        .unwrap()
        .diagnostics()
        .iter()
        .any(|diagnostic| {
            diagnostic.code() == FormControlDiagnosticCode::UnprovenMirror
                && diagnostic.detail().contains(fragment)
        })
}

fn assert_mirror_warning_in_eager_and_source(
    source: &[u8],
    position: usize,
    field: &str,
    label: &str,
) {
    let eager = Workbook::from_bytes(source.to_vec())
        .unwrap()
        .sheet(0)
        .unwrap()
        .unwrap()
        .form_controls()
        .unwrap();
    assert!(
        has_mirror_detail(&eager, position, field),
        "{label} did not produce an eager UnprovenMirror diagnostic for {field}"
    );

    let deferred = source_collection(source);
    assert!(
        has_mirror_detail(&deferred, position, field),
        "{label} did not produce a source-backed UnprovenMirror diagnostic for {field}"
    );
}

#[test]
fn native_mirror_pairs_are_clean_and_changed_vml_values_are_diagnosed() {
    let checked = fixture_bytes("tdf161365.xlsx");
    let checked_baseline = Workbook::from_bytes(checked.clone())
        .unwrap()
        .sheet(0)
        .unwrap()
        .unwrap()
        .form_control(ControlSelector::position(1))
        .unwrap()
        .unwrap();
    assert_eq!(
        known_token(checked_baseline.properties().checked()),
        Some("Checked".to_owned())
    );
    assert!(!checked_baseline.diagnostics().iter().any(|diagnostic| {
        diagnostic.code() == FormControlDiagnosticCode::UnprovenMirror
            && diagnostic.detail().contains("checked")
    }));
    let checked_changed = rewrite_member(&checked, "xl/drawings/vmlDrawing1.vml", |xml| {
        xml.replace("<x:Checked>1</x:Checked>", "<x:Checked>0</x:Checked>")
    });
    let checked_changed_view = Workbook::from_bytes(checked_changed.clone())
        .unwrap()
        .sheet(0)
        .unwrap()
        .unwrap()
        .form_control(ControlSelector::position(1))
        .unwrap()
        .unwrap();
    assert_eq!(checked_changed_view.shape().shape_id(), 1027);
    assert_eq!(checked_changed_view.shape().vml_id(), "_x0000_s1027");
    assert_eq!(
        known_token(checked_changed_view.properties().checked()),
        Some("Checked".to_owned())
    );
    assert_mirror_warning_in_eager_and_source(&checked_changed, 1, "checked", "Checked 1 -> 0");

    let formula = fixture_bytes("tdf134769.xlsx");
    let formula_baseline = Workbook::from_bytes(formula.clone())
        .unwrap()
        .sheet(0)
        .unwrap()
        .unwrap()
        .form_control(ControlSelector::position(0))
        .unwrap()
        .unwrap();
    assert_eq!(
        formula_baseline
            .properties()
            .fmla_link()
            .map(|value| value.as_str()),
        Some("#REF!")
    );
    assert!(!formula_baseline.diagnostics().iter().any(|diagnostic| {
        diagnostic.code() == FormControlDiagnosticCode::UnprovenMirror
            && diagnostic.detail().contains("fmlaLink")
    }));
    let formula_changed = rewrite_member(&formula, "xl/drawings/vmlDrawing1.vml", |xml| {
        xml.replace(
            "<x:FmlaLink>#REF!</x:FmlaLink>",
            "<x:FmlaLink>#A1</x:FmlaLink>",
        )
    });
    let formula_changed_view = Workbook::from_bytes(formula_changed.clone())
        .unwrap()
        .sheet(0)
        .unwrap()
        .unwrap()
        .form_control(ControlSelector::position(0))
        .unwrap()
        .unwrap();
    assert_eq!(formula_changed_view.shape().shape_id(), 1025);
    assert_eq!(formula_changed_view.shape().vml_id(), "_x0000_s1025");
    assert_eq!(
        formula_changed_view
            .properties()
            .fmla_link()
            .map(|value| value.as_str()),
        Some("#REF!")
    );
    assert_mirror_warning_in_eager_and_source(
        &formula_changed,
        0,
        "fmlaLink",
        "FmlaLink #REF! -> #A1",
    );

    let aligned = rewrite_members(
        &fixture_bytes("button-form-control.xlsx"),
        &[
            ("xl/ctrlProps/ctrlProp1.xml", &|xml: String| {
                xml.replace(
                    "objectType=\"Button\" lockText=\"1\"/>",
                    "objectType=\"Button\" lockText=\"1\" textHAlign=\"center\" textVAlign=\"center\"/>",
                )
            }),
            ("xl/drawings/vmlDrawing1.vml", &|xml: String| xml),
        ],
    );
    let aligned_baseline = Workbook::from_bytes(aligned.clone())
        .unwrap()
        .sheet(0)
        .unwrap()
        .unwrap()
        .form_controls()
        .unwrap();
    assert_eq!(
        aligned_baseline
            .get(ControlSelector::position(0))
            .unwrap()
            .unwrap()
            .shape()
            .shape_id(),
        1025
    );
    assert!(!has_mirror_detail(&aligned_baseline, 0, "textHAlign"));
    assert!(!has_mirror_detail(&aligned_baseline, 0, "textVAlign"));
    let aligned_changed = rewrite_member(&aligned, "xl/drawings/vmlDrawing1.vml", |xml| {
        xml.replace(
            "<x:TextHAlign>Center</x:TextHAlign>",
            "<x:TextHAlign>Right</x:TextHAlign>",
        )
        .replace(
            "<x:TextVAlign>Center</x:TextVAlign>",
            "<x:TextVAlign>Top</x:TextVAlign>",
        )
    });
    let aligned_changed_eager = Workbook::from_bytes(aligned_changed.clone())
        .unwrap()
        .sheet(0)
        .unwrap()
        .unwrap()
        .form_controls()
        .unwrap();
    assert_eq!(
        aligned_changed_eager
            .get(ControlSelector::position(0))
            .unwrap()
            .unwrap()
            .shape()
            .shape_id(),
        1025
    );
    assert!(has_mirror_detail(&aligned_changed_eager, 0, "textHAlign"));
    assert!(has_mirror_detail(&aligned_changed_eager, 0, "textVAlign"));
    let aligned_changed_source = source_collection(&aligned_changed);
    assert!(has_mirror_detail(&aligned_changed_source, 0, "textHAlign"));
    assert!(has_mirror_detail(&aligned_changed_source, 0, "textVAlign"));

    let list_baseline = rewrite_members(
        &fixture_bytes("button-form-control.xlsx"),
        &[
            ("xl/ctrlProps/ctrlProp1.xml", &|xml: String| {
                xml.replace(
                    "objectType=\"Button\" lockText=\"1\"/>",
                    "objectType=\"Drop\"><itemLst><item val=\"Alpha\"/><item val=\"Beta\"/></itemLst></formControlPr>",
                )
            }),
            ("xl/drawings/vmlDrawing1.vml", &|xml: String| {
                xml.replace("ObjectType=\"Button\"", "ObjectType=\"Drop\"")
                    .replace(
                        "</x:ClientData>",
                        "<x:ListItem>Alpha</x:ListItem><x:ListItem>Beta</x:ListItem></x:ClientData>",
                    )
            }),
        ],
    );
    let list_baseline_eager = Workbook::from_bytes(list_baseline.clone())
        .unwrap()
        .sheet(0)
        .unwrap()
        .unwrap()
        .form_controls()
        .unwrap();
    assert!(!has_mirror_detail(&list_baseline_eager, 0, "ListItem"));
    let list_changed = rewrite_member(&list_baseline, "xl/drawings/vmlDrawing1.vml", |xml| {
        xml.replace(
            "<x:ListItem>Beta</x:ListItem>",
            "<x:ListItem>Gamma</x:ListItem>",
        )
    });
    let list_changed_eager = Workbook::from_bytes(list_changed.clone())
        .unwrap()
        .sheet(0)
        .unwrap()
        .unwrap()
        .form_controls()
        .unwrap();
    assert!(has_mirror_detail(&list_changed_eager, 0, "ListItem"));
    let list_changed_source = source_collection(&list_changed);
    assert!(has_mirror_detail(&list_changed_source, 0, "ListItem"));
}

#[test]
fn unanchored_drawing_shape_with_unrelated_valid_anchor_is_refused() {
    let source = fixture_bytes("checkbox-form-control.xlsx");
    let unanchored = rewrite_member(&source, "xl/drawings/drawing1.xml", |xml| {
        let anchor_start = xml.find("<xdr:twoCellAnchor").unwrap();
        let anchor_end = xml[anchor_start..].find("</xdr:twoCellAnchor>").unwrap()
            + anchor_start
            + "</xdr:twoCellAnchor>".len();
        let anchor = &xml[anchor_start..anchor_end];
        let shape_start = anchor.find("<xdr:sp ").unwrap();
        let shape_end =
            anchor[shape_start..].find("</xdr:sp>").unwrap() + shape_start + "</xdr:sp>".len();
        let control_shape = &anchor[shape_start..shape_end];
        let unrelated_shape = control_shape
            .replace("id=\"1025\"", "id=\"2048\"")
            .replace("name=\"Check Box 1\"", "name=\"Unrelated shape\"")
            .replace("spid=\"_x0000_s1025\"", "spid=\"_x0000_s2048\"");
        let unrelated_anchor = anchor.replacen(control_shape, &unrelated_shape, 1);
        let replacement = format!("{unrelated_anchor}{control_shape}");
        format!(
            "{}{}{}",
            &xml[..anchor_start],
            replacement,
            &xml[anchor_end..]
        )
    });

    let eager = Workbook::from_bytes(unanchored.clone())
        .unwrap()
        .sheet(0)
        .unwrap()
        .unwrap()
        .form_controls();
    assert!(
        eager.is_err(),
        "unanchored DrawingML control shape was admitted"
    );

    let source_result = SourceBackedWorkbook::from_reader(Cursor::new(unanchored))
        .unwrap()
        .sheet(0)
        .unwrap()
        .unwrap()
        .form_controls();
    assert!(
        source_result.is_err(),
        "source owner admitted an unanchored DrawingML control shape"
    );
}

#[test]
fn optional_control_pr_anchor_is_read_with_a_diagnostic() {
    let source = fixture_bytes("checkbox-form-control.xlsx");
    let absent = rewrite_member(&source, "xl/worksheets/sheet1.xml", |xml| {
        let start = xml.find("<controlPr").unwrap();
        let end = xml[start..].find("</controlPr>").unwrap() + start + "</controlPr>".len();
        format!("{}{}", &xml[..start], &xml[end..])
    });
    let malformed = rewrite_member(&source, "xl/worksheets/sheet1.xml", |xml| {
        let start = xml.find("<to>").unwrap();
        let end = xml[start..].find("</to>").unwrap() + start + "</to>".len();
        format!("{}{}", &xml[..start], &xml[end..])
    });

    for candidate in [absent, malformed] {
        let eager = Workbook::from_bytes(candidate.clone())
            .unwrap()
            .sheet(0)
            .unwrap()
            .unwrap()
            .form_controls()
            .unwrap();
        let eager_view = eager.get(ControlSelector::position(0)).unwrap().unwrap();
        assert_eq!(eager_view.anchor_profile(), None);
        assert!(
            eager_view
                .diagnostics()
                .iter()
                .any(|diagnostic| diagnostic.code() == FormControlDiagnosticCode::ControlPrAnchor)
        );
        assert_eq!(eager_view.properties().no_three_d(), Some(true));

        let deferred = source_collection(&candidate);
        let deferred_view = deferred.get(ControlSelector::position(0)).unwrap().unwrap();
        assert_eq!(deferred_view, eager_view);
        assert_eq!(deferred_view.anchor_profile(), None);
        assert!(
            deferred_view
                .diagnostics()
                .iter()
                .any(|diagnostic| diagnostic.code() == FormControlDiagnosticCode::ControlPrAnchor)
        );
    }
}

#[test]
fn losml_anchor_coordinate_grammar_is_diagnosed_without_discarding_owner() {
    let source = fixture_bytes("checkbox-form-control.xlsx");
    let candidates = [
        (
            "missing coordinate child",
            rewrite_member(&source, "xl/worksheets/sheet1.xml", |xml| {
                xml.replacen("<xdr:colOff>209550</xdr:colOff>", "", 1)
            }),
        ),
        (
            "invalid coordinate lexical form",
            rewrite_member(&source, "xl/worksheets/sheet1.xml", |xml| {
                xml.replacen("<xdr:row>3</xdr:row>", "<xdr:row>not-a-row</xdr:row>", 1)
            }),
        ),
        (
            "coordinate overflow",
            rewrite_member(&source, "xl/worksheets/sheet1.xml", |xml| {
                xml.replacen(
                    "<xdr:rowOff>28575</xdr:rowOff>",
                    "<xdr:rowOff>18446744073709551616</xdr:rowOff>",
                    1,
                )
            }),
        ),
    ];

    for (label, candidate) in candidates {
        let eager = Workbook::from_bytes(candidate.clone())
            .unwrap()
            .sheet(0)
            .unwrap()
            .unwrap()
            .form_controls()
            .unwrap();
        let eager_view = eager.get(ControlSelector::position(0)).unwrap().unwrap();
        assert_eq!(
            eager_view.anchor_profile(),
            None,
            "{label} kept the profile"
        );
        assert!(
            eager_view
                .diagnostics()
                .iter()
                .any(|diagnostic| diagnostic.code() == FormControlDiagnosticCode::ControlPrAnchor),
            "{label} did not produce the ControlPrAnchor diagnostic"
        );

        let deferred = source_collection(&candidate);
        let deferred_view = deferred.get(ControlSelector::position(0)).unwrap().unwrap();
        assert_eq!(deferred_view, eager_view, "{label} eager/deferred mismatch");
        assert_eq!(
            deferred_view.anchor_profile(),
            None,
            "{label} kept source profile"
        );
    }
}

#[test]
fn malformed_vml_root_and_incomplete_eof_are_refused() {
    let source = fixture_bytes("checkbox-form-control.xlsx");
    let malformed_root = rewrite_member(&source, "xl/drawings/vmlDrawing1.vml", |xml| {
        xml.replacen("<xml ", "<notVml ", 1)
            .replacen("</xml>", "</notVml>", 1)
    });
    let incomplete_eof = rewrite_member(&source, "xl/drawings/vmlDrawing1.vml", |mut xml| {
        assert!(xml.ends_with("</xml>"));
        xml.truncate(xml.len() - "</xml>".len());
        xml
    });

    for (label, candidate) in [
        ("malformed VML root", malformed_root),
        ("incomplete VML EOF", incomplete_eof),
    ] {
        let eager = Workbook::from_bytes(candidate.clone())
            .unwrap()
            .sheet(0)
            .unwrap()
            .unwrap()
            .form_controls();
        assert!(eager.is_err(), "{label} was admitted by the eager owner");

        let deferred = SourceBackedWorkbook::from_reader(Cursor::new(candidate))
            .unwrap()
            .sheet(0)
            .unwrap()
            .unwrap()
            .form_controls();
        assert!(
            deferred.is_err(),
            "{label} was admitted by the source owner"
        );
    }
}

#[test]
fn control_name_over_32_characters_is_refused_by_the_native_profile() {
    let source = fixture_bytes("checkbox-form-control.xlsx");
    let long_name = "N".repeat(33);
    let candidate = rewrite_member(&source, "xl/worksheets/sheet1.xml", |xml| {
        xml.replace("name=\"Check Box 1\"", &format!("name=\"{long_name}\""))
    });
    let candidate = rewrite_member(&candidate, "xl/drawings/drawing1.xml", |xml| {
        xml.replace("name=\"Check Box 1\"", &format!("name=\"{long_name}\""))
    });

    assert!(
        Workbook::from_bytes(candidate.clone())
            .unwrap()
            .sheet(0)
            .unwrap()
            .unwrap()
            .form_controls()
            .is_err(),
        "eager owner admitted a control name longer than the 32-character profile"
    );
    assert!(
        SourceBackedWorkbook::from_reader(Cursor::new(candidate))
            .unwrap()
            .sheet(0)
            .unwrap()
            .unwrap()
            .form_controls()
            .is_err(),
        "source owner admitted a control name longer than the 32-character profile"
    );
}

fn unsupported_choice_with_fallback(xml: String, capability: &str) -> String {
    let marker = format!("Requires=\"{capability}\"");
    let choice_start = xml.find(&marker).unwrap();
    let open_end = xml[choice_start..].find('>').unwrap() + choice_start + 1;
    // The worksheet's outer AlternateContent has no native fallback, while
    // the drawing fixture has an empty one.  In both cases copy the selected
    // branch into a valid synthetic fallback.
    let mut replaced = xml;
    let choice_end = replaced.rfind("</mc:Choice>").unwrap();
    let branch = replaced[open_end..choice_end].to_owned();
    let has_fallback = replaced[choice_end..].contains("<mc:Fallback/>");
    replaced.replace_range(
        choice_start..choice_start + marker.len(),
        "xmlns:future=\"urn:test:future\" Requires=\"future\"",
    );
    let fallback = if capability == "a14" {
        format!(
            "<mc:Fallback xmlns:a14=\"http://schemas.microsoft.com/office/drawing/2010/main\">{branch}</mc:Fallback>"
        )
    } else {
        format!("<mc:Fallback>{branch}</mc:Fallback>")
    };
    if has_fallback {
        let fallback_start = replaced.rfind("<mc:Fallback/>").unwrap();
        replaced.replace_range(
            fallback_start..fallback_start + "<mc:Fallback/>".len(),
            &fallback,
        );
    } else {
        let alternate_end = replaced.rfind("</mc:AlternateContent>").unwrap();
        replaced.insert_str(alternate_end, &fallback);
    }
    replaced
}

#[test]
fn unsupported_mce_choice_uses_fallback_and_missing_fallback_refuses() {
    let source = fixture_bytes("checkbox-form-control.xlsx");
    let worksheet_fallback = rewrite_member(&source, "xl/worksheets/sheet1.xml", |xml| {
        unsupported_choice_with_fallback(xml, "x14")
    });
    let worksheet = Workbook::from_bytes(worksheet_fallback)
        .unwrap()
        .sheet(0)
        .unwrap()
        .unwrap();
    assert_eq!(worksheet.form_controls().unwrap().len(), 1);

    let drawing_fallback = rewrite_member(&source, "xl/drawings/drawing1.xml", |xml| {
        unsupported_choice_with_fallback(xml, "a14")
    });
    let drawing = Workbook::from_bytes(drawing_fallback)
        .unwrap()
        .sheet(0)
        .unwrap()
        .unwrap();
    assert_eq!(drawing.form_controls().unwrap().len(), 1);

    let missing_fallback = rewrite_member(&source, "xl/worksheets/sheet1.xml", |xml| {
        let marker = "Requires=\"x14\"";
        xml.replace(
            marker,
            "xmlns:future=\"urn:test:future\" Requires=\"future\"",
        )
    });
    assert!(
        Workbook::from_bytes(missing_fallback)
            .unwrap()
            .sheet(0)
            .unwrap()
            .unwrap()
            .form_controls()
            .is_err()
    );
}

#[test]
fn properties_relationship_member_presence_is_read_and_malformed_member_refused() {
    let source = fixture_bytes("checkbox-form-control.xlsx");
    let relationship_member = "xl/ctrlProps/_rels/ctrlProp1.xml.rels";
    let drawing_relationship_member = "xl/drawings/_rels/drawing1.xml.rels";
    let vml_relationship_member = "xl/drawings/_rels/vmlDrawing1.vml.rels";
    assert!(
        !ArchiveReader::new(&source)
            .unwrap()
            .file_names()
            .any(|name| name == relationship_member)
    );
    assert!(
        !ArchiveReader::new(&source)
            .unwrap()
            .file_names()
            .any(|name| name == drawing_relationship_member)
    );
    assert!(
        !ArchiveReader::new(&source)
            .unwrap()
            .file_names()
            .any(|name| name == vml_relationship_member)
    );
    let empty_relationships = br#"<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"/>"#;
    let valid = add_member(&source, relationship_member, empty_relationships);
    let valid = add_member(&valid, drawing_relationship_member, empty_relationships);
    let valid = add_member(&valid, vml_relationship_member, empty_relationships);
    let source_controls = source_collection(&valid);
    let source_view = source_controls
        .get(ControlSelector::position(0))
        .unwrap()
        .unwrap();
    assert!(source_view.properties_relationships_present());
    assert!(source_view.shape().drawing_relationships_present());
    assert!(source_view.shape().vml_relationships_present());
    let read_set = source_controls.read_set().unwrap();
    let property_read = &read_set.properties()[0];
    assert_eq!(
        property_read.relationship_bytes(),
        Some(empty_relationships.as_slice())
    );
    assert!(property_read.relationship_is_source_backed());
    assert!(property_read.relationships().present());
    assert_eq!(
        property_read.relationships().bytes(),
        empty_relationships.len()
    );
    assert_eq!(property_read.relationships().edges(), 0);
    assert_eq!(
        source_view.properties_relationships(),
        property_read.relationships()
    );
    let drawing_read = read_set.drawing().unwrap();
    assert_eq!(
        drawing_read.relationship_bytes(),
        Some(empty_relationships.as_slice())
    );
    assert!(drawing_read.relationship_is_source_backed());
    let vml_read = read_set.vml().unwrap();
    assert_eq!(
        vml_read.relationship_bytes(),
        Some(empty_relationships.as_slice())
    );
    assert!(vml_read.relationship_is_source_backed());
    let limited_source = SourceBackedWorkbook::from_reader(Cursor::new(valid.clone()))
        .unwrap()
        .sheet(0)
        .unwrap()
        .unwrap();
    assert!(
        limited_source
            .form_controls_with_limits(
                OwnerLimits::new().with_max_control_properties_relationship_bytes(1)
            )
            .is_err()
    );
    assert!(
        limited_source
            .form_controls_with_limits(OwnerLimits::new().with_max_sidecar_relationship_bytes(1))
            .is_err()
    );
    assert_eq!(
        Workbook::from_bytes(valid)
            .unwrap()
            .sheet(0)
            .unwrap()
            .unwrap()
            .form_controls()
            .unwrap()
            .len(),
        1
    );

    let malformed = add_member(&source, relationship_member, b"<Relationships>");
    if let Ok(workbook) = Workbook::from_bytes(malformed) {
        assert!(workbook.sheet(0).unwrap().unwrap().form_controls().is_err());
    }
    let malformed = add_member(&source, drawing_relationship_member, b"<Relationships>");
    if let Ok(workbook) = SourceBackedWorkbook::from_reader(Cursor::new(malformed)) {
        assert!(workbook.sheet(0).unwrap().unwrap().form_controls().is_err());
    }
}

#[test]
fn sidecar_relationships_retain_exact_target_data_and_fingerprint() {
    let source = fixture_bytes("checkbox-form-control.xlsx");
    let property_member = "xl/ctrlProps/_rels/ctrlProp1.xml.rels";
    let drawing_member = "xl/drawings/_rels/drawing1.xml.rels";
    let vml_member = "xl/drawings/_rels/vmlDrawing1.vml.rels";
    let property_relationships = br#"<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rCtrlTarget" Type="urn:litchi:form-control-target" Target="../ctrlProps/ctrlProp1.xml"/></Relationships>"#;
    let drawing_relationships = br#"<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rDrawingTarget" Type="urn:litchi:drawing-target" Target="../ctrlProps/ctrlProp1.xml"/></Relationships>"#;
    let vml_relationships = br#"<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rVmlTarget" Type="urn:litchi:vml-target" Target="../ctrlProps/ctrlProp1.xml"/></Relationships>"#;
    let source = add_member(&source, property_member, property_relationships);
    let source = add_member(&source, drawing_member, drawing_relationships);
    let source = add_member(&source, vml_member, vml_relationships);
    let properties_xml = ArchiveReader::new(&source)
        .unwrap()
        .read("xl/ctrlProps/ctrlProp1.xml")
        .unwrap();

    let source_controls = source_collection(&source);
    let source_read_set = source_controls.read_set().unwrap();
    assert_eq!(source_read_set.sidecar_targets().len(), 1);
    let sidecar_target = &source_read_set.sidecar_targets()[0];
    assert_eq!(sidecar_target.bytes(), properties_xml.as_slice());
    assert!(sidecar_target.is_source_backed());
    assert_eq!(sidecar_target.range(), 0..properties_xml.len());
    assert_eq!(
        sidecar_target.relationship_bytes(),
        Some(property_relationships.as_slice())
    );
    assert!(sidecar_target.relationship_is_source_backed());
    assert_eq!(sidecar_target.relationships().edges(), 1);
    assert_eq!(
        sidecar_target.relationships().bytes(),
        property_relationships.len()
    );
    let property_read = &source_read_set.properties()[0];
    assert_eq!(
        property_read.relationship_bytes(),
        Some(property_relationships.as_slice())
    );
    assert!(property_read.relationship_is_source_backed());
    assert_eq!(property_read.relationships().edges(), 1);
    assert_eq!(
        property_read.relationships().bytes(),
        property_relationships.len()
    );
    assert_ne!(property_read.relationships().digest(), 0);
    let drawing_read = source_read_set.drawing().unwrap();
    assert_eq!(
        drawing_read.relationship_bytes(),
        Some(drawing_relationships.as_slice())
    );
    assert_eq!(drawing_read.relationships().edges(), 1);
    assert_ne!(drawing_read.relationships().digest(), 0);
    let vml_read = source_read_set.vml().unwrap();
    assert_eq!(
        vml_read.relationship_bytes(),
        Some(vml_relationships.as_slice())
    );
    assert_eq!(vml_read.relationships().edges(), 1);
    assert_ne!(vml_read.relationships().digest(), 0);

    let source_view = source_controls
        .get(ControlSelector::position(0))
        .unwrap()
        .unwrap();
    assert_eq!(
        source_view.properties_relationships(),
        property_read.relationships()
    );
    assert_eq!(
        source_view.shape().drawing_relationships(),
        drawing_read.relationships()
    );
    assert_eq!(
        source_view.shape().vml_relationships(),
        vml_read.relationships()
    );

    let eager_view = Workbook::from_bytes(source)
        .unwrap()
        .sheet(0)
        .unwrap()
        .unwrap()
        .form_control(ControlSelector::position(0))
        .unwrap()
        .unwrap();
    assert_eq!(eager_view.properties_relationships().edges(), 1);
    assert_eq!(eager_view.shape().drawing_relationships().edges(), 1);
    assert_eq!(eager_view.shape().vml_relationships().edges(), 1);
}

#[test]
fn unreferenced_properties_are_reported_without_becoming_selectable_controls() {
    let source = fixture_bytes("checkbox-form-control.xlsx");
    let source = rewrite_member(&source, "[Content_Types].xml", |xml| {
        xml.replace(
            "</Types>",
            &format!(
                "<Override PartName=\"/xl/ctrlProps/ctrlProp-unused.xml\" ContentType=\"{CONTROL_PROPERTIES_CONTENT_TYPE}\"/></Types>"
            ),
        )
    });
    let source = add_member(
        &source,
        "xl/ctrlProps/ctrlProp-unused.xml",
        format!("<formControlPr xmlns=\"{FORM_CONTROL_NAMESPACE}\" objectType=\"Button\"/>")
            .as_bytes(),
    );
    let controls = source_collection(&source);
    assert_eq!(controls.len(), 1);
    assert!(
        controls
            .get(ControlSelector::position(1))
            .unwrap()
            .is_none()
    );
    assert!(controls.diagnostics().iter().any(|diagnostic| {
        diagnostic.code() == FormControlDiagnosticCode::UnreferencedControlProperties
    }));
}

#[test]
fn source_read_set_retains_exact_owner_relationship_and_mce_provenance() {
    let source = fixture_bytes("checkbox-form-control.xlsx");
    let archive = ArchiveReader::new(&source).unwrap();
    let worksheet_xml = archive.read("xl/worksheets/sheet1.xml").unwrap();
    let worksheet_rels = archive.read("xl/worksheets/_rels/sheet1.xml.rels").unwrap();
    let drawing_xml = archive.read("xl/drawings/drawing1.xml").unwrap();
    let vml_xml = archive.read("xl/drawings/vmlDrawing1.vml").unwrap();
    let properties_xml = archive.read("xl/ctrlProps/ctrlProp1.xml").unwrap();

    let workbook = SourceBackedWorkbook::from_reader(Cursor::new(source)).unwrap();
    let collection = workbook.sheet(0).unwrap().unwrap().form_controls().unwrap();
    let read_set = collection.read_set().unwrap();
    assert_eq!(collection.source_version(), read_set.source_version());
    assert!(read_set.source_version().is_some());

    let worksheet = read_set.worksheet();
    assert_eq!(worksheet.bytes(), worksheet_xml.as_slice());
    assert!(worksheet.is_source_backed());
    assert_eq!(worksheet.range(), 0..worksheet_xml.len());
    assert_eq!(
        worksheet.relationship_bytes(),
        Some(worksheet_rels.as_slice())
    );
    assert!(worksheet.relationship_is_source_backed());
    assert_eq!(
        worksheet.relationship_range(),
        Some(0..worksheet_rels.len())
    );
    assert!(worksheet.relationships().present());
    assert_eq!(worksheet.relationships().bytes(), worksheet_rels.len());
    assert!(worksheet.relationships().edges() > 0);

    let drawing = read_set.drawing().unwrap();
    assert_eq!(drawing.bytes(), drawing_xml.as_slice());
    assert!(drawing.is_source_backed());
    assert!(!drawing.relationships().present());
    assert_eq!(drawing.relationship_bytes(), None);
    let vml = read_set.vml().unwrap();
    assert_eq!(vml.bytes(), vml_xml.as_slice());
    assert!(vml.is_source_backed());
    assert!(!vml.relationships().present());
    assert_eq!(vml.relationship_bytes(), None);

    assert_eq!(read_set.properties().len(), 1);
    let properties = &read_set.properties()[0];
    assert_eq!(properties.bytes(), properties_xml.as_slice());
    assert!(properties.is_source_backed());
    assert!(!properties.relationships().present());
    assert_eq!(properties.relationship_bytes(), None);

    let worksheet_mce = read_set.worksheet_mce();
    assert_eq!(worksheet_mce.raw_bytes(), worksheet_xml.as_slice());
    assert!(!worksheet_mce.selected_bytes().is_empty());
    assert!(worksheet_mce.selected_choices() >= 2);
    assert!(!worksheet_mce.selected_ranges().is_empty());
    assert_eq!(
        worksheet_xml
            .windows(b"xmlns:x14=\"".len())
            .filter(|window| *window == b"xmlns:x14=\"")
            .count(),
        1,
        "the native worksheet uses one baseline x14 namespace declaration"
    );
    assert!(
        worksheet_mce.selected_ranges().iter().all(|range| {
            worksheet_xml[range.clone()]
                .windows(b"Requires=\"x14\"".len())
                .any(|window| window == b"Requires=\"x14\"")
        }),
        "selected worksheet MCE ranges lost their baseline Requires branch"
    );
    assert!(
        worksheet_mce
            .selected_bytes()
            .windows(b"<control ".len())
            .any(|window| window == b"<control ")
    );
    let drawing_mce = read_set.drawing_mce();
    assert_eq!(drawing_mce.raw_bytes(), drawing_xml.as_slice());
    assert!(!drawing_mce.selected_bytes().is_empty());
    assert_eq!(drawing_mce.selected_choices(), 1);
    assert!(!drawing_mce.selected_ranges().is_empty());

    let view = collection
        .get(ControlSelector::position(0))
        .unwrap()
        .unwrap();
    assert!(!view.properties_relationships().present());
    assert!(!view.shape().drawing_relationships().present());
    assert!(!view.shape().vml_relationships().present());
}

#[test]
fn shared_target_and_external_edges_are_refused_before_projection() {
    let source = fixture_bytes("tdf161365.xlsx");
    let shared = rewrite_member(&source, "xl/worksheets/_rels/sheet1.xml.rels", |xml| {
        xml.replace(
            "Id=\"rId4\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/ctrlProp\" Target=\"../ctrlProps/ctrlProp2.xml\"",
            "Id=\"rId4\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/ctrlProp\" Target=\"../ctrlProps/ctrlProp1.xml\"",
        )
    });
    assert!(
        Workbook::from_bytes(shared)
            .unwrap()
            .sheet(0)
            .unwrap()
            .unwrap()
            .form_controls()
            .is_err()
    );

    let external = rewrite_member(&source, "xl/worksheets/_rels/sheet1.xml.rels", |xml| {
        xml.replace(
            "Target=\"../ctrlProps/ctrlProp1.xml\"",
            "Target=\"https://example.invalid/ctrlProp.xml\" TargetMode=\"External\"",
        )
    });
    assert!(
        Workbook::from_bytes(external)
            .unwrap()
            .sheet(0)
            .unwrap()
            .unwrap()
            .form_controls()
            .is_err()
    );
}

#[test]
fn caller_part_limit_refuses_before_form_control_source_projection() {
    let source = fixture_bytes("tdf134769.xlsx");
    let limits = ReadLimits::builder()
        .max_part_bytes(1)
        .unwrap()
        .build()
        .unwrap();
    assert!(SourceBackedWorkbook::from_reader_with_limits(Cursor::new(source), limits).is_err());
}

#[test]
fn caller_owner_limits_are_applied_through_eager_and_source_facades() {
    let source = fixture_bytes("checkbox-form-control.xlsx");
    let eager_workbook = Workbook::from_bytes(source.clone()).unwrap();
    let eager_sheet = eager_workbook.sheet(0).unwrap().unwrap();
    let source_workbook = SourceBackedWorkbook::from_reader(Cursor::new(source)).unwrap();
    let source_sheet = source_workbook.sheet(0).unwrap().unwrap();
    let cases = [
        ("controls", OwnerLimits::new().with_max_controls(0)),
        ("MCE branches", OwnerLimits::new().with_max_mce_branches(0)),
        ("MCE depth", OwnerLimits::new().with_max_mce_depth(0)),
        ("MCE bytes", OwnerLimits::new().with_max_mce_bytes(1)),
        (
            "relationship edges",
            OwnerLimits::new().with_max_relationship_edges(1),
        ),
        (
            "DrawingML bytes",
            OwnerLimits::new().with_max_drawing_bytes(1),
        ),
        ("VML bytes", OwnerLimits::new().with_max_vml_bytes(1)),
        ("shape identities", OwnerLimits::new().with_max_shapes(0)),
        ("mirror nodes", OwnerLimits::new().with_max_mirror_nodes(0)),
        (
            "identity name bytes",
            OwnerLimits::new().with_max_name_bytes(1),
        ),
    ];
    for (label, limits) in cases {
        assert!(
            eager_sheet.form_controls_with_limits(limits).is_err(),
            "eager owner admitted the {label} limit"
        );
        assert!(
            source_sheet.form_controls_with_limits(limits).is_err(),
            "source owner admitted the {label} limit"
        );
    }
}

#[test]
fn caller_leaf_depth_event_and_opaque_caps_are_forwarded() {
    let source = fixture_bytes("checkbox-form-control.xlsx");
    let eager_sheet = Workbook::from_bytes(source.clone())
        .unwrap()
        .sheet(0)
        .unwrap()
        .unwrap();
    let source_sheet = SourceBackedWorkbook::from_reader(Cursor::new(source))
        .unwrap()
        .sheet(0)
        .unwrap()
        .unwrap();
    let cases = [
        ("leaf depth", OwnerLimits::new().with_max_mce_depth(1)),
        ("leaf events", OwnerLimits::new().with_max_mce_events(1)),
        (
            "leaf opaque bytes",
            OwnerLimits::new().with_max_mce_bytes(1),
        ),
    ];
    for (label, limits) in cases {
        assert!(
            eager_sheet.form_controls_with_limits(limits).is_err(),
            "eager owner admitted the lowered {label} cap"
        );
        assert!(
            source_sheet.form_controls_with_limits(limits).is_err(),
            "source owner admitted the lowered {label} cap"
        );
    }
}

#[test]
fn source_reads_are_read_only_and_repeated_semantic_selection_is_stable() {
    let source = fixture_bytes("tdf134769.xlsx");
    let workbook = SourceBackedWorkbook::from_reader(Cursor::new(source.clone())).unwrap();
    let sheet = workbook.sheet(0).unwrap().unwrap();
    let first = sheet
        .form_control(ControlSelector::name("Check Box 1"))
        .unwrap()
        .unwrap();
    let second = sheet
        .form_control(ControlSelector::position(0))
        .unwrap()
        .unwrap();
    assert_eq!(first, second);
    assert_eq!(first.properties().fmla_link().unwrap().as_str(), "#REF!");
    let archive = ArchiveReader::new(&source).unwrap();
    let raw = archive.read("xl/ctrlProps/ctrlProp1.xml").unwrap();
    assert_eq!(first.properties().source_bytes(), Some(raw.as_slice()));
}

#[test]
fn source_owner_final_fence_rejects_revision_flip_after_scan() {
    let source_bytes = fixture_bytes("tdf134769.xlsx");
    let baseline_source = Arc::new(VersionFlipSource::new(source_bytes.clone(), None));
    let baseline = SourceBackedWorkbook::from_read_at(baseline_source.clone()).unwrap();
    baseline.sheet(0).unwrap().unwrap().form_controls().unwrap();
    let final_check_call = baseline_source.version_calls.load(Ordering::SeqCst);
    drop(baseline);

    let source = Arc::new(VersionFlipSource::new(source_bytes, Some(final_check_call)));
    let workbook = SourceBackedWorkbook::from_read_at(source).unwrap();
    let sheet = workbook.sheet(0).unwrap().unwrap();
    assert!(matches!(
        sheet.form_controls(),
        Err(Error::Package(OpcError::SourceChanged { .. }))
    ));
}
