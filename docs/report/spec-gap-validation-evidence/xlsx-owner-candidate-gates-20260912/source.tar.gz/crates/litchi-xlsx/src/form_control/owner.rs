//! Worksheet/package ownership for SpreadsheetML form controls.
//!
//! The leaf [`super::Properties`] codec owns one `formControlPr` part.  This
//! module proves the worksheet relationship and the DrawingML/VML identity
//! closure before exposing that leaf through a worksheet-facing, selector
//! first view.  It intentionally has no mutation or publication API.

#![allow(
    clippy::arbitrary_source_item_ordering,
    clippy::too_many_lines,
    clippy::type_complexity,
    reason = "the scanner follows the worksheet, relationship, drawing, and VML wire order"
)]

use litchi_ooxml_common::mce::{Capabilities, Limits as MceLimits, process_markup_compatibility};
use litchi_opc::constants::{content_type as ct, relationship_type as rt};
use litchi_opc::{
    OpcPackage, OwnedRelationships, PackURI, PartData, ReadLimits, Relationships,
    SourceBackedPackage, TargetMode,
};
use quick_xml::events::{BytesStart, Event};
use quick_xml::name::{Namespace, ResolveResult};
use quick_xml::reader::NsReader;
use std::collections::{HashMap, HashSet};
use std::io::Read;
use std::ops::Range;
#[cfg(any(unix, windows))]
use std::path::Path;
use std::sync::Arc;

use super::{
    CONTROL_PROPERTIES_CONTENT_TYPE, CONTROL_PROPERTIES_RELATIONSHIP_TYPE, ControlSelector,
    FORM_CONTROL_NAMESPACE, FormControlError, Limits as LeafLimits, Properties, parse_with_limits,
};
use crate::error::{Error, Result, invalid};
use crate::raw;
use crate::workbook::source::validate_sheet_graph;
use crate::{Selector, WorksheetKind};

const SML: &[u8] = b"http://schemas.openxmlformats.org/spreadsheetml/2006/main";
const STRICT_SML: &[u8] = b"http://purl.oclc.org/ooxml/spreadsheetml/main";
const REL: &[u8] = b"http://schemas.openxmlformats.org/officeDocument/2006/relationships";
const STRICT_REL: &[u8] = b"http://purl.oclc.org/ooxml/officeDocument/relationships";
const XDR: &[u8] = b"http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing";
const STRICT_XDR: &[u8] = b"http://purl.oclc.org/ooxml/drawingml/spreadsheetDrawing";
const A14: &[u8] = b"http://schemas.microsoft.com/office/drawing/2010/main";
const VML: &[u8] = b"urn:schemas-microsoft-com:vml";
const OFFICE: &[u8] = b"urn:schemas-microsoft-com:office:office";
const EXCEL: &[u8] = b"urn:schemas-microsoft-com:office:excel";

const MAX_SHAPE_ID: u64 = 67_098_623;
const MIN_SP_ID: u64 = 1_025;
const MAX_SP_ID: u64 = 268_435_456;
const MAX_CONTROLS_PROFILE: usize = 65_535;
const DEFAULT_MAX_DRAWING_BYTES: usize = 16 * 1024 * 1024;
const DEFAULT_MAX_VML_BYTES: usize = 16 * 1024 * 1024;
const DEFAULT_MAX_MCE_BYTES: usize = 32 * 1024 * 1024;
const DEFAULT_MAX_RELATIONSHIP_EDGES: usize = 1_000_000;
const DEFAULT_MAX_SHAPES: usize = 65_535;
const DEFAULT_MAX_MIRROR_NODES: usize = 65_536;
const DEFAULT_MAX_NAME_BYTES: usize = 4 * 1024;
const MAX_AUTHORED_NAME_CHARS: usize = 32;
const ACTIVE_X_REL: &str =
    "http://schemas.openxmlformats.org/officeDocument/2006/relationships/control";
const STRICT_ACTIVE_X_REL: &str = "http://purl.oclc.org/ooxml/officeDocument/relationships/control";

/// Bounded host policy for worksheet form-control reads.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct OwnerLimits {
    max_controls: usize,
    max_mce_branches: usize,
    max_mce_depth: usize,
    max_mce_events: usize,
    max_mce_bytes: usize,
    max_relationship_edges: usize,
    max_drawing_bytes: usize,
    max_vml_bytes: usize,
    max_sidecar_relationship_bytes: usize,
    max_control_properties_relationship_bytes: usize,
    max_shapes: usize,
    max_mirror_nodes: usize,
    max_name_bytes: usize,
}

impl Default for OwnerLimits {
    fn default() -> Self {
        Self {
            max_controls: MAX_CONTROLS_PROFILE,
            max_mce_branches: 65_536,
            max_mce_depth: 256,
            max_mce_events: super::MAX_XML_EVENTS,
            max_mce_bytes: DEFAULT_MAX_MCE_BYTES,
            max_relationship_edges: DEFAULT_MAX_RELATIONSHIP_EDGES,
            max_drawing_bytes: DEFAULT_MAX_DRAWING_BYTES,
            max_vml_bytes: DEFAULT_MAX_VML_BYTES,
            max_sidecar_relationship_bytes: 4 * 1024 * 1024,
            max_control_properties_relationship_bytes: 4 * 1024 * 1024,
            max_shapes: DEFAULT_MAX_SHAPES,
            max_mirror_nodes: DEFAULT_MAX_MIRROR_NODES,
            max_name_bytes: DEFAULT_MAX_NAME_BYTES,
        }
    }
}

impl OwnerLimits {
    /// Create the standard bounded host policy.
    #[must_use]
    pub const fn new() -> Self {
        Self {
            max_controls: MAX_CONTROLS_PROFILE,
            max_mce_branches: 65_536,
            max_mce_depth: 256,
            max_mce_events: super::MAX_XML_EVENTS,
            max_mce_bytes: DEFAULT_MAX_MCE_BYTES,
            max_relationship_edges: DEFAULT_MAX_RELATIONSHIP_EDGES,
            max_drawing_bytes: DEFAULT_MAX_DRAWING_BYTES,
            max_vml_bytes: DEFAULT_MAX_VML_BYTES,
            max_sidecar_relationship_bytes: 4 * 1024 * 1024,
            max_control_properties_relationship_bytes: 4 * 1024 * 1024,
            max_shapes: DEFAULT_MAX_SHAPES,
            max_mirror_nodes: DEFAULT_MAX_MIRROR_NODES,
            max_name_bytes: DEFAULT_MAX_NAME_BYTES,
        }
    }

    /// Lower the effective-control ceiling.  The profile ceiling is 65,535.
    #[must_use]
    pub const fn with_max_controls(mut self, value: usize) -> Self {
        self.max_controls = if value < MAX_CONTROLS_PROFILE {
            value
        } else {
            MAX_CONTROLS_PROFILE
        };
        self
    }

    /// Lower the selected/ignored MCE branch ceiling.
    #[must_use]
    pub const fn with_max_mce_branches(mut self, value: usize) -> Self {
        self.max_mce_branches = if value < 65_536 { value } else { 65_536 };
        self
    }

    /// Lower the MCE nesting ceiling.
    #[must_use]
    pub const fn with_max_mce_depth(mut self, value: usize) -> Self {
        self.max_mce_depth = if value < 256 { value } else { 256 };
        self
    }

    /// Lower the XML-event ceiling applied to every owner scanner and leaf.
    #[must_use]
    pub const fn with_max_mce_events(mut self, value: usize) -> Self {
        self.max_mce_events = if value < super::MAX_XML_EVENTS {
            value
        } else {
            super::MAX_XML_EVENTS
        };
        self
    }

    /// Lower the MCE source/output-byte ceiling.
    #[must_use]
    pub const fn with_max_mce_bytes(mut self, value: usize) -> Self {
        self.max_mce_bytes = if value < DEFAULT_MAX_MCE_BYTES {
            value
        } else {
            DEFAULT_MAX_MCE_BYTES
        };
        self
    }

    /// Lower the relationship-edge ceiling.
    #[must_use]
    pub const fn with_max_relationship_edges(mut self, value: usize) -> Self {
        self.max_relationship_edges = if value < DEFAULT_MAX_RELATIONSHIP_EDGES {
            value
        } else {
            DEFAULT_MAX_RELATIONSHIP_EDGES
        };
        self
    }

    /// Lower the retained DrawingML byte ceiling.
    #[must_use]
    pub const fn with_max_drawing_bytes(mut self, value: usize) -> Self {
        self.max_drawing_bytes = if value < DEFAULT_MAX_DRAWING_BYTES {
            value
        } else {
            DEFAULT_MAX_DRAWING_BYTES
        };
        self
    }

    /// Lower the retained VML byte ceiling.
    #[must_use]
    pub const fn with_max_vml_bytes(mut self, value: usize) -> Self {
        self.max_vml_bytes = if value < DEFAULT_MAX_VML_BYTES {
            value
        } else {
            DEFAULT_MAX_VML_BYTES
        };
        self
    }

    /// Lower the DrawingML/VML sidecar relationship-member ceiling.
    #[must_use]
    pub const fn with_max_sidecar_relationship_bytes(mut self, value: usize) -> Self {
        self.max_sidecar_relationship_bytes = if value < 4 * 1024 * 1024 {
            value
        } else {
            4 * 1024 * 1024
        };
        self
    }

    /// Lower the selected control-properties relationship-member ceiling.
    #[must_use]
    pub const fn with_max_control_properties_relationship_bytes(mut self, value: usize) -> Self {
        self.max_control_properties_relationship_bytes = if value < 4 * 1024 * 1024 {
            value
        } else {
            4 * 1024 * 1024
        };
        self
    }

    /// Lower the retained shape-identity ceiling.
    #[must_use]
    pub const fn with_max_shapes(mut self, value: usize) -> Self {
        self.max_shapes = if value < DEFAULT_MAX_SHAPES {
            value
        } else {
            DEFAULT_MAX_SHAPES
        };
        self
    }

    /// Lower the mirror-node ceiling.
    #[must_use]
    pub const fn with_max_mirror_nodes(mut self, value: usize) -> Self {
        self.max_mirror_nodes = if value < DEFAULT_MAX_MIRROR_NODES {
            value
        } else {
            DEFAULT_MAX_MIRROR_NODES
        };
        self
    }

    /// Lower the bound for one authored control, shape, or VML identity name.
    #[must_use]
    pub const fn with_max_name_bytes(mut self, value: usize) -> Self {
        self.max_name_bytes = if value < DEFAULT_MAX_NAME_BYTES {
            value
        } else {
            DEFAULT_MAX_NAME_BYTES
        };
        self
    }

    /// Derive an owner policy from the caller's OPC read policy.
    #[must_use]
    pub fn from_read_limits(read_limits: ReadLimits) -> Self {
        let mut limits = Self::default();
        limits.max_drawing_bytes =
            lower_u64(limits.max_drawing_bytes, read_limits.max_part_bytes());
        limits.max_vml_bytes = lower_u64(limits.max_vml_bytes, read_limits.max_part_bytes());
        limits.max_mce_bytes = lower_u64(limits.max_mce_bytes, read_limits.max_part_bytes());
        limits.max_sidecar_relationship_bytes = lower_usize(
            limits.max_sidecar_relationship_bytes,
            read_limits.max_relationship_xml_bytes(),
        );
        limits.max_control_properties_relationship_bytes = lower_usize(
            limits.max_control_properties_relationship_bytes,
            read_limits.max_relationship_xml_bytes(),
        );
        limits.max_relationship_edges = limits
            .max_relationship_edges
            .min(read_limits.max_relationship_graph_nodes());
        limits
    }

    /// Maximum effective controls admitted by this policy.
    #[must_use]
    pub const fn max_controls(self) -> usize {
        self.max_controls
    }

    /// Maximum MCE branches admitted by this policy.
    #[must_use]
    pub const fn max_mce_branches(self) -> usize {
        self.max_mce_branches
    }

    /// Maximum MCE nesting depth admitted by this policy.
    #[must_use]
    pub const fn max_mce_depth(self) -> usize {
        self.max_mce_depth
    }

    /// Maximum XML events admitted by this policy.
    #[must_use]
    pub const fn max_mce_events(self) -> usize {
        self.max_mce_events
    }

    /// Maximum bytes retained for MCE input/output.
    #[must_use]
    pub const fn max_mce_bytes(self) -> usize {
        self.max_mce_bytes
    }

    /// Maximum relationship edges admitted by this policy.
    #[must_use]
    pub const fn max_relationship_edges(self) -> usize {
        self.max_relationship_edges
    }

    /// Maximum DrawingML bytes retained by this policy.
    #[must_use]
    pub const fn max_drawing_bytes(self) -> usize {
        self.max_drawing_bytes
    }

    /// Maximum VML bytes retained by this policy.
    #[must_use]
    pub const fn max_vml_bytes(self) -> usize {
        self.max_vml_bytes
    }

    /// Maximum shape identities admitted by this policy.
    #[must_use]
    pub const fn max_shapes(self) -> usize {
        self.max_shapes
    }

    /// Maximum mirror nodes admitted by this policy.
    #[must_use]
    pub const fn max_mirror_nodes(self) -> usize {
        self.max_mirror_nodes
    }

    /// Maximum retained DrawingML/VML sidecar relationship bytes.
    #[must_use]
    pub const fn max_sidecar_relationship_bytes(self) -> usize {
        self.max_sidecar_relationship_bytes
    }

    /// Maximum retained selected control-properties relationship bytes.
    #[must_use]
    pub const fn max_control_properties_relationship_bytes(self) -> usize {
        self.max_control_properties_relationship_bytes
    }

    /// Maximum bytes in one authored identity/name token.
    #[must_use]
    pub const fn max_name_bytes(self) -> usize {
        self.max_name_bytes
    }
}

fn lower_usize(current: usize, requested: usize) -> usize {
    if requested < current {
        requested
    } else {
        current
    }
}

fn lower_u64(current: usize, requested: u64) -> usize {
    current.min(usize::try_from(requested).unwrap_or(usize::MAX))
}

/// A stable host profile identity for the first canonical worksheet dialect.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub struct OwnerProfile {
    /// Profile version.
    pub version: u16,
    /// Expanded worksheet capability URI.
    pub worksheet_capability: &'static str,
    /// Expanded DrawingML capability URI.
    pub drawing_capability: &'static str,
}

impl OwnerProfile {
    /// The admitted canonical x14/a14 profile.
    #[must_use]
    pub const fn canonical() -> Self {
        Self {
            version: 1,
            worksheet_capability: FORM_CONTROL_NAMESPACE,
            drawing_capability: "http://schemas.microsoft.com/office/drawing/2010/main",
        }
    }
}

#[derive(Clone, Debug)]
enum RetainedPayload {
    Owned(Arc<[u8]>),
    Source(PartData),
    Relationships(OwnedRelationships),
}

impl RetainedPayload {
    fn owned(bytes: Vec<u8>) -> Self {
        Self::Owned(Arc::from(bytes))
    }

    fn source(data: PartData) -> Self {
        Self::Source(data)
    }

    fn relationships(token: OwnedRelationships) -> Self {
        Self::Relationships(token)
    }

    fn as_bytes(&self) -> &[u8] {
        match self {
            Self::Owned(bytes) => bytes,
            Self::Source(data) => data.as_bytes(),
            Self::Relationships(token) => token.bytes(),
        }
    }

    const fn is_source_backed(&self) -> bool {
        matches!(self, Self::Source(_))
    }
}

impl PartialEq for RetainedPayload {
    fn eq(&self, other: &Self) -> bool {
        self.as_bytes() == other.as_bytes()
    }
}

impl Eq for RetainedPayload {}

/// Bounded provenance for one MCE-selected owner part.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct MceProvenance {
    raw: Arc<[u8]>,
    selected: Arc<[u8]>,
    ignored: Arc<[u8]>,
    selected_ranges: Box<[Range<usize>]>,
    ignored_ranges: Box<[Range<usize>]>,
    wrapper_ranges: Box<[Range<usize>]>,
    selected_parent_ranges: Box<[Range<usize>]>,
    ignored_parent_ranges: Box<[Range<usize>]>,
    selected_choices: usize,
    selected_fallbacks: usize,
    ignored_elements: usize,
    ignored_attributes: usize,
}

impl MceProvenance {
    /// Exact bounded source bytes presented to the MCE resolver.
    #[must_use]
    pub fn raw_bytes(&self) -> &[u8] {
        &self.raw
    }

    /// Exact bounded semantic bytes emitted by the resolver.
    #[must_use]
    pub fn selected_bytes(&self) -> &[u8] {
        &self.selected
    }

    /// Source bytes retained as inactive/ignored provenance.
    #[must_use]
    pub fn ignored_bytes(&self) -> &[u8] {
        &self.ignored
    }

    /// Source ranges of selected MCE branches, relative to [`Self::raw_bytes`].
    #[must_use]
    pub fn selected_ranges(&self) -> &[Range<usize>] {
        &self.selected_ranges
    }

    /// Source ranges of inactive MCE branches, relative to [`Self::raw_bytes`].
    #[must_use]
    pub fn ignored_ranges(&self) -> &[Range<usize>] {
        &self.ignored_ranges
    }

    /// Source ranges of all `mc:AlternateContent` wrappers, including nested
    /// wrappers, relative to [`Self::raw_bytes`].
    #[must_use]
    pub fn wrapper_ranges(&self) -> &[Range<usize>] {
        &self.wrapper_ranges
    }

    /// Wrapper ranges whose effective branch was selected.
    #[must_use]
    pub fn selected_parent_ranges(&self) -> &[Range<usize>] {
        &self.selected_parent_ranges
    }

    /// Wrapper ranges whose effective branch was ignored.
    #[must_use]
    pub fn ignored_parent_ranges(&self) -> &[Range<usize>] {
        &self.ignored_parent_ranges
    }

    /// Number of selected `mc:Choice` branches.
    #[must_use]
    pub const fn selected_choices(&self) -> usize {
        self.selected_choices
    }

    /// Number of selected `mc:Fallback` branches.
    #[must_use]
    pub const fn selected_fallbacks(&self) -> usize {
        self.selected_fallbacks
    }

    /// Number of ignored source elements.
    #[must_use]
    pub const fn ignored_elements(&self) -> usize {
        self.ignored_elements
    }

    /// Number of ignored source attributes.
    #[must_use]
    pub const fn ignored_attributes(&self) -> usize {
        self.ignored_attributes
    }
}

/// A bounded sidecar relationship-member fingerprint.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub struct RelationshipFingerprint {
    present: bool,
    bytes: usize,
    digest: u64,
    edges: usize,
}

impl RelationshipFingerprint {
    /// Whether a physical `.rels` member was present.
    #[must_use]
    pub const fn present(self) -> bool {
        self.present
    }

    /// Bounded canonical relationship-byte size used for the fingerprint.
    #[must_use]
    pub const fn bytes(self) -> usize {
        self.bytes
    }

    /// Stable FNV-1a digest of the parsed relationship graph.
    #[must_use]
    pub const fn digest(self) -> u64 {
        self.digest
    }

    /// Number of parsed relationship edges.
    #[must_use]
    pub const fn edges(self) -> usize {
        self.edges
    }
}

/// One retained package owner payload in a source read set.
#[derive(Clone, Debug)]
pub struct FormControlPartRead {
    payload: RetainedPayload,
    relationship_payload: Option<RetainedPayload>,
    source_version: Option<litchi_core::SourceVersion>,
    relationship_source_version: Option<litchi_core::SourceVersion>,
    range: Range<usize>,
    relationship_range: Option<Range<usize>>,
    relationships: RelationshipFingerprint,
}

impl PartialEq for FormControlPartRead {
    fn eq(&self, other: &Self) -> bool {
        self.payload == other.payload
            && self.relationship_payload == other.relationship_payload
            && self.source_version == other.source_version
            && self.relationship_source_version == other.relationship_source_version
            && self.range == other.range
            && self.relationship_range == other.relationship_range
            && self.relationships == other.relationships
    }
}

impl Eq for FormControlPartRead {}

impl FormControlPartRead {
    /// Borrow the retained owner bytes.
    #[must_use]
    pub fn bytes(&self) -> &[u8] {
        self.payload.as_bytes()
    }

    /// Source version captured when this payload was read, if deferred.
    #[must_use]
    pub const fn source_version(&self) -> Option<litchi_core::SourceVersion> {
        self.source_version
    }

    /// Source version captured for the retained physical relationship
    /// member, if one was present in a deferred read set.
    #[must_use]
    pub const fn relationship_source_version(&self) -> Option<litchi_core::SourceVersion> {
        self.relationship_source_version
    }

    /// Exact range retained from the owner payload.
    #[must_use]
    pub fn range(&self) -> Range<usize> {
        self.range.clone()
    }

    /// Exact range retained for the physical relationship member, if present.
    #[must_use]
    pub fn relationship_range(&self) -> Option<Range<usize>> {
        self.relationship_range.clone()
    }

    /// Fingerprint of the owner's physical relationship member.
    #[must_use]
    pub const fn relationships(&self) -> RelationshipFingerprint {
        self.relationships
    }

    /// Borrow exact retained relationship-member bytes when a physical member
    /// was present.
    #[must_use]
    pub fn relationship_bytes(&self) -> Option<&[u8]> {
        self.relationship_payload
            .as_ref()
            .map(RetainedPayload::as_bytes)
    }

    /// Whether the retained relationship member is backed by managed
    /// source-owned `PartData`.
    #[must_use]
    pub fn relationship_is_source_backed(&self) -> bool {
        self.relationship_payload
            .as_ref()
            .is_some_and(RetainedPayload::is_source_backed)
    }

    /// Whether this payload is retained through source-backed `PartData`.
    #[must_use]
    pub const fn is_source_backed(&self) -> bool {
        self.payload.is_source_backed()
    }
}

/// Scoped owner read set retained by a form-control collection.
#[derive(Clone, Debug)]
pub struct FormControlReadSet {
    source_version: Option<litchi_core::SourceVersion>,
    worksheet: FormControlPartRead,
    drawing: Option<FormControlPartRead>,
    vml: Option<FormControlPartRead>,
    properties: Box<[FormControlPartRead]>,
    sidecar_targets: Box<[FormControlPartRead]>,
    worksheet_mce: MceProvenance,
    drawing_mce: MceProvenance,
}

impl PartialEq for FormControlReadSet {
    fn eq(&self, other: &Self) -> bool {
        self.source_version == other.source_version
            && self.worksheet == other.worksheet
            && self.drawing == other.drawing
            && self.vml == other.vml
            && self.properties == other.properties
            && self.sidecar_targets == other.sidecar_targets
            && self.worksheet_mce == other.worksheet_mce
            && self.drawing_mce == other.drawing_mce
    }
}

impl Eq for FormControlReadSet {}

impl FormControlReadSet {
    /// Source version shared by every retained source payload.
    #[must_use]
    pub const fn source_version(&self) -> Option<litchi_core::SourceVersion> {
        self.source_version
    }

    /// Worksheet XML and relationship-member fingerprint.
    #[must_use]
    pub const fn worksheet(&self) -> &FormControlPartRead {
        &self.worksheet
    }

    /// Selected DrawingML payload and sidecar fingerprint.
    #[must_use]
    pub const fn drawing(&self) -> Option<&FormControlPartRead> {
        self.drawing.as_ref()
    }

    /// Selected VML payload and sidecar fingerprint.
    #[must_use]
    pub const fn vml(&self) -> Option<&FormControlPartRead> {
        self.vml.as_ref()
    }

    /// Selected control-properties payloads in effective control order.
    #[must_use]
    pub fn properties(&self) -> &[FormControlPartRead] {
        &self.properties
    }

    /// Internal targets reached from retained DrawingML, VML, or selected
    /// properties sidecar relationship members.  Each target is retained as a
    /// bounded source payload so the sidecar edge cannot silently disappear
    /// between a read and a later source-backed operation.
    #[must_use]
    pub fn sidecar_targets(&self) -> &[FormControlPartRead] {
        &self.sidecar_targets
    }

    /// Worksheet MCE raw/selected/inactive provenance.
    #[must_use]
    pub const fn worksheet_mce(&self) -> &MceProvenance {
        &self.worksheet_mce
    }

    /// Drawing MCE raw/selected/inactive provenance.
    #[must_use]
    pub const fn drawing_mce(&self) -> &MceProvenance {
        &self.drawing_mce
    }
}

/// Diagnostic category carried by an owner collection or one control.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
#[non_exhaustive]
pub enum FormControlDiagnosticCode {
    /// A control-properties part has no effective incoming worksheet owner.
    UnreferencedControlProperties,
    /// A graph branch was retained but is not admitted to the typed profile.
    OpaqueGraph,
    /// A shape or relationship identity is ambiguous.
    AmbiguousIdentity,
    /// A source mirror is not proven by the admitted profile.
    UnprovenMirror,
    /// An MCE wrapper could not be selected deterministically.
    MarkupCompatibility,
    /// A strict or mixed worksheet dialect was refused.
    UnsupportedDialect,
    /// The optional SpreadsheetML control-pr anchor was absent or malformed.
    ControlPrAnchor,
}

/// One inert diagnostic.  Details are explanatory and never interpreted as a
/// selector or package path by the public facade.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct FormControlDiagnostic {
    code: FormControlDiagnosticCode,
    detail: Box<str>,
}

impl FormControlDiagnostic {
    fn new(code: FormControlDiagnosticCode, detail: impl Into<Box<str>>) -> Self {
        Self {
            code,
            detail: detail.into(),
        }
    }

    /// Diagnostic category.
    #[must_use]
    pub const fn code(&self) -> FormControlDiagnosticCode {
        self.code
    }

    /// Human-readable inert detail.
    #[must_use]
    pub fn detail(&self) -> &str {
        &self.detail
    }
}

/// DrawingML/VML identity closure for one effective control.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ShapeClosure {
    shape_id: u64,
    drawing_name: Option<Box<str>>,
    compat_spid: Box<str>,
    vml_id: Box<str>,
    vml_spid: Option<Box<str>>,
    object_type: Box<str>,
    vml_object_type: Box<str>,
    drawing_relationships_present: bool,
    vml_relationships_present: bool,
    drawing_relationships: RelationshipFingerprint,
    vml_relationships: RelationshipFingerprint,
}

impl ShapeClosure {
    /// Worksheet/DrawingML numeric identity.
    #[must_use]
    pub const fn shape_id(&self) -> u64 {
        self.shape_id
    }

    /// DrawingML `cNvPr/@name`, if authored.
    #[must_use]
    pub fn drawing_name(&self) -> Option<&str> {
        self.drawing_name.as_deref()
    }

    /// Selected `a14:compatExt/@spid` lexical value.
    #[must_use]
    pub fn compat_spid(&self) -> &str {
        &self.compat_spid
    }

    /// VML `v:shape/@id` lexical value.
    #[must_use]
    pub fn vml_id(&self) -> &str {
        &self.vml_id
    }

    /// VML `o:spid`, if authored.
    #[must_use]
    pub fn vml_spid(&self) -> Option<&str> {
        self.vml_spid.as_deref()
    }

    /// Typed x14 `formControlPr/@objectType` token.
    #[must_use]
    pub fn object_type(&self) -> &str {
        &self.object_type
    }

    /// VML `ClientData/@ObjectType` token retained by the closure.
    #[must_use]
    pub fn vml_object_type(&self) -> &str {
        &self.vml_object_type
    }

    /// Whether the DrawingML part had a physical `.rels` member.
    #[must_use]
    pub const fn drawing_relationships_present(&self) -> bool {
        self.drawing_relationships_present
    }

    /// Whether the VML part had a physical `.rels` member.
    #[must_use]
    pub const fn vml_relationships_present(&self) -> bool {
        self.vml_relationships_present
    }

    /// Fingerprint of the DrawingML sidecar relationship member.
    #[must_use]
    pub const fn drawing_relationships(&self) -> RelationshipFingerprint {
        self.drawing_relationships
    }

    /// Fingerprint of the VML sidecar relationship member.
    #[must_use]
    pub const fn vml_relationships(&self) -> RelationshipFingerprint {
        self.vml_relationships
    }
}

/// One typed, source-backed form-control projection.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct FormControlView {
    position: usize,
    name: Option<Box<str>>,
    anchor_profile: Option<Box<str>>,
    properties: Properties,
    properties_relationships_present: bool,
    properties_relationships: RelationshipFingerprint,
    shape: ShapeClosure,
    diagnostics: Box<[FormControlDiagnostic]>,
}

impl FormControlView {
    /// Effective zero-based selector position.
    #[must_use]
    pub const fn position(&self) -> usize {
        self.position
    }

    /// Return the selector represented by this entry.
    #[must_use]
    pub fn selector(&self) -> ControlSelector<'_> {
        ControlSelector::Position(self.position)
    }

    /// Worksheet `control/@name`, if present.
    #[must_use]
    pub fn name(&self) -> Option<&str> {
        self.name.as_deref()
    }

    /// Matched SpreadsheetML control-pr anchor ancestry, if the optional
    /// `sml:controlPr/sml:anchor` shape is a canonical `LoSmlAnchorV1`.
    #[must_use]
    pub fn anchor_profile(&self) -> Option<&str> {
        self.anchor_profile.as_deref()
    }

    /// Typed `formControlPr` properties.
    #[must_use]
    pub fn properties(&self) -> &Properties {
        &self.properties
    }

    /// Whether the selected properties part had a physical `.rels` member.
    #[must_use]
    pub const fn properties_relationships_present(&self) -> bool {
        self.properties_relationships_present
    }

    /// Fingerprint of the selected control-properties relationship member.
    #[must_use]
    pub const fn properties_relationships(&self) -> RelationshipFingerprint {
        self.properties_relationships
    }

    /// DrawingML/VML identity closure.
    #[must_use]
    pub fn shape(&self) -> &ShapeClosure {
        &self.shape
    }

    /// Inert diagnostics for this source projection.
    #[must_use]
    pub fn diagnostics(&self) -> &[FormControlDiagnostic] {
        &self.diagnostics
    }
}

/// Immutable selector-first collection of effective worksheet controls.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct FormControlCollection {
    profile: OwnerProfile,
    controls: Box<[FormControlView]>,
    diagnostics: Box<[FormControlDiagnostic]>,
    read_set: Option<Box<FormControlReadSet>>,
}

impl FormControlCollection {
    /// Number of effective typed controls.
    #[must_use]
    pub fn len(&self) -> usize {
        self.controls.len()
    }

    /// Whether no effective controls were admitted.
    #[must_use]
    pub fn is_empty(&self) -> bool {
        self.controls.is_empty()
    }

    /// Profile used for the projection.
    #[must_use]
    pub const fn profile(&self) -> OwnerProfile {
        self.profile
    }

    /// Collection-level graph diagnostics.
    #[must_use]
    pub fn diagnostics(&self) -> &[FormControlDiagnostic] {
        &self.diagnostics
    }

    /// Scoped source read set, present for deferred source-backed reads.
    #[must_use]
    pub fn read_set(&self) -> Option<&FormControlReadSet> {
        self.read_set.as_deref()
    }

    /// Source version captured by this collection, if source-backed.
    #[must_use]
    pub fn source_version(&self) -> Option<litchi_core::SourceVersion> {
        self.read_set
            .as_deref()
            .and_then(FormControlReadSet::source_version)
    }

    /// Iterate controls in effective worksheet source order.
    pub fn iter(
        &self,
    ) -> impl ExactSizeIterator<Item = &FormControlView> + DoubleEndedIterator + '_ {
        self.controls.iter()
    }

    /// Resolve a semantic position or exact name.
    pub fn get<'a>(
        &self,
        selector: impl Into<ControlSelector<'a>>,
    ) -> Result<Option<&FormControlView>> {
        match selector.into() {
            ControlSelector::Position(position) => Ok(self.controls.get(position)),
            ControlSelector::Name(name) => {
                let mut found = None;
                for control in &self.controls {
                    if control.name() == Some(name) {
                        if found.is_some() {
                            return Err(invalid("form-control name selector is ambiguous"));
                        }
                        found = Some(control);
                    }
                }
                Ok(found)
            },
        }
    }
}

impl<'a> IntoIterator for &'a FormControlCollection {
    type Item = &'a FormControlView;
    type IntoIter = std::slice::Iter<'a, FormControlView>;

    fn into_iter(self) -> Self::IntoIter {
        self.controls.iter()
    }
}

/// Failure returned by the worksheet owner scanner.
#[derive(Debug, thiserror::Error)]
#[non_exhaustive]
pub enum FormControlOwnerError {
    /// A bounded owner graph is malformed or outside the admitted profile.
    #[error("invalid XLSX form-control owner graph: {0}")]
    Invalid(String),
    /// A host resource ceiling was exceeded before retaining more data.
    #[error("XLSX form-control owner {resource} exceeds {maximum} (observed {observed})")]
    Limit {
        resource: &'static str,
        observed: usize,
        maximum: usize,
    },
    /// The leaf properties codec refused a selected part.
    #[error(transparent)]
    Leaf(#[from] FormControlError),
    /// The underlying OPC source refused a bounded read.
    #[error(transparent)]
    Package(#[from] litchi_opc::OpcError),
    /// The source-backed XLSX facade returned a worksheet error.
    #[error(transparent)]
    Xlsx(#[from] Error),
}

/// Result type for direct owner operations.
pub type OwnerResult<T> = std::result::Result<T, FormControlOwnerError>;

/// Source-backed read-only owner for one XLSX package.
pub struct SourceBackedFormControlOwner {
    package: SourceBackedPackage,
    limits: OwnerLimits,
}

impl SourceBackedFormControlOwner {
    /// Open a deferred OPC package from a reader and retain the source-backed
    /// package for subsequent worksheet selections.
    pub fn from_reader<R: Read>(reader: R) -> OwnerResult<Self> {
        Self::from_source_backed_package(SourceBackedPackage::from_reader(reader)?)
    }

    /// Open a deferred OPC package from a filesystem path.
    #[cfg(any(unix, windows))]
    pub fn from_path(path: impl AsRef<Path>) -> OwnerResult<Self> {
        Self::from_source_backed_package(SourceBackedPackage::from_path(path)?)
    }

    /// Build an owner from an already opened deferred OPC package.
    pub fn from_source_backed_package(package: SourceBackedPackage) -> OwnerResult<Self> {
        package.check_execution()?;
        if package.has_encrypted_entries() {
            return Err(FormControlOwnerError::Invalid(
                "encrypted XLSX form-control source is not admitted".into(),
            ));
        }
        let limits = OwnerLimits::from_read_limits(package.read_limits());
        Ok(Self { package, limits })
    }

    /// Set a lower host policy before selecting a worksheet.
    #[must_use]
    pub fn with_limits(mut self, limits: OwnerLimits) -> Self {
        self.limits = limits;
        self
    }

    /// Capture one worksheet's effective form-control collection.
    pub fn form_controls<'a>(
        &self,
        selector: impl Into<Selector<'a>>,
    ) -> OwnerResult<FormControlCollection> {
        self.package.check_execution()?;
        let workbook = self.package.main_document_part()?;
        let catalog =
            raw::parse_catalog(workbook.data()?.as_bytes()).map_err(FormControlOwnerError::Xlsx)?;
        let sheet_parts = validate_sheet_graph(&self.package, &workbook, &catalog.sheets)
            .map_err(FormControlOwnerError::Xlsx)?;
        let position = resolve_sheet_position(&catalog.sheets, selector.into())?;
        let sheet = catalog
            .sheets
            .get(position)
            .ok_or_else(|| owner_invalid("worksheet selector did not resolve"))?;
        let part = sheet_parts
            .get(position)
            .ok_or_else(|| owner_invalid("worksheet graph position is absent"))?;
        if part.kind != WorksheetKind::Worksheet {
            return Err(FormControlOwnerError::Invalid(format!(
                "sheet '{}' is not a worksheet",
                sheet.name
            )));
        }
        let source_version = self.package.source_version()?;
        let worksheet = self.package.part(&part.uri)?;
        let worksheet_data = worksheet.data()?;
        let relationships = worksheet.rels().clone();
        let (relationship_member, relationship_payload) = source_relationship_payload(
            &self.package,
            &part.uri,
            &relationships,
            self.limits.max_sidecar_relationship_bytes,
            self.limits.max_relationship_edges,
            "worksheet relationship bytes",
        )?;
        let worksheet_part = source_loaded_part(
            worksheet.content_type(),
            worksheet_data,
            relationships.len(),
            relationship_member,
            source_version,
            &relationships,
            self.limits.max_sidecar_relationship_bytes,
            "worksheet bytes",
            self.limits.max_mce_bytes,
            relationship_payload,
        )?;
        let loader =
            |uri: &PackURI, maximum: usize, resource: &'static str| -> OwnerResult<LoadedPart> {
                let part = self.package.part(uri)?;
                let data = part.data()?;
                if data.as_bytes().len() > maximum {
                    return Err(owner_limit(resource, data.as_bytes().len(), maximum));
                }
                let relationships = part.rels().clone();
                let relationship_limit = if resource == "control-properties bytes" {
                    self.limits.max_control_properties_relationship_bytes
                } else {
                    self.limits.max_sidecar_relationship_bytes
                };
                let (relationship_member, relationship_payload) = source_relationship_payload(
                    &self.package,
                    uri,
                    &relationships,
                    relationship_limit,
                    self.limits.max_relationship_edges,
                    "source relationship bytes",
                )?;
                let fingerprint = fingerprint_relationships(
                    &relationships,
                    relationship_member,
                    relationship_limit,
                    resource,
                    relationship_payload.as_ref().map(RetainedPayload::as_bytes),
                )?;
                Ok(LoadedPart {
                    content_type: part.content_type().to_owned(),
                    payload: RetainedPayload::source(data),
                    source_version: Some(source_version),
                    relationship_count: relationships.len(),
                    relationships: fingerprint,
                    relationship_payload,
                    relationship_graph: relationships,
                })
            };
        scan_owner(
            worksheet_part,
            &relationships,
            &loader,
            &self.limits,
            Some(&self.package),
            &[],
        )
    }

    /// Resolve one semantic control in a selected worksheet.
    pub fn form_control<'a>(
        &self,
        sheet: impl Into<Selector<'a>>,
        selector: impl Into<ControlSelector<'a>>,
    ) -> OwnerResult<Option<FormControlView>> {
        let collection = self.form_controls(sheet)?;
        Ok(collection.get(selector)?.cloned())
    }

    /// Expose source cache diagnostics without exposing package identities.
    #[must_use]
    pub fn cache_diagnostics(&self) -> litchi_opc::SourceCacheDiagnostics {
        self.package.cache_diagnostics()
    }
}

/// Read one worksheet through the eager workbook package owner.
pub(crate) fn eager_form_controls(
    package: &OpcPackage,
    worksheet_uri: &PackURI,
    limits: OwnerLimits,
) -> OwnerResult<FormControlCollection> {
    let worksheet = package
        .get_part(worksheet_uri)
        .map_err(FormControlOwnerError::from)?;
    let worksheet_bytes = bounded_owned(worksheet.blob(), limits.max_mce_bytes, "worksheet bytes")?;
    let relationships = worksheet.rels().clone();
    let unreferenced_parts = eager_unreferenced_properties(package, &limits)?;
    let (relationship_member, relationship_payload) = eager_relationship_payload(
        package,
        worksheet_uri,
        &relationships,
        limits.max_sidecar_relationship_bytes,
        limits.max_relationship_edges,
        "worksheet relationship bytes",
    )?;
    let worksheet_part = eager_loaded_part(
        worksheet.content_type(),
        worksheet_bytes,
        worksheet.rels().len(),
        relationship_member,
        &relationships,
        limits.max_sidecar_relationship_bytes,
        "worksheet bytes",
        relationship_payload,
    )?;
    let loader =
        |uri: &PackURI, maximum: usize, resource: &'static str| -> OwnerResult<LoadedPart> {
            let part = package.get_part(uri).map_err(FormControlOwnerError::from)?;
            let bytes = bounded_owned(part.blob(), maximum, resource)?;
            let relationship_limit = if resource == "control-properties bytes" {
                limits.max_control_properties_relationship_bytes
            } else {
                limits.max_sidecar_relationship_bytes
            };
            let relationships = part.rels().clone();
            let (relationship_member, relationship_payload) = eager_relationship_payload(
                package,
                uri,
                &relationships,
                relationship_limit,
                limits.max_relationship_edges,
                "sidecar relationship bytes",
            )?;
            Ok(LoadedPart {
                content_type: part.content_type().to_owned(),
                payload: RetainedPayload::owned(bytes),
                source_version: None,
                relationship_count: relationships.len(),
                relationships: fingerprint_relationships(
                    &relationships,
                    relationship_member,
                    relationship_limit,
                    resource,
                    relationship_payload.as_ref().map(RetainedPayload::as_bytes),
                )?,
                relationship_payload,
                relationship_graph: relationships,
            })
        };
    scan_owner(
        worksheet_part,
        &relationships,
        &loader,
        &limits,
        None,
        &unreferenced_parts,
    )
}

/// Read-only host hook for an eager worksheet handle.
pub(crate) fn eager_form_controls_for_sheet(
    package: &OpcPackage,
    worksheet_uri: &PackURI,
) -> Result<FormControlCollection> {
    eager_form_controls_for_sheet_with_limits(package, worksheet_uri, OwnerLimits::default())
        .map_err(owner_to_xlsx)
}

pub(crate) fn eager_form_controls_for_sheet_with_limits(
    package: &OpcPackage,
    worksheet_uri: &PackURI,
    limits: OwnerLimits,
) -> OwnerResult<FormControlCollection> {
    eager_form_controls(package, worksheet_uri, limits)
}

/// Read-only host hook for a source-backed worksheet handle.
pub(crate) fn source_form_controls_for_sheet(
    package: &SourceBackedPackage,
    worksheet_uri: &PackURI,
) -> Result<FormControlCollection> {
    source_form_controls_for_sheet_with_limits(
        package,
        worksheet_uri,
        OwnerLimits::from_read_limits(package.read_limits()),
    )
}

pub(crate) fn source_form_controls_for_sheet_with_limits(
    package: &SourceBackedPackage,
    worksheet_uri: &PackURI,
    limits: OwnerLimits,
) -> Result<FormControlCollection> {
    package
        .check_execution()
        .map_err(FormControlOwnerError::from)
        .map_err(owner_to_xlsx)?;
    let worksheet = package
        .part(worksheet_uri)
        .map_err(FormControlOwnerError::from)
        .map_err(owner_to_xlsx)?;
    let source_version = package
        .source_version()
        .map_err(FormControlOwnerError::from)
        .map_err(owner_to_xlsx)?;
    let data = worksheet
        .data()
        .map_err(FormControlOwnerError::from)
        .map_err(owner_to_xlsx)?;
    let relationships = worksheet.rels().clone();
    let (relationship_member, relationship_payload) = source_relationship_payload(
        package,
        worksheet_uri,
        &relationships,
        limits.max_sidecar_relationship_bytes,
        limits.max_relationship_edges,
        "worksheet relationship bytes",
    )
    .map_err(owner_to_xlsx)?;
    let worksheet_part = source_loaded_part(
        worksheet.content_type(),
        data,
        relationships.len(),
        relationship_member,
        source_version,
        &relationships,
        limits.max_sidecar_relationship_bytes,
        "worksheet bytes",
        limits.max_mce_bytes,
        relationship_payload,
    )
    .map_err(owner_to_xlsx)?;
    let loader =
        |uri: &PackURI, maximum: usize, resource: &'static str| -> OwnerResult<LoadedPart> {
            let part = package.part(uri)?;
            let data = part.data()?;
            if data.as_bytes().len() > maximum {
                return Err(owner_limit(resource, data.as_bytes().len(), maximum));
            }
            let relationships = part.rels().clone();
            let relationship_limit = if resource == "control-properties bytes" {
                limits.max_control_properties_relationship_bytes
            } else {
                limits.max_sidecar_relationship_bytes
            };
            let (relationship_member, relationship_payload) = source_relationship_payload(
                package,
                uri,
                &relationships,
                relationship_limit,
                limits.max_relationship_edges,
                "source relationship bytes",
            )?;
            Ok(LoadedPart {
                content_type: part.content_type().to_owned(),
                payload: RetainedPayload::source(data),
                source_version: Some(source_version),
                relationship_count: relationships.len(),
                relationships: fingerprint_relationships(
                    &relationships,
                    relationship_member,
                    relationship_limit,
                    resource,
                    relationship_payload.as_ref().map(RetainedPayload::as_bytes),
                )?,
                relationship_payload,
                relationship_graph: relationships,
            })
        };
    scan_owner(
        worksheet_part,
        &relationships,
        &loader,
        &limits,
        Some(package),
        &[],
    )
    .map_err(owner_to_xlsx)
}

fn owner_to_xlsx(error: FormControlOwnerError) -> Error {
    match error {
        FormControlOwnerError::Xlsx(error) => error,
        FormControlOwnerError::Package(error) => Error::Package(error),
        FormControlOwnerError::Leaf(error) => Error::Invalid(error.to_string()),
        FormControlOwnerError::Invalid(error) => Error::Invalid(error),
        FormControlOwnerError::Limit {
            resource,
            observed,
            maximum,
        } => Error::Invalid(format!(
            "form-control owner {resource} exceeds {maximum} (observed {observed})"
        )),
    }
}

#[derive(Clone, Debug)]
struct LoadedPart {
    content_type: String,
    payload: RetainedPayload,
    source_version: Option<litchi_core::SourceVersion>,
    relationship_count: usize,
    relationships: RelationshipFingerprint,
    relationship_payload: Option<RetainedPayload>,
    relationship_graph: Relationships,
}

impl LoadedPart {
    fn bytes(&self) -> &[u8] {
        self.payload.as_bytes()
    }

    fn into_public(self) -> FormControlPartRead {
        let range = 0..self.bytes().len();
        let relationship_source_version =
            self.relationship_payload.as_ref().and(self.source_version);
        let relationship_range = self
            .relationship_payload
            .as_ref()
            .map(|payload| 0..payload.as_bytes().len());
        FormControlPartRead {
            payload: self.payload,
            relationship_payload: self.relationship_payload,
            source_version: self.source_version,
            relationship_source_version,
            range,
            relationship_range,
            relationships: self.relationships,
        }
    }
}

fn eager_loaded_part(
    content_type: &str,
    bytes: Vec<u8>,
    relationship_count: usize,
    relationship_member: bool,
    relationships: &Relationships,
    relationship_limit: usize,
    resource: &'static str,
    relationship_payload: Option<RetainedPayload>,
) -> OwnerResult<LoadedPart> {
    Ok(LoadedPart {
        content_type: content_type.to_owned(),
        payload: RetainedPayload::owned(bytes),
        source_version: None,
        relationship_count,
        relationships: fingerprint_relationships(
            relationships,
            relationship_member,
            relationship_limit,
            resource,
            relationship_payload.as_ref().map(RetainedPayload::as_bytes),
        )?,
        relationship_payload,
        relationship_graph: relationships.clone(),
    })
}

fn source_loaded_part(
    content_type: &str,
    data: PartData,
    relationship_count: usize,
    relationship_member: bool,
    source_version: litchi_core::SourceVersion,
    relationships: &Relationships,
    relationship_limit: usize,
    resource: &'static str,
    maximum: usize,
    relationship_payload: Option<RetainedPayload>,
) -> OwnerResult<LoadedPart> {
    if data.as_bytes().len() > maximum {
        return Err(owner_limit(resource, data.as_bytes().len(), maximum));
    }
    Ok(LoadedPart {
        content_type: content_type.to_owned(),
        payload: RetainedPayload::source(data),
        source_version: Some(source_version),
        relationship_count,
        relationships: fingerprint_relationships(
            relationships,
            relationship_member,
            relationship_limit,
            resource,
            relationship_payload.as_ref().map(RetainedPayload::as_bytes),
        )?,
        relationship_payload,
        relationship_graph: relationships.clone(),
    })
}

fn fingerprint_relationships(
    relationships: &Relationships,
    present: bool,
    maximum: usize,
    resource: &'static str,
    raw: Option<&[u8]>,
) -> OwnerResult<RelationshipFingerprint> {
    if !present {
        return Ok(RelationshipFingerprint {
            present: false,
            bytes: 0,
            digest: 0,
            edges: 0,
        });
    }
    if let Some(raw) = raw {
        if raw.len() > maximum {
            return Err(owner_limit(resource, raw.len(), maximum));
        }
        return Ok(RelationshipFingerprint {
            present: true,
            bytes: raw.len(),
            digest: fnv_bytes(0xcbf29ce484222325, raw),
            edges: relationships.len(),
        });
    }
    let mut entries = Vec::new();
    entries
        .try_reserve(relationships.len())
        .map_err(|source| owner_alloc("relationship fingerprint entries", source))?;
    entries.extend(relationships.iter());
    entries.sort_unstable_by(|left, right| left.r_id().cmp(right.r_id()));
    let mut bytes = b"<Relationships>".len();
    let mut digest = 0xcbf29ce484222325u64;
    for relationship in entries {
        let edge_bytes = relationship
            .r_id()
            .len()
            .checked_add(relationship.reltype().len())
            .and_then(|value| value.checked_add(relationship.target_ref().len()))
            .and_then(|value| value.checked_add(16))
            .ok_or_else(|| owner_invalid("relationship fingerprint byte count overflow"))?;
        bytes = bytes
            .checked_add(edge_bytes)
            .ok_or_else(|| owner_invalid("relationship fingerprint byte count overflow"))?;
        if bytes > maximum {
            return Err(owner_limit(resource, bytes, maximum));
        }
        digest = fnv_bytes(digest, relationship.r_id().as_bytes());
        digest = fnv_bytes(digest, relationship.reltype().as_bytes());
        digest = fnv_bytes(digest, relationship.target_ref().as_bytes());
        digest = fnv_bytes(
            digest,
            match relationship.target_mode() {
                TargetMode::Internal => b"I",
                TargetMode::External => b"E",
            },
        );
    }
    Ok(RelationshipFingerprint {
        present: true,
        bytes,
        digest,
        edges: relationships.len(),
    })
}

fn eager_relationship_payload(
    package: &OpcPackage,
    owner: &PackURI,
    relationships: &Relationships,
    maximum: usize,
    edge_limit: usize,
    resource: &'static str,
) -> OwnerResult<(bool, Option<RetainedPayload>)> {
    if relationships.len() > edge_limit {
        return Err(owner_limit(
            "relationship edges",
            relationships.len(),
            edge_limit,
        ));
    }
    let package_limits = package.read_limits();
    let plan = package.plan_source_relationships_with_limits(owner, package_limits)?;
    if plan.final_len() > maximum {
        return Err(owner_limit(resource, plan.final_len(), maximum));
    }
    let token = package.source_relationships_with_limits(owner, package_limits)?;
    let present = token.member_present();
    let payload = present.then(|| RetainedPayload::relationships(token));
    Ok((present, payload))
}

fn source_relationship_payload(
    package: &SourceBackedPackage,
    owner: &PackURI,
    relationships: &Relationships,
    maximum: usize,
    edge_limit: usize,
    resource: &'static str,
) -> OwnerResult<(bool, Option<RetainedPayload>)> {
    if relationships.len() > edge_limit {
        return Err(owner_limit(
            "relationship edges",
            relationships.len(),
            edge_limit,
        ));
    }
    let data = package.relationships_data_for_with_limit(owner, maximum)?;
    let Some(data) = data else {
        return Ok((false, None));
    };
    if data.as_bytes().len() > maximum {
        return Err(owner_limit(resource, data.as_bytes().len(), maximum));
    }
    Ok((true, Some(RetainedPayload::source(data))))
}

fn retain_sidecar_targets<F>(
    owner: &PackURI,
    part: &LoadedPart,
    load: &F,
    limits: &OwnerLimits,
    seen: &mut HashSet<String>,
    retained: &mut Vec<LoadedPart>,
    graph_edges: &mut usize,
) -> OwnerResult<()>
where
    F: Fn(&PackURI, usize, &'static str) -> OwnerResult<LoadedPart>,
{
    if part.relationship_graph.len() > limits.max_relationship_edges {
        return Err(owner_limit(
            "sidecar relationship edges",
            part.relationship_graph.len(),
            limits.max_relationship_edges,
        ));
    }
    for relationship in part.relationship_graph.iter() {
        if relationship.target_mode() != TargetMode::Internal {
            return Err(owner_invalid(format!(
                "sidecar relationship from {} has an external target",
                owner.as_str()
            )));
        }
        let target = relationship.target_partname()?;
        if !seen.insert(target.as_str().to_owned()) {
            continue;
        }
        if retained.len() >= limits.max_mirror_nodes {
            return Err(owner_limit(
                "sidecar target nodes",
                retained.len() + 1,
                limits.max_mirror_nodes,
            ));
        }
        let target_part = load(
            &target,
            limits.max_mce_bytes.min(super::MAX_PART_BYTES),
            "sidecar target bytes",
        )?;
        *graph_edges = graph_edges
            .checked_add(target_part.relationship_count)
            .ok_or_else(|| owner_invalid("form-control relationship edge count overflow"))?;
        if *graph_edges > limits.max_relationship_edges {
            return Err(owner_limit(
                "relationship edges",
                *graph_edges,
                limits.max_relationship_edges,
            ));
        }
        retained
            .try_reserve(1)
            .map_err(|source| owner_alloc("form-control sidecar target read set", source))?;
        retained.push(target_part);
    }
    Ok(())
}

const fn fnv_bytes(mut digest: u64, bytes: &[u8]) -> u64 {
    let mut index = 0;
    while index < bytes.len() {
        digest ^= bytes[index] as u64;
        digest = digest.wrapping_mul(0x100000001b3);
        index += 1;
    }
    digest
}

fn scan_owner<F>(
    worksheet_part: LoadedPart,
    worksheet_rels: &Relationships,
    load: &F,
    limits: &OwnerLimits,
    source_package: Option<&SourceBackedPackage>,
    unreferenced_parts: &[String],
) -> OwnerResult<FormControlCollection>
where
    F: Fn(&PackURI, usize, &'static str) -> OwnerResult<LoadedPart>,
{
    let expected_version = if let Some(package) = source_package {
        package.check_execution()?;
        Some(package.source_version()?)
    } else {
        None
    };
    if expected_version != worksheet_part.source_version {
        if expected_version.is_some() {
            return Err(owner_invalid(
                "worksheet source version changed before owner scan",
            ));
        }
    }
    let result = scan_owner_inner(
        worksheet_part,
        worksheet_rels,
        load,
        limits,
        source_package,
        unreferenced_parts,
    );
    if let Some(package) = source_package {
        let current_version = package
            .check_execution()
            .and_then(|()| package.source_version())
            .map_err(FormControlOwnerError::from);
        let current_version = current_version?;
        if Some(current_version) != expected_version {
            return Err(owner_invalid(
                "worksheet source version changed during owner scan",
            ));
        }
    }
    result
}

fn scan_owner_inner<F>(
    worksheet_part: LoadedPart,
    worksheet_rels: &Relationships,
    load: &F,
    limits: &OwnerLimits,
    source_package: Option<&SourceBackedPackage>,
    unreferenced_parts: &[String],
) -> OwnerResult<FormControlCollection>
where
    F: Fn(&PackURI, usize, &'static str) -> OwnerResult<LoadedPart>,
{
    validate_canonical_worksheet_root(worksheet_part.bytes())?;
    if worksheet_rels.len() > limits.max_relationship_edges {
        return Err(owner_limit(
            "worksheet relationship edges",
            worksheet_rels.len(),
            limits.max_relationship_edges,
        ));
    }
    if worksheet_rels
        .iter()
        .any(|relationship| matches!(relationship.reltype(), ACTIVE_X_REL | STRICT_ACTIVE_X_REL))
    {
        return Err(FormControlOwnerError::Invalid(
            "worksheet ActiveX persistence is not admitted by the form-control owner".into(),
        ));
    }
    let selected = select_mce(
        worksheet_part.bytes(),
        FORM_CONTROL_NAMESPACE,
        limits,
        "worksheet",
    )?;
    reject_mixed_dialect(&selected.xml, "worksheet", &[STRICT_SML, STRICT_REL])?;
    let worksheet = parse_worksheet(&selected.xml, limits)?;
    if worksheet.controls.is_empty() {
        return empty_collection(
            source_package,
            &HashSet::new(),
            worksheet_part,
            selected.provenance,
            unreferenced_parts,
        );
    }
    let drawing_uri = relationship_target(
        worksheet_rels,
        worksheet.drawing_relationship_id.as_deref(),
        rt::DRAWING,
        "worksheet drawing",
    )?;
    let vml_uri = relationship_target(
        worksheet_rels,
        worksheet.vml_relationship_id.as_deref(),
        rt::VML_DRAWING,
        "worksheet legacyDrawing",
    )?;
    let mut owner_parts = HashMap::<String, usize>::new();
    owner_parts
        .try_reserve(worksheet.controls.len())
        .map_err(|source| owner_alloc("control owner index", source))?;
    let mut controls = Vec::new();
    controls
        .try_reserve_exact(worksheet.controls.len())
        .map_err(|source| owner_alloc("form-control inventory", source))?;
    let mut retained_properties = Vec::new();
    retained_properties
        .try_reserve_exact(worksheet.controls.len())
        .map_err(|source| owner_alloc("form-control source read set", source))?;
    let mut retained_sidecar_targets = Vec::new();
    retained_sidecar_targets
        .try_reserve(worksheet.controls.len().min(limits.max_mirror_nodes))
        .map_err(|source| owner_alloc("form-control sidecar target read set", source))?;
    let mut retained_sidecar_target_uris = HashSet::<String>::new();
    retained_sidecar_target_uris
        .try_reserve(worksheet.controls.len().min(limits.max_mirror_nodes))
        .map_err(|source| owner_alloc("form-control sidecar target index", source))?;
    let mut incoming_targets = HashSet::<String>::new();
    incoming_targets
        .try_reserve(worksheet.controls.len())
        .map_err(|source| owner_alloc("form-control incoming index", source))?;
    let drawing_part = load(&drawing_uri, limits.max_drawing_bytes, "DrawingML bytes")?;
    let mut graph_edges = worksheet_rels
        .len()
        .checked_add(drawing_part.relationship_count)
        .ok_or_else(|| owner_invalid("form-control relationship edge count overflow"))?;
    if drawing_part.content_type != ct::OFC_DRAWING {
        return Err(owner_invalid(
            "drawing relationship target has an unexpected content type",
        ));
    }
    retain_sidecar_targets(
        &drawing_uri,
        &drawing_part,
        load,
        limits,
        &mut retained_sidecar_target_uris,
        &mut retained_sidecar_targets,
        &mut graph_edges,
    )?;
    let drawing_selected = select_mce(
        drawing_part.bytes(),
        "http://schemas.microsoft.com/office/drawing/2010/main",
        limits,
        "drawing",
    )?;
    reject_mixed_dialect(&drawing_selected.xml, "drawing", &[STRICT_XDR, STRICT_REL])?;
    validate_canonical_drawing_root(&drawing_selected.xml)?;
    validate_drawing_anchors(&drawing_selected.xml, limits)?;
    let drawing_shapes = parse_drawing(&drawing_selected.xml, limits)?;
    let drawing_index = index_drawing_shapes(&drawing_shapes)?;
    let vml_part = load(&vml_uri, limits.max_vml_bytes, "VML bytes")?;
    graph_edges = graph_edges
        .checked_add(vml_part.relationship_count)
        .ok_or_else(|| owner_invalid("form-control relationship edge count overflow"))?;
    if graph_edges > limits.max_relationship_edges {
        return Err(owner_limit(
            "relationship edges",
            graph_edges,
            limits.max_relationship_edges,
        ));
    }
    if vml_part.content_type != ct::OFC_VML_DRAWING {
        return Err(owner_invalid(
            "VML relationship target has an unexpected content type",
        ));
    }
    retain_sidecar_targets(
        &vml_uri,
        &vml_part,
        load,
        limits,
        &mut retained_sidecar_target_uris,
        &mut retained_sidecar_targets,
        &mut graph_edges,
    )?;
    let vml_shapes = parse_vml(vml_part.bytes(), limits)?;
    let vml_index = index_vml_shapes(&vml_shapes)?;
    let mirror_nodes = worksheet
        .controls
        .len()
        .checked_add(drawing_shapes.len())
        .and_then(|count| count.checked_add(vml_shapes.len()))
        .ok_or_else(|| owner_invalid("form-control mirror-node count overflow"))?;
    if mirror_nodes > limits.max_mirror_nodes {
        return Err(owner_limit(
            "form-control mirror nodes",
            mirror_nodes,
            limits.max_mirror_nodes,
        ));
    }
    for (position, source_control) in worksheet.controls.iter().enumerate() {
        if position >= limits.max_controls {
            return Err(owner_limit(
                "effective controls",
                position + 1,
                limits.max_controls,
            ));
        }
        let relationship = worksheet_rels
            .get(&source_control.relationship_id)
            .ok_or_else(|| owner_invalid("form-control worksheet relationship is missing"))?;
        if relationship.target_mode() != TargetMode::Internal {
            return Err(owner_invalid(
                "form-control relationship target is external",
            ));
        }
        if relationship.reltype() != CONTROL_PROPERTIES_RELATIONSHIP_TYPE {
            return Err(owner_invalid(
                "form-control relationship type is not canonical ctrlProp",
            ));
        }
        let target = relationship.target_partname()?;
        if !incoming_targets.insert(target.as_str().to_owned()) {
            return Err(owner_invalid(
                "form-control properties target has multiple effective owners",
            ));
        }
        let part = load(
            &target,
            limits.max_mce_bytes.min(super::MAX_PART_BYTES),
            "control-properties bytes",
        )?;
        graph_edges = graph_edges
            .checked_add(part.relationship_count)
            .ok_or_else(|| owner_invalid("form-control relationship edge count overflow"))?;
        if graph_edges > limits.max_relationship_edges {
            return Err(owner_limit(
                "relationship edges",
                graph_edges,
                limits.max_relationship_edges,
            ));
        }
        if part.content_type != CONTROL_PROPERTIES_CONTENT_TYPE {
            return Err(owner_invalid(
                "form-control properties content type is not canonical",
            ));
        }
        retain_sidecar_targets(
            &target,
            &part,
            load,
            limits,
            &mut retained_sidecar_target_uris,
            &mut retained_sidecar_targets,
            &mut graph_edges,
        )?;
        let leaf = leaf_limits(limits);
        let properties = parse_with_limits(part.bytes(), &leaf)?;
        retained_properties.push(part.clone().into_public());
        let drawing = source_control.shape_id;
        let shape = match drawing_index.get(&drawing) {
            Some(Some(index)) => drawing_shapes
                .get(*index)
                .ok_or_else(|| owner_invalid("DrawingML identity index is inconsistent"))?,
            Some(None) => return Err(owner_invalid("DrawingML identity is ambiguous")),
            None => {
                return Err(owner_invalid(
                    "DrawingML cNvPr identity does not match control shapeId",
                ));
            },
        };
        if shape.compat_spid.is_empty() {
            return Err(owner_invalid("DrawingML cNvPr is missing a14:compatExt"));
        }
        if numeric_spid(&shape.compat_spid) != Some(shape.id) {
            return Err(owner_invalid(
                "DrawingML a14:compatExt/@spid does not match cNvPr/@id",
            ));
        }
        if let (Some(control_name), Some(drawing_name)) =
            (source_control.name.as_deref(), shape.name.as_deref())
        {
            if control_name != drawing_name {
                return Err(owner_invalid(
                    "DrawingML cNvPr name does not match worksheet control name",
                ));
            }
        }
        let object_type = properties
            .object_type()
            .map(|value| match value {
                super::KnownOrUnknown::Known(value) => value.to_string(),
                super::KnownOrUnknown::Unknown(value) => value.clone(),
            })
            .unwrap_or_default();
        let expected_vml_type = match object_type.as_str() {
            "CheckBox" => Some("Checkbox"),
            "Button" => Some("Button"),
            "Radio" => Some("Radio"),
            "Drop" => Some("Drop"),
            "List" => Some("List"),
            "Label" => Some("Label"),
            "GBox" => Some("GBox"),
            "Scroll" => Some("Scroll"),
            "Spin" => Some("Spin"),
            "EditBox" => Some("Edit"),
            "Dialog" => Some("Dialog"),
            _ => None,
        };
        let vml = match_vml(
            &vml_shapes,
            &vml_index,
            shape,
            expected_vml_type,
            source_control.name.as_deref(),
        )?;
        let mirror_diagnostics = vml_mirror_diagnostics(&properties, vml, limits)?;
        let closure = ShapeClosure {
            shape_id: drawing,
            drawing_name: shape.name.clone().map(Into::into),
            compat_spid: shape.compat_spid.clone().into(),
            vml_id: vml.id.clone().into(),
            vml_spid: vml.spid.clone().map(Into::into),
            object_type: object_type.clone().into(),
            vml_object_type: vml.object_type.clone().into(),
            drawing_relationships_present: drawing_part.relationships.present(),
            vml_relationships_present: vml_part.relationships.present(),
            drawing_relationships: drawing_part.relationships,
            vml_relationships: vml_part.relationships,
        };
        if owner_parts
            .insert(target.as_str().to_owned(), position)
            .is_some()
        {
            return Err(owner_invalid(
                "form-control properties part is shared by multiple owners",
            ));
        }
        let mut diagnostics = Vec::new();
        diagnostics
            .try_reserve(4)
            .map_err(|source| owner_alloc("form-control diagnostics", source))?;
        if let Some(detail) = source_control.anchor_diagnostic.as_deref() {
            diagnostics.push(FormControlDiagnostic::new(
                FormControlDiagnosticCode::ControlPrAnchor,
                detail,
            ));
        }
        if object_type.is_empty()
            || properties
                .object_type()
                .is_some_and(|value| value.unknown().is_some())
        {
            diagnostics.push(FormControlDiagnostic::new(
                FormControlDiagnosticCode::OpaqueGraph,
                "form-control objectType is absent or unknown; the VML mirror remains opaque",
            ));
        }
        if expected_vml_type.is_none()
            || vml.object_type.is_empty()
            || expected_vml_type != Some(vml.object_type.as_str())
        {
            diagnostics.push(FormControlDiagnostic::new(
                FormControlDiagnosticCode::UnprovenMirror,
                "VML ClientData does not prove the typed form-control objectType mirror",
            ));
        }
        if properties.source_bytes().is_none() {
            diagnostics.push(FormControlDiagnostic::new(
                FormControlDiagnosticCode::OpaqueGraph,
                "properties source bytes were not retained",
            ));
        }
        for diagnostic in mirror_diagnostics {
            diagnostics
                .try_reserve(1)
                .map_err(|source| owner_alloc("form-control diagnostics", source))?;
            diagnostics.push(diagnostic);
        }
        controls.push(FormControlView {
            position,
            name: source_control.name.clone().map(Into::into),
            anchor_profile: source_control.anchor_profile.clone().map(Into::into),
            properties,
            properties_relationships_present: part.relationships.present(),
            properties_relationships: part.relationships,
            shape: closure,
            diagnostics: diagnostics.into_boxed_slice(),
        });
    }
    let diagnostics =
        collection_diagnostics(source_package, &incoming_targets, unreferenced_parts)?;
    let read_set = if source_package.is_some() {
        let mut sidecar_targets = Vec::new();
        sidecar_targets
            .try_reserve_exact(retained_sidecar_targets.len())
            .map_err(|source| owner_alloc("form-control sidecar target read set", source))?;
        for part in retained_sidecar_targets {
            sidecar_targets.push(part.into_public());
        }
        Some(FormControlReadSet {
            source_version: worksheet_part.source_version,
            worksheet: worksheet_part.into_public(),
            drawing: Some(drawing_part.into_public()),
            vml: Some(vml_part.into_public()),
            properties: retained_properties.into_boxed_slice(),
            sidecar_targets: sidecar_targets.into_boxed_slice(),
            worksheet_mce: selected.provenance,
            drawing_mce: drawing_selected.provenance,
        })
    } else {
        None
    };
    Ok(FormControlCollection {
        profile: OwnerProfile::canonical(),
        controls: controls.into_boxed_slice(),
        diagnostics: diagnostics.into_boxed_slice(),
        read_set: read_set.map(Box::new),
    })
}

fn empty_collection(
    source_package: Option<&SourceBackedPackage>,
    referenced: &HashSet<String>,
    worksheet_part: LoadedPart,
    worksheet_mce: MceProvenance,
    unreferenced_parts: &[String],
) -> OwnerResult<FormControlCollection> {
    let diagnostics = collection_diagnostics(source_package, referenced, unreferenced_parts)?;
    let read_set = source_package.is_some().then(|| FormControlReadSet {
        source_version: worksheet_part.source_version,
        worksheet: worksheet_part.into_public(),
        drawing: None,
        vml: None,
        properties: Box::new([]),
        sidecar_targets: Box::new([]),
        worksheet_mce,
        drawing_mce: empty_mce_provenance(),
    });
    Ok(FormControlCollection {
        profile: OwnerProfile::canonical(),
        controls: Box::new([]),
        diagnostics: diagnostics.into_boxed_slice(),
        read_set: read_set.map(Box::new),
    })
}

fn collection_diagnostics(
    source_package: Option<&SourceBackedPackage>,
    referenced: &HashSet<String>,
    eager_parts: &[String],
) -> OwnerResult<Vec<FormControlDiagnostic>> {
    let mut diagnostics = Vec::new();
    diagnostics
        .try_reserve(1)
        .map_err(|source| owner_alloc("form-control collection diagnostics", source))?;
    if let Some(package) = source_package {
        for part in package.iter_parts() {
            if part.content_type() == CONTROL_PROPERTIES_CONTENT_TYPE
                && !referenced.contains(part.partname().as_str())
            {
                diagnostics.push(FormControlDiagnostic::new(
                    FormControlDiagnosticCode::UnreferencedControlProperties,
                    "an unreferenced control-properties part was retained as opaque source",
                ));
            }
        }
    }
    for partname in eager_parts {
        if !referenced.contains(partname) {
            diagnostics.push(FormControlDiagnostic::new(
                FormControlDiagnosticCode::UnreferencedControlProperties,
                "an unreferenced control-properties part was retained as opaque source",
            ));
        }
    }
    Ok(diagnostics)
}

fn eager_unreferenced_properties(
    package: &OpcPackage,
    limits: &OwnerLimits,
) -> OwnerResult<Vec<String>> {
    let mut parts = Vec::new();
    for part in package.iter_parts() {
        if part.content_type() == CONTROL_PROPERTIES_CONTENT_TYPE {
            if parts.len() >= limits.max_mirror_nodes {
                return Err(owner_limit(
                    "unreferenced control-properties inventory",
                    parts.len() + 1,
                    limits.max_mirror_nodes,
                ));
            }
            parts.try_reserve(1).map_err(|source| {
                owner_alloc("unreferenced control-properties inventory", source)
            })?;
            parts.push(part.partname().as_str().to_owned());
        }
    }
    parts.sort_unstable();
    Ok(parts)
}

fn resolve_sheet_position(sheets: &[raw::Sheet], selector: Selector<'_>) -> OwnerResult<usize> {
    match selector {
        litchi_core::Selector::Position(position) => Ok(position.get()),
        litchi_core::Selector::Name(name) => sheets
            .iter()
            .position(|sheet| sheet.name.eq_ignore_ascii_case(name.as_ref()))
            .ok_or_else(|| owner_invalid("worksheet selector did not resolve")),
        litchi_core::Selector::Id(_) => {
            Err(owner_invalid("worksheet ID selectors are not admitted"))
        },
        _ => Err(owner_invalid("worksheet selector is unsupported")),
    }
}

fn validate_canonical_worksheet_root(xml: &[u8]) -> OwnerResult<()> {
    let mut reader = NsReader::from_reader(xml);
    reader.config_mut().trim_text(false);
    loop {
        let event = reader
            .read_event()
            .map_err(|error| owner_invalid(error.to_string()))?;
        match event {
            Event::Start(root) | Event::Empty(root) => {
                let (namespace, local) = reader.resolver().resolve_element(root.name());
                if !matches!(namespace, ResolveResult::Bound(Namespace(value)) if value == SML)
                    || local.as_ref() != b"worksheet"
                {
                    if matches!(namespace, ResolveResult::Bound(Namespace(value)) if value == STRICT_SML)
                    {
                        return Err(FormControlOwnerError::Invalid(
                            "strict worksheet form-control dialect is not admitted".into(),
                        ));
                    }
                    return Err(owner_invalid(
                        "worksheet root is not canonical SpreadsheetML",
                    ));
                }
                return Ok(());
            },
            Event::Text(text) if text.as_ref().iter().all(u8::is_ascii_whitespace) => {},
            Event::Decl(_) | Event::Comment(_) | Event::PI(_) => {},
            Event::Eof => return Err(owner_invalid("worksheet XML has no root element")),
            _ => return Err(owner_invalid("worksheet XML has no root element")),
        }
    }
}

fn select_mce(
    xml: &[u8],
    capability: &str,
    limits: &OwnerLimits,
    subject: &str,
) -> OwnerResult<MceSelection> {
    let mut capabilities = Capabilities::default();
    capabilities.understand_namespace(capability.to_owned());
    let mce_limits = MceLimits {
        max_input_bytes: limits.max_mce_bytes,
        max_output_bytes: limits.max_mce_bytes,
        max_depth: limits.max_mce_depth,
        max_choices_per_alternate: limits.max_mce_branches,
        ..MceLimits::default()
    };
    match process_markup_compatibility(xml, &capabilities, &mce_limits) {
        Ok(output) => Ok(mce_selection(
            xml,
            output.xml.into_owned(),
            output.report,
            capability,
            limits,
        )?),
        Err(first_error) => {
            // Some native producers rename the capability prefix on the
            // selected branch but leave an inherited `mc:Ignorable` value
            // using the old spelling.  The expanded namespace is still
            // unambiguous, so bind that stale spelling only for MCE
            // selection; the owner never publishes this normalized buffer.
            let Some(alias_input) = repair_renamed_capability_prefix(xml, capability) else {
                return Err(FormControlOwnerError::Invalid(format!(
                    "{subject} MCE selection failed: {first_error}"
                )));
            };
            process_markup_compatibility(&alias_input, &capabilities, &mce_limits)
                .map_err(|error| {
                    FormControlOwnerError::Invalid(format!(
                        "{subject} MCE selection failed: {error}"
                    ))
                })
                .and_then(|output| {
                    mce_selection(
                        xml,
                        output.xml.into_owned(),
                        output.report,
                        capability,
                        limits,
                    )
                })
        },
    }
}

struct MceSelection {
    xml: Vec<u8>,
    provenance: MceProvenance,
}

fn mce_selection(
    raw: &[u8],
    selected: Vec<u8>,
    report: litchi_ooxml_common::mce::Report,
    capability: &str,
    limits: &OwnerLimits,
) -> OwnerResult<MceSelection> {
    let ranges = mce_branch_ranges(raw, capability, limits)?;
    let ignored_len = ranges
        .ignored
        .iter()
        .try_fold(0usize, |total, range| {
            total
                .checked_add(range.end.checked_sub(range.start).ok_or(())?)
                .ok_or(())
        })
        .map_err(|()| owner_invalid("MCE ignored provenance byte count overflow"))?;
    let retained_len = raw
        .len()
        .checked_add(selected.len())
        .and_then(|length| length.checked_add(ignored_len))
        .ok_or_else(|| owner_invalid("MCE retained provenance byte count overflow"))?;
    if retained_len > limits.max_mce_bytes {
        return Err(owner_limit(
            "MCE retained provenance",
            retained_len,
            limits.max_mce_bytes,
        ));
    }
    let mut ignored = Vec::new();
    ignored
        .try_reserve_exact(ignored_len)
        .map_err(|source| owner_alloc("MCE ignored provenance", source))?;
    for range in &ranges.ignored {
        ignored.extend_from_slice(
            raw.get(range.clone())
                .ok_or_else(|| owner_invalid("MCE ignored provenance range is invalid"))?,
        );
    }
    let raw = bounded_owned(raw, limits.max_mce_bytes, "MCE raw provenance")?;
    let selected_bytes = bounded_owned(&selected, limits.max_mce_bytes, "MCE selected provenance")?;
    Ok(MceSelection {
        xml: selected,
        provenance: MceProvenance {
            raw: Arc::from(raw),
            selected: Arc::from(selected_bytes),
            ignored: Arc::from(ignored),
            selected_ranges: ranges.selected.into_boxed_slice(),
            ignored_ranges: ranges.ignored.into_boxed_slice(),
            wrapper_ranges: ranges.wrappers.into_boxed_slice(),
            selected_parent_ranges: ranges.selected_parents.into_boxed_slice(),
            ignored_parent_ranges: ranges.ignored_parents.into_boxed_slice(),
            selected_choices: report.selected_choices,
            selected_fallbacks: report.selected_fallbacks,
            ignored_elements: report.ignored_elements,
            ignored_attributes: report.ignored_attributes,
        },
    })
}

fn empty_mce_provenance() -> MceProvenance {
    MceProvenance {
        raw: Arc::from([]),
        selected: Arc::from([]),
        ignored: Arc::from([]),
        selected_ranges: Box::new([]),
        ignored_ranges: Box::new([]),
        wrapper_ranges: Box::new([]),
        selected_parent_ranges: Box::new([]),
        ignored_parent_ranges: Box::new([]),
        selected_choices: 0,
        selected_fallbacks: 0,
        ignored_elements: 0,
        ignored_attributes: 0,
    }
}

struct MceBranchRanges {
    selected: Vec<Range<usize>>,
    ignored: Vec<Range<usize>>,
    wrappers: Vec<Range<usize>>,
    selected_parents: Vec<Range<usize>>,
    ignored_parents: Vec<Range<usize>>,
}

#[derive(Clone, Copy)]
enum MceBranchKind {
    Choice,
    Fallback,
}

struct MceBranchRange {
    start: usize,
    end: usize,
    kind: MceBranchKind,
    supported: bool,
}

struct MceAlternateFrame {
    start: usize,
    branches: Vec<MceBranchRange>,
}

struct MceElementFrame {
    alternate: Option<usize>,
    branch: Option<(usize, usize)>,
}

fn mce_branch_ranges(
    xml: &[u8],
    capability: &str,
    limits: &OwnerLimits,
) -> OwnerResult<MceBranchRanges> {
    const MCE: &[u8] = b"http://schemas.openxmlformats.org/markup-compatibility/2006";
    let mut reader = NsReader::from_reader(xml);
    reader.config_mut().trim_text(false);
    reader.config_mut().check_end_names = true;
    let mut elements = Vec::<MceElementFrame>::new();
    let mut alternates = Vec::<Option<MceAlternateFrame>>::new();
    let mut selected = Vec::new();
    let mut ignored = Vec::new();
    let mut wrappers = Vec::new();
    let mut selected_parents = Vec::new();
    let mut ignored_parents = Vec::new();
    let mut events = 0usize;
    loop {
        events = events
            .checked_add(1)
            .ok_or_else(|| owner_invalid("MCE provenance event count overflow"))?;
        if events > limits.max_mce_events {
            return Err(owner_limit(
                "MCE provenance events",
                events,
                limits.max_mce_events,
            ));
        }
        let start = usize::try_from(reader.buffer_position())
            .map_err(|error| owner_invalid(format!("MCE source position overflow: {error}")))?;
        let event = reader
            .read_event()
            .map_err(|error| owner_invalid(error.to_string()))?;
        let end = usize::try_from(reader.buffer_position())
            .map_err(|error| owner_invalid(format!("MCE source position overflow: {error}")))?;
        let resolver = reader.resolver().clone();
        match event {
            Event::Start(element) => {
                let (namespace, local) = resolver.resolve_element(element.name());
                let namespace = namespace_bytes(namespace);
                let local = local.as_ref().to_vec();
                let alternate =
                    if namespace.as_slice() == MCE && local.as_slice() == b"AlternateContent" {
                        if alternates.len() >= limits.max_mce_branches {
                            return Err(owner_limit(
                                "MCE provenance wrappers",
                                alternates.len() + 1,
                                limits.max_mce_branches,
                            ));
                        }
                        alternates
                            .try_reserve(1)
                            .map_err(|source| owner_alloc("MCE provenance branches", source))?;
                        alternates.push(Some(MceAlternateFrame {
                            start,
                            branches: Vec::new(),
                        }));
                        Some(alternates.len() - 1)
                    } else {
                        None
                    };
                let parent_alternate = elements.last().and_then(|frame| frame.alternate);
                let branch = if let Some(parent_alternate) = parent_alternate {
                    if namespace.as_slice() == MCE
                        && matches!(local.as_slice(), b"Choice" | b"Fallback")
                    {
                        let kind = if local.as_slice() == b"Choice" {
                            MceBranchKind::Choice
                        } else {
                            MceBranchKind::Fallback
                        };
                        let supported = match kind {
                            MceBranchKind::Fallback => true,
                            MceBranchKind::Choice => mce_choice_supported(
                                &element,
                                &resolver,
                                reader.decoder(),
                                capability,
                                mce_baseline_namespaces(capability),
                            )?,
                        };
                        let parent = alternates
                            .get_mut(parent_alternate)
                            .and_then(Option::as_mut)
                            .ok_or_else(|| {
                                owner_invalid("MCE provenance alternate state is invalid")
                            })?;
                        if parent.branches.len() >= limits.max_mce_branches {
                            return Err(owner_limit(
                                "MCE provenance branches",
                                parent.branches.len() + 1,
                                limits.max_mce_branches,
                            ));
                        }
                        parent
                            .branches
                            .try_reserve(1)
                            .map_err(|source| owner_alloc("MCE provenance branches", source))?;
                        parent.branches.push(MceBranchRange {
                            start,
                            end,
                            kind,
                            supported,
                        });
                        Some((parent_alternate, parent.branches.len() - 1))
                    } else {
                        None
                    }
                } else {
                    None
                };
                if elements.len() >= limits.max_mce_depth {
                    return Err(owner_limit(
                        "MCE provenance depth",
                        elements.len() + 1,
                        limits.max_mce_depth,
                    ));
                }
                elements.push(MceElementFrame { alternate, branch });
            },
            Event::Empty(element) => {
                let (namespace, local) = resolver.resolve_element(element.name());
                let namespace = namespace_bytes(namespace);
                let local = local.as_ref().to_vec();
                if namespace.as_slice() == MCE && local.as_slice() == b"AlternateContent" {
                    return Err(owner_invalid("MCE AlternateContent cannot be empty"));
                }
                if let Some(parent) = elements.last().and_then(|frame| {
                    frame
                        .alternate
                        .and_then(|index| alternates.get_mut(index))
                        .and_then(Option::as_mut)
                }) {
                    if namespace.as_slice() == MCE
                        && matches!(local.as_slice(), b"Choice" | b"Fallback")
                    {
                        let kind = if local.as_slice() == b"Choice" {
                            MceBranchKind::Choice
                        } else {
                            MceBranchKind::Fallback
                        };
                        let supported = match kind {
                            MceBranchKind::Fallback => true,
                            MceBranchKind::Choice => mce_choice_supported(
                                &element,
                                &resolver,
                                reader.decoder(),
                                capability,
                                mce_baseline_namespaces(capability),
                            )?,
                        };
                        if parent.branches.len() >= limits.max_mce_branches {
                            return Err(owner_limit(
                                "MCE provenance branches",
                                parent.branches.len() + 1,
                                limits.max_mce_branches,
                            ));
                        }
                        parent
                            .branches
                            .try_reserve(1)
                            .map_err(|source| owner_alloc("MCE provenance branches", source))?;
                        parent.branches.push(MceBranchRange {
                            start,
                            end,
                            kind,
                            supported,
                        });
                    }
                }
            },
            Event::End(_) => {
                let frame = elements
                    .pop()
                    .ok_or_else(|| owner_invalid("MCE provenance closing tag is unmatched"))?;
                if let Some((alternate, branch)) = frame.branch {
                    if let Some(Some(state)) = alternates.get_mut(alternate) {
                        let item = state.branches.get_mut(branch).ok_or_else(|| {
                            owner_invalid("MCE provenance branch index is invalid")
                        })?;
                        item.end = end;
                    }
                }
                if let Some(alternate) = frame.alternate {
                    let Some(Some(state)) = alternates.get_mut(alternate) else {
                        return Err(owner_invalid("MCE provenance alternate state is invalid"));
                    };
                    let selected_index = state
                        .branches
                        .iter()
                        .position(|branch| {
                            matches!(branch.kind, MceBranchKind::Choice) && branch.supported
                        })
                        .or_else(|| {
                            state
                                .branches
                                .iter()
                                .position(|branch| matches!(branch.kind, MceBranchKind::Fallback))
                        });
                    let selected_index = selected_index.ok_or_else(|| {
                        owner_invalid("MCE provenance has no selected Choice or Fallback")
                    })?;
                    let wrapper_range = state.start..end;
                    wrappers
                        .try_reserve(1)
                        .map_err(|source| owner_alloc("MCE wrapper ranges", source))?;
                    wrappers.push(wrapper_range.clone());
                    if state.branches[selected_index].supported
                        || matches!(state.branches[selected_index].kind, MceBranchKind::Fallback)
                    {
                        selected_parents
                            .try_reserve(1)
                            .map_err(|source| owner_alloc("MCE selected parent ranges", source))?;
                        selected_parents.push(wrapper_range.clone());
                    }
                    let mut has_ignored_branch = false;
                    for (index, branch) in state.branches.iter().enumerate() {
                        let range = branch.start..branch.end;
                        if index == selected_index {
                            selected
                                .try_reserve(1)
                                .map_err(|source| owner_alloc("MCE selected ranges", source))?;
                            selected.push(range);
                        } else {
                            has_ignored_branch = true;
                            ignored
                                .try_reserve(1)
                                .map_err(|source| owner_alloc("MCE ignored ranges", source))?;
                            ignored.push(range);
                        }
                    }
                    if has_ignored_branch {
                        ignored_parents
                            .try_reserve(1)
                            .map_err(|source| owner_alloc("MCE ignored parent ranges", source))?;
                        ignored_parents.push(wrapper_range);
                    }
                    alternates[alternate] = None;
                }
            },
            Event::Eof => break,
            _ => {},
        }
    }
    if !elements.is_empty() {
        return Err(owner_invalid("MCE provenance XML is unterminated"));
    }
    coalesce_nested_ranges(&mut selected);
    coalesce_nested_ranges(&mut ignored);
    Ok(MceBranchRanges {
        selected,
        ignored,
        wrappers,
        selected_parents,
        ignored_parents,
    })
}

fn mce_choice_supported(
    element: &BytesStart<'_>,
    resolver: &quick_xml::name::NamespaceResolver,
    decoder: quick_xml::encoding::Decoder,
    capability: &str,
    baseline: &[&[u8]],
) -> OwnerResult<bool> {
    let mut requires = None;
    for attribute in element.attributes().with_checks(false) {
        let attribute = attribute.map_err(|error| owner_invalid(error.to_string()))?;
        if attribute.key.as_ref() == b"Requires" {
            requires = Some(decode_attribute(attribute.value.as_ref(), decoder)?);
            break;
        }
    }
    let requires = requires.ok_or_else(|| owner_invalid("MCE Choice requires Requires"))?;
    let mut tokens = requires.split_whitespace();
    let mut supported = true;
    let mut count = 0usize;
    for prefix in tokens.by_ref() {
        count = count
            .checked_add(1)
            .ok_or_else(|| owner_invalid("MCE Requires token count overflow"))?;
        let qualified = format!("{prefix}:x");
        let (namespace, _) = resolver.resolve_element(quick_xml::name::QName(qualified.as_bytes()));
        let namespace = match namespace {
            ResolveResult::Bound(Namespace(value)) => value,
            _ => return Err(owner_invalid("MCE Choice Requires prefix is unbound")),
        };
        supported &= namespace == capability.as_bytes() || baseline.contains(&namespace);
    }
    if count == 0 {
        return Err(owner_invalid("MCE Choice Requires is empty"));
    }
    Ok(supported)
}

fn mce_baseline_namespaces(capability: &str) -> &'static [&'static [u8]] {
    const MCE: &[u8] = b"http://schemas.openxmlformats.org/markup-compatibility/2006";
    const DRAWING: &[u8] = b"http://schemas.openxmlformats.org/drawingml/2006/main";
    const STRICT_DRAWING: &[u8] = b"http://purl.oclc.org/ooxml/drawingml/main";
    const MATH: &[u8] = b"http://schemas.openxmlformats.org/officeDocument/2006/math";
    const STRICT_MATH: &[u8] = b"http://purl.oclc.org/ooxml/officeDocument/math";
    const VML_NS: &[u8] = b"urn:schemas-microsoft-com:vml";
    const OFFICE_NS: &[u8] = b"urn:schemas-microsoft-com:office:office";
    const XML_NS: &[u8] = b"http://www.w3.org/XML/1998/namespace";
    const SML_BASELINE: &[&[u8]] = &[
        SML,
        STRICT_SML,
        REL,
        STRICT_REL,
        XDR,
        STRICT_XDR,
        DRAWING,
        STRICT_DRAWING,
        MATH,
        STRICT_MATH,
        VML_NS,
        OFFICE_NS,
        XML_NS,
        MCE,
    ];
    let _ = capability;
    SML_BASELINE
}

fn coalesce_nested_ranges(ranges: &mut Vec<Range<usize>>) {
    ranges.sort_unstable_by_key(|range| (range.start, std::cmp::Reverse(range.end)));
    let mut write = 0usize;
    for read in 0..ranges.len() {
        if write != 0 && ranges[write - 1].end >= ranges[read].end {
            continue;
        }
        if write != read {
            ranges.swap(write, read);
        }
        write += 1;
    }
    ranges.truncate(write);
}

fn validate_canonical_drawing_root(xml: &[u8]) -> OwnerResult<()> {
    let mut reader = NsReader::from_reader(xml);
    reader.config_mut().trim_text(false);
    loop {
        let event = reader
            .read_event()
            .map_err(|error| owner_invalid(error.to_string()))?;
        match event {
            Event::Start(root) | Event::Empty(root) => {
                let (namespace, local) = reader.resolver().resolve_element(root.name());
                if matches!(namespace, ResolveResult::Bound(Namespace(value)) if value == STRICT_XDR)
                {
                    return Err(FormControlOwnerError::Invalid(
                        "strict DrawingML form-control dialect is not admitted".into(),
                    ));
                }
                if !is_ns(&namespace, XDR) || local.as_ref() != b"wsDr" {
                    return Err(owner_invalid(
                        "drawing root is not canonical SpreadsheetDrawing",
                    ));
                }
                return Ok(());
            },
            Event::Decl(_) | Event::Comment(_) | Event::PI(_) => {},
            Event::Text(text) if text.as_ref().iter().all(u8::is_ascii_whitespace) => {},
            Event::Eof => return Err(owner_invalid("drawing XML has no root element")),
            _ => return Err(owner_invalid("drawing XML has no root element")),
        }
    }
}

fn reject_mixed_dialect(
    xml: &[u8],
    subject: &'static str,
    strict_namespaces: &[&[u8]],
) -> OwnerResult<()> {
    let mut reader = NsReader::from_reader(xml);
    reader.config_mut().trim_text(false);
    loop {
        let event = reader
            .read_event()
            .map_err(|error| owner_invalid(error.to_string()))?;
        let resolver = reader.resolver().clone();
        match event {
            Event::Start(element) | Event::Empty(element) => {
                let (namespace, _) = resolver.resolve_element(element.name());
                let mut strict_attribute = false;
                for attribute in element.attributes().with_checks(false) {
                    let attribute = attribute.map_err(|error| owner_invalid(error.to_string()))?;
                    let (namespace, _) = resolver.resolve_attribute(attribute.key);
                    if is_ns(&namespace, STRICT_REL) {
                        strict_attribute = true;
                        break;
                    }
                }
                if strict_namespaces
                    .iter()
                    .any(|wanted| is_ns(&namespace, wanted))
                    || strict_attribute
                {
                    return Err(FormControlOwnerError::Invalid(format!(
                        "{subject} contains a strict/mixed dialect branch"
                    )));
                }
            },
            Event::Eof => return Ok(()),
            _ => {},
        }
    }
}

fn validate_drawing_anchors(xml: &[u8], limits: &OwnerLimits) -> OwnerResult<()> {
    let mut reader = NsReader::from_reader(xml);
    reader.config_mut().trim_text(false);
    reader.config_mut().check_end_names = true;
    let mut stack: Vec<(Vec<u8>, Vec<u8>)> = Vec::new();
    let mut anchors = Vec::<(Vec<u8>, usize, usize, usize, usize)>::new();
    let mut events = 0usize;
    loop {
        events = events
            .checked_add(1)
            .ok_or_else(|| owner_invalid("drawing anchor event count overflow"))?;
        if events > limits.max_mce_events {
            return Err(owner_limit(
                "drawing anchor events",
                events,
                limits.max_mce_events,
            ));
        }
        let event = reader
            .read_event()
            .map_err(|error| owner_invalid(error.to_string()))?;
        let resolver = reader.resolver().clone();
        match event {
            Event::Start(element) => {
                let (namespace, local) = resolver.resolve_element(element.name());
                let namespace = namespace_bytes(namespace);
                let local = local.as_ref().to_vec();
                if namespace.as_slice() == XDR
                    && matches!(
                        local.as_slice(),
                        b"twoCellAnchor" | b"oneCellAnchor" | b"absoluteAnchor"
                    )
                {
                    if anchors.len() >= limits.max_shapes {
                        return Err(owner_limit(
                            "DrawingML anchor identities",
                            anchors.len() + 1,
                            limits.max_shapes,
                        ));
                    }
                    anchors.push((local.clone(), 0, 0, 0, 0));
                } else if namespace.as_slice() == XDR {
                    if let Some(anchor) = anchors.last_mut() {
                        match local.as_slice() {
                            b"from"
                                if stack.last().is_some_and(|(ns, parent)| {
                                    ns.as_slice() == XDR && parent.as_slice() == anchor.0.as_slice()
                                }) =>
                            {
                                anchor.1 = anchor.1.saturating_add(1)
                            },
                            b"to"
                                if stack.last().is_some_and(|(ns, parent)| {
                                    ns.as_slice() == XDR && parent.as_slice() == anchor.0.as_slice()
                                }) =>
                            {
                                anchor.2 = anchor.2.saturating_add(1)
                            },
                            b"ext"
                                if stack.last().is_some_and(|(ns, parent)| {
                                    ns.as_slice() == XDR && parent.as_slice() == anchor.0.as_slice()
                                }) =>
                            {
                                anchor.3 = anchor.3.saturating_add(1)
                            },
                            b"clientData"
                                if stack.last().is_some_and(|(ns, parent)| {
                                    ns.as_slice() == XDR && parent.as_slice() == anchor.0.as_slice()
                                }) =>
                            {
                                anchor.4 = anchor.4.saturating_add(1)
                            },
                            _ => {},
                        }
                    }
                }
                if stack.len() >= limits.max_mce_depth {
                    return Err(owner_limit(
                        "drawing anchor depth",
                        stack.len() + 1,
                        limits.max_mce_depth,
                    ));
                }
                stack.push((namespace, local));
            },
            Event::Empty(element) => {
                let (namespace, local) = resolver.resolve_element(element.name());
                if is_ns(&namespace, XDR) {
                    if let Some(anchor) = anchors.last_mut() {
                        match local.as_ref() {
                            b"from"
                                if stack.last().is_some_and(|(ns, parent)| {
                                    ns.as_slice() == XDR && parent.as_slice() == anchor.0.as_slice()
                                }) =>
                            {
                                anchor.1 = anchor.1.saturating_add(1)
                            },
                            b"to"
                                if stack.last().is_some_and(|(ns, parent)| {
                                    ns.as_slice() == XDR && parent.as_slice() == anchor.0.as_slice()
                                }) =>
                            {
                                anchor.2 = anchor.2.saturating_add(1)
                            },
                            b"ext"
                                if stack.last().is_some_and(|(ns, parent)| {
                                    ns.as_slice() == XDR && parent.as_slice() == anchor.0.as_slice()
                                }) =>
                            {
                                anchor.3 = anchor.3.saturating_add(1)
                            },
                            b"clientData"
                                if stack.last().is_some_and(|(ns, parent)| {
                                    ns.as_slice() == XDR && parent.as_slice() == anchor.0.as_slice()
                                }) =>
                            {
                                anchor.4 = anchor.4.saturating_add(1)
                            },
                            _ => {},
                        }
                    }
                    if matches!(
                        local.as_ref(),
                        b"twoCellAnchor" | b"oneCellAnchor" | b"absoluteAnchor"
                    ) {
                        return Err(owner_invalid("DrawingML anchor is empty"));
                    }
                }
            },
            Event::End(_) => {
                let closed = stack
                    .pop()
                    .ok_or_else(|| owner_invalid("DrawingML closing tag is unmatched"))?;
                if closed.0.as_slice() == XDR && {
                    let local = closed.1.as_slice();
                    matches!(
                        local,
                        b"twoCellAnchor" | b"oneCellAnchor" | b"absoluteAnchor"
                    )
                } {
                    let (kind, from, to, ext, client_data) = anchors
                        .pop()
                        .ok_or_else(|| owner_invalid("DrawingML anchor state is inconsistent"))?;
                    let valid = match kind.as_slice() {
                        b"twoCellAnchor" => from == 1 && to == 1 && client_data == 1,
                        b"oneCellAnchor" => from == 1 && ext == 1 && client_data == 1,
                        b"absoluteAnchor" => ext == 1 && client_data == 1,
                        _ => false,
                    };
                    if !valid {
                        return Err(owner_invalid(
                            "DrawingML anchor closure is incomplete or ambiguous",
                        ));
                    }
                }
            },
            Event::Eof => break,
            Event::Decl(_)
            | Event::Comment(_)
            | Event::Text(_)
            | Event::CData(_)
            | Event::PI(_)
            | Event::DocType(_)
            | Event::GeneralRef(_) => {},
        }
    }
    if !stack.is_empty() {
        return Err(owner_invalid("DrawingML XML is unterminated"));
    }
    if !anchors.is_empty() {
        return Err(owner_invalid("DrawingML anchor is unterminated"));
    }
    Ok(())
}

fn repair_renamed_capability_prefix(xml: &[u8], capability: &str) -> Option<Vec<u8>> {
    let source = std::str::from_utf8(xml).ok()?;
    if !source.contains("mc:Ignorable=\"a14\"") {
        return None;
    }
    let declaration = format!("=\"{capability}\"");
    let mut alias = None;
    let mut search = 0;
    while let Some(offset) = source[search..].find("xmlns:") {
        let start = search + offset + "xmlns:".len();
        let equals = source[start..].find('=')? + start;
        let prefix = &source[start..equals];
        if !prefix.is_empty() && source[equals..].starts_with(&declaration) {
            alias = Some(prefix);
            break;
        }
        search = equals.saturating_add(1);
    }
    let alias = alias?;
    if alias == "a14" {
        return None;
    }
    let replacement = format!("mc:Ignorable=\"{alias}\"");
    Some(
        source
            .replace("mc:Ignorable=\"a14\"", &replacement)
            .into_bytes(),
    )
}

#[derive(Clone, Debug)]
struct SourceControl {
    shape_id: u64,
    relationship_id: String,
    name: Option<String>,
    anchor_profile: Option<String>,
    anchor_diagnostic: Option<String>,
}

struct WorksheetScan {
    controls: Vec<SourceControl>,
    drawing_relationship_id: Option<String>,
    vml_relationship_id: Option<String>,
}

fn parse_worksheet(xml: &[u8], limits: &OwnerLimits) -> OwnerResult<WorksheetScan> {
    let mut reader = NsReader::from_reader(xml);
    reader.config_mut().trim_text(false);
    reader.config_mut().check_end_names = true;
    let mut stack: Vec<(Vec<u8>, Vec<u8>)> = Vec::new();
    let mut controls = Vec::new();
    controls
        .try_reserve(8.min(limits.max_controls))
        .map_err(|source| owner_alloc("worksheet controls", source))?;
    let mut drawing = None;
    let mut vml = None;
    let mut current_control: Option<(SourceControl, bool, usize, usize)> = None;
    let mut events = 0usize;
    loop {
        events = events
            .checked_add(1)
            .ok_or_else(|| owner_invalid("worksheet event count overflow"))?;
        if events > limits.max_mce_events {
            return Err(owner_limit(
                "worksheet XML events",
                events,
                limits.max_mce_events,
            ));
        }
        let event = reader
            .read_event()
            .map_err(|error| owner_invalid(error.to_string()))?;
        let resolver = reader.resolver().clone();
        match event {
            Event::Start(element) => {
                let (namespace, local) = resolver.resolve_element(element.name());
                if is_ns(&namespace, SML) {
                    if local.as_ref() == b"control" {
                        if current_control.is_some() {
                            return Err(owner_invalid("worksheet controls are nested"));
                        }
                        current_control = Some((
                            parse_control(&element, &resolver, reader.decoder(), limits)?,
                            false,
                            0,
                            0,
                        ));
                    }
                    if local.as_ref() == b"anchor"
                        && stack.last().is_some_and(|(ns, parent)| {
                            ns.as_slice() == SML && parent.as_slice() == b"controlPr"
                        })
                    {
                        if let Some((_, anchor, _, _)) = current_control.as_mut() {
                            *anchor = true;
                        }
                    }
                    if local.as_ref() == b"from"
                        && stack.last().is_some_and(|(ns, parent)| {
                            ns.as_slice() == SML && parent.as_slice() == b"anchor"
                        })
                    {
                        if let Some((_, _, from, _)) = current_control.as_mut() {
                            *from = from.saturating_add(1);
                        }
                    }
                    if local.as_ref() == b"to"
                        && stack.last().is_some_and(|(ns, parent)| {
                            ns.as_slice() == SML && parent.as_slice() == b"anchor"
                        })
                    {
                        if let Some((_, _, _, to)) = current_control.as_mut() {
                            *to = to.saturating_add(1);
                        }
                    }
                    if local.as_ref() == b"drawing" {
                        if drawing.is_some() {
                            return Err(owner_invalid(
                                "worksheet has duplicate drawing references",
                            ));
                        }
                        drawing = attr_rel_id(&element, &resolver, reader.decoder(), limits)?;
                    }
                    if local.as_ref() == b"legacyDrawing" {
                        if vml.is_some() {
                            return Err(owner_invalid(
                                "worksheet has duplicate legacyDrawing references",
                            ));
                        }
                        vml = attr_rel_id(&element, &resolver, reader.decoder(), limits)?;
                    }
                }
                if stack.len() >= limits.max_mce_depth {
                    return Err(owner_limit(
                        "worksheet XML depth",
                        stack.len() + 1,
                        limits.max_mce_depth,
                    ));
                }
                stack.push((namespace_bytes(namespace), local.as_ref().to_vec()));
            },
            Event::Empty(element) => {
                let (namespace, local) = resolver.resolve_element(element.name());
                if is_ns(&namespace, SML) {
                    if local.as_ref() == b"control" {
                        let mut control =
                            parse_control(&element, &resolver, reader.decoder(), limits)?;
                        control.anchor_diagnostic =
                            Some("worksheet control has no LoSmlAnchorV1 controlPr anchor".into());
                        if controls.len() >= limits.max_controls {
                            return Err(owner_limit(
                                "effective controls",
                                controls.len() + 1,
                                limits.max_controls,
                            ));
                        }
                        controls
                            .try_reserve(1)
                            .map_err(|source| owner_alloc("worksheet controls", source))?;
                        controls.push(control);
                    }
                    if local.as_ref() == b"from"
                        && stack.last().is_some_and(|(ns, parent)| {
                            ns.as_slice() == SML && parent.as_slice() == b"anchor"
                        })
                    {
                        if let Some((_, _, from, _)) = current_control.as_mut() {
                            *from = from.saturating_add(1);
                        }
                    }
                    if local.as_ref() == b"to"
                        && stack.last().is_some_and(|(ns, parent)| {
                            ns.as_slice() == SML && parent.as_slice() == b"anchor"
                        })
                    {
                        if let Some((_, _, _, to)) = current_control.as_mut() {
                            *to = to.saturating_add(1);
                        }
                    }
                    if local.as_ref() == b"drawing" {
                        if drawing.is_some() {
                            return Err(owner_invalid(
                                "worksheet has duplicate drawing references",
                            ));
                        }
                        drawing = attr_rel_id(&element, &resolver, reader.decoder(), limits)?;
                    }
                    if local.as_ref() == b"legacyDrawing" {
                        if vml.is_some() {
                            return Err(owner_invalid(
                                "worksheet has duplicate legacyDrawing references",
                            ));
                        }
                        vml = attr_rel_id(&element, &resolver, reader.decoder(), limits)?;
                    }
                }
            },
            Event::End(_) => {
                let closed = stack.pop();
                if closed
                    .as_ref()
                    .is_some_and(|(_, local)| local.as_slice() == b"control")
                {
                    let (mut control, anchor, from, to) = current_control
                        .take()
                        .ok_or_else(|| owner_invalid("worksheet control state is inconsistent"))?;
                    if anchor && from == 1 && to == 1 {
                        control.anchor_profile = Some("LoSmlAnchorV1".into());
                    } else {
                        control.anchor_diagnostic = Some(
                            "worksheet controlPr anchor is incomplete or ambiguous for LoSmlAnchorV1".into(),
                        );
                    }
                    if controls.len() >= limits.max_controls {
                        return Err(owner_limit(
                            "effective controls",
                            controls.len() + 1,
                            limits.max_controls,
                        ));
                    }
                    controls
                        .try_reserve(1)
                        .map_err(|source| owner_alloc("worksheet controls", source))?;
                    controls.push(control);
                }
            },
            Event::Eof => break,
            Event::Decl(_)
            | Event::Comment(_)
            | Event::Text(_)
            | Event::CData(_)
            | Event::PI(_)
            | Event::DocType(_)
            | Event::GeneralRef(_) => {},
        }
    }
    if current_control.is_some() {
        return Err(owner_invalid("worksheet control is unterminated"));
    }
    if controls.len() > limits.max_controls {
        return Err(owner_limit(
            "effective controls",
            controls.len(),
            limits.max_controls,
        ));
    }
    let anchor_diagnostics = validate_losml_anchor_values(xml, limits)?;
    if anchor_diagnostics.len() != controls.len() {
        return Err(owner_invalid(
            "worksheet LoSmlAnchorV1 control inventory is inconsistent",
        ));
    }
    for (control, diagnostic) in controls.iter_mut().zip(anchor_diagnostics) {
        if let Some(diagnostic) = diagnostic {
            control.anchor_profile = None;
            control.anchor_diagnostic = Some(diagnostic);
        }
    }
    Ok(WorksheetScan {
        controls,
        drawing_relationship_id: drawing,
        vml_relationship_id: vml,
    })
}

const MAX_ANCHOR_COLUMN: u64 = 16_383;
const MAX_ANCHOR_ROW: u64 = 1_048_575;
const MAX_ANCHOR_OFFSET: u64 = 2_147_483_647;

#[derive(Default)]
struct AnchorEndpoint {
    kind: Vec<u8>,
    fields: [Option<String>; 4],
    active_field: Option<(usize, Vec<u8>)>,
}

#[derive(Default)]
struct AnchorValidation {
    seen: bool,
    from: Option<AnchorEndpoint>,
    to: Option<AnchorEndpoint>,
    endpoint: Option<AnchorEndpoint>,
    diagnostic: Option<String>,
}

fn validate_losml_anchor_values(
    xml: &[u8],
    limits: &OwnerLimits,
) -> OwnerResult<Vec<Option<String>>> {
    let mut reader = NsReader::from_reader(xml);
    reader.config_mut().trim_text(false);
    reader.config_mut().check_end_names = true;
    let mut stack: Vec<(Vec<u8>, Vec<u8>)> = Vec::new();
    let mut validations: Vec<Option<String>> = Vec::new();
    let mut current: Option<AnchorValidation> = None;
    let mut events = 0usize;
    loop {
        events = events
            .checked_add(1)
            .ok_or_else(|| owner_invalid("worksheet anchor event count overflow"))?;
        if events > limits.max_mce_events {
            return Err(owner_limit(
                "worksheet anchor events",
                events,
                limits.max_mce_events,
            ));
        }
        let event = reader
            .read_event()
            .map_err(|error| owner_invalid(error.to_string()))?;
        let resolver = reader.resolver().clone();
        match event {
            Event::Start(element) => {
                let (namespace, local) = resolver.resolve_element(element.name());
                let namespace = namespace_bytes(namespace);
                let local = local.as_ref().to_vec();
                if namespace.as_slice() == SML && local.as_slice() == b"control" {
                    if current.is_some() {
                        return Err(owner_invalid("worksheet controls are nested"));
                    }
                    current = Some(AnchorValidation::default());
                } else if let Some(state) = current.as_mut() {
                    if namespace.as_slice() == SML
                        && local.as_slice() == b"anchor"
                        && stack.last().is_some_and(|(parent_ns, parent)| {
                            parent_ns.as_slice() == SML && parent.as_slice() == b"controlPr"
                        })
                    {
                        if state.seen {
                            state.diagnostic = Some(
                                "worksheet controlPr contains duplicate LoSmlAnchorV1 anchors"
                                    .into(),
                            );
                        }
                        state.seen = true;
                    } else if namespace.as_slice() == SML
                        && matches!(local.as_slice(), b"from" | b"to")
                        && stack.last().is_some_and(|(parent_ns, parent)| {
                            parent_ns.as_slice() == SML && parent.as_slice() == b"anchor"
                        })
                    {
                        if state.endpoint.is_some() {
                            state.diagnostic =
                                Some("worksheet LoSmlAnchorV1 has nested anchor endpoints".into());
                        } else {
                            state.endpoint = Some(AnchorEndpoint {
                                kind: local.clone(),
                                ..AnchorEndpoint::default()
                            });
                        }
                    } else if namespace.as_slice() == XDR
                        && anchor_field_index(local.as_slice()).is_some()
                        && state.endpoint.as_ref().is_some_and(|endpoint| {
                            stack.last().is_some_and(|(parent_ns, parent)| {
                                parent_ns.as_slice() == SML
                                    && parent.as_slice() == endpoint.kind.as_slice()
                            })
                        })
                    {
                        let index = anchor_field_index(local.as_slice()).expect("checked above");
                        if let Some(endpoint) = state.endpoint.as_mut() {
                            if endpoint.fields[index].is_some() || endpoint.active_field.is_some() {
                                state.diagnostic = Some(format!(
                                    "worksheet LoSmlAnchorV1 endpoint field {} is duplicated",
                                    String::from_utf8_lossy(&local)
                                ));
                            } else {
                                endpoint.active_field = Some((index, local.clone()));
                            }
                        }
                    }
                }
                if stack.len() >= limits.max_mce_depth {
                    return Err(owner_limit(
                        "worksheet anchor depth",
                        stack.len() + 1,
                        limits.max_mce_depth,
                    ));
                }
                stack.push((namespace, local));
            },
            Event::Empty(element) => {
                let (namespace, local) = resolver.resolve_element(element.name());
                let namespace = namespace_bytes(namespace);
                let local = local.as_ref().to_vec();
                if namespace.as_slice() == SML && local.as_slice() == b"control" {
                    if current.is_some() {
                        return Err(owner_invalid("worksheet controls are nested"));
                    }
                    validations.push(None);
                } else if let Some(state) = current.as_mut() {
                    if namespace.as_slice() == XDR && anchor_field_index(local.as_slice()).is_some()
                    {
                        state.diagnostic = Some(format!(
                            "worksheet LoSmlAnchorV1 field {} has no numeric lexical value",
                            String::from_utf8_lossy(&local)
                        ));
                    }
                }
            },
            Event::Text(text) => append_anchor_text(
                current.as_mut(),
                text.as_ref(),
                reader.decoder(),
                limits.max_name_bytes,
            )?,
            Event::CData(text) => append_anchor_text(
                current.as_mut(),
                text.as_ref(),
                reader.decoder(),
                limits.max_name_bytes,
            )?,
            Event::End(_) => {
                let closed = stack
                    .pop()
                    .ok_or_else(|| owner_invalid("worksheet anchor closing tag is unmatched"))?;
                if let Some(state) = current.as_mut() {
                    if closed.0.as_slice() == XDR
                        && anchor_field_index(closed.1.as_slice()).is_some()
                    {
                        if let Some(endpoint) = state.endpoint.as_mut() {
                            if let Some((index, _)) = endpoint.active_field.take() {
                                if endpoint.fields[index].is_none() {
                                    state.diagnostic = Some(
                                        "worksheet LoSmlAnchorV1 numeric field is empty".into(),
                                    );
                                }
                            }
                        }
                    } else if closed.0.as_slice() == SML
                        && matches!(closed.1.as_slice(), b"from" | b"to")
                    {
                        if let Some(endpoint) = state.endpoint.take() {
                            if endpoint.fields.iter().any(Option::is_none) {
                                state.diagnostic = Some(format!(
                                    "worksheet LoSmlAnchorV1 {} endpoint is incomplete",
                                    String::from_utf8_lossy(&endpoint.kind)
                                ));
                            } else {
                                for (index, value) in endpoint.fields.iter().enumerate() {
                                    let value = value.as_deref().unwrap_or_default();
                                    let maximum = match index {
                                        0 => MAX_ANCHOR_COLUMN,
                                        1 => MAX_ANCHOR_OFFSET,
                                        2 => MAX_ANCHOR_ROW,
                                        _ => MAX_ANCHOR_OFFSET,
                                    };
                                    if !valid_anchor_integer(value, maximum) {
                                        state.diagnostic = Some(format!(
                                            "worksheet LoSmlAnchorV1 {} field {} is outside its decimal range",
                                            String::from_utf8_lossy(&endpoint.kind),
                                            anchor_field_name(index)
                                        ));
                                    }
                                }
                            }
                            if endpoint.kind.as_slice() == b"from" {
                                if state.from.is_some() {
                                    state.diagnostic = Some(
                                        "worksheet LoSmlAnchorV1 has duplicate from endpoints"
                                            .into(),
                                    );
                                }
                                state.from = Some(endpoint);
                            } else {
                                if state.to.is_some() {
                                    state.diagnostic = Some(
                                        "worksheet LoSmlAnchorV1 has duplicate to endpoints".into(),
                                    );
                                }
                                state.to = Some(endpoint);
                            }
                        }
                    } else if closed.0.as_slice() == SML && closed.1.as_slice() == b"anchor" {
                        if state.from.is_none() || state.to.is_none() {
                            state.diagnostic = Some(
                                "worksheet LoSmlAnchorV1 anchor is missing from/to endpoints"
                                    .into(),
                            );
                        }
                    } else if closed.0.as_slice() == SML && closed.1.as_slice() == b"control" {
                        let state = current.take().ok_or_else(|| {
                            owner_invalid("worksheet anchor state is inconsistent")
                        })?;
                        validations.push(state.diagnostic);
                    }
                }
            },
            Event::Eof => break,
            Event::Decl(_)
            | Event::Comment(_)
            | Event::PI(_)
            | Event::DocType(_)
            | Event::GeneralRef(_) => {},
        }
    }
    if current.is_some() || !stack.is_empty() {
        return Err(owner_invalid("worksheet anchor XML is unterminated"));
    }
    Ok(validations)
}

fn append_anchor_text(
    current: Option<&mut AnchorValidation>,
    bytes: &[u8],
    decoder: quick_xml::encoding::Decoder,
    maximum: usize,
) -> OwnerResult<()> {
    let Some(state) = current else {
        return Ok(());
    };
    let Some(endpoint) = state.endpoint.as_mut() else {
        return Ok(());
    };
    let Some((index, _)) = endpoint.active_field.take() else {
        return Ok(());
    };
    let decoded = decoder
        .decode(bytes)
        .map_err(|error| owner_invalid(error.to_string()))?;
    if decoded.len() > maximum {
        state.diagnostic =
            Some("worksheet LoSmlAnchorV1 numeric lexical value exceeds the owner bound".into());
    } else if endpoint.fields[index].is_some() {
        state.diagnostic =
            Some("worksheet LoSmlAnchorV1 numeric field has multiple text nodes".into());
    } else {
        endpoint.fields[index] = Some(decoded.into_owned());
    }
    endpoint.active_field = Some((index, Vec::new()));
    Ok(())
}

fn anchor_field_index(local: &[u8]) -> Option<usize> {
    match local {
        b"col" => Some(0),
        b"colOff" => Some(1),
        b"row" => Some(2),
        b"rowOff" => Some(3),
        _ => None,
    }
}

const fn anchor_field_name(index: usize) -> &'static str {
    match index {
        0 => "col",
        1 => "colOff",
        2 => "row",
        _ => "rowOff",
    }
}

fn valid_anchor_integer(value: &str, maximum: u64) -> bool {
    !value.is_empty()
        && value.bytes().all(|byte| byte.is_ascii_digit())
        && value.parse::<u64>().is_ok_and(|value| value <= maximum)
}

fn relationship_target(
    relationships: &Relationships,
    relationship_id: Option<&str>,
    expected_type: &'static str,
    subject: &'static str,
) -> OwnerResult<PackURI> {
    let relationship_id = relationship_id
        .ok_or_else(|| owner_invalid(format!("{subject} relationship is missing")))?;
    let relationship = relationships
        .get(relationship_id)
        .ok_or_else(|| owner_invalid(format!("{subject} relationship is missing")))?;
    if relationship.target_mode() != TargetMode::Internal {
        return Err(owner_invalid(format!(
            "{subject} relationship target is external"
        )));
    }
    if relationship.reltype() != expected_type {
        return Err(owner_invalid(format!(
            "{subject} relationship type is not canonical"
        )));
    }
    relationship
        .target_partname()
        .map_err(FormControlOwnerError::from)
}

fn parse_control(
    element: &BytesStart<'_>,
    resolver: &quick_xml::name::NamespaceResolver,
    decoder: quick_xml::encoding::Decoder,
    limits: &OwnerLimits,
) -> OwnerResult<SourceControl> {
    let mut shape = None;
    let mut rel_id = None;
    let mut name = None;
    for attribute in element.attributes().with_checks(false) {
        let attribute = attribute.map_err(|error| owner_invalid(error.to_string()))?;
        let value = bounded_name(
            decode_attribute(attribute.value.as_ref(), decoder)?,
            limits,
            "worksheet control identity",
        )?;
        let (namespace, local) = resolver.resolve_attribute(attribute.key);
        match (namespace, local.as_ref()) {
            (ResolveResult::Unbound, b"shapeId") => {
                shape = Some(
                    value
                        .parse::<u64>()
                        .map_err(|_| owner_invalid("control shapeId is not decimal"))?,
                )
            },
            (ResolveResult::Bound(Namespace(value_ns)), b"id") if value_ns == REL => {
                rel_id = Some(value)
            },
            (ResolveResult::Unbound, b"name") => {
                name = Some(bounded_display_name(
                    value,
                    limits,
                    "worksheet control name",
                )?)
            },
            (ResolveResult::Bound(Namespace(value_ns)), b"id") if value_ns == STRICT_REL => {
                return Err(FormControlOwnerError::Invalid(
                    "strict worksheet relationship attribute is not admitted".into(),
                ));
            },
            _ => {},
        }
    }
    let shape_id = shape.ok_or_else(|| owner_invalid("control shapeId is missing"))?;
    if !(1..=MAX_SHAPE_ID).contains(&shape_id) {
        return Err(owner_invalid("control shapeId is outside the Office range"));
    }
    Ok(SourceControl {
        shape_id,
        relationship_id: rel_id.ok_or_else(|| owner_invalid("control r:id is missing"))?,
        name,
        anchor_profile: None,
        anchor_diagnostic: None,
    })
}

fn attr_rel_id(
    element: &BytesStart<'_>,
    resolver: &quick_xml::name::NamespaceResolver,
    decoder: quick_xml::encoding::Decoder,
    limits: &OwnerLimits,
) -> OwnerResult<Option<String>> {
    for attribute in element.attributes().with_checks(false) {
        let attribute = attribute.map_err(|error| owner_invalid(error.to_string()))?;
        let (namespace, local) = resolver.resolve_attribute(attribute.key);
        if local.as_ref() == b"id" {
            if matches!(namespace, ResolveResult::Bound(Namespace(value)) if value == STRICT_REL) {
                return Err(FormControlOwnerError::Invalid(
                    "strict worksheet relationship attribute is not admitted".into(),
                ));
            }
            if matches!(namespace, ResolveResult::Bound(Namespace(value)) if value == REL) {
                return Ok(Some(bounded_name(
                    decode_attribute(attribute.value.as_ref(), decoder)?,
                    limits,
                    "worksheet relationship identity",
                )?));
            }
        }
    }
    Ok(None)
}

#[derive(Clone, Debug)]
struct DrawingShape {
    id: u64,
    name: Option<String>,
    compat_spid: String,
}

fn index_drawing_shapes(shapes: &[DrawingShape]) -> OwnerResult<HashMap<u64, Option<usize>>> {
    let mut index = HashMap::new();
    index
        .try_reserve(shapes.len())
        .map_err(|source| owner_alloc("DrawingML identity index", source))?;
    for (position, shape) in shapes.iter().enumerate() {
        match index.entry(shape.id) {
            std::collections::hash_map::Entry::Vacant(entry) => {
                entry.insert(Some(position));
            },
            std::collections::hash_map::Entry::Occupied(mut entry) => {
                entry.insert(None);
            },
        }
    }
    Ok(index)
}

fn is_admitted_sp_cnvpr(stack: &[(Vec<u8>, Vec<u8>)]) -> bool {
    // The owner only admits the non-visual properties of a shape (`sp`) when
    // the cNvPr is its direct child through `nvSpPr`, and that shape is itself
    // directly descended from one of the three admitted anchor kinds.  A
    // global cNvPr scan would otherwise accidentally adopt a picture or an
    // unrelated shape with the same numeric identity.
    if stack.len() < 2 {
        return false;
    }
    let parent = &stack[stack.len() - 1];
    let grandparent = &stack[stack.len() - 2];
    if parent.0.as_slice() != XDR
        || parent.1.as_slice() != b"nvSpPr"
        || grandparent.0.as_slice() != XDR
        || grandparent.1.as_slice() != b"sp"
    {
        return false;
    }
    stack[..stack.len() - 2]
        .iter()
        .rev()
        .any(|(namespace, local)| {
            namespace.as_slice() == XDR
                && matches!(
                    local.as_slice(),
                    b"twoCellAnchor" | b"oneCellAnchor" | b"absoluteAnchor"
                )
        })
}

fn parse_drawing(xml: &[u8], limits: &OwnerLimits) -> OwnerResult<Vec<DrawingShape>> {
    let mut reader = NsReader::from_reader(xml);
    reader.config_mut().trim_text(false);
    reader.config_mut().check_end_names = true;
    let mut stack: Vec<(Vec<u8>, Vec<u8>)> = Vec::new();
    let mut shapes = Vec::new();
    shapes
        .try_reserve(8.min(limits.max_shapes))
        .map_err(|source| owner_alloc("drawing shape identities", source))?;
    let mut current_cnvpr = None;
    let mut events = 0usize;
    loop {
        events = events
            .checked_add(1)
            .ok_or_else(|| owner_invalid("drawing XML event count overflow"))?;
        if events > limits.max_mce_events {
            return Err(owner_limit(
                "drawing XML events",
                events,
                limits.max_mce_events,
            ));
        }
        let event = reader
            .read_event()
            .map_err(|error| owner_invalid(error.to_string()))?;
        let resolver = reader.resolver().clone();
        match event {
            Event::Start(element) => {
                let (namespace, local) = resolver.resolve_element(element.name());
                let namespace = namespace_bytes(namespace);
                let local = local.as_ref().to_vec();
                if namespace.as_slice() == XDR && local.as_slice() == b"cNvPr" {
                    let has_shape = stack
                        .iter()
                        .any(|(ns, local)| ns.as_slice() == XDR && local.as_slice() == b"sp");
                    if !has_shape {
                        if stack.len() >= limits.max_mce_depth {
                            return Err(owner_limit(
                                "drawing XML depth",
                                stack.len() + 1,
                                limits.max_mce_depth,
                            ));
                        }
                        stack.push((namespace, local));
                        continue;
                    }
                    if !is_admitted_sp_cnvpr(&stack) {
                        return Err(owner_invalid(
                            "DrawingML xdr:sp/cNvPr is outside its admitted anchor",
                        ));
                    }
                    if current_cnvpr.is_some() {
                        return Err(owner_invalid("DrawingML cNvPr elements are nested"));
                    }
                    if shapes.len() >= limits.max_shapes {
                        return Err(owner_limit(
                            "shape identities",
                            shapes.len() + 1,
                            limits.max_shapes,
                        ));
                    }
                    if shapes.len() >= limits.max_shapes {
                        return Err(owner_limit(
                            "shape identities",
                            shapes.len() + 1,
                            limits.max_shapes,
                        ));
                    }
                    shapes
                        .try_reserve(1)
                        .map_err(|source| owner_alloc("drawing shape identities", source))?;
                    shapes.push(parse_drawing_shape(
                        &element,
                        &resolver,
                        reader.decoder(),
                        limits,
                    )?);
                    if shapes.len() > limits.max_shapes {
                        return Err(owner_limit(
                            "shape identities",
                            shapes.len(),
                            limits.max_shapes,
                        ));
                    }
                    current_cnvpr = Some(shapes.len() - 1);
                } else if namespace.as_slice() == A14 && local.as_slice() == b"compatExt" {
                    let Some(index) = current_cnvpr else {
                        continue;
                    };
                    let spid = attr_unqualified(&element, b"spid", &resolver, reader.decoder())?
                        .ok_or_else(|| owner_invalid("DrawingML a14:compatExt/@spid is missing"))
                        .and_then(|value| bounded_name(value, limits, "DrawingML compat spid"))?;
                    if !shapes[index].compat_spid.is_empty() {
                        return Err(owner_invalid("DrawingML cNvPr has duplicate a14:compatExt"));
                    }
                    shapes[index].compat_spid = spid;
                }
                if stack.len() >= limits.max_mce_depth {
                    return Err(owner_limit(
                        "drawing XML depth",
                        stack.len() + 1,
                        limits.max_mce_depth,
                    ));
                }
                stack.push((namespace, local));
            },
            Event::Empty(element) => {
                let (namespace, local) = resolver.resolve_element(element.name());
                if is_ns(&namespace, XDR) && local.as_ref() == b"cNvPr" {
                    let has_shape = stack
                        .iter()
                        .any(|(ns, local)| ns.as_slice() == XDR && local.as_slice() == b"sp");
                    if !has_shape {
                        continue;
                    }
                    if !is_admitted_sp_cnvpr(&stack) {
                        return Err(owner_invalid(
                            "DrawingML xdr:sp/cNvPr is outside its admitted anchor",
                        ));
                    }
                    if shapes.len() >= limits.max_shapes {
                        return Err(owner_limit(
                            "shape identities",
                            shapes.len() + 1,
                            limits.max_shapes,
                        ));
                    }
                    if shapes.len() >= limits.max_shapes {
                        return Err(owner_limit(
                            "shape identities",
                            shapes.len() + 1,
                            limits.max_shapes,
                        ));
                    }
                    shapes
                        .try_reserve(1)
                        .map_err(|source| owner_alloc("drawing shape identities", source))?;
                    let shape = parse_drawing_shape(&element, &resolver, reader.decoder(), limits)?;
                    shapes.push(shape);
                    if shapes.len() > limits.max_shapes {
                        return Err(owner_limit(
                            "shape identities",
                            shapes.len(),
                            limits.max_shapes,
                        ));
                    }
                } else if is_ns(&namespace, A14) && local.as_ref() == b"compatExt" {
                    let Some(index) = current_cnvpr else {
                        continue;
                    };
                    let spid = attr_unqualified(&element, b"spid", &resolver, reader.decoder())?
                        .ok_or_else(|| owner_invalid("DrawingML a14:compatExt/@spid is missing"))
                        .and_then(|value| bounded_name(value, limits, "DrawingML compat spid"))?;
                    if !shapes[index].compat_spid.is_empty() {
                        return Err(owner_invalid("DrawingML cNvPr has duplicate a14:compatExt"));
                    }
                    shapes[index].compat_spid = spid;
                }
            },
            Event::End(_) => {
                let closed = stack.pop();
                if closed.as_ref().is_some_and(|(namespace, local)| {
                    namespace.as_slice() == XDR && local.as_slice() == b"cNvPr"
                }) {
                    let Some(_index) = current_cnvpr.take() else {
                        continue;
                    };
                }
            },
            Event::Eof => break,
            Event::Decl(_)
            | Event::Comment(_)
            | Event::Text(_)
            | Event::CData(_)
            | Event::PI(_)
            | Event::DocType(_)
            | Event::GeneralRef(_) => {},
        }
    }
    Ok(shapes)
}

fn parse_drawing_shape(
    element: &BytesStart<'_>,
    resolver: &quick_xml::name::NamespaceResolver,
    decoder: quick_xml::encoding::Decoder,
    limits: &OwnerLimits,
) -> OwnerResult<DrawingShape> {
    let mut id = None;
    let mut name = None;
    for attribute in element.attributes().with_checks(false) {
        let attribute = attribute.map_err(|error| owner_invalid(error.to_string()))?;
        let (namespace, local) = resolver.resolve_attribute(attribute.key);
        if !matches!(namespace, ResolveResult::Unbound) {
            continue;
        }
        let value = bounded_name(
            decode_attribute(attribute.value.as_ref(), decoder)?,
            limits,
            "DrawingML identity",
        )?;
        match local.as_ref() {
            b"id" => {
                id = Some(
                    value
                        .parse::<u64>()
                        .map_err(|_| owner_invalid("DrawingML cNvPr id is not decimal"))?,
                )
            },
            b"name" => name = Some(bounded_display_name(value, limits, "DrawingML shape name")?),
            _ => {},
        }
    }
    let id = id.ok_or_else(|| owner_invalid("DrawingML cNvPr id is missing"))?;
    if !(1..=MAX_SHAPE_ID).contains(&id) {
        return Err(owner_invalid(
            "DrawingML cNvPr id is outside the Office range",
        ));
    }
    Ok(DrawingShape {
        id,
        name,
        compat_spid: String::new(),
    })
}

#[derive(Clone, Debug)]
struct VmlShape {
    id: String,
    spid: Option<String>,
    object_type: String,
    client_fields: Vec<VmlField>,
}

#[derive(Clone, Debug)]
struct VmlField {
    name: String,
    value: String,
    empty: bool,
}

struct VmlIdentityIndex {
    by_numeric: HashMap<u64, Option<usize>>,
    mismatched: HashSet<u64>,
}

fn index_vml_shapes(shapes: &[VmlShape]) -> OwnerResult<VmlIdentityIndex> {
    let mut by_numeric = HashMap::new();
    by_numeric
        .try_reserve(shapes.len())
        .map_err(|source| owner_alloc("VML identity index", source))?;
    let mut mismatched = HashSet::new();
    mismatched
        .try_reserve(shapes.len())
        .map_err(|source| owner_alloc("VML identity mismatch index", source))?;
    for (position, shape) in shapes.iter().enumerate() {
        let id_number = numeric_spid(&shape.id);
        let spid_number = shape.spid.as_deref().and_then(numeric_spid);
        if let (Some(id_number), Some(spid_number)) = (id_number, spid_number) {
            if id_number != spid_number {
                mismatched.insert(id_number);
                mismatched.insert(spid_number);
                continue;
            }
        }
        let Some(canonical) = id_number.or(spid_number) else {
            continue;
        };
        match by_numeric.entry(canonical) {
            std::collections::hash_map::Entry::Vacant(entry) => {
                entry.insert(Some(position));
            },
            std::collections::hash_map::Entry::Occupied(mut entry) => {
                entry.insert(None);
            },
        }
    }
    Ok(VmlIdentityIndex {
        by_numeric,
        mismatched,
    })
}

fn parse_vml(xml: &[u8], limits: &OwnerLimits) -> OwnerResult<Vec<VmlShape>> {
    let mut reader = NsReader::from_reader(xml);
    reader.config_mut().trim_text(false);
    reader.config_mut().check_end_names = true;
    let mut stack: Vec<(Vec<u8>, Vec<u8>)> = Vec::new();
    let mut shapes = Vec::new();
    shapes
        .try_reserve(8.min(limits.max_shapes))
        .map_err(|source| owner_alloc("VML shape identities", source))?;
    let mut current: Option<(VmlShape, usize)> = None;
    let mut root_seen = false;
    let mut events = 0usize;
    loop {
        events = events
            .checked_add(1)
            .ok_or_else(|| owner_invalid("VML XML event count overflow"))?;
        if events > limits.max_mce_events {
            return Err(owner_limit("VML XML events", events, limits.max_mce_events));
        }
        let event = reader
            .read_event()
            .map_err(|error| owner_invalid(error.to_string()))?;
        let resolver = reader.resolver().clone();
        match event {
            Event::Start(element) => {
                let (namespace, local) = resolver.resolve_element(element.name());
                let namespace = namespace_bytes(namespace);
                let local = local.as_ref().to_vec();
                if !root_seen {
                    if !namespace.is_empty() || local.as_slice() != b"xml" {
                        return Err(owner_invalid(
                            "VML root must be the unqualified xml element",
                        ));
                    }
                    root_seen = true;
                } else if stack.is_empty() {
                    return Err(owner_invalid("VML XML has more than one root element"));
                }
                if namespace.as_slice() == VML && local.as_slice() == b"shape" {
                    if current.is_some() {
                        return Err(owner_invalid("VML control shapes are nested"));
                    }
                    if shapes.len() >= limits.max_shapes {
                        return Err(owner_limit(
                            "VML shape identities",
                            shapes.len() + 1,
                            limits.max_shapes,
                        ));
                    }
                    let id = attr_unqualified(&element, b"id", &resolver, reader.decoder())?
                        .ok_or_else(|| owner_invalid("VML control shape id is missing"))
                        .and_then(|value| bounded_name(value, limits, "VML identity"))?;
                    let spid =
                        attr_qualified(&element, OFFICE, b"spid", &resolver, reader.decoder())?
                            .map(|value| bounded_name(value, limits, "VML o:spid"))
                            .transpose()?;
                    if spid
                        .as_deref()
                        .is_some_and(|value| numeric_spid(value).is_none())
                    {
                        return Err(owner_invalid("VML o:spid is not a valid numeric identity"));
                    }
                    current = Some((
                        VmlShape {
                            id,
                            spid,
                            object_type: String::new(),
                            client_fields: Vec::new(),
                        },
                        stack.len(),
                    ));
                } else if namespace.as_slice() == EXCEL && local.as_slice() == b"ClientData" {
                    if let Some((shape, _)) = current.as_mut() {
                        shape.object_type =
                            attr_unqualified(&element, b"ObjectType", &resolver, reader.decoder())?
                                .map(|value| {
                                    bounded_name(value, limits, "VML ClientData ObjectType")
                                })
                                .transpose()?
                                .unwrap_or_default();
                    }
                }
                if stack.len() >= limits.max_mce_depth {
                    return Err(owner_limit(
                        "VML XML depth",
                        stack.len() + 1,
                        limits.max_mce_depth,
                    ));
                }
                stack.push((namespace, local));
            },
            Event::Empty(element) => {
                let (namespace, local) = resolver.resolve_element(element.name());
                let namespace = namespace_bytes(namespace);
                let local = local.as_ref();
                if !root_seen || stack.is_empty() {
                    return Err(owner_invalid(
                        "VML empty element is outside the root element",
                    ));
                }
                if namespace.as_slice() == VML && local == b"shape" {
                    let id = attr_unqualified(&element, b"id", &resolver, reader.decoder())?
                        .ok_or_else(|| owner_invalid("VML control shape id is missing"))
                        .and_then(|value| bounded_name(value, limits, "VML identity"))?;
                    let spid =
                        attr_qualified(&element, OFFICE, b"spid", &resolver, reader.decoder())?
                            .map(|value| bounded_name(value, limits, "VML o:spid"))
                            .transpose()?;
                    if spid
                        .as_deref()
                        .is_some_and(|value| numeric_spid(value).is_none())
                    {
                        return Err(owner_invalid("VML o:spid is not a valid numeric identity"));
                    }
                    if shapes.len() >= limits.max_shapes {
                        return Err(owner_limit(
                            "VML shape identities",
                            shapes.len() + 1,
                            limits.max_shapes,
                        ));
                    }
                    shapes
                        .try_reserve(1)
                        .map_err(|source| owner_alloc("VML shape identities", source))?;
                    shapes.push(VmlShape {
                        id,
                        spid,
                        object_type: String::new(),
                        client_fields: Vec::new(),
                    });
                } else if namespace.as_slice() == EXCEL && local == b"ClientData" {
                    if let Some((shape, _)) = current.as_mut() {
                        shape.object_type =
                            attr_unqualified(&element, b"ObjectType", &resolver, reader.decoder())?
                                .map(|value| {
                                    bounded_name(value, limits, "VML ClientData ObjectType")
                                })
                                .transpose()?
                                .unwrap_or_default();
                    }
                }
            },
            Event::End(_) => {
                let closed = stack
                    .pop()
                    .ok_or_else(|| owner_invalid("VML closing tag is unmatched"))?;
                if let Some((_, depth)) = current.as_ref() {
                    if closed.0.as_slice() == VML
                        && closed.1.as_slice() == b"shape"
                        && *depth == stack.len()
                    {
                        if let Some((shape, _)) = current.take() {
                            if shapes.len() >= limits.max_shapes {
                                return Err(owner_limit(
                                    "VML shape identities",
                                    shapes.len() + 1,
                                    limits.max_shapes,
                                ));
                            }
                            shapes
                                .try_reserve(1)
                                .map_err(|source| owner_alloc("VML shape identities", source))?;
                            shapes.push(shape);
                        }
                    }
                }
            },
            Event::Eof => break,
            Event::Decl(_)
            | Event::Comment(_)
            | Event::Text(_)
            | Event::CData(_)
            | Event::PI(_)
            | Event::DocType(_)
            | Event::GeneralRef(_) => {},
        }
        if shapes.len() > limits.max_shapes {
            return Err(owner_limit(
                "VML shape identities",
                shapes.len(),
                limits.max_shapes,
            ));
        }
    }
    if !root_seen {
        return Err(owner_invalid("VML XML has no root element"));
    }
    if !stack.is_empty() || current.is_some() {
        return Err(owner_invalid("VML XML is unterminated"));
    }
    let fields = parse_vml_client_fields(xml, limits)?;
    if fields.len() != shapes.len() {
        return Err(owner_invalid(
            "VML ClientData shape inventory does not match VML shape identities",
        ));
    }
    for (shape, fields) in shapes.iter_mut().zip(fields) {
        shape.client_fields = fields;
    }
    Ok(shapes)
}

fn parse_vml_client_fields(xml: &[u8], limits: &OwnerLimits) -> OwnerResult<Vec<Vec<VmlField>>> {
    let mut reader = NsReader::from_reader(xml);
    reader.config_mut().trim_text(false);
    reader.config_mut().check_end_names = true;
    let mut stack: Vec<(Vec<u8>, Vec<u8>)> = Vec::new();
    let mut fields_by_shape: Vec<Vec<VmlField>> = Vec::new();
    let mut current_shape = None;
    let mut shape_depth = 0usize;
    let mut client_depth = None;
    let mut active_field: Option<(usize, usize, usize, Vec<u8>)> = None;
    let mut field_nodes = 0usize;
    let mut events = 0usize;
    loop {
        events = events
            .checked_add(1)
            .ok_or_else(|| owner_invalid("VML ClientData event count overflow"))?;
        if events > limits.max_mce_events {
            return Err(owner_limit(
                "VML ClientData events",
                events,
                limits.max_mce_events,
            ));
        }
        let event = reader
            .read_event()
            .map_err(|error| owner_invalid(error.to_string()))?;
        let resolver = reader.resolver().clone();
        match event {
            Event::Start(element) => {
                let (namespace, local) = resolver.resolve_element(element.name());
                let namespace = namespace_bytes(namespace);
                let local = local.as_ref().to_vec();
                if namespace.as_slice() == VML && local.as_slice() == b"shape" {
                    if current_shape.is_some() {
                        return Err(owner_invalid("VML ClientData shapes are nested"));
                    }
                    if fields_by_shape.len() >= limits.max_shapes {
                        return Err(owner_limit(
                            "VML ClientData shapes",
                            fields_by_shape.len() + 1,
                            limits.max_shapes,
                        ));
                    }
                    fields_by_shape
                        .try_reserve(1)
                        .map_err(|source| owner_alloc("VML ClientData shapes", source))?;
                    fields_by_shape.push(Vec::new());
                    current_shape = Some(fields_by_shape.len() - 1);
                    shape_depth = stack.len();
                    client_depth = None;
                } else if namespace.as_slice() == EXCEL
                    && local.as_slice() == b"ClientData"
                    && current_shape.is_some()
                    && stack.last().is_some_and(|(parent_ns, parent)| {
                        parent_ns.as_slice() == VML && parent.as_slice() == b"shape"
                    })
                {
                    client_depth = Some(stack.len());
                } else if current_shape.is_some()
                    && client_depth.is_some_and(|depth| stack.len() == depth + 1)
                {
                    let shape = match current_shape {
                        Some(shape) => shape,
                        None => {
                            return Err(owner_invalid("VML ClientData field has no owning shape"));
                        },
                    };
                    field_nodes = field_nodes
                        .checked_add(1)
                        .ok_or_else(|| owner_invalid("VML ClientData field count overflow"))?;
                    if field_nodes > limits.max_mirror_nodes {
                        return Err(owner_limit(
                            "VML ClientData fields",
                            field_nodes,
                            limits.max_mirror_nodes,
                        ));
                    }
                    let fields = fields_by_shape
                        .get_mut(shape)
                        .ok_or_else(|| owner_invalid("VML ClientData shape index is invalid"))?;
                    fields
                        .try_reserve(1)
                        .map_err(|source| owner_alloc("VML ClientData fields", source))?;
                    fields.push(VmlField {
                        name: bounded_name(
                            String::from_utf8_lossy(&local).into_owned(),
                            limits,
                            "VML ClientData field name",
                        )?,
                        value: String::new(),
                        empty: false,
                    });
                    active_field = Some((shape, fields.len() - 1, stack.len(), local.clone()));
                }
                if stack.len() >= limits.max_mce_depth {
                    return Err(owner_limit(
                        "VML ClientData depth",
                        stack.len() + 1,
                        limits.max_mce_depth,
                    ));
                }
                stack.push((namespace, local));
            },
            Event::Empty(element) => {
                let (namespace, local) = resolver.resolve_element(element.name());
                let namespace = namespace_bytes(namespace);
                let local = local.as_ref().to_vec();
                if namespace.as_slice() == VML && local.as_slice() == b"shape" {
                    if fields_by_shape.len() >= limits.max_shapes {
                        return Err(owner_limit(
                            "VML ClientData shapes",
                            fields_by_shape.len() + 1,
                            limits.max_shapes,
                        ));
                    }
                    fields_by_shape
                        .try_reserve(1)
                        .map_err(|source| owner_alloc("VML ClientData shapes", source))?;
                    fields_by_shape.push(Vec::new());
                } else if current_shape.is_some()
                    && client_depth.is_some_and(|depth| stack.len() == depth + 1)
                {
                    let shape = current_shape.expect("checked above");
                    field_nodes = field_nodes
                        .checked_add(1)
                        .ok_or_else(|| owner_invalid("VML ClientData field count overflow"))?;
                    if field_nodes > limits.max_mirror_nodes {
                        return Err(owner_limit(
                            "VML ClientData fields",
                            field_nodes,
                            limits.max_mirror_nodes,
                        ));
                    }
                    let fields = fields_by_shape
                        .get_mut(shape)
                        .ok_or_else(|| owner_invalid("VML ClientData shape index is invalid"))?;
                    fields
                        .try_reserve(1)
                        .map_err(|source| owner_alloc("VML ClientData fields", source))?;
                    fields.push(VmlField {
                        name: bounded_name(
                            String::from_utf8_lossy(&local).into_owned(),
                            limits,
                            "VML ClientData field name",
                        )?,
                        value: String::new(),
                        empty: true,
                    });
                }
            },
            Event::Text(text) => append_vml_field_text(
                &mut active_field,
                &mut fields_by_shape,
                text.as_ref(),
                reader.decoder(),
                limits.max_name_bytes,
            )?,
            Event::CData(text) => append_vml_field_text(
                &mut active_field,
                &mut fields_by_shape,
                text.as_ref(),
                reader.decoder(),
                limits.max_name_bytes,
            )?,
            Event::End(_) => {
                let closed = stack
                    .pop()
                    .ok_or_else(|| owner_invalid("VML ClientData closing tag is unmatched"))?;
                if let Some((_, _, depth, name)) = active_field.as_ref() {
                    if *depth == stack.len() && closed.1 == *name {
                        active_field = None;
                    }
                }
                if closed.0.as_slice() == EXCEL
                    && closed.1.as_slice() == b"ClientData"
                    && client_depth == Some(stack.len())
                {
                    client_depth = None;
                }
                if closed.0.as_slice() == VML
                    && closed.1.as_slice() == b"shape"
                    && shape_depth == stack.len()
                {
                    current_shape = None;
                    client_depth = None;
                    active_field = None;
                }
            },
            Event::Eof => break,
            Event::Decl(_)
            | Event::Comment(_)
            | Event::PI(_)
            | Event::DocType(_)
            | Event::GeneralRef(_) => {},
        }
    }
    if !stack.is_empty() || current_shape.is_some() || active_field.is_some() {
        return Err(owner_invalid("VML ClientData XML is unterminated"));
    }
    Ok(fields_by_shape)
}

fn append_vml_field_text(
    active_field: &mut Option<(usize, usize, usize, Vec<u8>)>,
    fields_by_shape: &mut [Vec<VmlField>],
    bytes: &[u8],
    decoder: quick_xml::encoding::Decoder,
    maximum: usize,
) -> OwnerResult<()> {
    let Some((shape, field, _, _)) = active_field.as_ref() else {
        return Ok(());
    };
    let decoded = decoder
        .decode(bytes)
        .map_err(|error| owner_invalid(error.to_string()))?;
    let decoded =
        quick_xml::escape::unescape(&decoded).map_err(|error| owner_invalid(error.to_string()))?;
    let target = fields_by_shape
        .get_mut(*shape)
        .and_then(|fields| fields.get_mut(*field))
        .ok_or_else(|| owner_invalid("VML ClientData field index is invalid"))?;
    let total = target
        .value
        .len()
        .checked_add(decoded.len())
        .ok_or_else(|| owner_invalid("VML ClientData field value length overflow"))?;
    if total > maximum {
        return Err(owner_limit("VML ClientData field value", total, maximum));
    }
    target.value.push_str(&decoded);
    Ok(())
}

fn vml_mirror_diagnostics(
    properties: &Properties,
    shape: &VmlShape,
    _limits: &OwnerLimits,
) -> OwnerResult<Vec<FormControlDiagnostic>> {
    let mut diagnostics = Vec::new();
    diagnostics
        .try_reserve(32)
        .map_err(|source| owner_alloc("VML mirror diagnostics", source))?;

    if let Some(value) = properties.checked() {
        let expected = match value {
            super::KnownOrUnknown::Known(super::Checked::Unchecked) => Some("0"),
            super::KnownOrUnknown::Known(super::Checked::Checked) => Some("1"),
            super::KnownOrUnknown::Known(super::Checked::Mixed) => Some("2"),
            super::KnownOrUnknown::Unknown(_) => None,
        };
        check_vml_lexical(
            &mut diagnostics,
            shape,
            "Checked",
            expected,
            false,
            "checked",
        )?;
    }
    check_vml_bool(
        &mut diagnostics,
        shape,
        "Colored",
        properties.colored(),
        "colored",
    )?;
    check_vml_number(
        &mut diagnostics,
        shape,
        "DropLines",
        properties.drop_lines(),
        "dropLines",
    )?;
    check_vml_token(
        &mut diagnostics,
        shape,
        "DropStyle",
        properties.drop_style(),
        "dropStyle",
    )?;
    check_vml_number(&mut diagnostics, shape, "Dx", properties.dx(), "dx")?;
    check_vml_bool(
        &mut diagnostics,
        shape,
        "FirstButton",
        properties.first_button(),
        "firstButton",
    )?;
    check_vml_formula(
        &mut diagnostics,
        shape,
        "FmlaGroup",
        properties.fmla_group(),
        "fmlaGroup",
    )?;
    check_vml_formula(
        &mut diagnostics,
        shape,
        "FmlaLink",
        properties.fmla_link(),
        "fmlaLink",
    )?;
    check_vml_formula(
        &mut diagnostics,
        shape,
        "FmlaRange",
        properties.fmla_range(),
        "fmlaRange",
    )?;
    check_vml_formula(
        &mut diagnostics,
        shape,
        "FmlaTxbx",
        properties.fmla_txbx(),
        "fmlaTxbx",
    )?;
    check_vml_bool(
        &mut diagnostics,
        shape,
        "Horiz",
        properties.horiz(),
        "horiz",
    )?;
    check_vml_number(&mut diagnostics, shape, "Inc", properties.inc(), "inc")?;
    check_vml_bool(
        &mut diagnostics,
        shape,
        "JustLastX",
        properties.just_last_x(),
        "justLastX",
    )?;
    check_vml_bool(
        &mut diagnostics,
        shape,
        "LockText",
        properties.lock_text(),
        "lockText",
    )?;
    check_vml_number(&mut diagnostics, shape, "Max", properties.max(), "max")?;
    check_vml_number(&mut diagnostics, shape, "Min", properties.min(), "min")?;
    check_vml_string(
        &mut diagnostics,
        shape,
        "MultiSel",
        properties.multi_sel(),
        "multiSel",
    )?;
    check_vml_bool(
        &mut diagnostics,
        shape,
        "NoThreeD",
        properties.no_three_d(),
        "noThreeD",
    )?;
    check_vml_bool(
        &mut diagnostics,
        shape,
        "NoThreeD2",
        properties.no_three_d2(),
        "noThreeD2",
    )?;
    check_vml_number(&mut diagnostics, shape, "Page", properties.page(), "page")?;
    check_vml_number(&mut diagnostics, shape, "Sel", properties.sel(), "sel")?;
    check_vml_token(
        &mut diagnostics,
        shape,
        "SelType",
        properties.seltype(),
        "seltype",
    )?;
    check_vml_token(
        &mut diagnostics,
        shape,
        "TextHAlign",
        properties.text_h_align(),
        "textHAlign",
    )?;
    check_vml_token(
        &mut diagnostics,
        shape,
        "TextVAlign",
        properties.text_v_align(),
        "textVAlign",
    )?;
    check_vml_number(&mut diagnostics, shape, "Val", properties.val(), "val")?;
    check_vml_number(
        &mut diagnostics,
        shape,
        "WidthMin",
        properties.width_min(),
        "widthMin",
    )?;
    if properties.edit_val().is_some() {
        check_vml_lexical(&mut diagnostics, shape, "VTEdit", None, true, "editVal")?;
    }
    check_vml_bool(
        &mut diagnostics,
        shape,
        "MultiLine",
        properties.multi_line(),
        "multiLine",
    )?;
    check_vml_bool(
        &mut diagnostics,
        shape,
        "VScroll",
        properties.vertical_bar(),
        "verticalBar",
    )?;
    check_vml_bool(
        &mut diagnostics,
        shape,
        "SecretEdit",
        properties.password_edit(),
        "passwordEdit",
    )?;
    check_vml_items(&mut diagnostics, shape, properties.item_list())?;
    Ok(diagnostics)
}

fn vml_field<'a>(shape: &'a VmlShape, name: &str) -> (Option<&'a VmlField>, bool) {
    let mut found = None;
    let mut duplicate = false;
    for field in &shape.client_fields {
        if field.name == name {
            if found.is_some() {
                duplicate = true;
            } else {
                found = Some(field);
            }
        }
    }
    (found, duplicate)
}

fn check_vml_lexical(
    diagnostics: &mut Vec<FormControlDiagnostic>,
    shape: &VmlShape,
    field_name: &str,
    expected: Option<&str>,
    read_only: bool,
    property: &str,
) -> OwnerResult<()> {
    let (field, duplicate) = vml_field(shape, field_name);
    let detail = if duplicate {
        Some(format!(
            "VML mirror {field_name} occurs more than once for {property}"
        ))
    } else if read_only {
        Some(format!(
            "{property}↔VML {field_name} mapping is read-only in this profile"
        ))
    } else {
        match (field, expected) {
            (None, Some(_)) => Some(format!("VML mirror {field_name} is absent for {property}")),
            (None, None) => None,
            (Some(_), None) => None,
            (Some(field), Some(expected)) if field.value != expected => Some(format!(
                "VML mirror {field_name} disagrees with x14 {property}"
            )),
            _ => None,
        }
    };
    if let Some(detail) = detail {
        push_mirror_diagnostic(diagnostics, detail.into())?;
    }
    Ok(())
}

fn check_vml_string(
    diagnostics: &mut Vec<FormControlDiagnostic>,
    shape: &VmlShape,
    field_name: &str,
    expected: Option<&str>,
    property: &str,
) -> OwnerResult<()> {
    check_vml_lexical(diagnostics, shape, field_name, expected, false, property)
}

fn check_vml_number(
    diagnostics: &mut Vec<FormControlDiagnostic>,
    shape: &VmlShape,
    field_name: &str,
    expected: Option<u32>,
    property: &str,
) -> OwnerResult<()> {
    let expected = expected.map(|value| value.to_string());
    check_vml_lexical(
        diagnostics,
        shape,
        field_name,
        expected.as_deref(),
        false,
        property,
    )
}

fn check_vml_bool(
    diagnostics: &mut Vec<FormControlDiagnostic>,
    shape: &VmlShape,
    field_name: &str,
    expected: Option<bool>,
    property: &str,
) -> OwnerResult<()> {
    let (field, duplicate) = vml_field(shape, field_name);
    let detail = if duplicate {
        Some(format!(
            "VML mirror {field_name} occurs more than once for {property}"
        ))
    } else {
        match (field, expected) {
            (None, Some(_)) => Some(format!("VML mirror {field_name} is absent for {property}")),
            (Some(_), None) => None,
            (Some(field), Some(expected)) => match vml_boolean(field) {
                Some(actual) if actual == expected => None,
                Some(_) => Some(format!(
                    "VML mirror {field_name} disagrees with x14 {property}"
                )),
                None => Some(format!(
                    "VML mirror {field_name} has an unknown boolean token"
                )),
            },
            (None, None) => None,
        }
    };
    if let Some(detail) = detail {
        push_mirror_diagnostic(diagnostics, detail.into())?;
    }
    Ok(())
}

fn check_vml_formula(
    diagnostics: &mut Vec<FormControlDiagnostic>,
    shape: &VmlShape,
    field_name: &str,
    expected: Option<&super::FormControlFormula>,
    property: &str,
) -> OwnerResult<()> {
    check_vml_lexical(
        diagnostics,
        shape,
        field_name,
        expected.map(super::FormControlFormula::as_str),
        false,
        property,
    )
}

fn check_vml_token<T: std::fmt::Display>(
    diagnostics: &mut Vec<FormControlDiagnostic>,
    shape: &VmlShape,
    field_name: &str,
    expected: Option<&super::KnownOrUnknown<T>>,
    property: &str,
) -> OwnerResult<()> {
    let expected = expected.and_then(|value| match value {
        super::KnownOrUnknown::Known(value) => Some(value.to_string()),
        super::KnownOrUnknown::Unknown(_) => None,
    });
    let (field, duplicate) = vml_field(shape, field_name);
    let detail = if duplicate {
        Some(format!(
            "VML mirror {field_name} occurs more than once for {property}"
        ))
    } else {
        match (field, expected.as_deref()) {
            (None, Some(_)) => Some(format!("VML mirror {field_name} is absent for {property}")),
            (None, None) | (Some(_), None) => None,
            (Some(field), Some(expected)) if !field.value.eq_ignore_ascii_case(expected) => Some(
                format!("VML mirror {field_name} disagrees with x14 {property}"),
            ),
            _ => None,
        }
    };
    if let Some(detail) = detail {
        push_mirror_diagnostic(diagnostics, detail.into())?;
    }
    Ok(())
}

fn check_vml_items(
    diagnostics: &mut Vec<FormControlDiagnostic>,
    shape: &VmlShape,
    list: Option<&super::ItemList>,
) -> OwnerResult<()> {
    let vml_items: Vec<&VmlField> = shape
        .client_fields
        .iter()
        .filter(|field| field.name == "ListItem")
        .collect();
    match (list, vml_items.is_empty()) {
        (None, true) => {},
        (None, false) => {},
        (Some(_), true) => push_mirror_diagnostic(
            diagnostics,
            "VML ListItem sequence is absent for x14 itemLst".into(),
        )?,
        (Some(list), false) => {
            if list.items().len() != vml_items.len()
                || list
                    .items()
                    .iter()
                    .zip(vml_items)
                    .any(|(item, field)| item.value() != field.value)
            {
                push_mirror_diagnostic(
                    diagnostics,
                    "VML ListItem sequence disagrees with x14 itemLst".into(),
                )?;
            }
        },
    }
    Ok(())
}

fn vml_boolean(field: &VmlField) -> Option<bool> {
    if field.empty || field.value.is_empty() {
        return Some(true);
    }
    match field.value.as_str() {
        "1" | "true" | "True" | "TRUE" | "t" | "T" | "on" | "On" | "ON" => Some(true),
        "0" | "false" | "False" | "FALSE" | "f" | "F" | "off" | "Off" | "OFF" => Some(false),
        _ => None,
    }
}

fn push_mirror_diagnostic(
    diagnostics: &mut Vec<FormControlDiagnostic>,
    detail: Box<str>,
) -> OwnerResult<()> {
    diagnostics
        .try_reserve(1)
        .map_err(|source| owner_alloc("VML mirror diagnostics", source))?;
    diagnostics.push(FormControlDiagnostic::new(
        FormControlDiagnosticCode::UnprovenMirror,
        detail,
    ));
    Ok(())
}

fn match_vml<'a>(
    shapes: &'a [VmlShape],
    index: &VmlIdentityIndex,
    drawing: &DrawingShape,
    _expected_type: Option<&str>,
    control_name: Option<&str>,
) -> OwnerResult<&'a VmlShape> {
    if index.mismatched.contains(&drawing.id) {
        return Err(owner_invalid("VML id and o:spid disagree"));
    }
    let shape = match index.by_numeric.get(&drawing.id) {
        Some(Some(position)) => shapes
            .get(*position)
            .ok_or_else(|| owner_invalid("VML identity index is inconsistent"))?,
        Some(None) => {
            return Err(owner_invalid(
                "VML control shape identity is missing or ambiguous",
            ));
        },
        None => {
            return Err(owner_invalid(
                "VML control shape identity is missing or ambiguous",
            ));
        },
    };
    if numeric_spid(&shape.id).is_none() {
        let Some(control_name) = control_name else {
            return Err(owner_invalid("nonnumeric VML identity has no control name"));
        };
        if decode_object_name(&shape.id)? != control_name {
            return Err(owner_invalid(
                "nonnumeric VML identity disagrees with control name",
            ));
        }
    }
    Ok(shape)
}

fn numeric_spid(value: &str) -> Option<u64> {
    let suffix = value.strip_prefix("_x0000_s")?;
    if suffix.is_empty() || !suffix.bytes().all(|byte| byte.is_ascii_digit()) {
        return None;
    }
    let number = suffix.parse().ok()?;
    (MIN_SP_ID..=MAX_SP_ID).contains(&number).then_some(number)
}

fn decode_object_name(value: &str) -> OwnerResult<String> {
    let mut output = String::new();
    let bytes = value.as_bytes();
    let mut index = 0;
    while index < bytes.len() {
        if bytes[index..].starts_with(b"_x005F_x") {
            if index + 13 > bytes.len() {
                return Err(owner_invalid(
                    "VML object name has malformed protected escape",
                ));
            }
            let digits = &bytes[index + 8..index + 12];
            if !digits.iter().all(|byte| byte.is_ascii_hexdigit()) || bytes[index + 12] != b'_' {
                return Err(owner_invalid(
                    "VML object name has malformed protected escape",
                ));
            }
            output.push_str("_x");
            output.push_str(
                std::str::from_utf8(digits)
                    .map_err(|_| owner_invalid("VML object name escape is not ASCII"))?,
            );
            output.push('_');
            index += 13;
            continue;
        }
        if bytes[index..].starts_with(b"_x") {
            if index + 7 > bytes.len() || bytes[index + 6] != b'_' {
                return Err(owner_invalid("VML object name has malformed escape"));
            }
            let digits = &bytes[index + 2..index + 6];
            if !digits.iter().all(|byte| byte.is_ascii_hexdigit()) {
                return Err(owner_invalid("VML object name has malformed escape"));
            }
            let value = u16::from_str_radix(
                std::str::from_utf8(digits)
                    .map_err(|_| owner_invalid("VML object name escape is not ASCII"))?,
                16,
            )
            .map_err(|_| owner_invalid("VML object name escape is invalid"))?;
            if (0xD800..=0xDFFF).contains(&value) {
                return Err(owner_invalid(
                    "VML object name escape is an unpaired surrogate",
                ));
            }
            output.push(
                char::from_u32(value as u32)
                    .ok_or_else(|| owner_invalid("VML object name escape is invalid Unicode"))?,
            );
            index += 7;
            continue;
        }
        let character = value[index..]
            .chars()
            .next()
            .ok_or_else(|| owner_invalid("VML object name is not UTF-8"))?;
        output.push(character);
        index += character.len_utf8();
    }
    Ok(output)
}

fn attr_unqualified(
    element: &BytesStart<'_>,
    wanted: &[u8],
    resolver: &quick_xml::name::NamespaceResolver,
    decoder: quick_xml::encoding::Decoder,
) -> OwnerResult<Option<String>> {
    for attribute in element.attributes().with_checks(false) {
        let attribute = attribute.map_err(|error| owner_invalid(error.to_string()))?;
        let (namespace, local) = resolver.resolve_attribute(attribute.key);
        if matches!(namespace, ResolveResult::Unbound) && local.as_ref() == wanted {
            return Ok(Some(decode_attribute(attribute.value.as_ref(), decoder)?));
        }
    }
    Ok(None)
}

fn attr_qualified(
    element: &BytesStart<'_>,
    wanted_ns: &[u8],
    wanted_local: &[u8],
    resolver: &quick_xml::name::NamespaceResolver,
    decoder: quick_xml::encoding::Decoder,
) -> OwnerResult<Option<String>> {
    for attribute in element.attributes().with_checks(false) {
        let attribute = attribute.map_err(|error| owner_invalid(error.to_string()))?;
        let (namespace, local) = resolver.resolve_attribute(attribute.key);
        if matches!(namespace, ResolveResult::Bound(Namespace(value)) if value == wanted_ns)
            && local.as_ref() == wanted_local
        {
            return Ok(Some(decode_attribute(attribute.value.as_ref(), decoder)?));
        }
    }
    Ok(None)
}

fn namespace_bytes(namespace: ResolveResult<'_>) -> Vec<u8> {
    match namespace {
        ResolveResult::Bound(Namespace(value)) => value.as_ref().to_vec(),
        _ => Vec::new(),
    }
}

fn is_ns(namespace: &ResolveResult<'_>, wanted: &[u8]) -> bool {
    matches!(namespace, ResolveResult::Bound(Namespace(value)) if *value == wanted)
}

fn decode_attribute(value: &[u8], decoder: quick_xml::encoding::Decoder) -> OwnerResult<String> {
    let decoded = decoder
        .decode(value)
        .map_err(|error| owner_invalid(error.to_string()))?;
    quick_xml::escape::unescape(&decoded)
        .map(|value| value.into_owned())
        .map_err(|error| owner_invalid(error.to_string()))
}

fn bounded_name(
    value: String,
    limits: &OwnerLimits,
    resource: &'static str,
) -> OwnerResult<String> {
    if value.len() > limits.max_name_bytes {
        return Err(owner_limit(resource, value.len(), limits.max_name_bytes));
    }
    Ok(value)
}

fn bounded_display_name(
    value: String,
    limits: &OwnerLimits,
    resource: &'static str,
) -> OwnerResult<String> {
    let value = bounded_name(value, limits, resource)?;
    if value.chars().count() > MAX_AUTHORED_NAME_CHARS {
        return Err(owner_limit(
            resource,
            value.chars().count(),
            MAX_AUTHORED_NAME_CHARS,
        ));
    }
    Ok(value)
}

fn leaf_limits(limits: &OwnerLimits) -> LeafLimits {
    let part_bytes = limits.max_mce_bytes.min(super::MAX_PART_BYTES);
    LeafLimits::new()
        .with_max_part_bytes(part_bytes)
        .with_max_output_bytes(part_bytes)
        .with_max_depth(limits.max_mce_depth)
        .with_max_events(limits.max_mce_events)
        .with_max_items(limits.max_mirror_nodes)
        .with_max_item_value_bytes(part_bytes)
        .with_max_attributes(super::MAX_ATTRIBUTES)
        .with_max_opaque_bytes(limits.max_mce_bytes.min(super::MAX_OPAQUE_BYTES))
        .with_max_retained_bytes(limits.max_mce_bytes.min(super::MAX_RETAINED_BYTES))
}

fn bounded_owned(source: &[u8], maximum: usize, resource: &'static str) -> OwnerResult<Vec<u8>> {
    if source.len() > maximum {
        return Err(owner_limit(resource, source.len(), maximum));
    }
    let mut owned = Vec::new();
    owned
        .try_reserve_exact(source.len())
        .map_err(|source| owner_alloc(resource, source))?;
    owned.extend_from_slice(source);
    Ok(owned)
}

fn owner_invalid(message: impl Into<String>) -> FormControlOwnerError {
    FormControlOwnerError::Invalid(message.into())
}
fn owner_limit(resource: &'static str, observed: usize, maximum: usize) -> FormControlOwnerError {
    FormControlOwnerError::Limit {
        resource,
        observed,
        maximum,
    }
}
fn owner_alloc(
    resource: &'static str,
    source: std::collections::TryReserveError,
) -> FormControlOwnerError {
    FormControlOwnerError::Invalid(format!(
        "could not reserve memory for XLSX form-control owner {resource}: {source}"
    ))
}
