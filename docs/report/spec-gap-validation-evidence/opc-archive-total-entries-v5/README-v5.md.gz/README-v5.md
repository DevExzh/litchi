# OPC `ArchiveTotalEntries` consistency candidate V5

This immutable candidate is based on `02fc6699ec7fee824f0cbb06af284a9387991b6c` and lives at:

`/var/tmp/litchi-opc-archive-total-entries-validation-20260910`

The V4 smoke fixture exposed that eager OPC ingress enforced `ReadLimits::max_archive_total_entries`, while source-backed and metadata-only ingress passed only `ArchiveLimits::max_files` to `IndexedArchive`. `max_files` intentionally excludes ZIP directory records, so a package with five ordinary members and one directory was admitted under a total-entry ceiling of five.

The candidate adds one shared OPC helper. It locates the ZIP EOCD with the existing bounded locator scratch, checks `entries_hint()` against `ReadResource::ArchiveTotalEntries`, and only then invokes `IndexedArchive::from_zip_archive_with_limits`. This makes the check happen before central-directory index, directory, layout, and ordering allocations. The helper is used by ordinary source-backed open, validation source-backed open, and metadata-only probe. Eager ingress keeps its existing preflight.

The focused regression fixture has five ordinary OPC members plus a real `unused/` central-directory entry. Exact maximum six admits through all three ingress paths. Maximum five returns the typed error with `actual=6` and `maximum=5` through all three paths. The V4 deterministic smoke now passes its 22 prior boundaries, the two new V4 resource boundaries, strict builder checks, and byte-exact source XML replacement/addition reopen assertions.

Validation passed:

- OPC all-features package gate: 551 tests total, 550 passed, one pre-existing ignored test, zero failures; five doctests passed.
- Focused `archive_total_entry_limit_is_consistent_across_ingress_paths`: passed.
- Strict all-target/all-feature OPC Clippy and fuzz-bin Clippy: passed.
- Rustdoc warnings, rustfmt check, and `git diff --check`: passed.

The frozen V3 and V4 candidates/evidence were not modified. This candidate has no primary worktree edits, staging, or commit.
