# Portable historical V8 verification

Verified 59 mapped files and all 31 released raw outputs without executing a binary.

The historical 21d5 pooled normal median reduction is 8.460474%; nearest-rank p95/p99 reductions are 7.868794% and 7.515784%.

Allocator counters were checked as operation-scoped metrics; allocator-instrumented elapsed values were excluded from latency. The result is historical to the shared 21d5 pair and makes no later-head claim.
