# Independent review: DOC `RgDofr` body publication candidate

Date: 2026-09-10 UTC
Reviewer: independent `/root/crypto_profile_fix` review

## Verdict

**CLEAR for the bounded DOFR body implementation, with the `FEATURE_MATRIX.md`
backfill kept as a separate documentation batch.** I found no correctness blocker in
the four implementation/test files. The candidate validates and publishes bounded
`Selsf` and `RgDofr` same-length changes through the normal DOC body owner, reopens
the result, preserves exact unknown bytes, and retains source-checked inverse and
stale-source behavior. The required-zero correction is supported by the local
MS-DOC text.

The candidate adds **12** matrix rows, although its manifest/report authority calls
them 11. All 12 rows have the claimed checked-in API/codec evidence, but they are
unrelated DOC backfill. They should be published separately after the count is
reconciled; they are not needed for the DOFR code handoff.

No candidate or primary source files were edited, staged, or committed during this
review.

## Reviewed inputs

- Candidate: `/var/tmp/litchi-doc-body-dofr-candidate-20260910`
- Candidate base/HEAD: `6bba8c3d48fc7d360c50f2fda607afc173e10d98`
- Candidate overlay patch: `/var/tmp/litchi-doc-body-dofr-candidate-20260910.patch`
- Overlay patch SHA-256: `4d2209a6d198ece07612247ff27f5ea89507172739f63d02feaa74aedff7f0ac`
- Candidate review manifest SHA-256: `ba1818d0509212c8ed9b68bbcba00b82a10271758c90d807a4e629476991d052`
- Accepted ADR: `docs/adr/0008-migration-and-verification.md`
  SHA-256: `a62594516b20a0c304d1435894d552e3a3a3f3c1b99305bc26ab0006ab7f63c1`
- Report authority: `/home/zhuhe/code/litchi-spec-gaps/docs/report/spec-gap-implementation-status.md`
  SHA-256: `0da764f51f843b81932a1224be808e01bab035f8d14b3b5de63142f10b872a6c`

The candidate worktree remained:

```
 M crates/litchi-doc/docs/FEATURE_MATRIX.md
 M crates/litchi-doc/src/body_text.rs
 M crates/litchi-doc/src/document/tests.rs
 M crates/litchi-doc/src/parts/dofr.rs
?? review-manifest.json
```

The four dirty source hashes at review time were:

```
a30159b8f11266b2c77b627a906ed774574fdcd1c901bceab285cb1f43d00477  crates/litchi-doc/docs/FEATURE_MATRIX.md
881a60fd96b3869ef631af52230e22dfa1808678918ebe743d72ce551a4b4595  crates/litchi-doc/src/body_text.rs
be0e0fe5fef5e8701a5e04915df30b99ec49f74312ff95f115c14649d4c5a07b  crates/litchi-doc/src/document/tests.rs
ffb96968337c794e8cbcd133687012969eb7147e23c255c81cb2c4fd3d8506d7  crates/litchi-doc/src/parts/dofr.rs
```

## DOFR source review

The local normative sources are `[MS-DOC]/2 Structures/2.5 The File Information
Block.md` §§ `fcWss`/`lcbWss` (lines 1501-1503) and `fcRgDofr`/`lcbRgDofr`
(lines 1980-1982), plus `[MS-DOC]/2 Structures/2.9 Basic Types.md` §§2.9.55-2.9.63
and §2.9.148.

- `DofrArray::parse` treats a zero `lcbRgDofr` as absent, checks the converted
  offset/length with checked addition against the table stream, and caps the
  selected payload at 16 MiB. `parse_bytes` caps record count at 65,536, reserves
  the record metadata fallibly, checks every `cb` range, and retains the exact
  selected bytes only after validation.
- Variable payloads are bounded before indexing: fixed sizes are exact; `Xstz`
  names enforce the 255/258-character limits, exact terminator and payload
  consumption; list-style count/size arithmetic is checked and capped.
- Sequence validation requires a frame-set or list-style root, balances nested
  `Fsnp` markers, associates names/paths with the most recent `Fsn`, and leaves
  unknown record kinds inert and source-preserved. The frame `fUnused1/fUnused2`
  and child-marker unused bits remain retained/ignored as the specification says.
- The dirty `DofrFsnSpbd` check rejects nonzero `fUnused` bits and projects the
  public field as zero. The dirty `Lstsf` check rejects nonzero three-bit
  `fUnused`. This matches the local normative wording: `DofrFsnSpbd.fUnused`
  **MUST be 0 and MUST be ignored** (§2.9.60, lines 5749-5757), and
  `Lstsf.fUnused` **MUST be zero and MUST be ignored** (§2.9.148, lines
  15532-15538). The focused regression covers rejecting invalid bits and accepting
  a valid nonzero `istdList`/`fStyleDef` value with zero reserved bits.
- `DofrArray` record access borrows from its retained source allocation. The
  high-level document accessor attaches the immutable DOC source owner without
  copying the complete CFB artifact. The body transaction only accepts complete
  same-length record replacements, reparses the candidate before installation,
  and keeps failed replacements atomic.

## Body publication/protection review

- The deferred document package captures only each FIB-selected optional range,
  checks its size before allocation, and caches the first malformed-source error
  until the accessor is used. `Snapshot::dofr_records` and `Snapshot::saved_selection`
  attach the exact snapshot owner to source-bound patches.
- Body patch preflight verifies the current FIB-selected range and exact source
  bytes before cloning the table stream. Applying a changed patch changes only
  that range; the normal commit reopens the resulting DOC under the original
  limits and protection policy.
- Exact no-ops return the original bytes and are allowed on signed sources.
  Changed `Selsf`/`RgDofr` patches are refused with `SignedSource`; ordinary body
  publication has the same signed-source guard. Existing protection authorization
  remains in the commit path. The candidate has no dirty changes in crypto,
  protection, `tracked_revision`, or document package ownership code.
- The in-memory `Patch` has exact apply/inverse and intentionally refuses the
  durable semantic envelope for auxiliary edits until a matching binary-table
  vocabulary exists. This is documented and tested; the candidate does not claim
  durable semantic serialization for DOFR/Selsf.
- Unknown auxiliary stream bytes are tested as untouched through publication;
  the body end-to-end test reopens both Selsf and DOFR and checks exact inverse
  restoration. No renderer, frame-file resolution, list-style application, or
  external access is exposed.

## Independent validation

All commands used `+1.95.0`, `TMPDIR=/var/tmp`, `CARGO_BUILD_JOBS=8`, and separate
`CARGO_TARGET_DIR` values. Each command ran in the candidate worktree.

| Result | Command | Log SHA-256 |
|---|---|---|
| PASS (8 tests) | `cargo +1.95.0 test -p litchi-doc --lib parts::dofr::tests -- --nocapture` | `6fcf12711883612e19c08332bd1a2c035379afe0c386805335eb92c1631817a8` |
| PASS (1 test) | `cargo +1.95.0 test -p litchi-doc --lib body_text::tests::auxiliary_tables_publish_through_body_commit_and_reopen -- --nocapture` | `5d51a354d5e1516ce0e04d70d36899057d9878a594d8de72f53809103b51edf9` |
| PASS (13 tests) | `cargo +1.95.0 test -p litchi-doc --test dofr_edits -- --nocapture` | `94f4cc6158695a3ab68a8d7718464095a6dd055af7f8aacaab3b75bfe972dd24` |
| PASS (1 test) | `cargo +1.95.0 test -p litchi-doc --lib document::tests::lazy_auxiliary_tests::malformed_optional_auxiliary_tables_are_deferred_until_access -- --nocapture` | `8828b7cf226b63e24e3892487118cb5459181c979e832dc2669d8b545e5ce16a` |
| PASS (2 tests) | `cargo +1.95.0 test -p litchi-doc --test auxiliary_tables -- --nocapture` | `2f6654a00a191aacf66d8ea5057034eb7cc4a916b1c7c8ce94b393fba977a1f6` |
| PASS (8 tests) | `cargo +1.95.0 test -p litchi-doc --test saved_selection -- --nocapture` | `0869b525b226cc2e46a0215d0f9870c02bfd9e276dceb47c977053dac29f59f8` |

The candidate's supplied manifest also records PASS for the default suite
(1054 unit tests, 14 doctests plus 11 ignored), all-features suite (1071 unit
tests, 14 doctests plus 12 ignored), all-target/all-feature Clippy with
`-D warnings`, warning-denied all-feature rustdoc, manifest-scoped rustfmt, and
`git diff --check`. Their supplied v2 log hashes were retained in the candidate
manifest; this receipt does not relabel those preexisting runs as independent.

## FEATURE_MATRIX backfill review

The dirty matrix insertion contains 12 rows, lines 97-108, not 11:

1. AutoText/attached glossary
2. Word 2003 XML schema references
3. Structured document tags
4. Format consistency checker marks
5. Text Services Framework tables
6. Grammar checker cookies
7. Language auto-detection state
8. Table character cache
9. E-mail revision threading
10. Repair bookmarks
11. Annotation bookmarks
12. Embedded font descriptions

Static source verification found the notes supported as follows:

| Row | Checked-in evidence | Write scope confirmed |
|---|---|---|
| AutoText/glossary | `Document::{glossary_metadata,glossary_item_text,attached_glossary}`, `Writer::{set,clear}_{glossary_metadata,attached_glossary}`, `GlossaryMetadata::to_table_bytes` | New glossary writer output and attached-glossary constraints; no opened-template CRUD |
| XML schema refs | `Document::xml_schemas`, `parts::xml_schemas::{Collection,codec}` with typed URI/name tables | Read-only; no semantic writer |
| Structured tags | `Document::structured_tags`, checked `parts::structured_tags` parser/model | Read-only |
| Format consistency | `Document::format_consistency_marks`, bounded `parts::format_consistency` parser/model | Read-only |
| Text Services | `Document::text_services_tables`, `UimTable`/`UimGuidTable` checked parse and `to_bytes` | Codec serialization only; no package transaction |
| Grammar cookies | `Document::grammar_cookie_tables`, current/legacy cookie parse and `to_bytes` | Codec serialization only; no package transaction |
| Language auto-detection | `Document::proofing_tables().language_detection()`, `ProofingStateTable::to_bytes`, proofing set/remove in the writer model | In-memory/writer table state only; no detection |
| Table character cache | `Document::table_character_cache`, checked `TableCharacterCache::parse_bytes`/`to_bytes` | Codec serialization only; no cache regeneration |
| E-mail revision threading | `Document::rmd_threading`, bounded `DocumentRmdThreading` parser | Read-only; no mail transport/threading writer |
| Repair bookmarks | `Document::repair_bookmarks`, `DocumentRepairBookmarks::to_bytes` for the three parallel tables | Codec serialization only; no repair application |
| Annotation bookmarks | `Document::annotation_bookmarks`, `parts::annotation_bookmarks::{Editor,Transaction,Patch}` and insert/replace/remove/clear tests | Source-checked package CRUD, separate from comment-story rewriting |
| Embedded font descriptions | `Document::embedded_fonts`, bounded `DocumentEmbeddedFonts` parser/model | Read-only descriptions; no font-program handling |

These rows are source-backed, but they are documentation-only and unrelated to
this DOFR implementation. The authority text describes the same set as “11” by
combining “grammar/language tables”; the actual matrix represents grammar and
language as two rows, yielding 12. Reconcile that wording/count and publish the
matrix as a separate docs batch. The DOFR row and the revised unmodeled-table
paragraph can accompany the DOFR implementation once the parent chooses the
commit split.

## Limitations and provenance

The fixtures used by the new tests are synthetic bounded DOC packages assembled by
the repository tests. This review found no native Office DOFR fixture and makes no
native Office or LibreOffice changed-save claim. The candidate preserves the
existing RC4/protection work inherited at its base; it does not add or alter that
feature.

## Receipt integrity

This report was written outside the candidate. `ARTIFACTS.sha256` beside this
report hashes this report, the independent logs, and the reviewed candidate/patch
inputs. Reproduce the hashes with:

```
sha256sum /var/tmp/litchi-doc-body-dofr-review-20260910/REPORT.md
sha256sum -c /var/tmp/litchi-doc-body-dofr-review-20260910/ARTIFACTS.sha256
```
