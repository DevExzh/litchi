# XLSB native data-model inventory receipt (v2 correction)

Date: 2026-09-09 (UTC)

This v2 receipt narrows the conclusion in the original receipt. The original
receipt is preserved byte-for-byte as `RECEIPT-v1.md`, and its source copy is
also available at `/var/tmp/litchi-xlsb-model-inventory-v1-20260909/RECEIPT.md`.

## Scope and source binding

* Repository: `/home/zhuhe/code/litchi-spec-gaps`
* Repository HEAD observed during scan: `5ffc03ebe1bb3ec885210edbb36f0f90e44619e3`
* Corpus roots: `3rdparty/**/*.xlsb`, `test-data/**/*.xlsb`
* Candidate model-validation checkout observed: `/var/tmp/litchi-xlsb-model-validation-20260909`
* Original receipt SHA-256: recorded in `v1-receipt-binding.sha256`.
* BIFF12 scanner: `scan.py`, SHA-256 `053f81862aa26f7cf13df84537a563efd15ec8ad86964ada5ef821638b83fd4a`
* Coverage companion: `coverage.py`, SHA-256 recorded in the v2 manifest.
* Local specification basis: `3rdparty/specs/[MS-XLSB]/2 Structures/2.1 File Structure.md`, `2.3 Record Enumeration.md`, and `2.4 Records.md`; see `spec-notes.md`.

The inventory was read-only. Inputs were opened as ZIP containers and bounded
entries; no input was extracted, imported, or executed. The one non-ZIP input
was recorded and not interpreted as a workbook.

## Commands

```text
python3 /var/tmp/litchi-xlsb-model-inventory-v2-20260909/scan.py \\
  /home/zhuhe/code/litchi-spec-gaps \\
  /var/tmp/litchi-xlsb-model-inventory-v2-20260909

python3 /var/tmp/litchi-xlsb-model-inventory-v2-20260909/coverage.py \\
  /home/zhuhe/code/litchi-spec-gaps \\
  /var/tmp/litchi-xlsb-model-inventory-v2-20260909
```

The scan limits were 128 MiB per archive, 128 MiB per entry, and 512 MiB total
uncompressed entries per archive. The scanner used the local MS-XLSB one/two
byte type and one/four byte continuation-size grammar.

## Correctly scoped result

* XLSB paths inspected: **35**.
* Inspectable ZIP XLSB paths: **34**.
* Non-ZIP/unreadable paths: **1**.
* Unique XLSB archive SHA-256 values: **20**.
* `xl/workbook.bin` present in inspectable ZIPs: **34/34**.
* `xl/workbook.bin` entries decoded completely: **34/34**, totaling 713
  complete BIFF12 records.
* XLSB data-model record hits for IDs 2121–2128 and 2137–2141 in those
  completely decoded workbook entries: **0**.
* XLSB `/xl/model/item.data` entries: **0**.
* XLSX `/xl/model/item.data` entries: **1**; binding is in
  `xlsx-native-model.md`.

Thus, the bounded conclusion is: **no data-model record fixture was found in
the 34 inspectable ZIP XLSB inputs, with complete coverage of their
`xl/workbook.bin` entries.** The one encrypted CFB/OLE2 input was not decoded,
so this inventory makes no claim about whether it contains such records.

## Framing errors and skipped input

The companion scan attempted every bounded `.bin` ZIP entry and records parser
coverage separately. It found 8 non-encrypted framing-error rows across 6
inspectable archive paths:

* 6 rows for `xl/printerSettings/printerSettings1.bin` (three duplicated
  content groups).
* 2 rows for `xl/vbaProject.bin` (one duplicated content group).

These entries are opaque/non-workbook binary parts for this inventory and were
not used to claim complete decoding. They are listed with exact source path,
entry name, and error in `frame-errors.tsv`. The 34 `xl/workbook.bin` entries
had no framing errors and are tabulated with byte counts and decoded-record
counts in `workbook-bin.tsv`. No archive or ZIP entry was skipped for a size
limit.

The single non-ZIP path is
`3rdparty/poi/test-data/spreadsheet/protected_passtika.xlsb`, 14,336 bytes,
SHA-256
`316aafa78433238ea38ecd39be718f3b64a81f54f95fa942a1038104ead99c5e`;
`file` identifies it as `CDFV2 Encrypted` and its leading bytes are the OLE2
compound-file signature. It was not decoded, and no conclusion is drawn from
its contents.

No real XLSB producer fixture was available within the inspectable ZIP inputs,
so no public snapshot/load/edit/save/inverse harness was built against the
candidate checkout. A harness would need to bind a producer XLSB record
sequence first; the existing XLSX model fixture is a separate format and must
not be substituted for that evidence.

## Files

* `RECEIPT-v1.md`: original receipt preserved byte-for-byte.
* `source-manifest.tsv`: every XLSB source path, bytes, and exact SHA-256.
* `scan.log`: per-path container, entry, and model-hit result.
* `inventory.json`: deterministic machine-readable result from the primary
  bounded scan.
* `frame-errors.tsv`: every bounded `.bin` framing error, including the
  encrypted archive as an unreadable-container row.
* `workbook-bin.tsv`: complete `xl/workbook.bin` coverage table.
* `coverage-summary.json`: deterministic companion coverage counts.
* `xlsx-native-model.md`: exact XLSX model-part binding.
* `spec-notes.md`: local Markdown specification references.
* `manifest.sha256`: hashes for all v2 receipt files except the manifest itself.
