# Existing native model fixture (XLSX, not XLSB)

The corpus scan found one `/xl/model/item.data` part, in the XLSX fixture:

* source: `3rdparty/libreoffice-core/sc/qa/unit/data/xlsx/tdf167689_x15_namespace.xlsx`
* archive bytes: `174497`
* archive SHA-256: `b9064db5694c5e60928a7b6732aabf440c7d2f997d907834e38f927342ec8688`
* part: `xl/model/item.data`
* part bytes: `118784`
* part SHA-256: `c0cbb38b2f6dd0163da6be154ab13891d458113d3410fbb07ceab64def71b8d4`

This is the native XLSX/XLDM package fixture used by the existing XLSX model
codec work. It is not an XLSB BIFF12 producer record and is excluded from the
XLSB fixture count.
