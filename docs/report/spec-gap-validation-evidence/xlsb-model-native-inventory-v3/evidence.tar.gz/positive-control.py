#!/usr/bin/env python3
"""Positive and negative framing controls for the bounded XLSB inventory."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

from biff12 import parse_biff12

OUT = Path(__file__).resolve().parent


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def run_case(name: str, data: bytes, *, expected_error: str | None = None, expected_hits: int | None = None, expected_records: int | None = None) -> dict:
    hits, records, error = parse_biff12(data)
    if expected_error is None:
        assert error is None, (name, error)
    else:
        assert error is not None and expected_error in error, (name, error)
    if expected_hits is not None:
        assert len(hits) == expected_hits, (name, hits)
    if expected_records is not None:
        assert records == expected_records, (name, records)
    return {
        "name": name,
        "bytes_hex": data.hex(),
        "bytes": len(data),
        "sha256": digest(data),
        "hits": hits,
        "complete_records": records,
        "error": error,
    }


# 2121 decimal is 0x849: MS-XLSB's two-byte type framing is C9 10.
positive = bytes.fromhex("c9 10 00")
chained = positive + bytes.fromhex("00 02 aa bb")
size_two = bytes.fromhex("00 80 01") + bytes(128)
size_four_terminal = bytes.fromhex("00 80 80 80 80")
results = [
    run_case(
        "BrtBeginDataModel_zero_size",
        positive,
        expected_hits=1,
        expected_records=1,
    ),
    run_case(
        "model_then_one_byte_type_record",
        chained,
        expected_hits=1,
        expected_records=2,
    ),
    run_case(
        "two_byte_size_128_payload",
        size_two,
        expected_hits=0,
        expected_records=1,
    ),
    run_case(
        "fourth_size_byte_is_terminal_high_bit_ignored",
        size_four_terminal,
        expected_hits=0,
        expected_records=1,
    ),
    run_case(
        "truncated_two_byte_type",
        bytes.fromhex("c9"),
        expected_error="truncated record type",
        expected_records=0,
    ),
    run_case(
        "truncated_four_byte_size",
        bytes.fromhex("00 80 80 80"),
        expected_error="truncated record size",
        expected_records=0,
    ),
    run_case(
        "record_data_exceeds_entry",
        bytes.fromhex("00 01"),
        expected_error="record data exceeds entry",
        expected_records=0,
    ),
    run_case(
        "two_byte_type_value_below_128",
        bytes.fromhex("80 00 00"),
        expected_error="record type out of two-byte range",
        expected_records=0,
    ),
]

assert results[0]["hits"] == [
    {"offset": 0, "id": 2121, "name": "BrtBeginDataModel", "size": 0}
]
summary = {
    "spec": "[MS-XLSB] 2.1.4",
    "model_id": 2121,
    "model_name": "BrtBeginDataModel",
    "known_record_bytes_hex": positive.hex(),
    "known_record_type_bytes_hex": "c910",
    "known_record_size_bytes_hex": "00",
    "cases": results,
    "passed": len(results),
}
(OUT / "positive-control.json").write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n")
with (OUT / "positive-control.log").open("w") as f:
    f.write("positive-control=pass\n")
    f.write("known_record=BrtBeginDataModel id=2121 bytes=c9 10 00 hit_count=1 complete_records=1\n")
    f.write("framing=type 1/2 bytes; size 1/4 bytes; fourth size high bit ignored\n")
    for case in results:
        f.write(
            f"case={case['name']} bytes={case['bytes']} complete_records={case['complete_records']} "
            f"hits={len(case['hits'])} error={case['error'] or 'none'}\n"
        )
print(json.dumps({"passed": len(results), "output": str(OUT / "positive-control.json")}, sort_keys=True))
