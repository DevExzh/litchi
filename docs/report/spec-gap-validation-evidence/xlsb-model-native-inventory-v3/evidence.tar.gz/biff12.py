"""Bounded BIFF12 record framing helpers for the local MS-XLSB grammar."""
from __future__ import annotations

MODEL_IDS = {
    2121: "BrtBeginDataModel",
    2122: "BrtEndDataModel",
    2123: "BrtBeginModelTables",
    2124: "BrtEndModelTables",
    2125: "BrtModelTable",
    2126: "BrtBeginModelRelationships",
    2127: "BrtEndModelRelationships",
    2128: "BrtModelRelationship",
    2137: "brtBeginModelTimeGroupings",
    2138: "brtEndModelTimeGroupings",
    2139: "brtBeginModelTimeGrouping",
    2140: "brtEndModelTimeGrouping",
    2141: "brtModelTimeGroupingCalcCol",
}


def read_record_type(data: bytes, pos: int) -> tuple[int, int]:
    """Read the one/two-byte record type from an MS-XLSB record header.

    The low byte's high bit is the two-byte discriminator. The high byte's
    high bit is not part of the value under the specification's seven-low-bit
    definition; exactly two bytes are consumed when the discriminator is set.
    """
    if pos >= len(data):
        raise ValueError(f"truncated record type at {pos}")
    low = data[pos]
    if not low & 0x80:
        return low, pos + 1
    if pos + 1 >= len(data):
        raise ValueError(f"truncated record type at {pos}")
    high = data[pos + 1]
    value = (low & 0x7F) | ((high & 0x7F) << 7)
    if not 128 <= value < 16384:
        raise ValueError(f"record type out of two-byte range at {pos}: {value}")
    return value, pos + 2


def read_record_size(data: bytes, pos: int) -> tuple[int, int]:
    """Read the one-to-four-byte little-endian 7-bit record size.

    The first three bytes use their high bit as a continuation flag. The
    fourth byte is terminal because its high bit is explicitly ignored by
    MS-XLSB 2.1.4.
    """
    value = 0
    shift = 0
    for index in range(4):
        at = pos + index
        if at >= len(data):
            raise ValueError(f"truncated record size at {pos}")
        byte = data[at]
        value |= (byte & 0x7F) << shift
        if index == 3 or not byte & 0x80:
            return value, at + 1
        shift += 7
    raise AssertionError("unreachable")


def parse_biff12(data: bytes) -> tuple[list[dict], int, str | None]:
    """Return model hits, complete record count, and the first framing error."""
    pos = 0
    count = 0
    hits: list[dict] = []
    error = None
    while pos < len(data):
        start = pos
        try:
            record_type, pos = read_record_type(data, pos)
            size, pos = read_record_size(data, pos)
            end = pos + size
            if end > len(data):
                raise ValueError(
                    f"record data exceeds entry ({end} > {len(data)})"
                )
            if record_type in MODEL_IDS:
                hits.append(
                    {
                        "offset": start,
                        "id": record_type,
                        "name": MODEL_IDS[record_type],
                        "size": size,
                    }
                )
            count += 1
            pos = end
        except ValueError as exc:
            error = str(exc)
            break
    return hits, count, error
