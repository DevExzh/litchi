# XLSB native data-model inventory receipt (v3 corrected coverage)

Date: 2026-09-09 (UTC)

This v3 bundle preserves the v1 and v2 receipts and fixes the v2 companion
coverage bug: `workbook_model_hits` is now aggregated from the parsed
`xl/workbook.bin` rows rather than being hardcoded. It also binds one shared
MS-XLSB record-framing parser to the scan, coverage report, and positive
controls.

## Scope and source binding

* Repository: `/home/zhuhe/code/litchi-spec-gaps`
* Repository HEAD observed during this run: `b2e2ff8e1fdabd4ab16a67ddf077e6968bf5e668`
* Corpus roots: `3rdparty/**/*.xlsb`, `test-data/**/*.xlsb`
* Local specification basis: `3rdparty/specs/[MS-XLSB]/2 Structures/2.1 File Structure.md:37-45`, `2.3 Record Enumeration.md:1695-1714`, and the model record sections in `2.4 Records.md`.
* v2 receipt SHA-256: `65e3f2e31fb9db1187a425792c6ac633a4b0e8791b4a4942500131f756321e58`, bound in `v2-receipt-binding.sha256`.
* v1/v2 directories were not modified.

The inventory is read-only. Inputs were opened as ZIP containers and bounded
entries; no input was extracted, imported, or executed. The encrypted CFB/OLE2
input was recorded by path and hash but was not decoded.

## Record framing verification

The shared `biff12.py` parser implements the local grammar:

* record type consumes one byte unless the low byte high bit is set, then
  exactly two bytes are consumed and the seven low bits of each byte form the
  value;
* record size consumes one through four bytes, with continuation high bits on
  the first three bytes; the fourth byte is terminal and its high bit is
  ignored;
* record data must end exactly within the bounded entry before the next record
  begins.

`positive-control.py` passed 8 controls. The explicit known record
`C9 10 00` decodes as type 2121, `BrtBeginDataModel`, with zero-byte data,
one complete record, and one model hit. The controls also cover a chained
record, a two-byte size with 128-byte data, the four-byte size terminal rule,
truncated type/size headers, data overrun, and an invalid two-byte type value.
The exact control outputs and hashes are in `positive-control.json` and
`positive-control.log`.

## Corrected bounded result

* XLSB paths considered: **35**.
* Inspectable ZIP XLSB paths: **34**.
* Non-ZIP/unreadable paths: **1**.
* Unique archive SHA-256 values: **20**.
* Inspectable `xl/workbook.bin` entries: **34/34**.
* Completely decoded `xl/workbook.bin` entries: **34/34**.
* Complete records in those workbook entries: **713**.
* Parsed workbook model-record hits for IDs 2121–2128 and 2137–2141: **0**.
* Corrected aggregated `workbook_model_hits`: **0**.
* Parsed model-record hits across every bounded `.bin` entry: **0**.
* Bound-skipped entries: **0**.

The corrected count did not change numerically because the parsed corpus has no
matching workbook hits; v2's hardcoded zero happened to equal the actual count.
The v3 workbook table has a per-row `model_hits` column and the summary has
per-ID counts, so the zero is now an observed result rather than a constant.
This conclusion is restricted to the 34 inspectable ZIP `xl/workbook.bin`
streams. It makes no claim about the contents of the encrypted CFB/OLE2 input.

## Error and skipped-entry accounting

`skipped-errors.tsv` lists every skipped or error entry. There were no bound
skips. There were 9 error rows:

* 6 inspectable archive paths produced one opaque `printerSettings1.bin`
  framing error each (the two duplicated corpus groups account for the repeated
  source paths).
* The two `testVarious.xlsb` paths each produced one additional
  `xl/vbaProject.bin` framing error; their printer errors are included in the
  six printer rows above.
* `3rdparty/poi/test-data/spreadsheet/protected_passtika.xlsb` is not a ZIP;
  it is the recorded encrypted CFB/OLE2 input and remains unexamined.

The exact source path, entry, and parser error are in `frame-errors.tsv` and
`skipped-errors.tsv`. No `xl/workbook.bin` row had a framing error.

## Commands

```text
python3 /var/tmp/litchi-xlsb-model-inventory-v3-20260909/positive-control.py
python3 /var/tmp/litchi-xlsb-model-inventory-v3-20260909/scan.py \
  /home/zhuhe/code/litchi-spec-gaps \
  /var/tmp/litchi-xlsb-model-inventory-v3-20260909
python3 /var/tmp/litchi-xlsb-model-inventory-v3-20260909/coverage.py \
  /home/zhuhe/code/litchi-spec-gaps \
  /var/tmp/litchi-xlsb-model-inventory-v3-20260909
```

The limits were 128 MiB per archive, 128 MiB per ZIP entry, and 512 MiB total
uncompressed entries per archive.

## Files

* `RECEIPT-v2.md`: v2 receipt copied byte-for-byte; v2 itself is unchanged.
* `v2-receipt-binding.sha256`: binding to the frozen v2 receipt and manifest.
* `biff12.py`: shared bounded record framing and model-ID parser.
* `positive-control.py`, `positive-control.json`, `positive-control.log`: framing and hit-detection controls.
* `scan.py`, `inventory.json`, `scan.log`, `scan.stdout`: primary bounded scan.
* `coverage.py`, `coverage-summary.json`, `coverage.stdout`: corrected aggregation.
* `source-manifest.tsv`: every XLSB source path, byte count, and exact hash.
* `workbook-bin.tsv`: all 35 source rows, including complete record and hit counts.
* `workbook-model-hits.tsv`: parsed workbook model hits; header only because count is zero.
* `frame-errors.tsv`, `skipped-errors.tsv`: complete parser-error and bound-skip accounting.
* `commands.txt`, `run.stdout`: command and machine-readable run output.
* `spec-notes.md`, `xlsx-native-model.md`: local specification and separate XLSX binding notes.
* `manifest.sha256`: hashes for the v3 evidence files except the manifest itself.
