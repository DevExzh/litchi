# Local MS-XLSB basis

The inventory used the Markdown copy of the local specification under
`3rdparty/specs/[MS-XLSB]/`, without reading online material.

* `2 Structures/2.1 File Structure.md:37-45` defines a binary record as record
  type, record size, and record data. The type is a one or two byte value; the
  size is a one to four byte little-endian 7-bit continuation value. The
  scanner implements those bounds and stops on the first malformed/truncated
  frame.
* `2 Structures/2.3 Record Enumeration.md:1695-1714` assigns the data-model
  record IDs: `2121..2128` for the outer/tables/relationships records and
  `2137..2141` for time-grouping records. The scanner searched all bounded
  `.bin` entries in every `.xlsb` ZIP, including (but not limiting itself to)
  `xl/workbook.bin`.
* `2 Structures/2.4 Records.md:3146` and `34586` document
  `BrtBeginDataModel`/`BrtEndDataModel`; sections `2.4.116-2.4.119`,
  `2.4.470-2.4.473`, and `2.4.714-2.4.716` document the model relationship,
  table, and time-grouping records. Their record data was not decoded because
  no corpus record with one of these IDs was found.

The scan was bounded to 128 MiB per archive, 128 MiB per ZIP entry, and 512 MiB
of uncompressed entries per archive. It only used Python's `zipfile` reader and
never extracted, imported, or executed an input file.
