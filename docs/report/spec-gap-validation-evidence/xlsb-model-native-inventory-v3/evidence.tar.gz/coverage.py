#!/usr/bin/env python3
"""Bounded companion coverage report for the XLSB model-record inventory.

This v3 report counts model hits from the parsed workbook.bin rows directly.
It uses the same strict one/two-byte type and one-to-four-byte size framing as
scan.py and positive-control.py, with MS-XLSB's fourth size-byte high bit
ignored.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import sys
import zipfile

from biff12 import MODEL_IDS, parse_biff12

REPO = Path(sys.argv[1]).resolve()
OUT = Path(sys.argv[2]).resolve()
MAX_ARCHIVE = 128 * 1024 * 1024
MAX_ENTRY = 128 * 1024 * 1024
MAX_TOTAL = 512 * 1024 * 1024


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        while True:
            chunk = f.read(1024 * 1024)
            if not chunk:
                return h.hexdigest()
            h.update(chunk)


paths = sorted(
    set(REPO.joinpath("test-data").rglob("*.xlsb"))
    | set(REPO.joinpath("3rdparty").rglob("*.xlsb"))
)
frame: list[tuple[str, str, str]] = []
skipped: list[tuple[str, str, str, str]] = []
work: list[tuple[str, str, int, str, int, str, int, int]] = []
workbook_hits: list[tuple[str, str, int, str, int, str, int, str, int, str]] = []
all_bin_hits = 0

for path in paths:
    rel = str(path.relative_to(REPO))
    archive_sha = sha(path)
    archive_bytes = path.stat().st_size
    if archive_bytes > MAX_ARCHIVE:
        detail = f"archive exceeds bound ({archive_bytes} > {MAX_ARCHIVE})"
        skipped.append((rel, "skipped", "<archive>", detail))
        work.append((rel, archive_sha, archive_bytes, "too-large", 0, detail, 0, 0))
        continue
    workbook_info = None
    workbook_data = None
    try:
        with zipfile.ZipFile(path) as zf:
            infos = sorted(zf.infolist(), key=lambda i: i.filename)
            total = 0
            for info in infos:
                if info.file_size > MAX_ENTRY:
                    detail = f"entry exceeds bound ({info.file_size} > {MAX_ENTRY})"
                    skipped.append((rel, "skipped", info.filename, detail))
                    continue
                if total + info.file_size > MAX_TOTAL:
                    detail = f"archive scan bound reached ({total} + {info.file_size} > {MAX_TOTAL})"
                    skipped.append((rel, "skipped", info.filename, detail))
                    continue
                total += info.file_size
                if info.filename.lower() != "xl/workbook.bin" and not info.filename.lower().endswith(".bin"):
                    continue
                with zf.open(info) as src:
                    data = src.read(MAX_ENTRY + 1)
                if len(data) > MAX_ENTRY:
                    detail = f"entry read exceeds bound ({len(data)} > {MAX_ENTRY})"
                    skipped.append((rel, "skipped", info.filename, detail))
                    continue
                hits, records, error = parse_biff12(data)
                if error:
                    frame.append((rel, info.filename, error))
                    skipped.append((rel, "error", info.filename, error))
                all_bin_hits += len(hits)
                if info.filename.lower() == "xl/workbook.bin":
                    workbook_info = info
                    workbook_data = (data, hits, records, error)
                    for hit in hits:
                        workbook_hits.append(
                            (
                                rel,
                                archive_sha,
                                archive_bytes,
                                info.filename,
                                hit["offset"],
                                hit["id"],
                                hit["name"],
                                hit["size"],
                                records,
                                "" if error is None else error,
                            )
                        )
    except (zipfile.BadZipFile, OSError, RuntimeError) as exc:
        detail = f"{type(exc).__name__}: {exc}"
        frame.append((rel, "<archive>", detail))
        skipped.append((rel, "error", "<archive>", detail))
        work.append((rel, archive_sha, archive_bytes, "unreadable", 0, detail, 0, 0))
        continue
    if workbook_info is None:
        work.append((rel, archive_sha, archive_bytes, "no", 0, "", 0, 0))
    else:
        data, hits, records, error = workbook_data
        work.append(
            (
                rel,
                archive_sha,
                archive_bytes,
                "yes",
                len(data),
                "" if error is None else error,
                records,
                len(hits),
            )
        )

with (OUT / "frame-errors.tsv").open("w") as f:
    f.write("source\tbin_entry\terror\n")
    for row in frame:
        f.write("\t".join(row) + "\n")
with (OUT / "skipped-errors.tsv").open("w") as f:
    f.write("source\tkind\tentry\tdetail\n")
    for row in skipped:
        f.write("\t".join(row) + "\n")
with (OUT / "workbook-bin.tsv").open("w") as f:
    f.write(
        "source\tarchive_sha256\tarchive_bytes\tworkbook_bin\tworkbook_bytes\t"
        "framing_error\tdecoded_records\tmodel_hits\n"
    )
    for row in work:
        f.write("\t".join(map(str, row)) + "\n")
with (OUT / "workbook-model-hits.tsv").open("w") as f:
    f.write(
        "source\tarchive_sha256\tarchive_bytes\tbin_entry\toffset\tid\tname\t"
        "record_size\tdecoded_records\tframing_error\n"
    )
    for row in workbook_hits:
        f.write("\t".join(map(str, row)) + "\n")

id_counts = {str(record_id): 0 for record_id in sorted(MODEL_IDS)}
for row in workbook_hits:
    id_counts[str(row[5])] += 1
summary = {
    "xlsb_paths": len(paths),
    "workbook_rows": len(work),
    "workbook_present": sum(row[3] == "yes" for row in work),
    "workbook_full_decode": sum(row[3] == "yes" and not row[5] for row in work),
    "workbook_model_hits": sum(row[7] for row in work),
    "workbook_model_hit_ids": id_counts,
    "all_bin_model_hits": all_bin_hits,
    "frame_error_rows": len(frame),
    "frame_error_sources": len(set(row[0] for row in frame)),
    "frame_error_entries": len(set((row[0], row[1]) for row in frame)),
    "skipped_error_rows": len(skipped),
    "skipped_rows": sum(row[1] == "skipped" for row in skipped),
    "error_rows": sum(row[1] == "error" for row in skipped),
}
(OUT / "coverage-summary.json").write_text(json.dumps(summary, sort_keys=True, indent=2) + "\n")
print(json.dumps(summary, sort_keys=True))
