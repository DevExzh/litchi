#!/usr/bin/env python3
"""Bounded, read-only XLSB model-record inventory (v3).

The scanner opens ZIP central directories and reads bounded entries. It never
extracts, imports, or executes a corpus file. BIFF12 framing is shared with
coverage.py and positive-control.py and follows local [MS-XLSB] 2.1.4.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import sys
import zipfile

from biff12 import MODEL_IDS, parse_biff12

REPO = Path(sys.argv[1]).resolve()
OUT = Path(sys.argv[2]).resolve()
MAX_ARCHIVE = 128 * 1024 * 1024
MAX_ENTRY = 128 * 1024 * 1024
MAX_TOTAL_ENTRIES = 512 * 1024 * 1024


def sha256_file(path: Path) -> str:
    size = path.stat().st_size
    if size > MAX_ARCHIVE:
        raise ValueError(f"archive exceeds bound ({size} > {MAX_ARCHIVE})")
    h = hashlib.sha256()
    with path.open("rb") as f:
        while True:
            chunk = f.read(1024 * 1024)
            if not chunk:
                return h.hexdigest()
            h.update(chunk)


def bounded_zip_entries(path: Path) -> tuple[dict, list[str]]:
    result = {
        "path": str(path.relative_to(REPO)),
        "bytes": path.stat().st_size,
        "sha256": sha256_file(path),
        "container": "zip",
        "entries": 0,
        "bin_entries": 0,
        "scanned_bytes": 0,
        "model_parts": [],
        "model_records": [],
        "parse_errors": [],
        "skipped_entries": [],
    }
    log: list[str] = []
    if result["bytes"] > MAX_ARCHIVE:
        result["container"] = "too-large"
        result["skipped_entries"].append(
            f"archive exceeds bound ({result['bytes']} > {MAX_ARCHIVE})"
        )
        log.append(f"{result['path']} container=too-large bytes={result['bytes']}")
        return result, log
    try:
        with zipfile.ZipFile(path) as zf:
            infos = sorted(zf.infolist(), key=lambda x: x.filename)
            result["entries"] = len(infos)
            total = 0
            for info in infos:
                if info.file_size > MAX_ENTRY:
                    message = f"entry exceeds bound: {info.filename} ({info.file_size})"
                    result["skipped_entries"].append(message)
                    continue
                if total + info.file_size > MAX_TOTAL_ENTRIES:
                    message = f"archive scan bound reached before: {info.filename}"
                    result["skipped_entries"].append(message)
                    continue
                total += info.file_size
                if not info.filename.lower().endswith(".bin"):
                    continue
                result["bin_entries"] += 1
                with zf.open(info, "r") as src:
                    data = src.read(MAX_ENTRY + 1)
                if len(data) > MAX_ENTRY:
                    result["skipped_entries"].append(
                        f"entry read exceeds bound: {info.filename}"
                    )
                    continue
                result["scanned_bytes"] += len(data)
                hits, records, error = parse_biff12(data)
                if hits:
                    result["model_records"].extend(
                        [{"entry": info.filename, **hit} for hit in hits]
                    )
                if error:
                    result["parse_errors"].append(f"{info.filename}: {error}")
                if info.filename.lower() == "xl/model/item.data":
                    result["model_parts"].append(
                        {
                            "entry": info.filename,
                            "bytes": len(data),
                            "sha256": hashlib.sha256(data).hexdigest(),
                        }
                    )
    except (zipfile.BadZipFile, OSError, RuntimeError) as exc:
        result["container"] = "non-zip-or-unreadable"
        result["error"] = f"{type(exc).__name__}: {exc}"
    if result["model_records"]:
        for hit in result["model_records"]:
            log.append(
                f"{result['path']} entry={hit['entry']} model_record={hit['name']} "
                f"id={hit['id']} offset={hit['offset']} size={hit['size']}"
            )
    else:
        log.append(
            f"{result['path']} container={result['container']} entries={result['entries']} "
            f"bin_entries={result['bin_entries']} model_records=none model_parts="
            f"{len(result['model_parts'])}"
        )
    return result, log


def scan_xlsx(path: Path) -> list[dict]:
    found = []
    if path.stat().st_size > MAX_ARCHIVE:
        return found
    try:
        with zipfile.ZipFile(path) as zf:
            for info in sorted(zf.infolist(), key=lambda x: x.filename):
                if info.file_size > MAX_ENTRY:
                    continue
                if info.filename.lower() != "xl/model/item.data":
                    continue
                with zf.open(info, "r") as src:
                    data = src.read(MAX_ENTRY + 1)
                if len(data) <= MAX_ENTRY:
                    found.append(
                        {
                            "path": str(path.relative_to(REPO)),
                            "archive_bytes": path.stat().st_size,
                            "archive_sha256": sha256_file(path),
                            "entry": info.filename,
                            "bytes": len(data),
                            "sha256": hashlib.sha256(data).hexdigest(),
                        }
                    )
    except (zipfile.BadZipFile, OSError, RuntimeError):
        pass
    return found


xlsb_paths = sorted(
    set(REPO.joinpath("test-data").rglob("*.xlsb"))
    | set(REPO.joinpath("3rdparty").rglob("*.xlsb"))
)
xlsx_paths = sorted(
    set(REPO.joinpath("test-data").rglob("*.xlsx"))
    | set(REPO.joinpath("3rdparty").rglob("*.xlsx"))
)
results = []
log = [
    "scan=read-only bounded ZIP/BIFF12 inventory",
    "record_framing=MS-XLSB 2.1.4: type 1/2 bytes, size 1/4 bytes, fourth size high bit ignored",
    f"xlsb_paths={len(xlsb_paths)} xlsx_paths={len(xlsx_paths)}",
    f"limits=max_archive={MAX_ARCHIVE} max_entry={MAX_ENTRY} max_total_entries={MAX_TOTAL_ENTRIES}",
    "model_record_ids=" + ",".join(f"{key}:{value}" for key, value in sorted(MODEL_IDS.items())),
]
for path in xlsb_paths:
    result, lines = bounded_zip_entries(path)
    results.append(result)
    log.extend(lines)
xlsx_models = []
for path in xlsx_paths:
    xlsx_models.extend(scan_xlsx(path))

inventory = {
    "repo": str(REPO),
    "limits": {
        "max_archive_bytes": MAX_ARCHIVE,
        "max_entry_bytes": MAX_ENTRY,
        "max_total_entry_bytes": MAX_TOTAL_ENTRIES,
    },
    "record_framing": {
        "spec": "[MS-XLSB] 2.1.4",
        "type_bytes": "one_or_two",
        "size_bytes": "one_to_four",
        "size_fourth_high_bit": "ignored",
    },
    "model_record_ids": MODEL_IDS,
    "xlsb_path_count": len(xlsb_paths),
    "xlsb_results": results,
    "xlsx_path_count": len(xlsx_paths),
    "xlsx_model_parts": xlsx_models,
}
OUT.mkdir(parents=True, exist_ok=True)
(OUT / "inventory.json").write_text(json.dumps(inventory, indent=2, sort_keys=True) + "\n")
(OUT / "scan.log").write_text("\n".join(log) + "\n")
with (OUT / "source-manifest.tsv").open("w") as f:
    for result in results:
        f.write(f"{result['sha256']}\t{result['bytes']}\t{result['path']}\n")
print(json.dumps({
    "xlsb_paths": len(xlsb_paths),
    "valid_zip_paths": sum(r["container"] == "zip" for r in results),
    "non_zip_paths": sum(r["container"] != "zip" for r in results),
    "model_record_hits": sum(len(r["model_records"]) for r in results),
    "model_parts_in_xlsb": sum(len(r["model_parts"]) for r in results),
    "xlsx_model_parts": len(xlsx_models),
    "skipped_entries": sum(len(r["skipped_entries"]) for r in results),
    "parse_error_entries": sum(len(r["parse_errors"]) for r in results),
    "output": str(OUT),
}, sort_keys=True))
