
#[test]
fn cache_layout_probe() {
    println!("LAYOUT Complex={} DemandCacheValue={} DemandCacheEntry={}",
        size_of::<super::super::complex::Complex>(),
        size_of::<super::DemandCacheValue>(), size_of::<super::DemandCacheEntry>());
}
