//! Typed, inert ODF drawing fill-image resources.

use base64::Engine as _;
use base64::engine::general_purpose::STANDARD as BASE64_STANDARD;
use litchi_core::{Error, Result};
use quick_xml::XmlVersion;
use quick_xml::events::{BytesStart, Event};
use quick_xml::name::ResolveResult;
use quick_xml::reader::NsReader;
use std::collections::{HashMap, HashSet};
use std::fmt;
use std::str::FromStr;

const OFFICE_NS: &[u8] = b"urn:oasis:names:tc:opendocument:xmlns:office:1.0";
const DRAW_NS: &[u8] = b"urn:oasis:names:tc:opendocument:xmlns:drawing:1.0";
const SVG_NS: &[u8] = b"urn:oasis:names:tc:opendocument:xmlns:svg-compatible:1.0";
const XLINK_NS: &[u8] = b"http://www.w3.org/1999/xlink";
const MAX_XML_BYTES: usize = 64 * 1_048_576;
const MAX_DEPTH: usize = 256;
const MAX_IMAGES: usize = 65_536;
const MAX_VALUE_BYTES: usize = 65_536;
const MAX_ENCODED_BYTES: usize = 24 * 1_048_576;
const MAX_INLINE_BYTES: usize = 16 * 1_048_576;
const MAX_TOTAL_INLINE_BYTES: usize = 64 * 1_048_576;
const MAX_AGGREGATE_BYTES: usize = 96 * 1_048_576;

/// Unit for an optional fill-image intrinsic size.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
#[non_exhaustive]
pub enum LengthUnit {
    Centimeter,
    Millimeter,
    Inch,
    Point,
    Pica,
    Pixel,
}

impl LengthUnit {
    const fn suffix(self) -> &'static str {
        match self {
            Self::Centimeter => "cm",
            Self::Millimeter => "mm",
            Self::Inch => "in",
            Self::Point => "pt",
            Self::Pica => "pc",
            Self::Pixel => "px",
        }
    }
}

/// A finite, nonnegative ODF length.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct Length {
    value: f64,
    unit: LengthUnit,
}

impl Length {
    ///
    /// # Errors
    ///
    /// Returns an error if `value` is non-finite or negative.
    pub fn new(value: f64, unit: LengthUnit) -> Result<Self> {
        if !value.is_finite() || value < 0.0 {
            return invalid("fill-image length must be finite and nonnegative");
        }
        Ok(Self { value, unit })
    }

    #[must_use]
    pub const fn value(self) -> f64 {
        self.value
    }

    #[must_use]
    pub const fn unit(self) -> LengthUnit {
        self.unit
    }
}

impl FromStr for Length {
    type Err = Error;

    fn from_str(value: &str) -> Result<Self> {
        let (number_text, unit) = split_length(value)?;
        validate_decimal(number_text, value)?;
        let number = number_text
            .parse::<f64>()
            .map_err(|error| make_error(format!("invalid fill-image length '{value}': {error}")))?;
        Self::new(number, unit)
    }
}

impl fmt::Display for Length {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(
            formatter,
            "{}{}",
            canonical_number(self.value),
            self.unit.suffix()
        )
    }
}

/// Whether an inert href is a safe relative package path.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
#[non_exhaustive]
pub enum LinkKind {
    PackagePart,
    InertExternal,
}

/// A retained link which is never automatically dereferenced.
#[derive(Clone, Debug, PartialEq, Eq, Hash)]
pub struct Link {
    href: String,
    kind: LinkKind,
}

impl Link {
    ///
    /// # Errors
    ///
    /// Returns an error if the href is too large or contains prohibited text.
    pub fn new(href: impl Into<String>) -> Result<Self> {
        let link_href = href.into();
        validate_text(&link_href, "xlink:href", true, MAX_VALUE_BYTES)?;
        let kind = if safe_package_path(&link_href) {
            LinkKind::PackagePart
        } else {
            LinkKind::InertExternal
        };
        Ok(Self {
            href: link_href,
            kind,
        })
    }

    #[must_use]
    pub fn href(&self) -> &str {
        &self.href
    }

    #[must_use]
    pub const fn kind(&self) -> LinkKind {
        self.kind
    }

    #[must_use]
    pub fn package_path(&self) -> Option<&str> {
        (self.kind == LinkKind::PackagePart).then_some(&self.href)
    }
}

/// The source of a fill-image resource.
#[derive(Clone, Debug, PartialEq, Eq)]
#[non_exhaustive]
pub enum Source {
    Linked(Link),
    Inline {
        bytes: Vec<u8>,
        /// ODF consumers ignore this link when inline data is present.
        ignored_link: Option<Link>,
    },
}

impl Source {
    #[must_use]
    pub fn inline_bytes(&self) -> Option<&[u8]> {
        match self {
            Self::Inline { bytes, .. } => Some(bytes),
            Self::Linked(_) => None,
        }
    }

    #[must_use]
    pub fn link(&self) -> Option<&Link> {
        match self {
            Self::Linked(link) => Some(link),
            Self::Inline { ignored_link, .. } => ignored_link.as_ref(),
        }
    }
}

/// The only schema-defined `xlink:show` mode for fill images.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub enum Show {
    Embed,
}

/// The only schema-defined `xlink:actuate` mode for fill images.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub enum Actuate {
    OnLoad,
}

/// One named `draw:fill-image` resource.
#[derive(Clone, Debug, PartialEq)]
pub struct Image {
    pub name: String,
    pub display_name: Option<String>,
    pub width: Option<Length>,
    pub height: Option<Length>,
    pub source: Source,
    pub show: Option<Show>,
    pub actuate: Option<Actuate>,
}

impl Image {
    ///
    /// # Errors
    ///
    /// Returns an error if the image has invalid metadata, an invalid source,
    /// or exceeds an inline-data limit.
    pub fn validate(&self) -> Result<()> {
        validate_text(&self.name, "draw:name", false, MAX_VALUE_BYTES)?;
        if let Some(display_name) = &self.display_name {
            validate_text(display_name, "draw:display-name", true, MAX_VALUE_BYTES)?;
        }
        for length in [self.width, self.height].into_iter().flatten() {
            Length::new(length.value, length.unit)?;
        }
        match &self.source {
            Source::Linked(link) => validate_link(link)?,
            Source::Inline {
                bytes,
                ignored_link,
            } => {
                if bytes.len() > MAX_INLINE_BYTES {
                    return invalid("inline fill image exceeds 16 MiB");
                }
                if let Some(link) = ignored_link {
                    validate_link(link)?;
                } else if self.show.is_some() || self.actuate.is_some() {
                    return invalid("XLink modes require an xlink:href");
                }
            },
        }
        Ok(())
    }

    ///
    /// # Errors
    ///
    /// Returns an error if the image fails validation.
    pub fn to_xml_fragment(&self) -> Result<String> {
        self.validate()?;
        let mut output = String::with_capacity(256 + encoded_size(&self.source));
        write_fill_image(&mut output, self, true);
        Ok(output)
    }
}

/// Ordered fill-image resources from `office:styles`.
#[derive(Clone, Debug, Default, PartialEq)]
pub struct Collection {
    pub images: Vec<Image>,
}

impl Collection {
    #[must_use]
    pub fn get(&self, name: &str) -> Option<&Image> {
        self.images.iter().find(|image| image.name == name)
    }

    ///
    /// # Errors
    ///
    /// Returns an error if a resource is invalid, names are duplicated, or a
    /// bounded aggregate limit is exceeded.
    pub fn validate(&self) -> Result<()> {
        if self.images.len() > MAX_IMAGES {
            return invalid(format!("drawing styles exceed {MAX_IMAGES} fill images"));
        }
        let mut names = HashSet::with_capacity(self.images.len());
        let mut aggregate = 0usize;
        let mut inline_total = 0usize;
        for image in &self.images {
            image.validate()?;
            if !names.insert(image.name.as_str()) {
                return invalid(format!(
                    "duplicate drawing fill-image name '{}'",
                    image.name
                ));
            }
            aggregate = aggregate
                .checked_add(image.name.len())
                .and_then(|size| {
                    size.checked_add(image.display_name.as_ref().map_or(0, String::len))
                })
                .and_then(|size| {
                    size.checked_add(image.source.link().map_or(0, |link| link.href().len()))
                })
                .ok_or_else(|| make_error("fill-image size overflow"))?;
            if let Some(bytes) = image.source.inline_bytes() {
                inline_total = inline_total
                    .checked_add(bytes.len())
                    .ok_or_else(|| make_error("inline fill-image size overflow"))?;
            }
            if aggregate > MAX_AGGREGATE_BYTES || inline_total > MAX_TOTAL_INLINE_BYTES {
                return invalid("fill-image resources exceed aggregate limits");
            }
        }
        Ok(())
    }

    ///
    /// # Errors
    ///
    /// Returns an error if the collection fails validation.
    pub fn to_xml(&self) -> Result<String> {
        self.validate()?;
        let capacity = self.images.iter().fold(256usize, |size, image| {
            size.saturating_add(256 + encoded_size(&image.source))
        });
        let mut output = String::with_capacity(capacity);
        output.push_str(
            r#"<office:styles xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0" xmlns:draw="urn:oasis:names:tc:opendocument:xmlns:drawing:1.0" xmlns:svg="urn:oasis:names:tc:opendocument:xmlns:svg-compatible:1.0" xmlns:xlink="http://www.w3.org/1999/xlink">"#,
        );
        for image in &self.images {
            write_fill_image(&mut output, image, false);
        }
        output.push_str("</office:styles>");
        Ok(output)
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
enum NamespaceKind {
    None,
    Office,
    Draw,
    Svg,
    Xlink,
    Other,
}

#[derive(Clone)]
struct Frame {
    namespace: NamespaceKind,
    local: String,
}

struct FillBuilder {
    parent_depth: usize,
    name: String,
    display_name: Option<String>,
    width: Option<Length>,
    height: Option<Length>,
    link: Option<Link>,
    show: Option<Show>,
    actuate: Option<Actuate>,
    binary_present: bool,
    binary_parent_depth: Option<usize>,
    encoded: String,
}

type Attributes = HashMap<(NamespaceKind, String), String>;

/// Parse `draw:fill-image` resources from a styles or flat-document XML part.
///
/// # Errors
///
/// Returns an error if the XML is malformed, uses invalid namespaced content,
/// or violates a fill-image resource bound.
pub fn parse_drawing_fill_images(xml: &str) -> Result<Collection> {
    if !xml.contains("fill-image") {
        return Ok(Collection::default());
    }
    if xml.len() > MAX_XML_BYTES {
        return invalid("drawing fill-image XML exceeds 64 MiB");
    }
    let mut reader = NsReader::from_str(xml);
    reader.config_mut().check_end_names = true;
    let mut buffer = Vec::new();
    let mut stack = Vec::<Frame>::new();
    let mut active: Option<FillBuilder> = None;
    let mut result = Collection::default();
    let mut aggregate = 0usize;
    let mut inline_total = 0usize;

    loop {
        let (resolved, event) = reader
            .read_resolved_event_into(&mut buffer)
            .map_err(|error| make_error(format!("invalid drawing fill-image XML: {error}")))?;
        let namespace = namespace_kind(&resolved)?;
        match event {
            Event::Start(ref element) => {
                let local = decode(element.local_name().as_ref(), "element name")?;
                reject_spoofed_name(namespace, &local)?;
                if let Some(fill) = active.as_mut() {
                    if fill.binary_parent_depth.is_some()
                        || namespace != NamespaceKind::Office
                        || local != "binary-data"
                        || stack.len() != fill.parent_depth + 1
                    {
                        return invalid("draw:fill-image contains an unsupported child element");
                    }
                    if fill.binary_present || element.attributes().next().is_some() {
                        return invalid("invalid or duplicate office:binary-data element");
                    }
                    fill.binary_present = true;
                    fill.binary_parent_depth = Some(stack.len());
                } else if namespace == NamespaceKind::Draw && local == "fill-image" {
                    ensure_location(&stack)?;
                    ensure_count(result.images.len())?;
                    active = Some(parse_fill_start(
                        &reader,
                        element,
                        stack.len(),
                        &mut aggregate,
                    )?);
                }
                stack.push(Frame { namespace, local });
                if stack.len() > MAX_DEPTH {
                    return invalid(format!("fill-image XML exceeds {MAX_DEPTH} levels"));
                }
            },
            Event::Empty(ref element) => {
                let local = decode(element.local_name().as_ref(), "element name")?;
                reject_spoofed_name(namespace, &local)?;
                if let Some(fill) = active.as_mut() {
                    if fill.binary_parent_depth.is_some()
                        || namespace != NamespaceKind::Office
                        || local != "binary-data"
                        || stack.len() != fill.parent_depth + 1
                        || fill.binary_present
                        || element.attributes().next().is_some()
                    {
                        return invalid("draw:fill-image contains an unsupported child element");
                    }
                    fill.binary_present = true;
                } else if namespace == NamespaceKind::Draw && local == "fill-image" {
                    ensure_location(&stack)?;
                    ensure_count(result.images.len())?;
                    let builder = parse_fill_start(&reader, element, stack.len(), &mut aggregate)?;
                    result.images.push(finish_fill(builder, &mut inline_total)?);
                }
            },
            Event::End(_) => {
                let frame = stack
                    .pop()
                    .ok_or_else(|| make_error("fill-image XML depth underflow"))?;
                if let Some(fill) = active.as_mut()
                    && fill.binary_parent_depth == Some(stack.len())
                {
                    if frame.namespace != NamespaceKind::Office || frame.local != "binary-data" {
                        return invalid("unexpected office:binary-data end element");
                    }
                    fill.binary_parent_depth = None;
                } else if active
                    .as_ref()
                    .is_some_and(|fill| fill.parent_depth == stack.len())
                {
                    if frame.namespace != NamespaceKind::Draw || frame.local != "fill-image" {
                        return invalid("unexpected draw:fill-image end element");
                    }
                    let fill = active.take().ok_or_else(|| {
                        make_error("drawing fill-image ended without an active definition")
                    })?;
                    result.images.push(finish_fill(fill, &mut inline_total)?);
                }
            },
            Event::Text(ref text) if active.is_some() => {
                let value = text
                    .xml_content(XmlVersion::Explicit1_0)
                    .map_err(|error| make_error(format!("invalid fill-image text: {error}")))?;
                if active
                    .as_ref()
                    .and_then(|fill| fill.binary_parent_depth)
                    .is_some()
                {
                    let fill = active.as_mut().ok_or_else(|| {
                        make_error("office:binary-data text appeared without an active fill image")
                    })?;
                    append_base64(fill, &value, &mut aggregate)?;
                } else if !value.chars().all(char::is_whitespace) {
                    return invalid("draw:fill-image may contain only office:binary-data");
                }
            },
            Event::CData(ref cdata)
                if active
                    .as_ref()
                    .and_then(|fill| fill.binary_parent_depth)
                    .is_some() =>
            {
                let value = cdata
                    .xml_content(XmlVersion::Explicit1_0)
                    .map_err(|error| make_error(format!("invalid fill-image CDATA: {error}")))?;
                let fill = active.as_mut().ok_or_else(|| {
                    make_error("office:binary-data CDATA appeared without an active fill image")
                })?;
                append_base64(fill, &value, &mut aggregate)?;
            },
            Event::CData(_) | Event::GeneralRef(_) if active.is_some() => {
                return invalid("draw:fill-image contains unsupported character data");
            },
            Event::DocType(_) | Event::PI(_) => {
                return invalid("DTDs and processing instructions are prohibited in fill images");
            },
            Event::Eof => break,
            Event::Text(_)
            | Event::CData(_)
            | Event::Comment(_)
            | Event::Decl(_)
            | Event::GeneralRef(_) => {},
        }
        buffer.clear();
    }
    if !stack.is_empty() || active.is_some() {
        return invalid("unterminated drawing fill-image XML");
    }
    result.validate()?;
    Ok(result)
}

fn parse_fill_start(
    reader: &NsReader<&[u8]>,
    element: &BytesStart<'_>,
    parent_depth: usize,
    aggregate: &mut usize,
) -> Result<FillBuilder> {
    let mut values = attributes(reader, element, aggregate)?;
    let name = required(&mut values, NamespaceKind::Draw, "name", "draw:name")?;
    let display_name = take(&mut values, NamespaceKind::Draw, "display-name");
    let width = take(&mut values, NamespaceKind::Svg, "width")
        .map(|value| value.parse())
        .transpose()?;
    let height = take(&mut values, NamespaceKind::Svg, "height")
        .map(|value| value.parse())
        .transpose()?;
    let href = take(&mut values, NamespaceKind::Xlink, "href");
    let link_type = take(&mut values, NamespaceKind::Xlink, "type");
    let show = take(&mut values, NamespaceKind::Xlink, "show")
        .map(|value| match value.as_str() {
            "embed" => Ok(Show::Embed),
            _ => invalid(format!("unsupported xlink:show '{value}'")),
        })
        .transpose()?;
    let actuate = take(&mut values, NamespaceKind::Xlink, "actuate")
        .map(|value| match value.as_str() {
            "onLoad" => Ok(Actuate::OnLoad),
            _ => invalid(format!("unsupported xlink:actuate '{value}'")),
        })
        .transpose()?;
    reject_attributes(&values)?;
    let link = href.map(Link::new).transpose()?;
    match (&link, link_type.as_deref()) {
        (Some(_), Some("simple")) => {},
        (Some(_), _) => return invalid("linked fill image requires xlink:type='simple'"),
        (None, None) if show.is_none() && actuate.is_none() => {},
        (None, _) => return invalid("XLink attributes require xlink:href"),
    }
    Ok(FillBuilder {
        parent_depth,
        name,
        display_name,
        width,
        height,
        link,
        show,
        actuate,
        binary_present: false,
        binary_parent_depth: None,
        encoded: String::new(),
    })
}

fn finish_fill(builder: FillBuilder, inline_total: &mut usize) -> Result<Image> {
    let source = if builder.binary_present {
        let bytes = BASE64_STANDARD
            .decode(builder.encoded.as_bytes())
            .map_err(|error| make_error(format!("invalid fill-image base64 data: {error}")))?;
        if bytes.len() > MAX_INLINE_BYTES {
            return invalid("inline fill image exceeds 16 MiB");
        }
        *inline_total = inline_total
            .checked_add(bytes.len())
            .ok_or_else(|| make_error("inline fill-image size overflow"))?;
        if *inline_total > MAX_TOTAL_INLINE_BYTES {
            return invalid("inline fill images exceed 64 MiB");
        }
        Source::Inline {
            bytes,
            ignored_link: builder.link,
        }
    } else {
        Source::Linked(
            builder
                .link
                .ok_or_else(|| make_error("fill image requires xlink:href or binary data"))?,
        )
    };
    let image = Image {
        name: builder.name,
        display_name: builder.display_name,
        width: builder.width,
        height: builder.height,
        source,
        show: builder.show,
        actuate: builder.actuate,
    };
    image.validate()?;
    Ok(image)
}

fn append_base64(fill: &mut FillBuilder, value: &str, aggregate: &mut usize) -> Result<()> {
    for byte in value.bytes() {
        if byte.is_ascii_whitespace() {
            continue;
        }
        if !(byte.is_ascii_alphanumeric() || matches!(byte, b'+' | b'/' | b'=')) {
            return invalid("inline fill image contains a non-base64 character");
        }
        fill.encoded.push(char::from(byte));
    }
    if fill.encoded.len() > MAX_ENCODED_BYTES {
        return invalid("encoded inline fill image exceeds 24 MiB");
    }
    *aggregate = aggregate
        .checked_add(value.len())
        .ok_or_else(|| make_error("fill-image aggregate size overflow"))?;
    if *aggregate > MAX_AGGREGATE_BYTES {
        return invalid("fill-image values exceed aggregate limit");
    }
    Ok(())
}

fn attributes(
    reader: &NsReader<&[u8]>,
    element: &BytesStart<'_>,
    aggregate: &mut usize,
) -> Result<Attributes> {
    let mut values = HashMap::new();
    for attribute_result in element.attributes().with_checks(true) {
        let attribute = attribute_result
            .map_err(|error| make_error(format!("invalid fill-image attribute: {error}")))?;
        let (resolved, raw_local) = reader.resolver().resolve_attribute(attribute.key);
        let namespace = namespace_kind(&resolved)?;
        let local = decode(raw_local.as_ref(), "attribute name")?;
        let value = attribute
            .decoded_and_normalized_value(XmlVersion::Explicit1_0, reader.decoder())
            .map_err(|error| make_error(format!("invalid fill-image attribute: {error}")))?
            .into_owned();
        if value.len() > MAX_VALUE_BYTES {
            return invalid("fill-image attribute exceeds 64 KiB");
        }
        *aggregate = aggregate
            .checked_add(value.len())
            .ok_or_else(|| make_error("fill-image aggregate size overflow"))?;
        if *aggregate > MAX_AGGREGATE_BYTES {
            return invalid("fill-image values exceed aggregate limit");
        }
        if values.insert((namespace, local), value).is_some() {
            return invalid("duplicate expanded fill-image attribute");
        }
    }
    Ok(values)
}

fn namespace_kind(resolved: &ResolveResult<'_>) -> Result<NamespaceKind> {
    match resolved {
        ResolveResult::Unbound => Ok(NamespaceKind::None),
        ResolveResult::Bound(namespace) => {
            let bytes: &[u8] = namespace.as_ref();
            Ok(if bytes == OFFICE_NS {
                NamespaceKind::Office
            } else if bytes == DRAW_NS {
                NamespaceKind::Draw
            } else if bytes == SVG_NS {
                NamespaceKind::Svg
            } else if bytes == XLINK_NS {
                NamespaceKind::Xlink
            } else {
                NamespaceKind::Other
            })
        },
        ResolveResult::Unknown(prefix) => invalid(format!(
            "unbound XML namespace prefix '{}'",
            String::from_utf8_lossy(prefix.as_ref())
        )),
    }
}

fn ensure_location(stack: &[Frame]) -> Result<()> {
    if stack
        .last()
        .is_some_and(|frame| frame.namespace == NamespaceKind::Office && frame.local == "styles")
    {
        Ok(())
    } else {
        invalid("draw:fill-image must be a direct child of office:styles")
    }
}

fn ensure_count(count: usize) -> Result<()> {
    if count >= MAX_IMAGES {
        invalid(format!("drawing styles exceed {MAX_IMAGES} fill images"))
    } else {
        Ok(())
    }
}

fn reject_spoofed_name(namespace: NamespaceKind, local: &str) -> Result<()> {
    if local == "fill-image" && namespace != NamespaceKind::Draw {
        return invalid("fill-image element uses the wrong namespace");
    }
    if local == "binary-data" && namespace != NamespaceKind::Office {
        return invalid("binary-data element uses the wrong namespace");
    }
    Ok(())
}

fn take(values: &mut Attributes, namespace: NamespaceKind, local: &str) -> Option<String> {
    values.remove(&(namespace, local.to_owned()))
}

fn required(
    values: &mut Attributes,
    namespace: NamespaceKind,
    local: &str,
    qualified: &str,
) -> Result<String> {
    take(values, namespace, local)
        .ok_or_else(|| make_error(format!("missing required {qualified} attribute")))
}

fn reject_attributes(values: &Attributes) -> Result<()> {
    if let Some(((namespace, local), _)) = values.iter().next() {
        return invalid(format!(
            "unsupported fill-image attribute {namespace:?}:{local}"
        ));
    }
    Ok(())
}

fn validate_link(link: &Link) -> Result<()> {
    validate_text(link.href(), "xlink:href", true, MAX_VALUE_BYTES)?;
    if link.kind
        != if safe_package_path(link.href()) {
            LinkKind::PackagePart
        } else {
            LinkKind::InertExternal
        }
    {
        return invalid("fill-image link classification is inconsistent");
    }
    Ok(())
}

fn safe_package_path(value: &str) -> bool {
    !value.is_empty()
        && !value.starts_with('/')
        && !value.starts_with('\\')
        && !value.contains(['\\', '?', '#', '%', ':'])
        && !value.chars().any(char::is_control)
        && value
            .split('/')
            .all(|segment| !segment.is_empty() && segment != "." && segment != "..")
}

fn split_length(value: &str) -> Result<(&str, LengthUnit)> {
    for (suffix, unit) in [
        ("cm", LengthUnit::Centimeter),
        ("mm", LengthUnit::Millimeter),
        ("in", LengthUnit::Inch),
        ("pt", LengthUnit::Point),
        ("pc", LengthUnit::Pica),
        ("px", LengthUnit::Pixel),
    ] {
        if let Some(number) = value.strip_suffix(suffix) {
            return Ok((number, unit));
        }
    }
    invalid(format!(
        "fill-image length lacks a supported unit: '{value}'"
    ))
}

fn validate_decimal(number: &str, original: &str) -> Result<()> {
    if number.is_empty()
        || number.starts_with('+')
        || number.starts_with('-')
        || number.chars().any(char::is_whitespace)
        || number.contains(['e', 'E'])
    {
        return invalid(format!("invalid fill-image length '{original}'"));
    }
    let mut parts = number.split('.');
    let integer = parts.next().unwrap_or_default();
    let fraction = parts.next();
    if parts.next().is_some()
        || integer.is_empty()
        || !integer.bytes().all(|byte| byte.is_ascii_digit())
        || fraction
            .is_some_and(|part| part.is_empty() || !part.bytes().all(|byte| byte.is_ascii_digit()))
    {
        return invalid(format!("invalid fill-image length '{original}'"));
    }
    Ok(())
}

fn validate_text(value: &str, name: &str, allow_empty: bool, limit: usize) -> Result<()> {
    if (!allow_empty && value.is_empty()) || value.len() > limit {
        return invalid(format!("invalid {name} length"));
    }
    if value
        .chars()
        .any(|character| character.is_control() && !matches!(character, '\t' | '\n' | '\r'))
    {
        return invalid(format!("{name} contains prohibited control characters"));
    }
    Ok(())
}

fn write_fill_image(output: &mut String, image: &Image, standalone: bool) {
    output.push_str("<draw:fill-image");
    if standalone {
        output.push_str(
            r#" xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0" xmlns:draw="urn:oasis:names:tc:opendocument:xmlns:drawing:1.0" xmlns:svg="urn:oasis:names:tc:opendocument:xmlns:svg-compatible:1.0" xmlns:xlink="http://www.w3.org/1999/xlink""#,
        );
    }
    write_attribute(output, "draw:name", &image.name);
    if let Some(display_name) = &image.display_name {
        write_attribute(output, "draw:display-name", display_name);
    }
    if let Some(width) = image.width {
        write_attribute(output, "svg:width", &width.to_string());
    }
    if let Some(height) = image.height {
        write_attribute(output, "svg:height", &height.to_string());
    }
    if let Some(link) = image.source.link() {
        write_attribute(output, "xlink:type", "simple");
        write_attribute(output, "xlink:href", link.href());
        if image.show.is_some() {
            write_attribute(output, "xlink:show", "embed");
        }
        if image.actuate.is_some() {
            write_attribute(output, "xlink:actuate", "onLoad");
        }
    }
    match &image.source {
        Source::Linked(_) => output.push_str("/>"),
        Source::Inline { bytes, .. } => {
            output.push_str("><office:binary-data>");
            BASE64_STANDARD.encode_string(bytes, output);
            output.push_str("</office:binary-data></draw:fill-image>");
        },
    }
}

fn encoded_size(source: &Source) -> usize {
    source
        .inline_bytes()
        .map_or(0, |bytes| bytes.len().saturating_add(2) / 3 * 4)
}

fn write_attribute(output: &mut String, name: &str, value: &str) {
    output.push(' ');
    output.push_str(name);
    output.push_str("=\"");
    escape_xml(output, value);
    output.push('"');
}

fn escape_xml(output: &mut String, value: &str) {
    for character in value.chars() {
        match character {
            '&' => output.push_str("&amp;"),
            '<' => output.push_str("&lt;"),
            '>' => output.push_str("&gt;"),
            '"' => output.push_str("&quot;"),
            '\'' => output.push_str("&apos;"),
            _ => output.push(character),
        }
    }
}

fn canonical_number(value: f64) -> String {
    if value == 0.0 {
        "0".to_owned()
    } else {
        value.to_string()
    }
}

fn decode(value: &[u8], what: &str) -> Result<String> {
    std::str::from_utf8(value)
        .map(str::to_owned)
        .map_err(|error| make_error(format!("invalid UTF-8 in fill-image {what}: {error}")))
}

fn invalid<T>(message: impl Into<String>) -> Result<T> {
    Err(make_error(message))
}

fn make_error(message: impl Into<String>) -> Error {
    Error::InvalidFormat(message.into())
}
