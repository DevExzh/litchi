//! Unified error types for Litchi library.
//!
//! This module provides a unified error type that encompasses errors from both
//! OLE2 and OOXML parsing, presenting a consistent API to users.
use std::collections::TryReserveError;

use crate::binary::BinaryError;
use crate::xml::CompactnessKind;
use thiserror::Error;

/// Main error type for Litchi operations.
#[derive(Error, Debug)]
#[non_exhaustive]
pub enum Error {
    /// IO error
    #[error("IO error: {0}")]
    Io(#[from] std::io::Error),

    /// Atomic publication replaced its destination, but a later durability
    /// synchronization failed. Callers must not retry as though publication
    /// had not occurred.
    #[error("publication committed but durability synchronization failed: {0}")]
    Committed(#[source] std::io::Error),

    /// Parse error occurred
    #[error("Parse error: {0}")]
    ParseError(String),

    /// Invalid file format
    #[error("Invalid format: {0}")]
    InvalidFormat(String),

    /// File is not a recognized Office format
    #[error("Not a valid Office file")]
    NotOfficeFile,

    /// Corrupted or malformed file
    #[error("Corrupted file: {0}")]
    CorruptedFile(String),

    /// Stream or part not found
    #[error("Component not found: {0}")]
    ComponentNotFound(String),

    /// XML parsing error
    #[error("XML error: {0}")]
    XmlError(String),

    /// XML cannot be represented by a compact parser.
    #[error("compact XML {kind} at byte offset {offset}")]
    XmlCompactness {
        /// Structural cause of the compactness failure.
        kind: CompactnessKind,
        /// Byte offset where the parser observed the failure.
        offset: u64,
    },

    /// Invalid content type
    #[error("Invalid content type: expected {expected}, got {got}")]
    InvalidContentType { expected: String, got: String },

    /// ZIP archive error
    #[error("ZIP error: {0}")]
    ZipError(String),

    /// Unsupported feature
    #[error("Unsupported feature: {0}")]
    Unsupported(String),

    /// Feature disabled at compile time
    #[error("Feature '{0}' is disabled. Enable it with --features {0}")]
    FeatureDisabled(String),

    /// A bounded operation could not reserve its required memory.
    #[error("allocation failed for {resource}: {source}")]
    Allocation {
        /// Resource whose bounded plan could not be reserved.
        resource: &'static str,
        /// Original allocator failure.
        #[source]
        source: TryReserveError,
    },

    /// A finite resource budget was exceeded.
    #[error(transparent)]
    ResourceLimit(#[from] crate::ResourceLimit),

    /// A positional source changed after a caller captured its identity.
    #[error("positional source changed (expected {expected:?}, observed {observed:?})")]
    SourceChanged {
        /// Source identity and revision captured before the operation.
        expected: crate::SourceVersion,
        /// Source identity and revision observed during or after the operation.
        observed: crate::SourceVersion,
    },

    /// Generic error
    #[error("{0}")]
    Other(String),
}

impl From<BinaryError> for Error {
    fn from(err: BinaryError) -> Self {
        Error::ParseError(format!("Binary parsing error: {err}"))
    }
}

/// Result type for Litchi operations.
pub type Result<T> = std::result::Result<T, Error>;
