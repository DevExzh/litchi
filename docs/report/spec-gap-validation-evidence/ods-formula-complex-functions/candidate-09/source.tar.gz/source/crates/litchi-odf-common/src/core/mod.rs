//! Core ODF parsing functionality.
//!
//! This module provides the fundamental building blocks for parsing
//! `OpenDocument` files. It handles ZIP package management, XML parsing,
//! manifest processing, and metadata extraction.
//!
//! # Implementation Progress
//!
//! ## ✅ Package System (`package.rs`) - COMPLETE
//! - ✅ `Package<R>` - Generic ZIP archive reader
//! - ✅ `from_reader()` - Open from any Read + Seek source
//! - ✅ `from_zip_archive()` - Reuse already-parsed ZIP archives
//! - ✅ `mimetype()` - Get MIME type from mimetype file
//! - ✅ `get_file()` - Extract file by path
//! - ✅ `has_file()` - Check file existence
//! - ✅ `files()` - List all files in package
//! - ✅ RefCell-based interior mutability for safe archive access
//!
//! ## ✅ Manifest (`manifest.rs`) - COMPLETE
//! - ✅ `Manifest` parsing from META-INF/manifest.xml
//! - ✅ File entry tracking with media types
//! - ✅ Encryption info parsing (basic)
//! - ✅ Manifest validation
//!
//! ## ✅ XML Processing (`xml.rs`) - COMPLETE
//! - ✅ `Content` - Parse content.xml (main document content)
//! - ✅ `Styles` - Parse styles.xml (document-wide styles)
//! - ✅ `Meta` - Parse meta.xml (metadata)
//! - ✅ `from_bytes()` - Parse from byte buffers
//! - ✅ High-performance quick-xml based parsing
//! - ✅ Namespace-aware processing
//! - ✅ Error handling with detailed messages
//!
//! ## ✅ Package Writing (`writer.rs`) - COMPLETE
//! - ✅ `PackageWriter<W>` - Generic ZIP archive writer
//! - ✅ `new()` / `with_writer()` - Create writers
//! - ✅ `with_writer_and_limits()` - Create bounded sequential writers
//! - ✅ `set_mimetype()` - Set MIME type (stored uncompressed)
//! - ✅ `set_mimetype_streaming()` - Set MIME type with typed sink progress
//! - ✅ `add_file()` - Add files to package
//! - ✅ `add_file_with_media_type()` - Add with manifest entry
//! - ✅ `add_file_reader()` - Stream opaque non-XML members from a reader
//! - ✅ `finish()` / `finish_to_bytes()` - Finalize package
//! - ✅ `finish_to_writer()` - Finalize on a sequential sink
//!
//! Sequential writer limits bound ZIP transport and retained manifest
//! bookkeeping; they do not materialize arbitrary reader payloads in memory.
//! - ✅ Default template generation (content.xml, styles.xml, meta.xml, settings.xml)
//! - ✅ Manifest.xml auto-generation
//!
//! ## ✅ Metadata (`metadata/`) - COMPLETE
//! - ✅ Unified metadata structure
//! - ✅ Dublin Core fields (title, creator, description, etc.)
//! - ✅ ODF-specific fields (editing cycles, generator, etc.)
//! - ✅ Creation and modification timestamps
//!
//! # References
//! - ODF Specification: §2 (Documents), §3 (Metadata)
//! - ODF Toolkit: ODFDOM package classes
//! - ZIP format: PKZIP Application Note

/// Borrowing namespace binding tracking for bounded XML scanners.
mod binding_tracker;
/// Shared content-document validation state machine.
mod content_validation;
/// ODF package-entry decryption.
mod encryption;
/// Shared ownership for simple packaged ODF families.
pub mod family;
/// Bounded publication of provider-authored generated XML members.
mod generated_xml;
/// ODF manifest parsing
mod manifest;
/// ODF metadata parsing
pub mod metadata;
/// ODF package handling
pub mod package;
/// XML event reader with normalized namespace declaration values.
pub mod resolved_reader;
/// Source-backed, content-only raw ZIP publication.
pub mod source_publication;
/// Fixed-window XML scanning for source-backed publication.
mod stream_xml;
/// ODF package writing
pub mod writer;
/// ODF XML utilities
pub mod xml;
/// Provenance-bearing publication of source-preserving XML splices.
pub mod xml_splice;

// Re-export main types for convenience
// Manifest is internal to the package system
pub use crate::package::ArchiveLimits;
/// Hidden, unstable cross-family implementation plumbing.
#[doc(hidden)]
pub mod private {
    pub use super::binding_tracker::{BindingTracker, BindingTrackerError};
    pub use super::content_validation::ContentDocumentValidator;
    pub use super::stream_xml::{XmlStreamEvent, XmlStreamLimits, XmlStreamReport, scan_xml};
}

pub use encryption::{Cipher, Kdf, Profile, StartKey};
pub use family::{Package, PreparedPackage, validate_content_document_part, validate_content_part};
pub use generated_xml::{
    GeneratedXmlEnvelope, GeneratedXmlLimitExceeded, GeneratedXmlLimitResource, GeneratedXmlLimits,
    GeneratedXmlReport,
};
#[allow(
    unused_imports,
    reason = "The manifest descriptors are intentionally re-exported as the core public API."
)]
pub use manifest::{
    Manifest, ManifestChecksum, ManifestChecksumAlgorithm, ManifestEncryption,
    ManifestEncryptionAlgorithm, ManifestEntry, ManifestKeyDerivation, ManifestStartKeyGeneration,
};
pub use metadata::{
    AutoReloadMetadata, DocumentStatistics, HyperlinkBehaviourMetadata, Metadata, TemplateMetadata,
    UserDefinedMetadata, UserDefinedValueType,
};
pub use metadata::{MetaXmlPatch, patch_meta_xml};
pub use package::{
    OwnedPackage, SourceBackedPackage, SourceMemberReaderError, SourcePackageLimits,
    is_signature_owner_path,
};
pub use resolved_reader::ResolvedReader;
pub use source_publication::{
    SourceContentInsertionCallbackError, SourceContentInsertionError, SourceContentInsertionPlan,
    SourceContentPublicationError, SourceContentPublicationOptions,
    SourceContentPublicationProgress, SourceContentPublicationReport, write_content_xml_to_stream,
    write_content_xml_to_stream_with_options,
};
pub use stream_xml::XmlStreamLimits;
pub use writer::{
    PackageCompression, PackageWriter, PackageWriterError, PackageWriterLimitExceeded,
    PackageWriterLimitResource, PackageWriterLimits, PackageWriterResult, Structure,
};
pub use xml::{Content, Meta, Styles};
pub use xml_splice::{
    AuthoredXmlFragment, XmlSourcePart, XmlSourceRange, XmlSplicePublication,
    rebuild_package_with_xml_splices,
};

#[cfg(test)]
mod generated_xml_tests;
#[cfg(test)]
mod writer_generated_xml_tests;
