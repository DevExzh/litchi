#![allow(
    missing_docs,
    reason = "many items in this crate were previously private inside the umbrella `litchi` crate and never had public doc coverage; tighten this once a docs pass lands"
)]
//! Common types, traits, and utilities shared across formats.
//!
//! This module provides unified types and traits used by both OLE2 (legacy)
//! and OOXML (modern) implementations, ensuring a consistent API for users.

// Submodule declarations
pub mod binary;
pub mod bom;
pub mod bounded;
pub mod budget;
pub mod detection;
pub mod error;
/// Runtime-neutral execution policy, cancellation, and resource charging.
pub mod execution;
pub mod hex;
pub mod metadata;
/// Microsoft Office's shared CRC-32 checksum algorithm.
pub mod mso_crc32;
/// Format-neutral durable patch envelopes and undo history.
pub mod patch;
pub mod selector;
pub mod shapes;
pub mod sheet;
pub mod simd;
pub mod source;
pub mod style;
/// Bounded semantic plain-text output to sequential sinks.
pub mod text_output;
/// Common unit conversion utilities (length units used across all formats)
pub mod unit;
/// Bounded, format-neutral validation report values.
pub mod validation;
/// XML utilities
pub mod xml;
/// Shared byte slice for zero-copy element storage across formats
pub mod xml_slice;
// ID generation utilities
pub mod id;

// Re-exports for convenience
pub use bom::{
    BomKind, UTF8_BOM, UTF16_BE_BOM, UTF16_LE_BOM, UTF32_BE_BOM, UTF32_LE_BOM, strip_bom, write_bom,
};
pub use bounded::{BoundedU32, BoundsError};
pub use budget::{Budget, Limits, Profile, Reservation, Resource, ResourceLimit};
pub use detection::FileFormat;
pub use error::{Error, Result};
pub use execution::{
    AffinityPolicy, CancellationSource, CancellationToken, ExecutionContext, ExecutionError,
    ExecutionLimits,
};
pub use metadata::Metadata;
pub use patch::{
    BlobBundle, BlobId, BlobLimits, CompositionError, CompositionLimitKind, CompositionLimits,
    ConflictSet, DiagnosticFingerprint, EffectAccess, EffectConflict, EffectSet, ForwardOnly,
    History, HistoryLimits, JoinedSubEdits, JsonLimitKind, MergeChoice, Patch, PatchError,
    PatchLimits, PatchOperation, Reversible, ReversibleOperation, SubEdit, SubEditConflict,
    SubEditJoinError, SubEditJoinFailure, ThreeWayMergeError, ThreeWayMergeFailure,
    ThreeWayMergePlan,
};
pub use selector::{Position, Selector};
pub use shapes::{PlaceholderType, ShapeType};
#[cfg(any(unix, windows))]
pub use source::{FileSource, FileVersionPolicy};
pub use source::{OwnedSource, ReadAt, SliceSource, SourceVersion};
pub use style::{Length, RGBColor, VerticalPosition};
pub use text_output::{
    SequentialTextWriter, TextObjectKind, TextOutputError, TextOutputLimit, TextOutputLimitKind,
    TextOutputOptions, TextOutputReport,
};
// Unit conversions
pub use unit::LengthUnit;
pub use validation::{
    CheckCapabilityId, CheckStatus, CompatibilityImpact, DEFAULT_VALIDATION_LIMITS, EvidenceDigest,
    EvidenceValue, IssueEvidence, IssueId, IssueLocation, IssueSeverity, RepairAvailability,
    SpecCitation, ValidateReport, ValidationCheck, ValidationIssue, ValidationLimitKind,
    ValidationLimits, ValidationReportError,
};
// Shared slice types — kept `pub` (not `pub(crate)` per spec) because the
// umbrella's docx code uses `XmlSlice` in public type signatures across the
// crate boundary. `#[doc(hidden)]` suppresses public docs surface.
#[doc(hidden)]
pub use xml_slice::{XmlArenaBuilder, XmlSlice};
