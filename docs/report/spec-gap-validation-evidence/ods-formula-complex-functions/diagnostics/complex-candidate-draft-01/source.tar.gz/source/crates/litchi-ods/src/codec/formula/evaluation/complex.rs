//! OpenFormula 1.4 section 6.8 complex-number functions.
//!
//! The evaluator keeps complex values as a finite pair of `f64` components
//! and a representation suffix.  The suffix is metadata for text round trips;
//! it does not participate in arithmetic.  This module owns conversion,
//! formatting, and the numerical kernels so the scalar evaluator only needs
//! to schedule the already-eager arguments.

use super::{
    EvaluationFailure, EvaluationResult, Evaluator, Node, NumberText, ScalarError, TextValue,
    WorkingValue, ensure_capacity, local_limit,
};
use litchi_core::{Reservation, Resource};
use std::fmt::{self, Display, Formatter, Write as FmtWrite};

const COMPLEX_FUNCTION_NAMES: [&str; 26] = [
    "COMPLEX",
    "IMABS",
    "IMAGINARY",
    "IMARGUMENT",
    "IMCONJUGATE",
    "IMCOS",
    "IMCOSH",
    "IMCOT",
    "IMCSC",
    "IMCSCH",
    "IMDIV",
    "IMEXP",
    "IMLN",
    "IMLOG10",
    "IMLOG2",
    "IMPOWER",
    "IMPRODUCT",
    "IMREAL",
    "IMSIN",
    "IMSINH",
    "IMSEC",
    "IMSECH",
    "IMSQRT",
    "IMSUB",
    "IMSUM",
    "IMTAN",
];

/// A bounded aggregate argument buffer whose storage reservation follows the
/// values until both have been consumed or dropped.  Fixed-arity functions
/// pop directly from the evaluator stack and do not create this buffer.
struct ComplexArguments<'a> {
    values: Vec<WorkingValue<'a>>,
    _reservation: Option<Reservation>,
}

struct ComplexArgumentsIntoIter<'a> {
    values: std::vec::IntoIter<WorkingValue<'a>>,
    _reservation: Option<Reservation>,
}

impl<'a> ComplexArguments<'a> {
    fn len(&self) -> usize {
        self.values.len()
    }

    fn pop(&mut self) -> Option<WorkingValue<'a>> {
        self.values.pop()
    }

    fn remove(&mut self, index: usize) -> WorkingValue<'a> {
        self.values.remove(index)
    }

    fn as_slice(&self) -> &[WorkingValue<'a>] {
        &self.values
    }

    fn into_iter(self) -> ComplexArgumentsIntoIter<'a> {
        ComplexArgumentsIntoIter {
            values: self.values.into_iter(),
            _reservation: self._reservation,
        }
    }
}

impl<'a> IntoIterator for ComplexArguments<'a> {
    type Item = WorkingValue<'a>;
    type IntoIter = ComplexArgumentsIntoIter<'a>;

    fn into_iter(self) -> Self::IntoIter {
        ComplexArguments::into_iter(self)
    }
}

impl<'a> Iterator for ComplexArgumentsIntoIter<'a> {
    type Item = WorkingValue<'a>;

    fn next(&mut self) -> Option<Self::Item> {
        self.values.next()
    }
}

/// A finite OpenFormula complex number.
///
/// The suffix is either lowercase `i` or `j` and is retained when a value is
/// converted back to formula text.  It does not affect numerical equality or
/// arithmetic.  Use [`Complex::new`] to construct a checked value.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct Complex {
    real: f64,
    imaginary: f64,
    suffix: char,
}

impl Complex {
    /// Construct a finite complex number with an explicit lowercase suffix.
    #[must_use]
    pub fn new(real: f64, imaginary: f64, suffix: char) -> Option<Self> {
        if real.is_finite() && imaginary.is_finite() && matches!(suffix, 'i' | 'j') {
            Some(Self {
                real,
                imaginary,
                suffix,
            })
        } else {
            None
        }
    }

    /// Return the real coefficient.
    #[must_use]
    pub const fn real(self) -> f64 {
        self.real
    }

    /// Return the imaginary coefficient.
    #[must_use]
    pub const fn imaginary(self) -> f64 {
        self.imaginary
    }

    /// Return the lowercase representation suffix (`i` or `j`).
    #[must_use]
    pub const fn suffix(self) -> char {
        self.suffix
    }

    fn checked(real: f64, imaginary: f64, suffix: char) -> Result<Self, ScalarError> {
        Self::new(real, imaginary, suffix).ok_or(ScalarError::Number)
    }

    const fn zero(suffix: char) -> Self {
        Self {
            real: 0.0,
            imaginary: 0.0,
            suffix,
        }
    }

    const fn one(suffix: char) -> Self {
        Self {
            real: 1.0,
            imaginary: 0.0,
            suffix,
        }
    }

    pub(super) fn negate(self) -> Self {
        Self {
            real: -self.real,
            imaginary: -self.imaginary,
            suffix: self.suffix,
        }
    }

    fn is_zero(self) -> bool {
        self.real == 0.0 && self.imaginary == 0.0
    }
}

impl Display for Complex {
    fn fmt(&self, formatter: &mut Formatter<'_>) -> fmt::Result {
        if self.imaginary == 0.0 {
            return write!(formatter, "{}", self.real);
        }
        if self.real == 0.0 {
            if self.imaginary == 1.0 {
                return write!(formatter, "{}", self.suffix);
            }
            if self.imaginary == -1.0 {
                return write!(formatter, "-{}", self.suffix);
            }
            return write!(formatter, "{}{}", self.imaginary, self.suffix);
        }

        write!(formatter, "{}", self.real)?;
        if self.imaginary > 0.0 {
            write!(formatter, "+")?;
        }
        if self.imaginary == 1.0 {
            write!(formatter, "{}", self.suffix)
        } else if self.imaginary == -1.0 {
            write!(formatter, "-{}", self.suffix)
        } else {
            write!(formatter, "{}{}", self.imaginary, self.suffix)
        }
    }
}

/// Return whether `name` belongs to the complete section 6.8 family.
pub(super) fn is_complex_function(name: &str) -> bool {
    COMPLEX_FUNCTION_NAMES
        .iter()
        .any(|candidate| name.eq_ignore_ascii_case(candidate))
}

/// Apply one section 6.8 function after its eager arguments are on the scalar
/// value stack.  The function family is outlined to keep the ordinary scalar
/// evaluator's hot dispatch small.
#[inline(never)]
pub(super) fn apply<'a>(
    evaluator: &mut Evaluator<'a, '_, '_>,
    node: Node<'a>,
    name: &str,
) -> EvaluationResult<()> {
    if name.eq_ignore_ascii_case("COMPLEX") {
        return apply_complex(evaluator, node);
    }
    if name.eq_ignore_ascii_case("IMABS") {
        return apply_unary_number(evaluator, node, unary_abs);
    }
    if name.eq_ignore_ascii_case("IMAGINARY") {
        return apply_unary_number(evaluator, node, |value| Ok(value.imaginary));
    }
    if name.eq_ignore_ascii_case("IMARGUMENT") {
        return apply_unary_number(evaluator, node, |value| Ok(complex_argument(value)));
    }
    if name.eq_ignore_ascii_case("IMCONJUGATE") {
        return apply_unary_complex(evaluator, node, |value| {
            Ok(Complex {
                real: value.real,
                imaginary: -value.imaginary,
                suffix: value.suffix,
            })
        });
    }
    if name.eq_ignore_ascii_case("IMCOS") {
        return apply_unary_complex(evaluator, node, complex_cos);
    }
    if name.eq_ignore_ascii_case("IMCOSH") {
        return apply_unary_complex(evaluator, node, complex_cosh);
    }
    if name.eq_ignore_ascii_case("IMCOT") {
        return apply_unary_complex(evaluator, node, |value| {
            let numerator = complex_cos(value)?;
            let denominator = complex_sin(value)?;
            complex_div(numerator, denominator)
        });
    }
    if name.eq_ignore_ascii_case("IMCSC") {
        return apply_unary_complex(evaluator, node, |value| {
            complex_reciprocal(complex_sin(value)?)
        });
    }
    if name.eq_ignore_ascii_case("IMCSCH") {
        return apply_unary_complex(evaluator, node, |value| {
            complex_reciprocal(complex_sinh(value)?)
        });
    }
    if name.eq_ignore_ascii_case("IMDIV") {
        return apply_binary_complex(evaluator, node, complex_div);
    }
    if name.eq_ignore_ascii_case("IMEXP") {
        return apply_unary_complex(evaluator, node, complex_exp);
    }
    if name.eq_ignore_ascii_case("IMLN") {
        return apply_unary_complex(evaluator, node, complex_ln);
    }
    if name.eq_ignore_ascii_case("IMLOG10") {
        return apply_unary_complex(evaluator, node, |value| {
            let logarithm = complex_ln(value)?;
            complex_div(
                logarithm,
                Complex::new(std::f64::consts::LN_10, 0.0, value.suffix)
                    .ok_or(ScalarError::Number)?,
            )
        });
    }
    if name.eq_ignore_ascii_case("IMLOG2") {
        return apply_unary_complex(evaluator, node, |value| {
            let logarithm = complex_ln(value)?;
            complex_div(
                logarithm,
                Complex::new(std::f64::consts::LN_2, 0.0, value.suffix)
                    .ok_or(ScalarError::Number)?,
            )
        });
    }
    if name.eq_ignore_ascii_case("IMPOWER") {
        return apply_power(evaluator, node);
    }
    if name.eq_ignore_ascii_case("IMPRODUCT") {
        return apply_product(evaluator, node);
    }
    if name.eq_ignore_ascii_case("IMREAL") {
        return apply_unary_number(evaluator, node, |value| Ok(value.real));
    }
    if name.eq_ignore_ascii_case("IMSIN") {
        return apply_unary_complex(evaluator, node, complex_sin);
    }
    if name.eq_ignore_ascii_case("IMSINH") {
        return apply_unary_complex(evaluator, node, complex_sinh);
    }
    if name.eq_ignore_ascii_case("IMSEC") {
        return apply_unary_complex(evaluator, node, |value| {
            complex_reciprocal(complex_cos(value)?)
        });
    }
    if name.eq_ignore_ascii_case("IMSECH") {
        return apply_unary_complex(evaluator, node, |value| {
            complex_reciprocal(complex_cosh(value)?)
        });
    }
    if name.eq_ignore_ascii_case("IMSQRT") {
        return apply_unary_complex(evaluator, node, complex_sqrt);
    }
    if name.eq_ignore_ascii_case("IMSUB") {
        return apply_binary_complex(evaluator, node, complex_sub);
    }
    if name.eq_ignore_ascii_case("IMSUM") {
        return apply_sum(evaluator, node);
    }
    if name.eq_ignore_ascii_case("IMTAN") {
        return apply_unary_complex(evaluator, node, |value| {
            let numerator = complex_sin(value)?;
            let denominator = complex_cos(value)?;
            complex_div(numerator, denominator)
        });
    }
    Err(EvaluationFailure::InvalidExpression(
        "unknown complex function reached evaluator",
    ))
}

fn pop_arguments<'a>(
    evaluator: &mut Evaluator<'a, '_, '_>,
    count: usize,
) -> EvaluationResult<ComplexArguments<'a>> {
    let mut arguments = ComplexArguments {
        values: Vec::new(),
        _reservation: None,
    };
    ensure_capacity(
        &mut arguments.values,
        &mut arguments._reservation,
        count,
        evaluator.limits.max_stack_entries,
        evaluator.context.execution,
        &evaluator.storage_budget,
        "formula complex function arguments",
    )?;
    for _ in 0..count {
        arguments.values.push(evaluator.pop_value()?);
    }
    arguments.values.reverse();
    Ok(arguments)
}

fn first_error(values: &[WorkingValue<'_>]) -> Option<ScalarError> {
    values.iter().find_map(|value| match value {
        WorkingValue::Error(error) => Some(*error),
        _ => None,
    })
}

fn apply_complex<'a>(
    evaluator: &mut Evaluator<'a, '_, '_>,
    node: Node<'a>,
) -> EvaluationResult<()> {
    let count = node.child_count();
    if !(2..=3).contains(&count) {
        return evaluator.finish_invalid_arity(node);
    }
    let mut values = pop_arguments(evaluator, count)?;
    if let Some(error) = first_error(values.as_slice()) {
        return evaluator.push_value(WorkingValue::Error(error));
    }
    let suffix = if values.len() == 3 {
        let value = values.pop().ok_or(EvaluationFailure::InvalidExpression(
            "complex suffix argument is missing",
        ))?;
        match value {
            WorkingValue::Text(text) => {
                evaluator.charge_bytes(text.text.len())?;
                if text.text == "i" {
                    'i'
                } else if text.text == "j" {
                    'j'
                } else {
                    return evaluator.push_value(WorkingValue::Error(ScalarError::Value));
                }
            },
            _ => return evaluator.push_value(WorkingValue::Error(ScalarError::Value)),
        }
    } else {
        'i'
    };
    let imaginary = values.pop().ok_or(EvaluationFailure::InvalidExpression(
        "complex imaginary argument is missing",
    ))?;
    let real = values.pop().ok_or(EvaluationFailure::InvalidExpression(
        "complex real argument is missing",
    ))?;
    let real = match super::to_number(real, evaluator)? {
        Ok(value) => value,
        Err(error) => return evaluator.push_value(WorkingValue::Error(error)),
    };
    let imaginary = match super::to_number(imaginary, evaluator)? {
        Ok(value) => value,
        Err(error) => return evaluator.push_value(WorkingValue::Error(error)),
    };
    push_complex(evaluator, Complex::checked(real, imaginary, suffix))
}

fn apply_unary_complex<'a, F>(
    evaluator: &mut Evaluator<'a, '_, '_>,
    node: Node<'a>,
    operation: F,
) -> EvaluationResult<()>
where
    F: FnOnce(Complex) -> Result<Complex, ScalarError>,
{
    if node.child_count() != 1 {
        return evaluator.finish_invalid_arity(node);
    }
    let mut values = pop_arguments(evaluator, 1)?;
    let value = values.pop().ok_or(EvaluationFailure::InvalidExpression(
        "complex argument is missing",
    ))?;
    let value = match to_complex(value, evaluator)? {
        Ok(value) => operation(value),
        Err(error) => Err(error),
    };
    push_complex(evaluator, value)
}

fn apply_unary_number<'a, F>(
    evaluator: &mut Evaluator<'a, '_, '_>,
    node: Node<'a>,
    operation: F,
) -> EvaluationResult<()>
where
    F: FnOnce(Complex) -> Result<f64, ScalarError>,
{
    if node.child_count() != 1 {
        return evaluator.finish_invalid_arity(node);
    }
    let mut values = pop_arguments(evaluator, 1)?;
    let value = values.pop().ok_or(EvaluationFailure::InvalidExpression(
        "complex argument is missing",
    ))?;
    let value = match to_complex(value, evaluator)? {
        Ok(value) => operation(value),
        Err(error) => Err(error),
    };
    match value {
        Ok(value) if value.is_finite() => evaluator.push_value(WorkingValue::Number(value)),
        Ok(_) => evaluator.push_value(WorkingValue::Error(ScalarError::Number)),
        Err(error) => evaluator.push_value(WorkingValue::Error(error)),
    }
}

fn apply_binary_complex<'a, F>(
    evaluator: &mut Evaluator<'a, '_, '_>,
    node: Node<'a>,
    operation: F,
) -> EvaluationResult<()>
where
    F: FnOnce(Complex, Complex) -> Result<Complex, ScalarError>,
{
    if node.child_count() != 2 {
        return evaluator.finish_invalid_arity(node);
    }
    let mut values = pop_arguments(evaluator, 2)?;
    if let Some(error) = first_error(values.as_slice()) {
        return evaluator.push_value(WorkingValue::Error(error));
    }
    let left = values
        .get_mut(0)
        .ok_or(EvaluationFailure::InvalidExpression(
            "complex left argument missing",
        ))?;
    let left = std::mem::replace(left, WorkingValue::Error(ScalarError::Value));
    let right = values.pop().ok_or(EvaluationFailure::InvalidExpression(
        "complex right argument missing",
    ))?;
    let left = match to_complex(left, evaluator)? {
        Ok(value) => value,
        Err(error) => return evaluator.push_value(WorkingValue::Error(error)),
    };
    let right = match to_complex(right, evaluator)? {
        Ok(value) => value,
        Err(error) => return evaluator.push_value(WorkingValue::Error(error)),
    };
    push_complex(evaluator, operation(left, right))
}

fn apply_power<'a>(evaluator: &mut Evaluator<'a, '_, '_>, node: Node<'a>) -> EvaluationResult<()> {
    if node.child_count() != 2 {
        return evaluator.finish_invalid_arity(node);
    }
    let mut values = pop_arguments(evaluator, 2)?;
    if let Some(error) = first_error(values.as_slice()) {
        return evaluator.push_value(WorkingValue::Error(error));
    }
    let left = values.remove(0);
    let right = values.pop().ok_or(EvaluationFailure::InvalidExpression(
        "complex exponent missing",
    ))?;
    let left = match to_complex(left, evaluator)? {
        Ok(value) => value,
        Err(error) => return evaluator.push_value(WorkingValue::Error(error)),
    };
    let right = match to_complex(right, evaluator)? {
        Ok(value) => value,
        Err(error) => return evaluator.push_value(WorkingValue::Error(error)),
    };
    if left.is_zero() {
        return evaluator.push_value(WorkingValue::Error(ScalarError::Number));
    }
    let logarithm = match complex_ln(left) {
        Ok(value) => value,
        Err(error) => return evaluator.push_value(WorkingValue::Error(error)),
    };
    let product = match complex_mul(logarithm, right) {
        Ok(value) => value,
        Err(error) => return evaluator.push_value(WorkingValue::Error(error)),
    };
    push_complex(evaluator, complex_exp(product))
}

fn apply_product<'a>(
    evaluator: &mut Evaluator<'a, '_, '_>,
    node: Node<'a>,
) -> EvaluationResult<()> {
    let count = node.child_count();
    if count == 0 {
        return evaluator.finish_invalid_arity(node);
    }
    let values = pop_arguments(evaluator, count)?;
    if let Some(error) = first_error(values.as_slice()) {
        return evaluator.push_value(WorkingValue::Error(error));
    }
    let mut result = Complex::one('i');
    let mut numeric_error = None;
    for value in values {
        let value = match to_complex(value, evaluator)? {
            Ok(value) => value,
            Err(error) => {
                return evaluator.push_value(WorkingValue::Error(error));
            },
        };
        result.suffix = choose_suffix(result.suffix, value.suffix);
        if numeric_error.is_none() {
            match complex_mul(result, value) {
                Ok(value) => result = value,
                Err(error) => numeric_error = Some(error),
            }
        }
    }
    match numeric_error {
        Some(error) => evaluator.push_value(WorkingValue::Error(error)),
        None => evaluator.push_value(WorkingValue::Complex(result)),
    }
}

fn apply_sum<'a>(evaluator: &mut Evaluator<'a, '_, '_>, node: Node<'a>) -> EvaluationResult<()> {
    let count = node.child_count();
    if count == 0 {
        return evaluator.push_value(WorkingValue::Number(0.0));
    }
    let values = pop_arguments(evaluator, count)?;
    if let Some(error) = first_error(values.as_slice()) {
        return evaluator.push_value(WorkingValue::Error(error));
    }
    let mut result = Complex::zero('i');
    let mut numeric_error = None;
    for value in values {
        let value = match value {
            WorkingValue::Text(text) => {
                evaluator.charge_bytes(text.text.len())?;
                match parse_complex_text(text.text.as_ref()) {
                    Ok(value) => value,
                    Err(_) => continue,
                }
            },
            value => match to_complex(value, evaluator)? {
                Ok(value) => value,
                Err(error) => return evaluator.push_value(WorkingValue::Error(error)),
            },
        };
        result.suffix = choose_suffix(result.suffix, value.suffix);
        if numeric_error.is_none() {
            match complex_add(result, value) {
                Ok(value) => result = value,
                Err(error) => numeric_error = Some(error),
            }
        }
    }
    match numeric_error {
        Some(error) => evaluator.push_value(WorkingValue::Error(error)),
        None => evaluator.push_value(WorkingValue::Complex(result)),
    }
}

fn push_complex<'a>(
    evaluator: &mut Evaluator<'a, '_, '_>,
    value: Result<Complex, ScalarError>,
) -> EvaluationResult<()> {
    match value {
        Ok(value) => evaluator.push_value(WorkingValue::Complex(value)),
        Err(error) => evaluator.push_value(WorkingValue::Error(error)),
    }
}

pub(super) fn to_complex<'a>(
    value: WorkingValue<'a>,
    evaluator: &mut Evaluator<'_, '_, '_>,
) -> EvaluationResult<Result<Complex, ScalarError>> {
    match value {
        WorkingValue::Number(value) => Ok(Complex::checked(value, 0.0, 'i')),
        WorkingValue::Logical(value) => {
            Ok(Complex::checked(if value { 1.0 } else { 0.0 }, 0.0, 'i'))
        },
        WorkingValue::Complex(value) => Ok(Ok(value)),
        WorkingValue::Text(text) => {
            evaluator.charge_bytes(text.text.len())?;
            Ok(parse_complex_text(text.text.as_ref()))
        },
        WorkingValue::Error(error) => Ok(Err(error)),
    }
}

fn parse_complex_text(text: &str) -> Result<Complex, ScalarError> {
    if text.is_empty() {
        return Err(ScalarError::Value);
    }
    let (body, suffix) = match text.as_bytes().last().copied() {
        Some(b'i') => (&text[..text.len() - 1], 'i'),
        Some(b'j') => (&text[..text.len() - 1], 'j'),
        _ => {
            let value = parse_finite_number(text)?;
            return Complex::checked(value, 0.0, 'i');
        },
    };

    if body.is_empty() || body == "+" || body == "-" {
        return Complex::checked(0.0, if body == "-" { -1.0 } else { 1.0 }, suffix);
    }

    let Some(first_end) = number_prefix(body) else {
        return Err(ScalarError::Value);
    };
    if first_end == body.len() {
        let imaginary = parse_finite_number(body)?;
        return Complex::checked(0.0, imaginary, suffix);
    }
    let separator = body.as_bytes().get(first_end).copied();
    if !matches!(separator, Some(b'+' | b'-')) {
        return Err(ScalarError::Value);
    }
    let real = parse_finite_number(&body[..first_end])?;
    let imaginary_text = &body[first_end..];
    let imaginary = if imaginary_text == "+" {
        1.0
    } else if imaginary_text == "-" {
        -1.0
    } else {
        parse_finite_number(imaginary_text)?
    };
    Complex::checked(real, imaginary, suffix)
}

fn parse_finite_number(text: &str) -> Result<f64, ScalarError> {
    if text.is_empty() {
        return Err(ScalarError::Value);
    }
    let value = fast_float2::parse::<f64, _>(text).map_err(|_| ScalarError::Value)?;
    if value.is_finite() {
        Ok(value)
    } else {
        Err(ScalarError::Number)
    }
}

fn number_prefix(text: &str) -> Option<usize> {
    let bytes = text.as_bytes();
    let mut index = 0usize;
    if matches!(bytes.first(), Some(b'+' | b'-')) {
        index += 1;
    }
    let mut digits = 0usize;
    while bytes.get(index).is_some_and(u8::is_ascii_digit) {
        index += 1;
        digits += 1;
    }
    if bytes.get(index) == Some(&b'.') {
        index += 1;
        while bytes.get(index).is_some_and(u8::is_ascii_digit) {
            index += 1;
            digits += 1;
        }
    }
    if digits == 0 {
        return None;
    }
    if matches!(bytes.get(index), Some(b'e' | b'E')) {
        index += 1;
        if matches!(bytes.get(index), Some(b'+' | b'-')) {
            index += 1;
        }
        let exponent_start = index;
        while bytes.get(index).is_some_and(u8::is_ascii_digit) {
            index += 1;
        }
        if index == exponent_start {
            return None;
        }
    }
    Some(index)
}

fn choose_suffix(left: char, right: char) -> char {
    if left == 'j' || right == 'j' {
        'j'
    } else {
        'i'
    }
}

fn unary_abs(value: Complex) -> Result<f64, ScalarError> {
    let value = value.real.hypot(value.imaginary);
    value
        .is_finite()
        .then_some(value)
        .ok_or(ScalarError::Number)
}

fn complex_argument(value: Complex) -> f64 {
    if value.is_zero() {
        return 0.0;
    }
    let mut angle = value.imaginary.atan2(value.real);
    if angle == -std::f64::consts::PI {
        angle = std::f64::consts::PI;
    } else if angle == 0.0 {
        angle = 0.0;
    }
    angle
}

pub(super) fn complex_add(left: Complex, right: Complex) -> Result<Complex, ScalarError> {
    Complex::checked(
        left.real + right.real,
        left.imaginary + right.imaginary,
        choose_suffix(left.suffix, right.suffix),
    )
}

fn complex_sub(left: Complex, right: Complex) -> Result<Complex, ScalarError> {
    Complex::checked(
        left.real - right.real,
        left.imaginary - right.imaginary,
        choose_suffix(left.suffix, right.suffix),
    )
}

pub(super) fn complex_mul(left: Complex, right: Complex) -> Result<Complex, ScalarError> {
    Complex::checked(
        left.real * right.real - left.imaginary * right.imaginary,
        left.real * right.imaginary + left.imaginary * right.real,
        choose_suffix(left.suffix, right.suffix),
    )
}

fn complex_div(left: Complex, right: Complex) -> Result<Complex, ScalarError> {
    if right.is_zero() {
        return Err(ScalarError::DivisionByZero);
    }
    // Scale numerator and denominator independently.  This is the Smith
    // quotient in a form that also keeps 1e308/1e308 and 1e-308/1e-308
    // finite without overflowing an intermediate square.
    let denominator_scale = right.real.abs().max(right.imaginary.abs());
    let numerator_scale = left.real.abs().max(left.imaginary.abs());
    if numerator_scale == 0.0 {
        return Complex::checked(0.0, 0.0, choose_suffix(left.suffix, right.suffix));
    }
    let real_denominator = right.real / denominator_scale;
    let imaginary_denominator = right.imaginary / denominator_scale;
    let denominator =
        real_denominator * real_denominator + imaginary_denominator * imaginary_denominator;
    let real_numerator = left.real / numerator_scale;
    let imaginary_numerator = left.imaginary / numerator_scale;
    let real_factor = (real_numerator * real_denominator
        + imaginary_numerator * imaginary_denominator)
        / denominator;
    let imaginary_factor = (imaginary_numerator * real_denominator
        - real_numerator * imaginary_denominator)
        / denominator;
    Complex::checked(
        scale_ratio(numerator_scale, real_factor, denominator_scale),
        scale_ratio(numerator_scale, imaginary_factor, denominator_scale),
        choose_suffix(left.suffix, right.suffix),
    )
}

/// Multiply a finite normalized factor by two finite positive scales without
/// forming an overflowing scale ratio first.  The factor is decomposed into a
/// binary mantissa and exponent, so cancellation in a very small component is
/// retained even when `numerator_scale / denominator_scale` itself overflows.
fn scale_ratio(numerator_scale: f64, factor: f64, denominator_scale: f64) -> f64 {
    if factor == 0.0 {
        return factor;
    }
    let (numerator_mantissa, numerator_exponent) = binary_parts(numerator_scale);
    let (denominator_mantissa, denominator_exponent) = binary_parts(denominator_scale);
    let (factor_mantissa, factor_exponent) = binary_parts(factor.abs());
    let normalized = factor_mantissa * numerator_mantissa / denominator_mantissa;
    let (normalized_mantissa, normalized_exponent) = binary_parts(normalized);
    let exponent =
        factor_exponent + numerator_exponent - denominator_exponent + normalized_exponent;
    scale_binary(normalized_mantissa.copysign(factor), exponent)
}

/// Return a positive finite nonzero value as `mantissa * 2^exponent`, where
/// `1 <= mantissa < 2`.  The one recursive step handles subnormal inputs.
fn binary_parts(value: f64) -> (f64, i32) {
    debug_assert!(value.is_finite() && value > 0.0);
    let bits = value.to_bits();
    let raw_exponent = ((bits >> 52) & 0x7ff) as i32;
    if raw_exponent == 0 {
        let (mantissa, exponent) = binary_parts(value * 18_014_398_509_481_984.0);
        return (mantissa, exponent - 54);
    }
    let fraction = bits & ((1_u64 << 52) - 1);
    let mantissa = f64::from_bits((1023_u64 << 52) | fraction);
    (mantissa, raw_exponent - 1023)
}

/// Scale a signed normalized mantissa by a power of two while retaining
/// subnormal results and rounding ties to even.
fn scale_binary(value: f64, exponent: i32) -> f64 {
    debug_assert!(value.is_finite() && value.abs() >= 1.0 && value.abs() < 2.0);
    let bits = value.to_bits();
    let sign = bits & (1_u64 << 63);
    let fraction = bits & ((1_u64 << 52) - 1);
    let target_exponent = 1023_i32 + exponent;
    if target_exponent >= 0x7ff {
        return f64::from_bits(sign | (0x7ff_u64 << 52));
    }
    if target_exponent >= 1 {
        return f64::from_bits(sign | ((target_exponent as u64) << 52) | fraction);
    }

    let significand = (1_u64 << 52) | fraction;
    let right_shift = 1_i32 - target_exponent;
    if right_shift >= 64 {
        return f64::from_bits(sign);
    }
    let right_shift = right_shift as u32;
    let mask = (1_u64 << right_shift) - 1;
    let mut subnormal = significand >> right_shift;
    let remainder = significand & mask;
    let halfway = 1_u64 << (right_shift - 1);
    if remainder > halfway || (remainder == halfway && subnormal & 1 != 0) {
        subnormal += 1;
    }
    if subnormal >= 1_u64 << 52 {
        return f64::from_bits(sign | (1_u64 << 52));
    }
    f64::from_bits(sign | subnormal)
}

fn complex_reciprocal(value: Complex) -> Result<Complex, ScalarError> {
    complex_div(Complex::one(value.suffix), value)
}

fn complex_sin(value: Complex) -> Result<Complex, ScalarError> {
    Complex::checked(
        value.real.sin() * value.imaginary.cosh(),
        value.real.cos() * value.imaginary.sinh(),
        value.suffix,
    )
}

fn complex_cos(value: Complex) -> Result<Complex, ScalarError> {
    Complex::checked(
        value.real.cos() * value.imaginary.cosh(),
        -(value.real.sin() * value.imaginary.sinh()),
        value.suffix,
    )
}

fn complex_sinh(value: Complex) -> Result<Complex, ScalarError> {
    Complex::checked(
        value.real.sinh() * value.imaginary.cos(),
        value.real.cosh() * value.imaginary.sin(),
        value.suffix,
    )
}

fn complex_cosh(value: Complex) -> Result<Complex, ScalarError> {
    Complex::checked(
        value.real.cosh() * value.imaginary.cos(),
        value.real.sinh() * value.imaginary.sin(),
        value.suffix,
    )
}

fn complex_exp(value: Complex) -> Result<Complex, ScalarError> {
    let scale = value.real.exp();
    Complex::checked(
        scale * value.imaginary.cos(),
        scale * value.imaginary.sin(),
        value.suffix,
    )
}

fn complex_ln(value: Complex) -> Result<Complex, ScalarError> {
    if value.is_zero() {
        return Err(ScalarError::Number);
    }
    Complex::checked(
        value.real.hypot(value.imaginary).ln(),
        complex_argument(value),
        value.suffix,
    )
}

fn complex_sqrt(value: Complex) -> Result<Complex, ScalarError> {
    if value.is_zero() {
        return Ok(Complex::zero(value.suffix));
    }
    let magnitude = value.real.hypot(value.imaginary);
    // Halve before adding/subtracting: `hypot + real` can overflow even
    // though both square-root components are finite (for example 1e308+1e308i).
    let half_magnitude = magnitude * 0.5;
    let half_real = value.real * 0.5;
    let real = (half_magnitude + half_real).sqrt();
    let imaginary_magnitude = (half_magnitude - half_real).sqrt();
    let imaginary = imaginary_magnitude.copysign(value.imaginary);
    Complex::checked(real, imaginary, value.suffix)
}

/// Convert a complex value to formula text for the ordinary concatenation
/// operator.  The bounded stack formatter avoids an intermediate infallible
/// `String` allocation; the final owned text follows the evaluator's normal
/// reservation contract.
pub(super) fn to_text<'a>(
    evaluator: &mut Evaluator<'a, '_, '_>,
    value: Complex,
) -> EvaluationResult<TextValue<'a>> {
    let mut number = NumberText::new();
    write!(&mut number, "{value}")
        .map_err(|_| EvaluationFailure::InvalidExpression("complex-to-text formatting failed"))?;
    let rendered = number
        .as_str()
        .map_err(|_| EvaluationFailure::InvalidExpression("invalid complex text"))?;
    evaluator.charge_bytes(rendered.len())?;
    if rendered.len() > evaluator.limits.max_text_bytes {
        return Err(local_limit(
            Resource::Memory,
            u64::try_from(rendered.len()).unwrap_or(u64::MAX),
            u64::try_from(evaluator.limits.max_text_bytes).unwrap_or(u64::MAX),
        ));
    }
    let reservation = evaluator.reserve_storage(rendered.len(), "formula complex text")?;
    let mut output = String::new();
    if !rendered.is_empty() {
        output.try_reserve_exact(rendered.len()).map_err(|source| {
            EvaluationFailure::Allocation {
                resource: "formula complex text",
                source,
            }
        })?;
    }
    output.push_str(rendered);
    Ok(TextValue::owned(output, reservation))
}

#[cfg(test)]
mod tests {
    use super::{number_prefix, parse_complex_text};

    #[test]
    fn parses_real_and_imaginary_forms() {
        let value = parse_complex_text("3+4i").expect("complex");
        assert_eq!(value.real(), 3.0);
        assert_eq!(value.imaginary(), 4.0);
        assert_eq!(value.suffix(), 'i');
        let value = parse_complex_text("-2j").expect("imaginary");
        assert_eq!(value.real(), 0.0);
        assert_eq!(value.imaginary(), -2.0);
        assert_eq!(value.suffix(), 'j');
    }

    #[test]
    fn exponent_sign_is_not_a_complex_separator() {
        assert_eq!(number_prefix("3e-2"), Some(4));
        let value = parse_complex_text("3e-2i").expect("imaginary exponent");
        assert_eq!(value.real(), 0.0);
        assert!((value.imaginary() - 0.03).abs() < 1e-15);
    }
}
