# OTH structures bounded v2 candidate receipt

- Candidate: `/var/tmp/litchi-odf-oth-structures-candidate-v2-20260910`
- Immutable v1 preserved: `/var/tmp/litchi-odf-oth-structures-candidate-20260910`
- Base HEAD: `fdd2b80dfa9efc246a5983a3fec64de25e5c4f63`
- Worktree target: `/var/tmp/litchi-odf-oth-structures-target-v2-195`
- Toolchain: `RUSTUP_HOME=/tmp/litchi-spec-gap-rustup cargo +1.95.0`
- Build jobs / affinity: `CARGO_BUILD_JOBS=4`, `taskset -c 8-31`
- No commits or staging performed.

## v2 delta from v1

- `crates/litchi-oth/src/facade/mod.rs`
  - Keeps source selector and records stable identity plus remapped target selector for structure text changes.
  - Remaps readback and durable patch validation by identity; durable wire is `LOTHP005`, with `LOTHP004` decoding retained.
  - Rejects `NoteClass::Other` in fresh typed note authoring.
- `crates/litchi-oth/src/codec/structure.rs`
  - Semantic namespace/XML-character-reference/percent-URI reference closure without external resolution.
  - Precharges parse-node names, namespace URIs, attributes, and decoded values before retained allocations; repeated text spaces use checked fallible reservation.
  - Projects `text:change` and ignores change markers when no owned `text:tracked-changes` declaration exists; foreign wrappers remain inert.
- `crates/litchi-oth/src/codec/mod.rs`: exports the bounded semantic-reference helper.
- `crates/litchi-oth/tests/structure_edits.rs`: remap + durable-wire, reference-decoding, and `Other` note regressions.
- `crates/litchi-oth/tests/body_structures.rs`: no-tracked-change/text-change, foreign-wrapper, index/frame-family, and malformed-repeat coverage.
- `crates/litchi-oth/docs/FEATURE_MATRIX.md`: narrows tracked-change/index/frame projection scope.

## Validation

- `env -u RUSTUP_HOME rustup run stable cargo fmt --package litchi-oth -- --check`: pass.
- `RUSTUP_HOME=/tmp/litchi-spec-gap-rustup CARGO_BUILD_JOBS=4 taskset -c 8-31 cargo +1.95.0 clippy -p litchi-oth --all-features --all-targets -- -D warnings`: pass.
- Same environment, `cargo +1.95.0 test -p litchi-oth --all-features --all-targets --no-fail-fast`: pass, 4 unit + 10 body-structure + 33 semantic + 9 structure-edit tests.
- Same environment, `cargo +1.95.0 test -p litchi-oth --doc`: pass (0 doctests discovered).
- Same environment, `cargo +1.95.0 test -p litchi-odf --all-features --all-targets --no-fail-fast`: pass (4 RDF tests; examples/unit targets pass with 0 tests).
- Same environment, `cargo +1.95.0 clippy -p litchi-odf --all-features --all-targets -- -D warnings`: pass.

## v2 hashes

crates/litchi-oth/src/codec/structure.rs  345293ed81daf8838d2ac112336b068355a44484d57cacd2ef94ba7aa6453d7a
crates/litchi-oth/src/codec/mod.rs  88bfc3169ebe6de036d04f68acf1803ec760ad74ec2a70d7cd779ecb7135069b
crates/litchi-oth/src/facade/mod.rs  7ee94326b723ae5e474de615089eb17043a053e9cc45c2e8e49051830e771761
crates/litchi-oth/tests/body_structures.rs  98b2490597b8129d0aa9db71a965e4fd86f19b6ac097ee8bd92e1b3e99085c6a
crates/litchi-oth/tests/structure_edits.rs  5615c40c971ef6fcae626bca5e5855e77326c2e1df9c7c8b4f2a35c1a52587d2
crates/litchi-oth/docs/FEATURE_MATRIX.md  cf227c6cdfbd72da763805f6581e69337a6c1b7ede01019dbdb120f2eaee58a7

## v1 immutability spot-check

crates/litchi-oth/src/codec/structure.rs  740647a80afe729da0b086c7213f450c253c6e4350a65883b6a8330daa17982b
crates/litchi-oth/src/facade/mod.rs  0c4cb920e5155602848368d365e9ef27c5b4e2f5d73bf8d93cadea681fe400d9
crates/litchi-oth/tests/structure_edits.rs  1ccff149119f9426ed3b1c98ed7cc4e1a9321898b56362c41d3b2bf41439e088
