# OTH v2 primary reconciliation proposal

**Status:** proposal/evidence only. No files were edited, staged, or committed in the primary worktree.

This bundle reconciles the exact 18-path OTH v2 candidate against the dirty primary worktree. It is based on the current primary `HEAD` and uses an isolated copy to prove patch application and final hashes.

## Source identities

- Primary root: `/home/zhuhe/code/litchi-spec-gaps`
- Primary `HEAD`: `0201c716e6005ad26712895db409b807cdbca5b0`
- Candidate root: `/var/tmp/litchi-odf-oth-structures-candidate-v2-20260910`
- Candidate base `HEAD`: `fdd2b80dfa9efc246a5983a3fec64de25e5c4f63`
- Scoped path manifest: [`scoped-paths.txt`](scoped-paths.txt) (18 paths)
- Primary scoped status: [`primary-scoped-status.txt`](primary-scoped-status.txt); candidate status: [`candidate-scoped-status.txt`](candidate-scoped-status.txt)

## Reconciliation scope

The primary has exactly the same 18 OTH scoped paths as the candidate. `6` paths differ and `12` are byte-identical.

Changed by the patch:
- `crates/litchi-oth/docs/FEATURE_MATRIX.md` — primary `26bb939e1cd84ba6038d280c0587af6005d060385b4cb57897ecf7b04794b561`, merged/candidate `cf227c6cdfbd72da763805f6581e69337a6c1b7ede01019dbdb120f2eaee58a7`
- `crates/litchi-oth/src/codec/mod.rs` — primary `0c7b65375c9475e1435c38c8fe19247399270dadb6702d78068e380c54d04ff1`, merged/candidate `88bfc3169ebe6de036d04f68acf1803ec760ad74ec2a70d7cd779ecb7135069b`
- `crates/litchi-oth/src/codec/structure.rs` — primary `740647a80afe729da0b086c7213f450c253c6e4350a65883b6a8330daa17982b`, merged/candidate `345293ed81daf8838d2ac112336b068355a44484d57cacd2ef94ba7aa6453d7a`
- `crates/litchi-oth/src/facade/mod.rs` — primary `655825f5aa405ef0ded5c16e16a50e794f3b5c652c185caa5060ef33d8b68a07`, merged/candidate `7ee94326b723ae5e474de615089eb17043a053e9cc45c2e8e49051830e771761`
- `crates/litchi-oth/tests/body_structures.rs` — primary `6b23d37895d9cb926d57315d6c82f8c0a41cca14d912a399a73a8996afc67f01`, merged/candidate `98b2490597b8129d0aa9db71a965e4fd86f19b6ac097ee8bd92e1b3e99085c6a`
- `crates/litchi-oth/tests/structure_edits.rs` — primary `1ccff149119f9426ed3b1c98ed7cc4e1a9321898b56362c41d3b2bf41439e088`, merged/candidate `5615c40c971ef6fcae626bca5e5855e77326c2e1df9c7c8b4f2a35c1a52587d2`

Already identical and therefore omitted from the patch (but part of the exact 18-path final set):
- `crates/litchi-oth/src/codec/content.rs` — `07c6dee6d445b5aed472811c44508e81bcd69ff12615273f595c94c704db9f4d`
- `crates/litchi-oth/src/lib.rs` — `2fd877212da7b1921bcede687e52777667c54c76322fa56a6465822ac3aed5c4`
- `crates/litchi-oth/src/model/annotation.rs` — `a884dea8c5d766675d9e9a661e72a33a90625235390fb7b4a14cd000db130391`
- `crates/litchi-oth/src/model/change.rs` — `059ed229d4152ab72242f47a09e4ccb5e193f85bedd338cc792db1f75be9ab69`
- `crates/litchi-oth/src/model/frame.rs` — `1c0ec861172bcc2b600ccd7a729b695a96ab3bc1ffcc267f8c178e4d86324ca4`
- `crates/litchi-oth/src/model/index.rs` — `e404741e9e4f9f222792311921592adf8334c3ad6d4ce25e1c1adf7a3916bac1`
- `crates/litchi-oth/src/model/mod.rs` — `4750e6d7022e832d4f914b355ed1487b21ce3236de19e294efedb3cbfa844da5`
- `crates/litchi-oth/src/model/note.rs` — `9ac5e13336436fd366a6e9b6ece2ae6c8fc05a7d86ed2f2e9bb7839699becfd5`
- `crates/litchi-oth/src/model/ruby.rs` — `f137e8ccb5733668302b2ee990af981af015d83983f9a5491ce2faa0527322cd`
- `crates/litchi-oth/src/model/section.rs` — `7b477ac0d7a26005cc47a990f85e40d5ae284c4cae74e2bf93004d5ad800c6a7`
- `crates/litchi-oth/src/model/table.rs` — `bd5008b46c4a27aea26277ca9ce176040686dd169e3ff11fabad945474567520`
- `crates/litchi-oth/src/package/snapshot.rs` — `bf1a0a872ec02430150a3fee86f9fe2a99af2592c05c0f72318fa0a7a4025388`

The complete primary preimage and merged final hash records are [`path-hashes.json`](path-hashes.json) and [`merged-final-hashes.json`](merged-final-hashes.json).

## Existing primary-only hunk

The only difference between the primary `facade/mod.rs` and the frozen v1 candidate is the existing `Edit::join` condition at source line 2395: primary uses `appended.iter().next().is_some()`, while v1/v2 use `!appended.is_empty()`. The exact proof is [`primary-v1-facade-only-diff.patch`](primary-v1-facade-only-diff.patch), SHA256 `c46f2477b465765959f90cc3ca677aec3fd1be45a30b3db381707b9b906fa5e3`.

This hunk is inside the owned OTH `facade/mod.rs` path, not an unrelated crate change. The v2 candidate intentionally supersedes it with the v2 source, which is the version covered by the supplied strict Clippy gate. No other primary path outside the 18-path manifest is included or changed by this proposal.

## Patch and isolated proof

- Patch: [`primary-to-candidate-v2.patch`](primary-to-candidate-v2.patch), SHA256 `fea3273bf1b9b274a51d87e0295e48f0e4cc380385f5b43dd3cd4c46b08bec2b`.
- The patch contains six file diffs. It was dry-run and applied with `patch --batch --forward --fuzz=0 -p1` in the fresh isolated tree `/var/tmp/litchi-oth-structures-v2-merge-check-20260910`.
- [`verification-receipt.json`](verification-receipt.json) reports all 18 primary preimages, all 18 candidate finals, and all 18 isolated merged finals matching.
- The portable verifier is [`verify_reconciliation.py`](verify_reconciliation.py).

The isolated check proves the patch against the recorded primary preimages; it does not modify the primary worktree. Before staging, re-run the verifier against the live primary and inspect the status for unrelated paths.

## Gate evidence

The supplied root logs were copied without rewriting:

- [`evidence-root-tests-v2-20260910.log`](evidence-root-tests-v2-20260910.log), SHA256 `24d6414f86c746fd38dd722af824c9fe7c737bdfc46046d8664132e1da5f1df2` — all-feature/all-target OTH tests: 56 ordinary tests, zero doctests, no failures.
- [`evidence-root-clippy-v2-20260910.log`](evidence-root-clippy-v2-20260910.log), SHA256 `45d8f7d972875790a6cec7ca48e9acc17c5af68372da1940633becec3b4cd60a` — strict all-feature/all-target Clippy completed successfully.
- [`evidence-root-rustdoc-v2-20260910.log`](evidence-root-rustdoc-v2-20260910.log), SHA256 `690106090986736088b0133154c17b11b510937b047f0bbe3c235dea9b2bfe9d` — rustdoc completed successfully with zero doctests.

The candidate receipt remains separately available at `/var/tmp/litchi-odf-oth-structures-v2-receipt-20260910.md` (SHA256 `bd9196e4b88a1c4253fa57f6720f2967a7a9007ef5c9a1d39dd97905aac25065`).

## Reproduction commands

From any shell, the no-edit verification command is:

```sh
python3 /var/tmp/litchi-oth-structures-v2-primary-reconciliation-20260910/verify_reconciliation.py \
  --manifest /var/tmp/litchi-oth-structures-v2-primary-reconciliation-20260910/path-hashes.json \
  --primary /home/zhuhe/code/litchi-spec-gaps \
  --candidate /var/tmp/litchi-odf-oth-structures-candidate-v2-20260910 \
  --merged /var/tmp/litchi-oth-structures-v2-merge-check-20260910 \
  --output /var/tmp/litchi-oth-structures-v2-primary-reconciliation-20260910/verification-receipt-rerun.json
```

A root-side commit should stage exactly the 18 paths listed in `scoped-paths.txt` after validating the live preimages. This bundle contains no commit or staging operation.

## Bundle integrity

[`artifact-sha256.txt`](artifact-sha256.txt) records SHA256 for every bundle file except the checksum list itself. The copied candidate receipt is [`candidate-v2-receipt.md`](candidate-v2-receipt.md) and retains the receipt SHA256 `bd9196e4b88a1c4253fa57f6720f2967a7a9007ef5c9a1d39dd97905aac25065`.
