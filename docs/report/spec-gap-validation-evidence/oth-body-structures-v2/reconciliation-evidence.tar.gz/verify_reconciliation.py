#!/usr/bin/env python3
"""Verify a primary-to-candidate OTH source reconciliation without editing either tree."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path


def digest(path: Path) -> tuple[str, int]:
    data = path.read_bytes()
    return hashlib.sha256(data).hexdigest(), len(data)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--primary", type=Path, required=True)
    parser.add_argument("--candidate", type=Path, required=True)
    parser.add_argument("--merged", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    manifest = json.loads(args.manifest.read_text())
    checks: list[dict[str, object]] = []
    failures: list[str] = []
    for item in manifest["paths"]:
        relative = Path(item["path"])
        primary_hash, primary_bytes = digest(args.primary / relative)
        candidate_hash, candidate_bytes = digest(args.candidate / relative)
        result: dict[str, object] = {
            "path": item["path"],
            "primary_sha256": primary_hash,
            "expected_primary_sha256": item["primary_preimage_sha256"],
            "primary_bytes": primary_bytes,
            "candidate_sha256": candidate_hash,
            "expected_candidate_sha256": item["candidate_final_sha256"],
            "candidate_bytes": candidate_bytes,
        }
        result["primary_ok"] = primary_hash == item["primary_preimage_sha256"]
        result["candidate_ok"] = candidate_hash == item["candidate_final_sha256"]
        if not result["primary_ok"]:
            failures.append(f"primary preimage mismatch: {item['path']}")
        if not result["candidate_ok"]:
            failures.append(f"candidate final mismatch: {item['path']}")
        if args.merged is not None:
            merged_hash, merged_bytes = digest(args.merged / relative)
            result["merged_sha256"] = merged_hash
            result["merged_bytes"] = merged_bytes
            result["merged_matches_candidate"] = merged_hash == candidate_hash
            if merged_hash != candidate_hash or merged_bytes != candidate_bytes:
                failures.append(f"merged final mismatch: {item['path']}")
        checks.append(result)
    receipt = {
        "manifest": str(args.manifest),
        "primary": str(args.primary),
        "candidate": str(args.candidate),
        "merged": str(args.merged) if args.merged is not None else None,
        "path_count": len(checks),
        "primary_all_ok": not any(not bool(c["primary_ok"]) for c in checks),
        "candidate_all_ok": not any(not bool(c["candidate_ok"]) for c in checks),
        "merged_all_ok": (
            None
            if args.merged is None
            else not any(not bool(c["merged_matches_candidate"]) for c in checks)
        ),
        "failures": failures,
        "checks": checks,
    }
    args.output.write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({key: receipt[key] for key in receipt if key != "checks"}, indent=2))
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
