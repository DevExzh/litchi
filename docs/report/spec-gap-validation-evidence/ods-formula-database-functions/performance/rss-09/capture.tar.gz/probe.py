from pathlib import Path
import subprocess, time, json, hashlib, re
root = Path(__file__).resolve().parent
binaries = [Path('/home/zhuhe/code/litchi-array-target/retained/value-complex-09'), Path('/home/zhuhe/code/litchi-array-target/retained/value-database-09')]
records=[]
for round_number, order in enumerate([(0,1),(1,0),(0,1)],1):
    for index in order:
        binary=binaries[index]; name=f'{round_number:02}-{index}'
        command=['taskset','-c','6',str(binary),'--workload','value-evaluation','--revision','candidate','--group','all','--phase','evaluate','--case','reference-range-256','--warmups','0','--iterations','1','--repeat','25000']
        before=hashlib.sha256(binary.read_bytes()).hexdigest()
        snapshots=[]
        with (root/(name+'.stdout')).open('w') as stdout, (root/(name+'.stderr')).open('w') as stderr:
            process=subprocess.Popen(command,stdout=stdout,stderr=stderr)
            while process.poll() is None and len(snapshots)<3:
                time.sleep(0.05)
                try:
                    executable=Path(f'/proc/{process.pid}/exe').resolve(strict=True)
                    if executable!=binary: continue
                    raw=Path(f'/proc/{process.pid}/smaps').read_bytes()
                except FileNotFoundError: break
                snap=f'{name}-{len(snapshots)}.smaps';(root/snap).write_bytes(raw);snapshots.append(snap)
            status=process.wait(timeout=60)
        after=hashlib.sha256(binary.read_bytes()).hexdigest()
        assert status==0 and before==after and len(snapshots)==3
        records.append({'round':round_number,'slot':'AB'[index],'command':command,'status':status,'binary_sha256':before,'snapshots':snapshots})
receipt={'purpose':'RSS attribution under a sustained range-evaluation loop; not a latency comparison','source_basis':'database candidate-09 versus complex candidate-09','records':records,'artifacts':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(root.iterdir()) if p.is_file()}}
(root/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('Captured six serial processes and eighteen live smaps snapshots.')
