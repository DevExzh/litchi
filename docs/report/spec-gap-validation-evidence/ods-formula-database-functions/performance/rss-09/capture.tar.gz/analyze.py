from pathlib import Path
import re,json,statistics
p=Path(__file__).resolve().parent
r=json.loads((p/'receipt.json').read_text());values={'A':[],'B':[]}
for record in r['records']:
 for n in record['snapshots']:
  sums={};kind=None
  for line in (p/n).read_text().splitlines():
   if re.match(r'^[0-9a-f]+-[0-9a-f]+ ',line):
    fields=line.split(maxsplit=5);path=fields[5] if len(fields)>5 else ''
    kind='binary' if '/retained/value-' in path else 'heap' if path=='[heap]' else 'stack' if path=='[stack]' else 'shared libraries' if '.so' in path else 'other'
   elif line.startswith('Rss:'):sums[kind]=sums.get(kind,0)+int(line.split()[1])
  sums['total']=sum(sums.values());values[record['slot']].append(sums)
summary={slot:{k:statistics.median(x.get(k,0) for x in rows) for k in sorted(set().union(*(x.keys() for x in rows)))} for slot,rows in values.items()}
print(json.dumps({'units':'KiB','median_across_nine_snapshots_per_slot':summary,'snapshots':values},indent=2))
