from pathlib import Path
import subprocess,json,hashlib,sys,shutil
root=Path('/home/zhuhe/code/litchi-spec-gaps')
p=root/'docs/report/spec-gap-validation-evidence/ods-formula-array-reference-evaluation/performance'
out=Path('/home/zhuhe/code/litchi-array-scalar-paired-01');out.mkdir()
shutil.copyfile(__file__,out/'run.py')
bins={'baseline':Path('/home/zhuhe/code/litchi-array-target/retained/scalar-baseline'),'candidate':Path('/home/zhuhe/code/litchi-array-target/release/ods-formula-array-reference-evaluation-scalar-profile')}
inputs=list(bins.values())+[p/'scalar-harness'/n for n in ('run.py','src/main.rs','Cargo.toml','Cargo.lock')]+[p/'compare.py']
def hashes():return {str(f):hashlib.sha256(f.read_bytes()).hexdigest() for f in inputs}
receipt={'before':hashes(),'commands':[],'orders':[['baseline','candidate'],['candidate','baseline'],['baseline','candidate']],'scope':'Three serial paired shared-host CPU6 windows; no automatic performance acceptance.'}
try:
 for i,order in enumerate(receipt['orders'],1):
  for rev in order:
   cmd=[sys.executable,'-B',str(p/'scalar-harness/run.py'),'--binary',str(bins[rev]),'--output',str(out/f'pair-{i}-{rev}'),'--revision',rev,'--warmups','5','--iterations','31']
   r=subprocess.run(cmd,cwd=root,capture_output=True,text=True)
   (out/f'pair-{i}-{rev}.log').write_text(r.stdout+r.stderr)
   receipt['commands'].append({'command':cmd,'status':r.returncode})
   if r.returncode:raise RuntimeError('capture failed')
  cmd=[sys.executable,'-B',str(p/'compare.py'),str(out/f'pair-{i}-baseline/raw.csv'),str(out/f'pair-{i}-candidate/raw.csv'),str(out/f'pair-{i}-compare.json')]
  r=subprocess.run(cmd,cwd=root,capture_output=True,text=True)
  (out/f'pair-{i}-compare.log').write_text(r.stdout+r.stderr)
  receipt['commands'].append({'command':cmd,'status':r.returncode})
  if r.returncode:raise RuntimeError('comparison failed')
 receipt['status']='complete'
finally:
 receipt['after']=hashes();receipt['inputs_unchanged']=receipt['before']==receipt['after'];(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
 if not receipt['inputs_unchanged']:raise RuntimeError('input mutation')
