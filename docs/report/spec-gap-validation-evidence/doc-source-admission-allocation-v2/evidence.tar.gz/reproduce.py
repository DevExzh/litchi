#!/usr/bin/env python3
"""Reproduce the debug allocation experiment using verified source checkouts."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--control-source", required=True, type=Path)
    parser.add_argument("--candidate-source", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--prepare-only", action="store_true")
    args = parser.parse_args()
    bundle = Path(__file__).resolve().parent
    source_manifest = json.loads((bundle / "source-manifest.json").read_text())
    sources = {
        "control": args.control_source.resolve(),
        "candidate": args.candidate_source.resolve(),
    }
    for entry in source_manifest["files"]:
        for side, root in sources.items():
            actual = hashlib.sha256((root / entry["path"]).read_bytes()).hexdigest()
            if actual != entry[f"{side}_sha256"]:
                raise ValueError(f"Source mismatch: {side}/{entry['path']}")
    fixtures = json.loads((bundle / "original-v2/fixture-manifest.json").read_text())["fixtures"]
    for name, expected in fixtures.items():
        data = (bundle / "fixtures" / name).read_bytes()
        if len(data) != expected["bytes"] or hashlib.sha256(data).hexdigest() != expected["sha256"]:
            raise ValueError(f"Fixture mismatch: {name}")

    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    env = os.environ.copy()
    env.pop("RUSTFLAGS", None)
    env.pop("CARGO_ENCODED_RUSTFLAGS", None)
    commands = []
    original_roots = {
        "control": "/var/tmp/litchi-common-doc-source-c859",
        "candidate": "/var/tmp/litchi-doc-ole-streams-validation-20260909",
    }
    for side, source in sources.items():
        project = output / side
        (project / "src").mkdir(parents=True)
        (project / "reports").mkdir()
        shutil.copytree(bundle / "fixtures", project / "fixtures")
        shutil.copyfile(bundle / "supplemental-v2/harness-main-oversized-arc.rs", project / "src/main.rs")
        shutil.copyfile(bundle / "supplemental-v2/Cargo.lock", project / "Cargo.lock")
        manifest = (bundle / f"supplemental-v2/{side}-Cargo.toml").read_text()
        for crate in ("litchi-cfb", "litchi-doc", "litchi-ole-common"):
            old = json.dumps(f"{original_roots[side]}/crates/{crate}")
            new = json.dumps(str(source / "crates" / crate))
            if old not in manifest:
                raise ValueError(f"Missing manifest path: {old}")
            manifest = manifest.replace(old, new)
        (project / "Cargo.toml").write_text(manifest)
        target = output / f"target-{side}"
        run_env = env | {"HARNESS_ROOT": str(project), "CARGO_TARGET_DIR": str(target)}
        command = ["cargo", "+1.95.0", "run", "--locked", "--manifest-path", str(project / "Cargo.toml")]
        if side == "candidate":
            command += ["--features", "candidate"]
        for mode in ("correctness", "measure"):
            invocation = command + ["--", mode]
            commands.append({"cwd": str(project), "argv": invocation,
                             "environment": {"HARNESS_ROOT": str(project), "CARGO_TARGET_DIR": str(target),
                                             "RUSTFLAGS": None, "CARGO_ENCODED_RUSTFLAGS": None,
                                             "RUSTUP_HOME": env.get("RUSTUP_HOME")}})
            (output / "commands.json").write_text(json.dumps(commands, indent=2) + "\n")
            if not args.prepare_only:
                with (project / f"{mode}.log").open("w") as log:
                    subprocess.run(invocation, cwd=project, env=run_env, stdout=log, stderr=subprocess.STDOUT, check=True)
                if mode == "correctness":
                    report = json.loads((project / "reports/correctness.json").read_text())
                    for profile, checks in report["embedded_object"].items():
                        for name, value in checks.items():
                            if isinstance(value, bool) and not value:
                                raise ValueError(f"Correctness failure: {side}/{profile}/{name}")
    print(f"{'Prepared' if args.prepare_only else 'Completed'} experiment: {output}")


if __name__ == "__main__":
    main()
