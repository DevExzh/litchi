#![allow(clippy::cast_possible_truncation)]
#![allow(clippy::cast_sign_loss)]
#![allow(clippy::too_many_arguments)]
#![allow(clippy::too_many_lines)]

//! Allocation-only matched harness for DOC embedded-object source admission.
//!
//! The control and candidate runs use this same source with only the
//! `litchi-*` dependency roots changed. Fixture construction and caller-owned
//! replacement setup happen outside counted regions. No clock is started.

use litchi_cfb::{OleFile, OleWriter};
use litchi_doc::embedded_object::{
    Editor as EmbeddedEditor, Limits as EmbeddedLimits, Snapshot as EmbeddedSnapshot,
    WriteOptions,
};
use litchi_doc::writer::Writer;
use litchi_ole_common::object::{
    Editor as CommonEditor, Limits as CommonLimits, Snapshot as CommonSnapshot, Target, Targets,
};
use serde_json::{Value, json};
use sha2::{Digest, Sha256};
use std::alloc::{GlobalAlloc, Layout, System};
use std::collections::BTreeMap;
use std::env;
use std::error::Error;
use std::fs;
use std::hint::black_box;
use std::io::Cursor;
use std::path::{Path, PathBuf};
use std::sync::Arc;
use std::sync::atomic::{AtomicUsize, Ordering};

type AnyResult<T> = Result<T, Box<dyn Error>>;

const SOURCE_COMMIT: &str = "c85997bc0d93ea523731d6e7622b2300e1747255";
const CANDIDATE_MANIFEST_SHA256: &str =
    "08d333312f13ae3be21cd64a10ba15659fc2678904f444a951fd82c69c716d92";
const STORAGE_ID: u32 = 42;
const WARMUPS: usize = 3;
const SAMPLES: usize = 15;

struct CountingAllocator;

struct Counters {
    alloc_calls: AtomicUsize,
    allocated_bytes: AtomicUsize,
    realloc_calls: AtomicUsize,
    reallocated_bytes: AtomicUsize,
    dealloc_calls: AtomicUsize,
    deallocated_bytes: AtomicUsize,
    live_bytes: AtomicUsize,
    peak_live_bytes: AtomicUsize,
    phase_peak_live_bytes: AtomicUsize,
}

#[derive(Clone, Copy, Debug)]
struct CounterSnapshot {
    alloc_calls: usize,
    allocated_bytes: usize,
    realloc_calls: usize,
    reallocated_bytes: usize,
    dealloc_calls: usize,
    deallocated_bytes: usize,
    live_bytes: usize,
}

#[derive(Clone, Copy, Debug)]
struct CounterDelta {
    alloc_calls: usize,
    allocated_bytes: usize,
    realloc_calls: usize,
    reallocated_bytes: usize,
    dealloc_calls: usize,
    deallocated_bytes: usize,
    peak_live_bytes: usize,
    end_live_delta: usize,
}

#[global_allocator]
static ALLOCATOR: CountingAllocator = CountingAllocator;

static COUNTERS: Counters = Counters {
    alloc_calls: AtomicUsize::new(0),
    allocated_bytes: AtomicUsize::new(0),
    realloc_calls: AtomicUsize::new(0),
    reallocated_bytes: AtomicUsize::new(0),
    dealloc_calls: AtomicUsize::new(0),
    deallocated_bytes: AtomicUsize::new(0),
    live_bytes: AtomicUsize::new(0),
    peak_live_bytes: AtomicUsize::new(0),
    phase_peak_live_bytes: AtomicUsize::new(0),
};

unsafe impl GlobalAlloc for CountingAllocator {
    unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
        // SAFETY: forwarding the allocator contract to the system allocator.
        let pointer = unsafe { System.alloc(layout) };
        if !pointer.is_null() {
            record_alloc(layout.size());
        }
        pointer
    }

    unsafe fn dealloc(&self, pointer: *mut u8, layout: Layout) {
        // SAFETY: the caller supplies the original pointer/layout pair.
        unsafe { System.dealloc(pointer, layout) };
        record_dealloc(layout.size());
    }

    unsafe fn realloc(&self, pointer: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
        // SAFETY: forwarding the allocator contract to the system allocator.
        let new_pointer = unsafe { System.realloc(pointer, layout, new_size) };
        if !new_pointer.is_null() {
            record_realloc(layout.size(), new_size);
        }
        new_pointer
    }
}

fn record_alloc(size: usize) {
    COUNTERS.alloc_calls.fetch_add(1, Ordering::Relaxed);
    COUNTERS.allocated_bytes.fetch_add(size, Ordering::Relaxed);
    add_live(size);
}

fn record_dealloc(size: usize) {
    COUNTERS.dealloc_calls.fetch_add(1, Ordering::Relaxed);
    COUNTERS.deallocated_bytes.fetch_add(size, Ordering::Relaxed);
    subtract_live(size);
}

fn record_realloc(old_size: usize, new_size: usize) {
    COUNTERS.realloc_calls.fetch_add(1, Ordering::Relaxed);
    COUNTERS.reallocated_bytes.fetch_add(new_size, Ordering::Relaxed);
    if new_size >= old_size {
        let growth = new_size - old_size;
        COUNTERS.alloc_calls.fetch_add(1, Ordering::Relaxed);
        COUNTERS.allocated_bytes.fetch_add(growth, Ordering::Relaxed);
        add_live(growth);
    } else {
        subtract_live(old_size - new_size);
    }
}

fn add_live(size: usize) {
    let live = COUNTERS
        .live_bytes
        .fetch_add(size, Ordering::Relaxed)
        .saturating_add(size);
    update_max(&COUNTERS.peak_live_bytes, live);
    update_max(&COUNTERS.phase_peak_live_bytes, live);
}

fn subtract_live(size: usize) {
    let _ = COUNTERS
        .live_bytes
        .fetch_update(Ordering::Relaxed, Ordering::Relaxed, |old| {
            Some(old.saturating_sub(size))
        });
}

fn update_max(target: &AtomicUsize, value: usize) {
    let _ = target.fetch_update(Ordering::Relaxed, Ordering::Relaxed, |old| {
        (value > old).then_some(value)
    });
}

fn counters() -> CounterSnapshot {
    CounterSnapshot {
        alloc_calls: COUNTERS.alloc_calls.load(Ordering::Relaxed),
        allocated_bytes: COUNTERS.allocated_bytes.load(Ordering::Relaxed),
        realloc_calls: COUNTERS.realloc_calls.load(Ordering::Relaxed),
        reallocated_bytes: COUNTERS.reallocated_bytes.load(Ordering::Relaxed),
        dealloc_calls: COUNTERS.dealloc_calls.load(Ordering::Relaxed),
        deallocated_bytes: COUNTERS.deallocated_bytes.load(Ordering::Relaxed),
        live_bytes: COUNTERS.live_bytes.load(Ordering::Relaxed),
    }
}

fn begin_phase() -> CounterSnapshot {
    let before = counters();
    COUNTERS
        .phase_peak_live_bytes
        .store(before.live_bytes, Ordering::Relaxed);
    before
}

fn end_phase(before: CounterSnapshot) -> CounterDelta {
    let after = counters();
    let phase_peak = COUNTERS.phase_peak_live_bytes.load(Ordering::Relaxed);
    CounterDelta {
        alloc_calls: after.alloc_calls.saturating_sub(before.alloc_calls),
        allocated_bytes: after.allocated_bytes.saturating_sub(before.allocated_bytes),
        realloc_calls: after.realloc_calls.saturating_sub(before.realloc_calls),
        reallocated_bytes: after
            .reallocated_bytes
            .saturating_sub(before.reallocated_bytes),
        dealloc_calls: after.dealloc_calls.saturating_sub(before.dealloc_calls),
        deallocated_bytes: after
            .deallocated_bytes
            .saturating_sub(before.deallocated_bytes),
        peak_live_bytes: phase_peak.saturating_sub(before.live_bytes),
        end_live_delta: after.live_bytes.saturating_sub(before.live_bytes),
    }
}

#[allow(dead_code, reason = "held values keep the measured result alive")]
struct Held {
    common_snapshot: Option<CommonSnapshot>,
    snapshot: Option<EmbeddedSnapshot>,
    transaction: Option<litchi_doc::embedded_object::Transaction>,
    commit: Option<litchi_doc::embedded_object::Commit>,
    bytes: Option<Vec<u8>>,
    input_pointer_survived: bool,
    input_capacity: usize,
    expected_input_pointer: usize,
    accepted: bool,
}

struct Counted {
    held: Held,
    counters: CounterDelta,
}

fn counted<F>(operation: F) -> AnyResult<Counted>
where
    F: FnOnce() -> AnyResult<Held>,
{
    let before = begin_phase();
    let result = operation();
    let counters = end_phase(before);
    let held = black_box(result?);
    Ok(Counted { held, counters })
}

#[derive(Clone)]
struct Fixtures {
    common_small: Vec<u8>,
    common_large: Vec<u8>,
    embedded_small: Vec<u8>,
    embedded_large: Vec<u8>,
    replacement_small: Vec<u8>,
    replacement_large: Vec<u8>,
    malformed_small: Vec<u8>,
    malformed_large: Vec<u8>,
}

fn write_cfb(
    build: impl FnOnce(&mut OleWriter) -> Result<(), litchi_cfb::OleError>,
) -> AnyResult<Vec<u8>> {
    let mut writer = OleWriter::new();
    build(&mut writer)?;
    let mut output = Cursor::new(Vec::new());
    writer.write_to(&mut output)?;
    Ok(output.into_inner())
}

fn pattern(size: usize, seed: u8) -> Vec<u8> {
    (0..size)
        .map(|index| seed.wrapping_add((index as u8).wrapping_mul(31)))
        .collect()
}

fn picture_data(storage_id: u32) -> Vec<u8> {
    let mut value = 12u32.to_le_bytes().to_vec();
    value.extend_from_slice(&storage_id.to_le_bytes());
    value.extend_from_slice(&[0; 4]);
    value
}

fn common_object_fixture(payload_size: usize, seed: u8) -> AnyResult<Vec<u8>> {
    let payload = pattern(payload_size, seed);
    let opaque = pattern(payload_size / 4 + 17, seed.wrapping_add(3));
    write_cfb(|writer| {
        writer.set_root_state_bits(0x1020_3040);
        writer.set_root_creation_time_from_source(0x0102_0304_0506_0708);
        writer.set_root_modified_time(0x1112_1314_1516_1718);
        writer.create_storage(&["ObjectPool", "_42"])?;
        writer.set_storage_metadata(
            &["ObjectPool", "_42"],
            0xA1A2_A3A4,
            0x2122_2324_2526_2728,
            0x3132_3334_3536_3738,
        )?;
        writer.create_stream(&["WordDocument"], b"host-document-bytes")?;
        writer.create_stream_with_metadata(
            &["ObjectPool", "_42", "\u{3}ObjInfo"],
            &[0x40, 0, 2, 0],
            0xB1B2_B3B4,
            0x4142_4344_4546_4748,
            0x5152_5354_5556_5758,
        )?;
        writer.create_stream_with_metadata(
            &["ObjectPool", "_42", "\u{1}CompObj"],
            b"opaque-compobj-metadata",
            0xC1C2_C3C4,
            0x6162_6364_6566_6768,
            0x7172_7374_7576_7778,
        )?;
        writer.create_stream_with_metadata(
            &["ObjectPool", "_42", "\u{3}PRINT"],
            &opaque,
            0xD1D2_D3D4,
            0x8182_8384_8586_8788,
            0x9192_9394_9596_9798,
        )?;
        writer.create_stream(&["ObjectPool", "_42", "Payload"], &payload)?;
        Ok(())
    })
}

fn common_limits() -> CommonLimits {
    CommonLimits {
        max_object_size: 4 * 1024 * 1024,
        ..CommonLimits::default()
    }
}

fn common_targets() -> Targets {
    Targets::one(Target::new("object", ["ObjectPool", "_42"]).expect("valid target"))
}

#[cfg(feature = "candidate")]
fn common_input_survives(
    editor: &CommonEditor,
    expected_pointer: usize,
    expected_capacity: usize,
) -> bool {
    let retained = editor.source_shared();
    retained.as_ref().as_ptr() as usize == expected_pointer
        && retained.capacity() == expected_capacity
}

#[cfg(not(feature = "candidate"))]
fn common_input_survives(
    _editor: &CommonEditor,
    _expected_pointer: usize,
    _expected_capacity: usize,
) -> bool {
    // The frozen control does not expose the retained source handle. Its
    // consumed Vec is nevertheless moved into the common owner; allocation
    // counts cover the observable comparison boundary.
    true
}

fn standalone_object(payload_size: usize, seed: u8) -> AnyResult<Vec<u8>> {
    let comp_obj = litchi_doc::writer::ole_metadata::generate_compobj_stream();
    let ole = litchi_doc::writer::ole_metadata::generate_ole_stream();
    let obj_info = [0x00, 0x00, 0x03, 0x00, 0x00, 0x00];
    let unknown = [0x10, 0x20, 0x30, 0x40];
    let payload = pattern(payload_size, seed);
    write_cfb(|writer| {
        writer.create_stream(&["\u{1}CompObj"], &comp_obj)?;
        writer.create_stream(&["\u{1}Ole"], &ole)?;
        writer.create_stream(&["\u{3}ObjInfo"], &obj_info)?;
        writer.create_stream(&["VendorMetadata"], &unknown)?;
        writer.create_stream(&["OpaquePayload", "Binary"], &payload)?;
        Ok(())
    })
}

fn base_doc(paragraphs: usize, width: usize) -> AnyResult<Vec<u8>> {
    let mut writer = Writer::new();
    for index in 0..paragraphs {
        writer.add_paragraph(&format!("{index:08}: {}", "x".repeat(width)))?;
    }
    let mut output = Cursor::new(Vec::new());
    writer.write_to(&mut output)?;
    Ok(output.into_inner())
}

fn embedded_doc_fixture(
    payload_size: usize,
    paragraphs: usize,
    width: usize,
    seed: u8,
) -> AnyResult<Vec<u8>> {
    let base = base_doc(paragraphs, width)?;
    let mut editor = EmbeddedEditor::open(base, EmbeddedLimits::default())?;
    editor.add(WriteOptions::new(
        STORAGE_ID,
        standalone_object(payload_size, seed)?,
        picture_data(STORAGE_ID),
    ))?;
    Ok(editor.finish()?)
}

fn generate_fixtures(dir: &Path) -> AnyResult<()> {
    fs::create_dir_all(dir)?;
    let fixtures = [
        ("common-small.cfb", common_object_fixture(4 * 1024, 0x11)?),
        (
            "common-large.cfb",
            common_object_fixture(1024 * 1024, 0x22)?,
        ),
        (
            "embedded-small.doc",
            embedded_doc_fixture(4 * 1024, 2, 64, 0x11)?,
        ),
        (
            "embedded-large.doc",
            embedded_doc_fixture(1024 * 1024, 2_048, 256, 0x22)?,
        ),
        ("replacement-small.cfb", standalone_object(8 * 1024, 0x33)?),
        (
            "replacement-large.cfb",
            standalone_object(1024 * 1024, 0x44)?,
        ),
        ("malformed-small.bin", vec![0u8; 16 * 1024]),
        ("malformed-large.bin", vec![0u8; 1024 * 1024]),
    ];
    for (name, bytes) in fixtures {
        fs::write(dir.join(name), bytes)?;
    }
    Ok(())
}

fn read_fixtures(dir: &Path) -> AnyResult<Fixtures> {
    let read = |name: &str| -> AnyResult<Vec<u8>> { Ok(fs::read(dir.join(name))?) };
    Ok(Fixtures {
        common_small: read("common-small.cfb")?,
        common_large: read("common-large.cfb")?,
        embedded_small: read("embedded-small.doc")?,
        embedded_large: read("embedded-large.doc")?,
        replacement_small: read("replacement-small.cfb")?,
        replacement_large: read("replacement-large.cfb")?,
        malformed_small: read("malformed-small.bin")?,
        malformed_large: read("malformed-large.bin")?,
    })
}

fn replacement_limits(profile: &str) -> EmbeddedLimits {
    EmbeddedLimits {
        max_object_size: if profile == "small" {
            256 * 1024
        } else {
            4 * 1024 * 1024
        },
        ..EmbeddedLimits::default()
    }
}

fn source_hash(bytes: &[u8]) -> String {
    let mut digest = Sha256::new();
    digest.update(bytes);
    digest
        .finalize()
        .iter()
        .map(|byte| format!("{byte:02x}"))
        .collect()
}

fn inventory_projection(snapshot: &EmbeddedSnapshot) -> AnyResult<Value> {
    let inventory = snapshot.inventory()?;
    let mut entries = Vec::new();
    for entry in inventory.iter() {
        let metadata = entry.metadata();
        entries.push(json!({
            "storage_id": entry.storage_id(),
            "reference": {
                "storage_id": entry.reference().storage_id,
                "storage_name": entry.reference().storage_name,
                "start_cp": entry.reference().start_cp,
                "separator_cp": entry.reference().separator_cp,
                "end_cp": entry.reference().end_cp,
                "data_offset": entry.reference().data_offset,
            },
            "class_id": metadata.class_id(),
            "comp_obj": metadata.comp_obj().map(|value| source_hash(value.bytes())),
            "ole": metadata.ole().map(|value| source_hash(value.bytes())),
            "obj_info": metadata.obj_info().map(|value| format!("{value:?}")),
            "unknown": metadata.unknown().iter().map(|value| {
                json!({
                    "path": value.path(),
                    "bytes": value.bytes().len(),
                    "sha256": source_hash(value.bytes()),
                })
            }).collect::<Vec<_>>(),
        }));
    }
    Ok(Value::Array(entries))
}

fn cfb_stream(bytes: &[u8], path: &[&str]) -> AnyResult<Vec<u8>> {
    let mut file = OleFile::open(Cursor::new(bytes.to_vec()))?;
    Ok(file.open_stream(path)?.to_vec())
}

fn correctness(fixtures: &Fixtures) -> AnyResult<Value> {
    let mut profiles = BTreeMap::new();
    for (profile, source, replacement) in [
        ("small", &fixtures.embedded_small, &fixtures.replacement_small),
        ("large", &fixtures.embedded_large, &fixtures.replacement_large),
    ] {
        let limits = replacement_limits(profile);
        let source_snapshot = EmbeddedSnapshot::open(source.clone(), limits)?;
        let before_objects = source_snapshot.objects()?;
        let before_inventory = inventory_projection(&source_snapshot)?;
        let source_shared = source_snapshot.bytes_shared();
        let no_op_exact = source_snapshot.finish() == *source;
        let noop_commit = source_snapshot.edit().commit()?;
        let no_op_commit_exact = noop_commit.snapshot().finish() == *source;
        let no_op_shared = Arc::ptr_eq(&source_shared, &noop_commit.snapshot().bytes_shared());

        let mut success_transaction = source_snapshot.edit();
        success_transaction.replace_storage(STORAGE_ID, replacement.clone())?;
        let success_commit = success_transaction.commit()?;
        let after = success_commit.snapshot();
        let after_inventory = inventory_projection(after)?;
        let replacement_payload = cfb_stream(
            after.bytes(),
            &["ObjectPool", "_42", "OpaquePayload", "Binary"],
        )?;
        let expected_payload = cfb_stream(replacement, &["OpaquePayload", "Binary"])?;
        let metadata_core_preserved = before_inventory
            .as_array()
            .zip(after_inventory.as_array())
            .is_some_and(|(before, after)| {
                before.len() == after.len()
                    && before.iter().zip(after).all(|(before, after)| {
                        before.get("storage_id") == after.get("storage_id")
                            && before.get("reference") == after.get("reference")
                            && before.get("class_id") == after.get("class_id")
                            && before.get("comp_obj") == after.get("comp_obj")
                            && before.get("ole") == after.get("ole")
                            && before.get("obj_info") == after.get("obj_info")
                    })
            });

        let malformed = if profile == "small" {
            &fixtures.malformed_small
        } else {
            &fixtures.malformed_large
        };
        let mut malformed_transaction = source_snapshot.edit();
        let malformed_rejected = malformed_transaction
            .replace_storage(STORAGE_ID, malformed.clone())
            .is_err();
        let malformed_commit = malformed_transaction.commit()?;
        let malformed_source_exact = malformed_commit.snapshot().bytes() == source;
        let malformed_refs_preserved = malformed_commit.snapshot().objects()? == before_objects;
        let malformed_inventory_preserved =
            inventory_projection(malformed_commit.snapshot())? == before_inventory;
        let malformed_shared = Arc::ptr_eq(
            &source_shared,
            &malformed_commit.snapshot().bytes_shared(),
        );

        let oversized = vec![0u8; limits.max_object_size as usize + 1];
        let mut oversized_transaction = source_snapshot.edit();
        let oversized_rejected = oversized_transaction
            .replace_storage(STORAGE_ID, oversized)
            .is_err();
        let oversized_commit = oversized_transaction.commit()?;
        let oversized_source_exact = oversized_commit.snapshot().bytes() == source;
        let oversized_shared = Arc::ptr_eq(
            &source_shared,
            &oversized_commit.snapshot().bytes_shared(),
        );
        let oversized_refs_preserved = oversized_commit.snapshot().objects()? == before_objects;
        let oversized_inventory_preserved =
            inventory_projection(oversized_commit.snapshot())? == before_inventory;
        profiles.insert(
            profile,
            json!({
                "source_bytes": source.len(),
                "source_sha256": source_hash(source),
                "replacement_bytes": replacement.len(),
                "replacement_sha256": source_hash(replacement),
                "source_reference_count": before_objects.len(),
                "snapshot_no_op_exact": no_op_exact,
                "snapshot_noop_commit_exact": no_op_commit_exact,
                "snapshot_noop_shared_source": no_op_shared,
                "valid_replacement_accepted": success_commit.changed(),
                "valid_replacement_payload_exact": replacement_payload == expected_payload,
                "valid_replacement_references_preserved": after.objects()? == before_objects,
                "valid_replacement_core_metadata_preserved": metadata_core_preserved,
                "malformed_rejected": malformed_rejected,
                "malformed_source_exact": malformed_source_exact,
                "malformed_references_preserved": malformed_refs_preserved,
                "malformed_inventory_preserved": malformed_inventory_preserved,
                "malformed_shared_source": malformed_shared,
                "oversized_rejected": oversized_rejected,
                "oversized_source_exact": oversized_source_exact,
                "oversized_shared_source": oversized_shared,
                "oversized_references_preserved": oversized_refs_preserved,
                "oversized_inventory_preserved": oversized_inventory_preserved,
            }),
        );
    }
    Ok(json!({
        "source_commit": SOURCE_COMMIT,
        "candidate_manifest_sha256": CANDIDATE_MANIFEST_SHA256,
        "timed": false,
        "allocation_only": true,
        "embedded_object": profiles,
    }))
}

fn counters_json(counters: CounterDelta) -> Value {
    json!({
        "alloc_calls": counters.alloc_calls,
        "allocated_bytes": counters.allocated_bytes,
        "realloc_calls": counters.realloc_calls,
        "reallocated_bytes": counters.reallocated_bytes,
        "dealloc_calls": counters.dealloc_calls,
        "deallocated_bytes": counters.deallocated_bytes,
        "peak_live_bytes": counters.peak_live_bytes,
        "end_live_delta": counters.end_live_delta,
    })
}

fn run_samples<F>(
    rows: &mut Vec<Value>,
    operation: &str,
    profile: &str,
    input_bytes: usize,
    input_kind: &str,
    source_bytes: usize,
    caller_input_setup_excluded: bool,
    mut run_once: F,
) -> AnyResult<()>
where
    F: FnMut() -> AnyResult<Counted>,
{
    for _ in 0..WARMUPS {
        let counted = run_once()?;
        if !counted.held.accepted {
            return Err(format!("warmup correctness failed for {operation}/{profile}").into());
        }
        drop(counted);
    }
    for sample in 0..SAMPLES {
        let counted = run_once()?;
        if !counted.held.accepted {
            return Err(format!("sample correctness failed for {operation}/{profile}").into());
        }
        let input_pointer_survived = counted.held.input_pointer_survived;
        let input_capacity = counted.held.input_capacity;
        let expected_input_pointer = counted.held.expected_input_pointer;
        let mut row = counters_json(counted.counters);
        if let Value::Object(object) = &mut row {
            object.insert("source_commit".to_owned(), json!(SOURCE_COMMIT));
            object.insert(
                "candidate_manifest_sha256".to_owned(),
                json!(CANDIDATE_MANIFEST_SHA256),
            );
            object.insert("operation".to_owned(), json!(operation));
            object.insert("profile".to_owned(), json!(profile));
            object.insert("sample".to_owned(), json!(sample));
            object.insert("warmup".to_owned(), json!(false));
            object.insert("allocation_only".to_owned(), json!(true));
            object.insert("timed".to_owned(), json!(false));
            object.insert("clock_started".to_owned(), json!(false));
            object.insert("input_bytes".to_owned(), json!(input_bytes));
            object.insert("input_kind".to_owned(), json!(input_kind));
            object.insert("source_bytes".to_owned(), json!(source_bytes));
            object.insert(
                "replacement_bytes".to_owned(),
                if input_kind == "replacement" {
                    json!(input_bytes)
                } else {
                    Value::Null
                },
            );
            object.insert(
                "caller_input_setup_excluded".to_owned(),
                json!(caller_input_setup_excluded),
            );
            object.insert(
                "input_pointer_survived".to_owned(),
                json!(input_pointer_survived),
            );
            object.insert("input_capacity".to_owned(), json!(input_capacity));
            object.insert(
                "expected_input_pointer".to_owned(),
                json!(expected_input_pointer),
            );
        }
        rows.push(row);
        drop(counted);
    }
    Ok(())
}

fn measure_common(fixtures: &Fixtures, rows: &mut Vec<Value>) -> AnyResult<()> {
    for (profile, source) in [
        ("small", &fixtures.common_small),
        ("large", &fixtures.common_large),
    ] {
        let source = source.clone();
        run_samples(
            rows,
            "common_editor_open_snapshot_noop_finish",
            profile,
            source.len(),
            "source",
            source.len(),
            true,
            || {
                let bytes = source.clone();
                let expected_pointer = bytes.as_ptr() as usize;
                let expected_capacity = bytes.capacity();
                counted(|| {
                    let editor =
                        CommonEditor::open(bytes, common_targets(), common_limits())?;
                    let input_pointer_survived =
                        common_input_survives(&editor, expected_pointer, expected_capacity);
                    let snapshot = editor.snapshot();
                    let output = editor.finish()?;
                    let exact = output == source;
                    Ok(Held {
                        common_snapshot: Some(snapshot),
                        snapshot: None,
                        transaction: None,
                        commit: None,
                        bytes: Some(output),
                        input_pointer_survived,
                        input_capacity: expected_capacity,
                        expected_input_pointer: expected_pointer,
                        accepted: exact && input_pointer_survived,
                    })
                })
            },
        )?;

        let source_for_unique = source.clone();
        run_samples(
            rows,
            "common_editor_open_unique_noop_finish",
            profile,
            source.len(),
            "source",
            source.len(),
            true,
            || {
                let bytes = source_for_unique.clone();
                let expected_pointer = bytes.as_ptr() as usize;
                let expected_capacity = bytes.capacity();
                counted(|| {
                    let editor =
                        CommonEditor::open(bytes, common_targets(), common_limits())?;
                    let input_pointer_survived =
                        common_input_survives(&editor, expected_pointer, expected_capacity);
                    let output = editor.finish()?;
                    let exact = output == source_for_unique;
                    Ok(Held {
                        common_snapshot: None,
                        snapshot: None,
                        transaction: None,
                        commit: None,
                        bytes: Some(output),
                        input_pointer_survived,
                        input_capacity: expected_capacity,
                        expected_input_pointer: expected_pointer,
                        accepted: exact && input_pointer_survived,
                    })
                })
            },
        )?;
    }
    Ok(())
}

fn measure(fixtures: &Fixtures) -> AnyResult<Vec<Value>> {
    let mut rows = Vec::new();
    measure_common(fixtures, &mut rows)?;
    for (profile, source, replacement) in [
        ("small", &fixtures.embedded_small, &fixtures.replacement_small),
        ("large", &fixtures.embedded_large, &fixtures.replacement_large),
    ] {
        let source = source.clone();
        run_samples(
            &mut rows,
            "embedded_object_snapshot_open",
            profile,
            source.len(),
            "source",
            source.len(),
            true,
            || {
                let bytes = source.clone();
                counted(|| {
                    let snapshot = EmbeddedSnapshot::open(bytes, EmbeddedLimits::default())?;
                    Ok(Held {
                        common_snapshot: None,
                        snapshot: Some(snapshot),
                        transaction: None,
                        commit: None,
                        bytes: None,
                        input_pointer_survived: true,
                        input_capacity: 0,
                        expected_input_pointer: 0,
                        accepted: true,
                    })
                })
            },
        )?;

        let source_for_run = source.clone();
        run_samples(
            &mut rows,
            "embedded_object_snapshot_open_noop_finish",
            profile,
            source.len(),
            "source",
            source.len(),
            true,
            || {
                let bytes = source_for_run.clone();
                counted(|| {
                    let snapshot = EmbeddedSnapshot::open(bytes, EmbeddedLimits::default())?;
                    let output = snapshot.finish();
                    let exact = output == source_for_run;
                    Ok(Held {
                        common_snapshot: None,
                        snapshot: Some(snapshot),
                        transaction: None,
                        commit: None,
                        bytes: Some(output),
                        input_pointer_survived: true,
                        input_capacity: 0,
                        expected_input_pointer: 0,
                        accepted: exact,
                    })
                })
            },
        )?;

        let malformed = if profile == "small" {
            fixtures.malformed_small.clone()
        } else {
            fixtures.malformed_large.clone()
        };
        run_samples(
            &mut rows,
            "embedded_object_snapshot_open_malformed_admission",
            profile,
            malformed.len(),
            "source",
            source.len(),
            true,
            || {
                let bytes = malformed.clone();
                counted(|| {
                    let rejected =
                        EmbeddedSnapshot::open(bytes, EmbeddedLimits::default()).is_err();
                    Ok(Held {
                        common_snapshot: None,
                        snapshot: None,
                        transaction: None,
                        commit: None,
                        bytes: None,
                        input_pointer_survived: true,
                        input_capacity: 0,
                        expected_input_pointer: 0,
                        accepted: rejected,
                    })
                })
            },
        )?;

        let source_for_replace =
            EmbeddedSnapshot::open(source.clone(), replacement_limits(profile))?;
        let replacement_success = replacement.clone();
        run_samples(
            &mut rows,
            "embedded_object_replace_storage_success_commit",
            profile,
            replacement_success.len(),
            "replacement",
            source.len(),
            true,
            || {
                let mut transaction = source_for_replace.edit();
                let replacement = replacement_success.clone();
                counted(|| {
                    transaction.replace_storage(STORAGE_ID, replacement)?;
                    let commit = transaction.commit()?;
                    Ok(Held {
                        common_snapshot: None,
                        snapshot: None,
                        transaction: None,
                        commit: Some(commit),
                        bytes: None,
                        input_pointer_survived: true,
                        input_capacity: 0,
                        expected_input_pointer: 0,
                        accepted: true,
                    })
                })
            },
        )?;

        let malformed_replacement = if profile == "small" {
            fixtures.malformed_small.clone()
        } else {
            fixtures.malformed_large.clone()
        };
        run_samples(
            &mut rows,
            "embedded_object_replace_storage_malformed_replacement",
            profile,
            malformed_replacement.len(),
            "replacement",
            source.len(),
            true,
            || {
                let mut transaction = source_for_replace.edit();
                let replacement = malformed_replacement.clone();
                counted(|| {
                    let rejected = transaction.replace_storage(STORAGE_ID, replacement).is_err();
                    Ok(Held {
                        common_snapshot: None,
                        snapshot: None,
                        transaction: Some(transaction),
                        commit: None,
                        bytes: None,
                        input_pointer_survived: true,
                        input_capacity: 0,
                        expected_input_pointer: 0,
                        accepted: rejected,
                    })
                })
            },
        )?;

        let oversized = vec![0u8; replacement_limits(profile).max_object_size as usize + 1];
        run_samples(
            &mut rows,
            "embedded_object_replace_storage_oversized_replacement",
            profile,
            oversized.len(),
            "replacement",
            source.len(),
            true,
            || {
                let mut transaction = source_for_replace.edit();
                let replacement = oversized.clone();
                counted(|| {
                    let rejected = transaction.replace_storage(STORAGE_ID, replacement).is_err();
                    Ok(Held {
                        common_snapshot: None,
                        snapshot: None,
                        transaction: Some(transaction),
                        commit: None,
                        bytes: None,
                        input_pointer_survived: true,
                        input_capacity: 0,
                        expected_input_pointer: 0,
                        accepted: rejected,
                    })
                })
            },
        )?;
    }
    Ok(rows)
}

fn fixture_manifest(dir: &Path, fixtures: &Fixtures) -> Value {
    let names = [
        ("common-small.cfb", &fixtures.common_small),
        ("common-large.cfb", &fixtures.common_large),
        ("embedded-small.doc", &fixtures.embedded_small),
        ("embedded-large.doc", &fixtures.embedded_large),
        ("replacement-small.cfb", &fixtures.replacement_small),
        ("replacement-large.cfb", &fixtures.replacement_large),
        ("malformed-small.bin", &fixtures.malformed_small),
        ("malformed-large.bin", &fixtures.malformed_large),
    ];
    let mut entries = BTreeMap::new();
    for (name, bytes) in names {
        entries.insert(
            name,
            json!({"bytes": bytes.len(), "sha256": source_hash(bytes)}),
        );
    }
    json!({
        "directory": dir,
        "source_commit": SOURCE_COMMIT,
        "candidate_manifest_sha256": CANDIDATE_MANIFEST_SHA256,
        "fixtures": entries,
    })
}

fn write_json(path: &Path, value: &Value) -> AnyResult<()> {
    fs::write(path, serde_json::to_vec_pretty(value)?)?;
    Ok(())
}

fn main() -> AnyResult<()> {
    let mut args = env::args().skip(1);
    let mode = args.next().unwrap_or_else(|| "measure".to_owned());
    let root = PathBuf::from(env::var("HARNESS_ROOT").unwrap_or_else(|_| ".".to_owned()));
    let fixture_dir = root.join("fixtures");
    let report_dir = root.join("reports");
    fs::create_dir_all(&report_dir)?;

    match mode.as_str() {
        "generate" => {
            generate_fixtures(&fixture_dir)?;
            let fixtures = read_fixtures(&fixture_dir)?;
            write_json(
                &report_dir.join("fixture-manifest.json"),
                &fixture_manifest(&fixture_dir, &fixtures),
            )?;
        }
        "correctness" => {
            let fixtures = read_fixtures(&fixture_dir)?;
            write_json(&report_dir.join("correctness.json"), &correctness(&fixtures)?)?;
        }
        "measure" => {
            let fixtures = read_fixtures(&fixture_dir)?;
            let rows = measure(&fixtures)?;
            let output = args
                .next()
                .map(PathBuf::from)
                .unwrap_or_else(|| report_dir.join("allocation.jsonl"));
            let mut text = String::new();
            for row in rows {
                text.push_str(&serde_json::to_string(&row)?);
                text.push('\n');
            }
            fs::write(output, text)?;
        }
        other => return Err(format!("unknown mode {other:?}").into()),
    }
    Ok(())
}
