Supplemental oversized-source Arc identity check; frozen v2 raw reports are not overwritten.
