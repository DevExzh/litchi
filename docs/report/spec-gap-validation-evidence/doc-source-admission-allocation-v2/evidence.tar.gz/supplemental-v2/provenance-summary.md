# DOC allocation v2 provenance supplement

The frozen v2 reports were not overwritten. A copied harness rerun was executed with the command script in `run-supplemental.sh`; both sides used Cargo default debug/dev, Rust 1.95.0, no `RUSTFLAGS`, and no release profile. The exact original frozen shell transcript was not persisted, so this receipt treats the copied rerun as the reproducible command evidence.

The harness has eight fixtures: common-small/large CFBs, embedded-small/large DOCs, replacement-small/large CFBs, and malformed-small/large inputs. The common counted closures include `common_targets()` and `common_limits()` setup; this is identical on both sides and therefore remains in absolute counts and matched deltas.

The supplemental correctness reports add `oversized_shared_source` and it is true for small and large profiles on both control and candidate. The supplemental 240-row-per-side raw results match frozen rows row-for-row on all non-pointer fields and reproduce every frozen median.

No release or wall-clock measurement was run. Allocation claims remain limited to allocated bytes/calls; peak/deallocation/net-live fields are retained only as raw diagnostics.
