#!/usr/bin/env bash
set -eu

receipt=/var/tmp/litchi-embedded-doc-allocation-v2-provenance-receipt
control_root=/var/tmp/litchi-embedded-doc-allocation-v2-provenance-control
candidate_root=/var/tmp/litchi-embedded-doc-allocation-v2-provenance-candidate
control_manifest=/var/tmp/litchi-embedded-doc-allocation-v2-provenance-control/Cargo.toml
candidate_manifest=/var/tmp/litchi-embedded-doc-allocation-v2-provenance-candidate/Cargo.toml
control_target=/var/tmp/litchi-embedded-doc-allocation-v2-provenance-control-target
candidate_target=/var/tmp/litchi-embedded-doc-allocation-v2-provenance-candidate-target
rustup_home=/tmp/litchi-spec-gap-rustup

{
    printf '%s\n' 'profile=debug (Cargo default dev; no --release)' \
        'release_profile=not_run' \
        'RUSTFLAGS=unset' \
        "RUSTUP_HOME=$rustup_home" \
        "control_cargo_root=$control_manifest" \
        "candidate_cargo_root=$candidate_manifest" \
        "control_harness_root=$control_root" \
        "candidate_harness_root=$candidate_root" \
        "control_target=$control_target" \
        "candidate_target=$candidate_target"
} > "$receipt/environment.txt"

RUSTUP_HOME="$rustup_home" CARGO_TARGET_DIR="$control_target" \
    cargo +1.95.0 check --manifest-path "$control_manifest" \
    > "$receipt/control-check.log" 2>&1
RUSTUP_HOME="$rustup_home" CARGO_TARGET_DIR="$candidate_target" \
    cargo +1.95.0 check --manifest-path "$candidate_manifest" --features candidate \
    > "$receipt/candidate-check.log" 2>&1
RUSTUP_HOME="$rustup_home" CARGO_TARGET_DIR="$control_target" \
    cargo +1.95.0 clippy --manifest-path "$control_manifest" --all-targets -- -D warnings \
    > "$receipt/control-clippy.log" 2>&1
RUSTUP_HOME="$rustup_home" CARGO_TARGET_DIR="$candidate_target" \
    cargo +1.95.0 clippy --manifest-path "$candidate_manifest" --all-targets --all-features -- -D warnings \
    > "$receipt/candidate-clippy.log" 2>&1

HARNESS_ROOT="$control_root" RUSTUP_HOME="$rustup_home" CARGO_TARGET_DIR="$control_target" \
    cargo +1.95.0 run --manifest-path "$control_manifest" --quiet -- correctness \
    > "$receipt/control-correctness.log" 2>&1
HARNESS_ROOT="$candidate_root" RUSTUP_HOME="$rustup_home" CARGO_TARGET_DIR="$candidate_target" \
    cargo +1.95.0 run --manifest-path "$candidate_manifest" --features candidate --quiet -- correctness \
    > "$receipt/candidate-correctness.log" 2>&1

HARNESS_ROOT="$control_root" RUSTUP_HOME="$rustup_home" CARGO_TARGET_DIR="$control_target" \
    cargo +1.95.0 run --manifest-path "$control_manifest" --quiet -- measure \
    "$control_root/run/allocation-v2-provenance.jsonl" \
    > "$receipt/control-measure.log" 2>&1
HARNESS_ROOT="$candidate_root" RUSTUP_HOME="$rustup_home" CARGO_TARGET_DIR="$candidate_target" \
    cargo +1.95.0 run --manifest-path "$candidate_manifest" --features candidate --quiet -- measure \
    "$candidate_root/run/allocation-v2-provenance.jsonl" \
    > "$receipt/candidate-measure.log" 2>&1
