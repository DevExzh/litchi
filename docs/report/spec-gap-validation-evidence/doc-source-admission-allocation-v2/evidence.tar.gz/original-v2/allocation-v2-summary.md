# DOC embedded-object allocation v2 receipt

The matched control uses frozen c85997bc0; the candidate uses the eight-file v2 manifest (`08d333312f13ae3be21cd64a10ba15659fc2678904f444a951fd82c69c716d92`). Both use Rust 1.95.0, identical fixtures, three warmups, and fifteen allocation-only samples per group. No clock is started.

| operation | profile | control allocated/calls | candidate allocated/calls | candidate-control |
|---|---:|---:|---:|---:|
| `common_editor_open_snapshot_noop_finish` | small | 77857 / 304 | 69665 / 303 | -8192 / -1 |
| `common_editor_open_snapshot_noop_finish` | large | 10610156 / 336 | 9285612 / 335 | -1324544 / -1 |
| `common_editor_open_unique_noop_finish` | small | 66925 / 255 | 58733 / 254 | -8192 / -1 |
| `common_editor_open_unique_noop_finish` | large | 9282872 / 287 | 7958328 / 286 | -1324544 / -1 |
| `embedded_object_replace_storage_malformed_replacement` | small | 18173 / 101 | 715 / 21 | -17458 / -80 |
| `embedded_object_replace_storage_malformed_replacement` | large | 1255261 / 101 | 715 / 21 | -1254546 / -80 |
| `embedded_object_replace_storage_oversized_replacement` | small | 18210 / 102 | 752 / 22 | -17458 / -80 |
| `embedded_object_replace_storage_oversized_replacement` | large | 1255298 / 102 | 752 / 22 | -1254546 / -80 |
| `embedded_object_replace_storage_success_commit` | small | 651344 / 1529 | 598163 / 1532 | -53181 / +3 |
| `embedded_object_replace_storage_success_commit` | large | 51984582 / 1676 | 47423753 / 1679 | -4560829 / +3 |
| `embedded_object_snapshot_open` | small | 184169 / 467 | 139113 / 465 | -45056 / -2 |
| `embedded_object_snapshot_open` | large | 16973245 / 506 | 12412349 / 504 | -4560896 / -2 |
| `embedded_object_snapshot_open_malformed_admission` | small | 32784 / 2 | 0 / 0 | -32784 / -2 |
| `embedded_object_snapshot_open_malformed_admission` | large | 2097168 / 2 | 0 / 0 | -2097168 / -2 |
| `embedded_object_snapshot_open_noop_finish` | small | 206697 / 468 | 161641 / 466 | -45056 / -2 |
| `embedded_object_snapshot_open_noop_finish` | large | 19253693 / 507 | 14692797 / 505 | -4560896 / -2 |

Correctness passed for both sides: valid managed `ObjectPool/_42` field ownership, exact no-op bytes and shared source, source references and core metadata preservation, exact replacement payload after DOC commit/reopen, and exact failure-atomic malformed/oversized rejection. Each raw row records `source_bytes` separately and labels `input_kind` as `source` or `replacement`; replacement `input_bytes` is also recorded as `replacement_bytes`.

The raw JSONL, source manifest, fixture manifest, harness copy, compiler checks, and machine-readable receipt are in this directory. Deallocation/peak/net-live counters are retained but excluded from comparison because caller setup is outside the measured region. These are allocation observations only; no timing or production performance claim is made.
