# Legacy non-CryptoAPI binary RC4 candidate

Date: 2026-09-10
Worktree: `/var/tmp/litchi-legacy-rc4-validation-20260910`
Base: `52519031b4c877032553bf5d4ea4393f3e0e60d1` (detached, clean before edits)
Rust test toolchain: `1.95.0`; target: `/var/tmp/litchi-legacy-rc4-target-20260910`; `TMPDIR=/var/tmp`; `CARGO_BUILD_JOBS=8`

No primary worktree files were edited, staged, or committed. The candidate has no commit. Per-file source hashes are in `source-sha256.txt`. The complete binary patch, including the untracked new module, is `/var/tmp/litchi-legacy-rc4-validation-20260910-evidence/litchi-legacy-rc4-validation-20260910.patch` (SHA-256 `179c1b07381fb5f9e44518833937086471436e68baed24f0706091b310c01f54`).

## Scope and implementation

`crates/litchi-crypto/src/legacy_rc4.rs` is a new format-neutral implementation of [MS-OFFCRYPTO] §2.3.6. It keeps the existing `litchi_crypto::rc4` CryptoAPI §2.3.5 module separate. It validates the exact 52-byte 1.1 header, derives the fixed 40-bit key through MD5, verifies the 16-byte verifier and MD5 hash over one continuous RC4 stream, and applies absolute-position block RC4 with a bounded caller block size. Passwords above the normative 255 UTF-16-unit limit, zero/oversize block sizes, arithmetic overflow, and a block index beyond `u32` are rejected before data mutation; temporary keystream discard storage is fixed at 4096 bytes.

DOC now delegates its existing OfficeBinaryRc4 profile to this shared primitive with the normative 512-byte stream block and its 68-byte WordDocument/52-byte Table clear-prefix layout. XLS delegates its existing OfficeBinaryRc4 profile with the normative 1024-byte BIFF block and existing clear-record exceptions. Existing CryptoAPI paths remain on `litchi_crypto::rc4`.

PPT was intentionally unchanged. Local [MS-PPT] §2.3.7 says only Office Binary Document RC4 CryptoAPI §2.3.5 is supported; adding §2.3.6 there would be nonconforming. OOXML Standard RC4 was not changed.

Changed source paths:

- `crates/litchi-crypto/src/legacy_rc4.rs`
- `crates/litchi-crypto/src/lib.rs`
- `crates/litchi-crypto/Cargo.toml`
- `crates/litchi-doc/src/encryption/codec.rs`
- `crates/litchi-doc/src/encryption/tests.rs`
- `crates/litchi-doc/Cargo.toml`
- `crates/litchi-xls/src/encryption.rs`
- `crates/litchi-xls/Cargo.toml`

## Local specification anchors

- [MS-OFFCRYPTO] `3rdparty/specs/[MS-OFFCRYPTO]/2 Structures/2.3 Encryption.md:1978-2152`: §2.3.6 fixed 1.1 header, 16-byte salt/verifier/hash, MD5 key derivation, 32-bit block number, 128-bit derived RC4 key, and continuous verifier stream.
- [MS-DOC] `3rdparty/specs/[MS-DOC]/2 Structures/2.2 Fundamental Concepts.md:585-593`: §2.2.6.2 places a clear 52-byte header in Table, encrypts the remainder/Table and WordDocument after 68 bytes/Data, and uses 512-byte blocks.
- [MS-XLS] `3rdparty/specs/[MS-XLS]/2 Structures/2.2 Conceptual Overview.md:2862-2900`: BIFF8 admits §2.3.6 and uses 1024-byte blocks with clear record headers and specified clear records.
- [MS-XLS] `3rdparty/specs/[MS-XLS]/2 Structures/2.4 Records.md:13334-13364`: FILEPASS `0x0001` selects §2.3.6 when the header begins `0x0001`; `0x0002..4` selects CryptoAPI.
- [MS-PPT] `3rdparty/specs/[MS-PPT]/2 Structures/2.3 File Structure Types.md:622-626`: PPT CryptSession10Container supports only §2.3.5 CryptoAPI.
- `docs/adr/0006-validation-security-and-compatibility.md:104-107`: weak legacy encryption remains an explicit policy boundary; this candidate does not alter existing writer policy APIs or silently downgrade another profile.

## Fixture and provenance evidence

The checked-in fixtures are Apache POI corpus files, not Office/LibreOffice-native outputs. The source copies under `3rdparty/poi` and the vendored test-data copies have identical hashes.

| Format | Candidate test path | Source corpus path | Size | SHA-256 | Documented password | Source evidence |
|---|---|---|---:|---|---|---|
| DOC §2.3.6 | `test-data/poi/test-data/document/password_tika_binaryrc4.doc` | `3rdparty/poi/test-data/document/password_tika_binaryrc4.doc` | 22,016 | `9231e724bb17a2e5f74815728d90b06e15684cf5fb2443a6fa24deebd33be952` | `tika` | POI `test-data/poi-integration-exceptions.csv:129`; `crates/litchi-doc/src/package/tests.rs:28-45` |
| XLS §2.3.6 | `test-data/ole/xls/password.xls` | `3rdparty/poi/test-data/spreadsheet/password.xls` | 22,528 | `3ad12a829132d9c157d213c623af9c534b1449c42e93ab39b17ca53c909ac412` | `password` | POI `test-data/poi-integration-exceptions.csv:123`; `crates/litchi-xls/src/encryption.rs:1051-1077` |

Independent CFB inspection recorded the DOC `1Table` stream beginning `01 00 01 00` and the XLS `Workbook` FILEPASS at BIFF offset `0x14`, payload length 54, with payload beginning `01 00 01 00 01 00`. These identify §2.3.6 without trusting filenames. No decrypted payload or unrelated credentials are included here.

Known-vector evidence is the Apache POI-derived salt/password vector in `legacy_rc4` tests: password `MoneyForNothing`, salt `17 f6 d1 6b 09 b1 5f 7b 4c 9d 03 b4 81 b5 b4 4a`, derived five-byte secret `c2 d9 56 b2 6b`. The test only uses this public test vector; it does not extract a fixture password.

## Verification

Passed with Rust 1.95.0 and the dedicated target:

- `cargo +1.95.0 test -p litchi-crypto --lib legacy_rc4`: 6 passed.
- `cargo +1.95.0 test -p litchi-doc --lib -- encryption`: 6 passed.
- `cargo +1.95.0 test -p litchi-doc --lib -- package::tests`: 3 passed, 2 existing ignored; includes the POI DOC fixture with missing/wrong/correct password checks.
- `cargo +1.95.0 test -p litchi-doc --test doc_writer_encryption`: 2 passed across XOR, legacy binary RC4, and CryptoAPI profiles.
- `cargo +1.95.0 test -p litchi-xls --lib -- encryption`: 13 passed; includes the POI XLS fixture with wrong/correct password checks.
- `cargo +1.95.0 test -p litchi-xls --test xls_writer_encryption`: 2 passed across XOR, legacy binary RC4, and CryptoAPI profiles.
- `cargo +1.95.0 test -p litchi-crypto -p litchi-doc -p litchi-xls --all-targets --all-features --no-fail-fast`: all reported tests passed; existing unrelated ignored tests remained ignored.
- `git diff --check`: passed.
- Stable rustfmt check of the touched files: passed. Workspace-wide rustfmt still reports two pre-existing unrelated files (`crates/litchi-keynote/src/document.rs`, `crates/litchi-opc/src/phys_pkg.rs`).
- Package-local stable Clippy with `--no-deps --all-targets --all-features -D warnings`: `litchi-crypto` and `litchi-xls` passed; `litchi-doc` is blocked by an existing `chunks_exact` warning in `crates/litchi-doc/src/tracked_revision/package.rs:3103`. The attempted workspace package Clippy is similarly blocked by existing `litchi-ole-common/src/ole1.rs:2707`.

Raw logs and hashes are in this directory. The complete all-target/all-feature test log is `litchi-legacy-rc4-full-tests.log`.
