# Independent legacy RC4 review receipt

Date: 2026-09-10
Verdict: **CLEAR for the submitted legacy RC4 scope**.

This review was read-only against the isolated candidate
`/var/tmp/litchi-legacy-rc4-validation-20260910`. I did not modify the candidate or
the primary worktree and did not stage or commit anything. The candidate was based on
`52519031b4c877032553bf5d4ea4393f3e0e60d1`. Its submitted patch is
`/var/tmp/litchi-legacy-rc4-validation-20260910-evidence/litchi-legacy-rc4-validation-20260910.patch`,
SHA-256
`179c1b07381fb5f9e44518833937086471436e68baed24f0706091b310c01f54`.
The candidate's author report is
`/var/tmp/litchi-legacy-rc4-validation-20260910-evidence/REPORT.md`, SHA-256
`d7ecfe7455f1ee877ceac9ddfad53666235d4ca6c9de3951329d2bb824a91369`.

The candidate source overlay is exactly these eight paths:

```
fa69b72850d653879ba200a486dd772b729f658d87ea16b1b9df92a98e7c581a  crates/litchi-crypto/src/legacy_rc4.rs
e2fd8b07bfc6232f9dcdd8890a96ff4611c4047f675ced5514ea0ad040651f22  crates/litchi-crypto/src/lib.rs
f560fb38a79198fde545df96f15d26dfe0c9979b0ec38d36232f8cbd210bc09b  crates/litchi-crypto/Cargo.toml
be9b641edb825a2ad7b5eb86c941780060c1a834ceba6898aae5cdb1535917e7  crates/litchi-doc/src/encryption/codec.rs
45df2b54be739d571be4abeb68c15cacdce6d10cca70c428975f15b7dba9fd93  crates/litchi-doc/src/encryption/tests.rs
6060db8ae26a2258085cddaecc442c35d4aac75380f296eb76981ece4de55320  crates/litchi-doc/Cargo.toml
4ecab4cb8facc4ba0a7e83a39a0073f6040be058f40df92fb25e53e1413d6b41  crates/litchi-xls/src/encryption.rs
627720b2568a31e7ba081449749835b74f222f2b858d46b33345a3c32cd06a95  crates/litchi-xls/Cargo.toml
```

The candidate's test invocation also caused Cargo to rewrite
`tools/perf-baseline/Cargo.lock` while resolving dependencies. That incidental
working-tree change is outside the submitted patch and outside the source hash list.

I checked the implementation against the local Markdown specifications:

- [MS-OFFCRYPTO] `3rdparty/specs/[MS-OFFCRYPTO]/2 Structures/2.3 Encryption.md:1978-2152`
  requires the exact 1.1/52-byte header, 16-byte salt/verifier/hash fields, MD5
  derivation, 32-bit block numbers, 128-bit derived RC4 key, and one continuous
  verifier stream. The candidate's fixed 40-bit secret, repeated 21-byte
  intermediate buffer, block-key derivation, continuous verifier/hash decryption,
  exact header parser, and checked block range match these requirements.
- [MS-DOC] `3rdparty/specs/[MS-DOC]/2 Structures/2.2 Fundamental Concepts.md:585-593`
  requires 512-byte blocks, a clear 68-byte WordDocument prefix, a clear 52-byte
  Table header, and stream-relative processing. DOC uses the shared primitive at
  those exact offsets.
- [MS-XLS] `3rdparty/specs/[MS-XLS]/2 Structures/2.2 Conceptual Overview.md:2862-2900`
  requires 1024-byte BIFF blocks, clear record headers/required records, zero-buffer
  advancement for clear bytes, and clear BoundSheet8 `lbPlyPos`. XLS applies the
  shared primitive at absolute record offsets and retains its existing clear-record
  rules.
- [MS-XLS] `3rdparty/specs/[MS-XLS]/2 Structures/2.4 Records.md:13334-13364`
  maps FILEPASS `0x0001` plus a 1.1 header to §2.3.6 and keeps 0x0002..4 on
  CryptoAPI. The candidate preserves this split.
- [MS-PPT] `3rdparty/specs/[MS-PPT]/2 Structures/2.3 File Structure Types.md:622-626`
  limits PPT CryptSession10Container to CryptoAPI §2.3.5; PPT remains unchanged.

The public Apache POI fixtures are genuine producer outputs and were independently
identified from their wire bytes rather than filenames:

- DOC `test-data/poi/test-data/document/password_tika_binaryrc4.doc`, 22,016 bytes,
  SHA-256 `9231e724bb17a2e5f74815728d90b06e15684cf5fb2443a6fa24deebd33be952`,
  source `3rdparty/poi/test-data/document/password_tika_binaryrc4.doc`, POI
  `poi-integration-exceptions.csv:129`, password `tika`. Its `1Table` stream
  begins with the 1.1 marker.
- XLS `test-data/ole/xls/password.xls`, 22,528 bytes,
  SHA-256 `3ad12a829132d9c157d213c623af9c534b1449c42e93ab39b17ca53c909ac412`,
  source `3rdparty/poi/test-data/spreadsheet/password.xls`, POI
  `poi-integration-exceptions.csv:123`, password `password`. Its FILEPASS is
  type 1, has the 54-byte payload, and begins `01 00 01 00 01 00`.
The candidate fixture copies and the vendored POI source copies are byte-identical.
These are Apache POI outputs, not Microsoft Office or LibreOffice-native vectors; no
native-Office claim is made.

Independent checks beyond the candidate's own tests:

- The dedicated perf-baseline ignored security corpus command
  `TMPDIR=/var/tmp CARGO_BUILD_JOBS=8 CARGO_TARGET_DIR=/var/tmp/litchi-legacy-rc4-review-target cargo +1.95.0 test --locked --manifest-path tools/perf-baseline/Cargo.toml --lib security_corpus -- --ignored`
  passed `security_corpus::real_producer_security_corpus_is_bounded_and_deterministic`
  (1 passed, 367 filtered). It exercised missing, wrong, and correct passwords and
  repeated semantic output for the POI DOC fixture; the captured output is in
  `security-corpus.log`; the pinned text digest was
  `5c5c945257fcd1569b5161722e15a9d73283daf786aca1daf04d0029d3736b78`.
- A separate temporary harness at
  `/var/tmp/litchi-legacy-rc4-independent-harness`, using only path dependencies
  on the candidate plus `sha2`, independently passed POI DOC missing/wrong/correct
  password checks, the same semantic digest, POI XLS missing/wrong/correct checks
  including the “ZIP bomb” cell, DOC writer/read round trip, XLS writer/read round
  trip, and direct DOC CFB header inspection. The captured output is in
  `independent-harness.log`.
- Candidate focused tests passed: crypto legacy RC4 6; DOC encryption 6; DOC package
  3 with 2 existing ignores; DOC writer 2; XLS encryption 13; XLS writer 2. The
  all-target/all-feature test invocation for the three affected packages passed,
  and `git diff --check` passed.
- Strict package-local Clippy passed for `litchi-crypto` and `litchi-xls`. The
  affected `litchi-doc` package and workspace Clippy remain blocked by unrelated
  pre-existing warnings at `crates/litchi-doc/src/tracked_revision/package.rs:3103`
  and `crates/litchi-ole-common/src/ole1.rs:2707`; this is a validation-environment
  limitation, not a candidate failure. Stable rustfmt for touched files passed.

No legacy RC4 correctness, wire-layout, password-verifier, block-boundary, overflow,
or failure-atomicity blocker was found. The candidate keeps CryptoAPI RC4 separate,
does not add legacy RC4 to PPT, and does not silently change the existing writer
profile selection. The remaining qualification is corpus scope: interoperability was
verified with public Apache POI producers and no native Office/LibreOffice fixture
was available for this profile.
