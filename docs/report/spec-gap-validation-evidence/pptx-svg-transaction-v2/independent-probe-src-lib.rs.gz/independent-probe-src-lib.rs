use std::io;
use std::sync::Arc;
use std::sync::atomic::{AtomicU64, Ordering};

use litchi_core::{ReadAt, SourceVersion};
use litchi_opc::constants::{content_type as ct, relationship_type as rt};
use litchi_opc::{BlobPart, OpcError, OpcPackage, PackURI, PackageWriter, ReadLimits, TargetMode};
use litchi_pptx::{Error, SourceBackedPresentation, SourceBackedPresentationEditor, SourceSvgReplacement};
use soapberry_zip::office::{ArchiveReader, StreamingArchiveWriter};

const PML: &str = "http://schemas.openxmlformats.org/presentationml/2006/main";
const DRAWINGML: &str = "http://schemas.openxmlformats.org/drawingml/2006/main";
const REL: &str = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
const SVG_NS: &str = "http://schemas.microsoft.com/office/drawing/2016/SVG/main";
const SVG_URI: &str = "{96DAC541-7B7A-43D3-8B79-37D633B846F1}";
const SLIDE1: &str = "/ppt/slides/slide1.xml";
const SLIDE2: &str = "/ppt/slides/slide2.xml";
const RASTER: &str = "/ppt/media/source.png";
const SVG: &str = "/ppt/media/source.svg";
const ALT_RASTER: &str = "/ppt/media/alternate.png";
const ALT_SVG: &str = "/ppt/media/alternate.svg";
const WRONG: &str = "/ppt/media/wrong.png";
const OPAQUE: &str = "/ppt/media/keep.bin";

struct Source { bytes: Vec<u8>, revision: AtomicU64 }

impl Source {
    fn new(bytes: Vec<u8>) -> Self { Self { bytes, revision: AtomicU64::new(0) } }
    fn changed(&self) { self.revision.fetch_add(1, Ordering::SeqCst); }
}

impl ReadAt for Source {
    fn len(&self) -> io::Result<u64> { Ok(self.bytes.len() as u64) }
    fn read_at(&self, offset: u64, output: &mut [u8]) -> io::Result<usize> {
        let offset = usize::try_from(offset).map_err(|_| io::Error::new(io::ErrorKind::InvalidInput, "offset overflow"))?;
        if offset >= self.bytes.len() { return Ok(0); }
        let count = output.len().min(self.bytes.len() - offset);
        output[..count].copy_from_slice(&self.bytes[offset..offset + count]);
        Ok(count)
    }
    fn version(&self) -> io::Result<SourceVersion> { Ok(SourceVersion::new(4_209, self.revision.load(Ordering::SeqCst))) }
}

fn slide_xml() -> Vec<u8> {
    format!(
        r#"<p:sld xmlns:p="{PML}" xmlns:a="{DRAWINGML}" xmlns:r="{REL}" xmlns:asvg="{SVG_NS}" xmlns:future="urn:independent:future"><p:cSld><p:spTree><p:nvGrpSpPr/><p:grpSpPr/><p:pic><p:nvPicPr><p:cNvPr id="17" name="independent SVG"/><p:cNvPicPr/><p:nvPr/></p:nvPicPr><p:blipFill><a:blip r:embed="rRaster"><a:extLst><a:ext uri="{SVG_URI}"><asvg:svgBlip r:embed="rSvg"/></a:ext><a:ext uri="{{independent-opaque}}"><future:opaque future:value="retain"/></a:ext></a:extLst></a:blip><a:stretch><a:fillRect/></a:stretch></p:blipFill><p:spPr><a:xfrm><a:off x="7" y="9"/><a:ext cx="11" cy="13"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></p:spPr></p:pic></p:spTree></p:cSld><p:clrMapOvr/></p:sld>"#
    ).into_bytes()
}

fn add_rel(package: &mut OpcPackage, part: &str, kind: &str, target: &str, id: &str) {
    package.get_part_mut(&PackURI::new(part).unwrap()).unwrap().rels_mut().try_add_relationship(kind.to_owned(), target.to_owned(), id.to_owned(), TargetMode::Internal).unwrap();
}

fn base_package(two_slides: bool, signed: bool) -> Vec<u8> {
    let presentation = if two_slides {
        format!(r#"<p:presentation xmlns:p="{PML}" xmlns:r="{REL}"><p:sldIdLst><p:sldId id="301" r:id="rSlide1"/><p:sldId id="302" r:id="rSlide2"/></p:sldIdLst></p:presentation>"#)
    } else {
        format!(r#"<p:presentation xmlns:p="{PML}" xmlns:r="{REL}"><p:sldIdLst><p:sldId id="301" r:id="rSlide1"/></p:sldIdLst></p:presentation>"#)
    };
    let mut package = OpcPackage::new();
    let add = |package: &mut OpcPackage, uri: &str, content_type: &str, blob: Vec<u8>| {
        package.try_add_part(Box::new(BlobPart::new(PackURI::new(uri).unwrap(), content_type.to_owned(), blob))).unwrap();
    };
    add(&mut package, "/ppt/presentation.xml", ct::PML_PRESENTATION_MAIN, presentation.into_bytes());
    add(&mut package, SLIDE1, ct::PML_SLIDE, slide_xml());
    if two_slides { add(&mut package, SLIDE2, ct::PML_SLIDE, slide_xml()); }
    add(&mut package, RASTER, "image/png", b"source-raster-v2".to_vec());
    add(&mut package, SVG, "image/svg+xml", br#"<svg xmlns="http://www.w3.org/2000/svg"><path d="M1 2"/></svg>"#.to_vec());
    add(&mut package, ALT_RASTER, "image/png", b"old-alternate-raster".to_vec());
    add(&mut package, ALT_SVG, "image/svg+xml", br#"<svg xmlns="http://www.w3.org/2000/svg"><path d="M3 4"/></svg>"#.to_vec());
    add(&mut package, WRONG, "image/jpeg", b"wrong-content-type".to_vec());
    add(&mut package, OPAQUE, "application/octet-stream", b"opaque-preserved".to_vec());
    add_rel(&mut package, "/ppt/presentation.xml", rt::SLIDE, "slides/slide1.xml", "rSlide1");
    if two_slides { add_rel(&mut package, "/ppt/presentation.xml", rt::SLIDE, "slides/slide2.xml", "rSlide2"); }
    for slide in [SLIDE1, SLIDE2].into_iter().take(if two_slides { 2 } else { 1 }) {
        add_rel(&mut package, slide, rt::IMAGE, "../media/source.png", "rRaster");
        add_rel(&mut package, slide, rt::IMAGE, "../media/source.svg", "rSvg");
        add_rel(&mut package, slide, "urn:independent:opaque", "../media/keep.bin", "rOpaque");
    }
    package.relate_to("ppt/presentation.xml", rt::OFFICE_DOCUMENT);
    if signed {
        add(&mut package, "/_xmlsignatures/origin.sigs", ct::OPC_DIGITAL_SIGNATURE_ORIGIN, b"<origin independent=\"yes\"/>".to_vec());
        package.relate_to("_xmlsignatures/origin.sigs", rt::DIGITAL_SIGNATURE_ORIGIN);
    }
    PackageWriter::to_bytes(&package).unwrap()
}

fn package_with_orphan_member() -> Vec<u8> {
    let source = base_package(false, false);
    let archive = ArchiveReader::new(&source).unwrap();
    let mut writer = StreamingArchiveWriter::new();
    for name in archive.file_names() { let data = archive.read(name).unwrap(); writer.write_stored(name, &data).unwrap(); }
    let rels = br#"<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rOpaqueOrphan" Type="urn:independent:orphan" Target="../media/source.png"/></Relationships>"#;
    writer.write_stored("ppt/slides/_rels/not-a-part.xml.rels", rels).unwrap();
    writer.finish_to_bytes().unwrap()
}

fn package_with_unselected_dangling_picture() -> Vec<u8> {
    let mut package = OpcPackage::from_bytes(&base_package(false, false)).unwrap();
    let uri = PackURI::new(SLIDE1).unwrap();
    let slide = package.get_part_mut(&uri).unwrap();
    let xml = String::from_utf8(slide.blob().to_vec()).unwrap();
    let start = xml.find("<p:pic>").unwrap();
    let end = xml.find("</p:pic>").unwrap() + "</p:pic>".len();
    let duplicate = xml[start..end].replace("rRaster", "rMissingRaster").replace("rSvg", "rMissingSvg");
    slide.set_blob(xml.replace("</p:spTree>", &format!("{duplicate}</p:spTree>")).into_bytes());
    PackageWriter::to_bytes(&package).unwrap()
}

fn make_editor(bytes: &[u8]) -> SourceBackedPresentationEditor { SourceBackedPresentationEditor::from_read_at(Arc::new(Source::new(bytes.to_vec()))).unwrap() }

fn changed_editor_and_commit(bytes: &[u8], svg_uri: &str, raster_uri: &str) -> (SourceBackedPresentationEditor, litchi_pptx::SourceBackedSvgCommit) {
    let editor = make_editor(bytes);
    let mut edit = editor.edit_svg_image(0, 0).unwrap();
    edit.replace(SourceSvgReplacement::new(br#"<svg xmlns="http://www.w3.org/2000/svg"><circle cx="8" cy="9" r="2"/></svg>"#.to_vec(), b"replacement-raster-v2".to_vec()).with_part_uris(PackURI::new(svg_uri).unwrap(), PackURI::new(raster_uri).unwrap())).unwrap();
    let commit = edit.commit_checked().unwrap();
    (editor, commit)
}

#[test]
fn public_retarget_existing_parts_preserves_slide_and_reopens() {
    let source = base_package(false, false);
    let source_pkg = OpcPackage::from_bytes(&source).unwrap();
    let original_slide = source_pkg.get_part(&PackURI::new(SLIDE1).unwrap()).unwrap().blob().to_vec();
    let slide = SourceBackedPresentation::from_read_at(Arc::new(Source::new(source.clone()))).unwrap().slide(0).unwrap();
    let image = slide.images().unwrap();
    assert_eq!(image.len(), 1);
    assert_eq!(image[0].relationship_id(), "rRaster");
    assert_eq!(image[0].svg().unwrap().relationship_id(), "rSvg");
    assert_eq!(image[0].target().part_uri().unwrap().as_str(), RASTER);
    let (editor, commit) = changed_editor_and_commit(&source, ALT_SVG, ALT_RASTER);
    let mut output = Vec::new();
    editor.publish_svg_commit_to_stream(&mut output, &commit).unwrap();
    let pkg = OpcPackage::from_bytes(&output).unwrap();
    let slide = pkg.get_part(&PackURI::new(SLIDE1).unwrap()).unwrap();
    assert_eq!(slide.blob(), original_slide.as_slice());
    assert_eq!(slide.rels().get("rSvg").unwrap().target_ref(), "../media/alternate.svg");
    assert_eq!(slide.rels().get("rRaster").unwrap().target_ref(), "../media/alternate.png");
    assert_eq!(slide.rels().get("rOpaque").unwrap().target_ref(), "../media/keep.bin");
    assert_eq!(pkg.get_part(&PackURI::new(ALT_SVG).unwrap()).unwrap().blob(), br#"<svg xmlns="http://www.w3.org/2000/svg"><circle cx="8" cy="9" r="2"/></svg>"#);
    assert_eq!(pkg.get_part(&PackURI::new(ALT_RASTER).unwrap()).unwrap().blob(), b"replacement-raster-v2");
    assert!(pkg.get_part(&PackURI::new(SVG).unwrap()).is_err());
    assert!(pkg.get_part(&PackURI::new(RASTER).unwrap()).is_err());
    assert_eq!(pkg.get_part(&PackURI::new(OPAQUE).unwrap()).unwrap().blob(), b"opaque-preserved");
    let reopened = SourceBackedPresentation::from_read_at(Arc::new(Source::new(output))).unwrap();
    assert_eq!(reopened.slide(0).unwrap().read_svg_image(0).unwrap().bytes(), br#"<svg xmlns="http://www.w3.org/2000/svg"><circle cx="8" cy="9" r="2"/></svg>"#);
}

#[test]
fn public_noop_is_exact_and_inverse_is_source_bound() {
    let source = base_package(false, false);
    let owner = make_editor(&source);
    let original = owner.edit_svg_image(0, 0).unwrap();
    let svg = original.source().svg_bytes().to_vec();
    let raster = original.source().raster_bytes().to_vec();
    let mut noop_edit = original;
    assert!(!noop_edit.replace(SourceSvgReplacement::new(svg, raster)).unwrap());
    let noop = noop_edit.commit_checked().unwrap();
    assert!(!noop.is_changed());
    let mut output = Vec::new();
    owner.publish_svg_commit_to_stream(&mut output, &noop).unwrap();
    assert_eq!(output, source);
    let (_editor_for_inverse, commit) = changed_editor_and_commit(&source, ALT_SVG, ALT_RASTER);
    let restored = commit.patch().inverse().apply(commit.snapshot()).unwrap();
    assert_eq!(restored.svg_part_uri().as_str(), SVG);
    assert_eq!(restored.raster_part_uri().as_str(), RASTER);
    assert_eq!(restored.svg_bytes(), br#"<svg xmlns="http://www.w3.org/2000/svg"><path d="M1 2"/></svg>"#);
    assert_eq!(restored.raster_bytes(), b"source-raster-v2");
}

#[test]
fn public_stale_and_signed_changed_refuse_before_output_begins() {
    let source = base_package(false, false);
    let versioned = Arc::new(Source::new(source.clone()));
    let editor = SourceBackedPresentationEditor::from_read_at(versioned.clone()).unwrap();
    let mut edit = editor.edit_svg_image(0, 0).unwrap();
    edit.replace(SourceSvgReplacement::new(b"<svg xmlns=\"http://www.w3.org/2000/svg\"><circle/></svg>".to_vec(), b"stale-raster".to_vec())).unwrap();
    let commit = edit.commit_checked().unwrap();
    versioned.changed();
    let mut stale_output = Vec::new();
    let error = match editor.publish_svg_commit_to_stream(&mut stale_output, &commit) { Err(error) => error, Ok(_) => panic!("stale source unexpectedly published") };
    assert!(matches!(error, Error::Opc(OpcError::SourceChanged { .. })));
    assert!(stale_output.is_empty());
    let signed_source = base_package(false, true);
    let signed_editor = make_editor(&signed_source);
    let mut signed_edit = signed_editor.edit_svg_image(0, 0).unwrap();
    signed_edit.replace(SourceSvgReplacement::new(b"<svg xmlns=\"http://www.w3.org/2000/svg\"><circle/></svg>".to_vec(), b"signed-raster".to_vec())).unwrap();
    let signed_commit = signed_edit.commit_checked().unwrap();
    let mut signed_output = Vec::new();
    let error = match signed_editor.publish_svg_commit_to_stream(&mut signed_output, &signed_commit) { Err(error) => error, Ok(_) => panic!("signed source unexpectedly published") };
    assert!(matches!(error, Error::Opc(OpcError::SignedSourceRequiresExplicitPolicy)));
    assert!(signed_output.is_empty());
    let signed_editor = make_editor(&signed_source);
    let signed_edit = signed_editor.edit_svg_image(0, 0).unwrap();
    let signed_noop = signed_edit.commit_checked().unwrap();
    let mut exact = Vec::new();
    signed_editor.publish_svg_commit_to_stream(&mut exact, &signed_noop).unwrap();
    assert_eq!(exact, signed_source);
}

#[test]
fn public_resource_preflight_rejects_wrong_target_and_limits_before_output() {
    let source = base_package(false, false);
    let (editor, commit) = changed_editor_and_commit(&source, WRONG, ALT_RASTER);
    let mut output = Vec::new();
    let error = match editor.publish_svg_commit_to_stream(&mut output, &commit) { Err(error) => error, Ok(_) => panic!("wrong target unexpectedly published") };
    assert!(matches!(error, Error::ContentType { expected, .. } if expected == "image/svg+xml"));
    assert!(output.is_empty());
    let limits = ReadLimits::builder().max_part_bytes(1_024).unwrap().build().unwrap();
    let limited = SourceBackedPresentationEditor::from_read_at_with_limits(Arc::new(Source::new(source.clone())), limits).unwrap();
    let mut edit = limited.edit_svg_image(0, 0).unwrap();
    let mut oversized = vec![b'Z'; 1_025];
    oversized[..4].copy_from_slice(b"<svg");
    let error = edit.replace(SourceSvgReplacement::new(oversized, b"small-raster".to_vec())).unwrap_err();
    assert!(matches!(error, Error::Limit { .. }));
    let noop = edit.commit_checked().unwrap();
    assert!(!noop.is_changed());
    let mut exact = Vec::new();
    limited.publish_svg_commit_to_stream(&mut exact, &noop).unwrap();
    assert_eq!(exact, source);
}

#[test]
fn public_opaque_orphan_relationship_refuses_media_removal_atomically() {
    let source = package_with_orphan_member();
    let (editor, commit) = changed_editor_and_commit(&source, ALT_SVG, ALT_RASTER);
    let mut output = Vec::new();
    let error = match editor.publish_svg_commit_to_stream(&mut output, &commit) { Err(error) => error, Ok(_) => panic!("orphan source unexpectedly published") };
    assert!(matches!(error, Error::Relationship(_)));
    assert!(output.is_empty());
}

#[test]
fn public_unselected_picture_relationship_is_resolved_before_selection() {
    let source = package_with_unselected_dangling_picture();
    let editor = make_editor(&source);
    let error = match editor.edit_svg_image(0, 0) { Err(error) => error, Ok(_) => panic!("unselected dangling picture unexpectedly accepted") };
    assert!(matches!(error, Error::Relationship(_)));
}

#[test]
fn public_recognized_shared_owner_keeps_old_media_and_publishes() {
    let source = base_package(true, false);
    let (editor, commit) = changed_editor_and_commit(&source, ALT_SVG, ALT_RASTER);
    let mut output = Vec::new();
    editor.publish_svg_commit_to_stream(&mut output, &commit).unwrap();
    let pkg = OpcPackage::from_bytes(&output).unwrap();
    assert!(pkg.get_part(&PackURI::new(SVG).unwrap()).is_ok());
    assert!(pkg.get_part(&PackURI::new(RASTER).unwrap()).is_ok());
    let second = pkg.get_part(&PackURI::new(SLIDE2).unwrap()).unwrap();
    assert_eq!(second.rels().get("rSvg").unwrap().target_ref(), "../media/source.svg");
    assert_eq!(second.rels().get("rRaster").unwrap().target_ref(), "../media/source.png");
    assert_eq!(pkg.get_part(&PackURI::new(ALT_SVG).unwrap()).unwrap().blob(), br#"<svg xmlns="http://www.w3.org/2000/svg"><circle cx="8" cy="9" r="2"/></svg>"#);
}
