# PPTX SVG transaction V2 evidence

This bundle is a portable record for the detached candidate `litchi-pptx-svg-transaction-v2-validation-20260910` at base commit `141970fd6df99e9553641fc52eb4e9b2b1687279`. `source-delta.patch` contains the four owned source/test paths; no candidate or primary commit was created.

V2 closes the two reviewed malformed-topology cases. Capture resolves every direct picture owner before selecting one. During a changed media publication, any retained physical relationship member that is not the root relationship member or the derived relationship member for an ordinary retained Part causes a typed refusal before the sink receives bytes. This is conservative because the owned OPC API exposes physical names but does not expose parsed payloads for opaque non-Part relationship members.

The local Section 13 correction task defines the PPTX operation as source-checked SVG relationship/payload replacement with PNG fallback and dependency closure. The candidate does not claim general picture-shape create/delete/reorder CRUD.

See `manifest.json` for exact hashes and commands. Logs are under `logs/`.
